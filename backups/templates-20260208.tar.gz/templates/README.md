# RevealUI Templates

This folder contains template applications and examples that were extracted from the main RevealUI monorepo to reduce repository size and complexity.

## Contents

### Apps (from `apps/`)
- `BiotixWellness/` - Wellness/health template
- `demo/` - Full demo application
- `Learn/` - Learning platform template  
- `StreetbeefsScrapyard/` - Community/marketplace template
- `WreckedUI/` - UI showcase template

### Examples (moved to `examples/`)
- `ai/` - AI integration example → moved to `examples/ai/`
- `automotive/` - Automotive industry template → moved to `examples/automotive/`
- `basic-blog/` - Simple blog template → moved to `examples/basic-blog/`
- `e-commerce/` - E-commerce template → moved to `examples/e-commerce/`
- `healthcare/` - Healthcare template → moved to `examples/healthcare/`
- `learning/` - Learning management template → moved to `examples/learning/`
- `portfolio/` - Portfolio template → moved to `examples/portfolio/`
- `saas-template/` - SaaS starter template → moved to `examples/saas-template/`

## Note

These templates may contain references to deprecated packages:
- `@revealui/email-go` → Use `@revealui/email/go`
- `@revealui/email-resend` → Use `@revealui/email/resend`
- `@revealui/content-plugins` → Use `@revealui/content/plugins/*`
- `@revealui/asset-pipeline` → Use `@revealui/core/assets/pipeline`
- `@revealui/scripts` → Use `@revealui/dev/quality` or `@revealui/dev/security`
- `@revealui/convergence` → Use `@revealui/experimental/convergence`

These imports need to be updated if you want to use these templates with the current RevealUI version.
