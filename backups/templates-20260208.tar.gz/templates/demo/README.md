# RevealUI Examples

A comprehensive collection of RevealUI examples showcasing different architectures, features, and use cases.

> Source of truth for all exported starters. Regenerate `/examples/*` and the product app starters from this app via `pnpm --filter @revealui/demo export:examples` to keep everything in sync.

## Overview

This consolidated examples app replaces 15+ individual demo applications with a single, configurable example that demonstrates:

- **Clean Architecture** (SaaS Starter)
- **E-commerce** platforms
- **Content Management** systems
- **AI-powered** applications
- **Healthcare** solutions
- **Automotive** industry
- **Portfolio** websites
- **Learning** platforms

## Quick Start

```bash
# Install dependencies
pnpm install

# Run in SaaS mode (default)
pnpm dev

# Run in specific example mode
EXAMPLE_MODE=ecommerce pnpm dev
EXAMPLE_MODE=healthcare pnpm dev
EXAMPLE_MODE=ai-assistant pnpm dev
```

## Starter exports

Generate per-mode starter folders under `/examples`:

```bash
pnpm --filter @revealui/demo export:examples
```

Each generated starter has `.env.example` pinned to its `EXAMPLE_MODE`.

## Example Modes

### SaaS Starter (default)
Full-featured SaaS application with Clean Architecture
```bash
pnpm dev
```
**Features**: Auth, Payments, Analytics, AI, Multi-tenant, Content

### E-commerce
Online store with products, orders, and payments
```bash
EXAMPLE_MODE=ecommerce pnpm dev
```
**Features**: Auth, Payments, Analytics, Products, Orders

### Content Management
Headless CMS with content creation and management
```bash
EXAMPLE_MODE=cms pnpm dev
```
**Features**: Auth, Content, Media, SEO

### AI Assistant
AI-powered application with chat and automation
```bash
EXAMPLE_MODE=ai-assistant pnpm dev
```
**Features**: Auth, AI, Chat, Analytics

### Healthcare
Medical application with patient management
```bash
EXAMPLE_MODE=healthcare pnpm dev
```
**Features**: Auth, Analytics, AI, Multi-tenant

### Automotive
Vehicle sales and parts management system
```bash
EXAMPLE_MODE=automotive pnpm dev
```
**Features**: Auth, Payments, Analytics, E-commerce

### Portfolio
Personal portfolio and content showcase
```bash
EXAMPLE_MODE=portfolio pnpm dev
```
**Features**: Content, SEO, Responsive

### Learning Platform
Online learning platform with courses and progress tracking
```bash
EXAMPLE_MODE=learning pnpm dev
```
**Features**: Auth, Analytics, AI, Courses

## Architecture

The examples app uses **Clean Architecture** principles:

```
src/
├── app/                    # Next.js app router
├── config/                 # Configuration (examples.ts)
├── contracts/              # Application contracts
├── domain/                 # Domain logic
├── infrastructure/         # Infrastructure services
├── presentation/           # UI components and providers
└── types/                  # TypeScript definitions
```

## Features Demonstrated

### Core RevealUI Features
- **Content Engine**: Collections, fields, relationships
- **Authentication**: User management, roles, permissions
- **Media Management**: File uploads, image optimization
- **API Routes**: REST endpoints (GraphQL disabled by design)
- **Admin Interface**: Content management UI

### Advanced Features
- **Multi-tenancy**: Organization-based data isolation
- **AI Integration**: Chat, automation, content generation
- **Payment Processing**: Stripe integration
- **Analytics**: Usage tracking and reporting
- **Real-time Updates**: WebSocket connections

## Development

### Adding New Examples

1. Add configuration to `src/config/examples.ts`
2. Create feature flags in the config
3. Implement conditional rendering in components
4. Add demo data for the new example

### Environment Variables

Copy `.env.example` to `.env.local` and configure:

```bash
# Database
DATABASE_URL=...

# Authentication
NEXTAUTH_SECRET=...
NEXTAUTH_URL=...

# Payments (Stripe)
STRIPE_SECRET_KEY=...
STRIPE_PUBLISHABLE_KEY=...

# AI (OpenAI)
OPENAI_API_KEY=...

# Analytics
ANALYTICS_KEY=...
```

### Scripts

```bash
# Development
pnpm dev

# Build
pnpm build

# Type checking
pnpm typecheck

# Testing
pnpm test

# Linting
pnpm lint
```

## Migration from Individual Apps

This examples app replaces the legacy demo folders (e.g., `apps/SaasStarter`, `apps/BiotixWellness`, `apps/StreetbeefsScrapyard`, `apps/WreckedUI`, `apps/demo`, `apps/portfolio`, `apps/learn`, and others). Those projects no longer exist as standalone `apps/*` directories; their functionality is preserved here as feature-flagged modes (see `EXAMPLE_MODE`). Use the export command (`pnpm --filter @revealui/demo export:examples`) to generate per-mode starters under `/examples`.

## Contributing

When adding new examples:

1. Follow the existing Clean Architecture structure
2. Add comprehensive TypeScript types
3. Include demo data and fixtures
4. Update this README
5. Test across all example modes
