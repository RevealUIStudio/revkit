import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import type { ExampleConfig } from '../src/config/examples';
import { getExampleManifest } from '../src/config/examples';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const repoRoot = path.resolve(__dirname, '..', '..', '..');
const appRoot = path.resolve(__dirname, '..');
const exportRoot = path.resolve(repoRoot, 'examples');

const ignoredEntries = new Set([
	'node_modules',
	'.next',
	'.turbo',
	'.eslintcache',
	'.tsbuildinfo',
	'.vercel',
	'.cache',
	'.tmp'
]);

function shouldCopy(entryPath: string): boolean {
	const base = path.basename(entryPath);
	return !ignoredEntries.has(base);
}

async function ensureDir(dirPath: string) {
	await fs.mkdir(dirPath, { recursive: true });
}

function formatFeatures(features: ExampleConfig['features']): string {
	return Object.entries(features)
		.filter(([, enabled]) => enabled)
		.map(([name]) => name)
		.join(', ');
}

async function writeStarterNotes(destination: string, manifest: ExampleConfig) {
	const note = [
		`# ${manifest.title} Starter`,
		'',
		`Generated from the shared examples shell in \`apps/demo\`.`,
		`Mode: \`${manifest.mode}\``,
		`Route: \`${manifest.route}\``,
		`Features: ${formatFeatures(manifest.features)}`,
		'',
		'## How to use',
		'',
		'```bash',
		'pnpm install',
		'pnpm dev',
		'```',
		'',
		'- The generated `.env.example` includes `EXAMPLE_MODE` fixed to this starter.',
		'- To regenerate, run `pnpm --filter @revealui/demo export:examples` from the repo root.',
		''
	].join('\n');

	await fs.writeFile(path.join(destination, 'STARTER.md'), note, 'utf8');
}

function mergeEnvWithMode(baseEnv: string, mode: string): string {
	const lines = baseEnv
		.split(/\r?\n/)
		.filter(Boolean)
		.filter((line) => !line.startsWith('EXAMPLE_MODE='));

	return [`EXAMPLE_MODE=${mode}`, ...lines].join('\n') + '\n';
}

async function copyStarter(manifest: ExampleConfig) {
	const destination = path.join(exportRoot, manifest.exportDir);

	await fs.rm(destination, { recursive: true, force: true });
	await ensureDir(destination);

	await fs.cp(appRoot, destination, {
		recursive: true,
		force: true,
		filter: shouldCopy
	});

	const baseEnv = await fs.readFile(path.join(appRoot, 'env.example'), 'utf8').catch(() => '');
	const mergedEnv = mergeEnvWithMode(baseEnv, manifest.mode);
	await fs.writeFile(path.join(destination, '.env.example'), mergedEnv, 'utf8');

	await writeStarterNotes(destination, manifest);
}

async function main() {
	const manifest = getExampleManifest();

	await ensureDir(exportRoot);

	for (const entry of manifest) {
		// eslint-disable-next-line no-console
		console.log(`Exporting ${entry.mode} to ${entry.exportDir}...`);
		await copyStarter(entry);
	}

	// eslint-disable-next-line no-console
	console.log('✅ Examples exported to /examples');
}

main().catch((error) => {
	// eslint-disable-next-line no-console
	console.error('Failed to export examples', error);
	process.exitCode = 1;
});

