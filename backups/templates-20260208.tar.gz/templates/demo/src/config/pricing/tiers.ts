/**
 * Pricing Tiers Configuration
 *
 * Re-exports from domain pricing configuration for backward compatibility
 * and to match import paths used throughout the codebase.
 */

export {
  getAllPricingTiers,
  getPricingTier,
  getTierByStripePriceId,
  isUnlimited,
  PRICING_TIERS,
  TIER_HIERARCHY,
  type BillingInterval,
  type CreditAllocation,
  type PricingTier,
  type PricingTierConfig,
  type ResourceLimits,
  type SupportConfig,
  type TierFeatures,
} from '../domain/pricing/tiers';
