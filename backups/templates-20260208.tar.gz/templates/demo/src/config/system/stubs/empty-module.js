// Empty module stub for broken @revealui/core RenderErrorPage import
export default function RenderErrorPage() {
  return null;
}

