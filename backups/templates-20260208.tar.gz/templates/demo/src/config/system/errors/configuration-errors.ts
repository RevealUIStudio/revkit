import { BaseError } from '@revealui/infrastructure';

/**
 * Configuration error extending Core's BaseError
 * Used for configuration-related errors in the system layer
 */
export class ConfigurationError extends BaseError {
  constructor(message: string, code: string = 'CONFIGURATION_ERROR') {
    super(message, code);
    this.name = 'ConfigurationError';
  }
}

export type ConfigurationErrorBuilder = ReturnType<typeof createConfigurationError>;

export function createConfigurationError() {
  const builder = {
    path: (_path: string) => builder,
    field: (_field: string) => builder,
    causedBy: (_cause: unknown) => builder,
    invalidValue: (message: string) => new ConfigurationError(message),
    missingRequired: (message: string) => new ConfigurationError(message),
    validationFailed: (message: string) => new ConfigurationError(message),
    environmentError: (message: string) => new ConfigurationError(message),
    dependencyError: (message: string) => new ConfigurationError(message),
    initializationError: (message: string) => new ConfigurationError(message),
  };

  return builder;
}

export function safeGetConfigValue<T>(getter: () => T, defaultValue: T): T {
  try {
    return getter();
  } catch {
    return defaultValue;
  }
}

export function validateConfiguration<T>(config: T, validator: (config: T) => void): T {
  validator(config);
  return config;
}
