/**
 * System Environment Utilities
 *
 * Cross-cutting environment variable access utilities that can be used by all layers.
 * This module provides type-safe environment variable access without violating Clean Architecture
 * layer dependencies.
 *
 * @module config/system/environment
 */

import { EnvironmentSchema, type EnvironmentVariables } from '@/contracts';

const ENV_VAR_NAME_PATTERN = /^[A-Z0-9_]+$/;

function logEnvironmentError(...args: unknown[]): void {
  if (typeof console !== 'undefined') {
    console.error('[config-environment]', ...args);
  }
}

/**
 * Get environment variable with proper validation
 *
 * @param key - Environment variable key (must match EnvironmentVariables type)
 * @returns Environment variable value or undefined
 * @throws Error if key format is invalid
 */
export function getEnvVar(key: keyof EnvironmentVariables): string | undefined {
  // Using process.env directly is acceptable for environment configuration
  const sanitizedKey = String(key);
  if (!ENV_VAR_NAME_PATTERN.test(sanitizedKey)) {
    throw new Error(`Invalid environment variable key requested: ${sanitizedKey}`);
  }

  return process.env[sanitizedKey];
}

/**
 * Get environment variable with fallback
 *
 * @param key - Environment variable key
 * @param fallback - Default value if variable is not set
 * @returns Environment variable value or fallback
 */
export function getEnvVarWithFallback(
  key: keyof EnvironmentVariables,
  fallback: Readonly<string>
): string {
  // Using process.env directly is acceptable for environment configuration
  const value = getEnvVar(key);
  return value ?? fallback;
}

/**
 * Get boolean environment variable
 *
 * @param key - Environment variable key
 * @param fallback - Default value if variable is not set (defaults to false)
 * @returns Boolean value (true if value is 'true' or '1', false otherwise)
 */
export function getBooleanEnvVar(key: keyof EnvironmentVariables, fallback = false): boolean {
  // Using process.env directly is acceptable for environment configuration
  const value = getEnvVar(key);
  if (value === undefined) return fallback;
  return value.toLowerCase() === 'true' || value === '1';
}

/**
 * Get numeric environment variable
 *
 * @param key - Environment variable key
 * @param fallback - Default value if variable is not set or invalid (defaults to 0)
 * @returns Numeric value or fallback
 */
export function getNumericEnvVar(key: keyof EnvironmentVariables, fallback = 0): number {
  // Using process.env directly is acceptable for environment configuration
  const value = getEnvVar(key);
  if (value === undefined) return fallback;
  const parsed = Number.parseInt(value, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
}

/**
 * Validate and parse environment variables
 *
 * @returns Validated environment variables object
 * @throws Error if validation fails
 */
export function validateEnvironment(): EnvironmentVariables {
  try {
    // Using process.env directly is acceptable for environment configuration
    return EnvironmentSchema.parse(process.env);
  } catch (error) {
    logEnvironmentError('Environment validation failed', error);
    throw new Error('Invalid environment configuration');
  }
}

/**
 * Get current environment
 *
 * @returns Validated environment variables object
 */
export function getCurrentEnvironment(): EnvironmentVariables {
  return validateEnvironment();
}

/**
 * Build-time validation of required environment variables
 * This function is designed to be called during build/CI processes
 * and provides clear error messages for missing required variables.
 *
 * @param requiredVars - Array of required environment variable keys
 * @param options - Validation options
 * @returns Object with validation result and details
 */
export function validateRequiredEnvVarsAtBuildTime(
  requiredVars: readonly (keyof EnvironmentVariables)[],
  options: {
    allowMissingOptional?: boolean;
    strictMode?: boolean;
  } = {}
): {
  valid: boolean;
  missing: string[];
  warnings: string[];
  errors: string[];
} {
  const { strictMode = false } = options;
  const missing: string[] = [];
  const warnings: string[] = [];
  const errors: string[] = [];

  // Check required variables
  for (const varName of requiredVars) {
    const value = getEnvVar(varName);
    if (!value || value.trim() === '') {
      missing.push(varName);
    } else if (
      !strictMode &&
      (value.includes('placeholder') ||
        value.includes('xxxxx') ||
        value.includes('your-') ||
        value.includes('YOUR_'))
    ) {
      warnings.push(`${varName} appears to contain a placeholder value`);
    }
  }

  // Validate schema if strict mode is enabled
  if (strictMode && missing.length === 0) {
    try {
      EnvironmentSchema.parse(process.env);
    } catch (error) {
      if (error instanceof Error) {
        errors.push(`Schema validation failed: ${error.message}`);
      } else {
        errors.push('Schema validation failed: Unknown error');
      }
    }
  }

  // Check for NEXT_PUBLIC_ variables that should be available at build time
  const nextPublicVars = requiredVars.filter(v => v.startsWith('NEXT_PUBLIC_'));
  if (nextPublicVars.length > 0) {
    const missingNextPublic = nextPublicVars.filter(v => !getEnvVar(v));
    if (missingNextPublic.length > 0) {
      warnings.push(
        `NEXT_PUBLIC_ variables should be set at build time: ${missingNextPublic.join(', ')}`
      );
    }
  }

  return {
    errors,
    missing,
    valid: missing.length === 0 && errors.length === 0,
    warnings,
  };
}
