/**
 * API Path Constants
 *
 * Centralized constants for API route paths to avoid duplicate string literals.
 * All API paths used in fetch calls, redirects, and route definitions should use these constants.
 *
 * @module config/system/constants/api-paths
 * @example
 * ```typescript
 * import { API_PATHS } from '@/config/system/constants/api-paths';
 *
 * // Use in fetch calls
 * const response = await fetch(API_PATHS.POSTS);
 *
 * // Use in redirects
 * redirect(API_PATHS.MEDIA);
 * ```
 */

import type { ApiPath } from '@revealui/core/shared-types';

export const API_PATHS = {
  // Collection API paths
  POSTS: '/api/posts',
  MEDIA: '/api/media',
  CATEGORIES: '/api/categories',
  PAGES: '/api/pages',
  USERS: '/api/users',
  CARTS: '/api/carts',
  ORDERS: '/api/orders',
  PRODUCTS: '/api/products',
  TAGS: '/api/tags',
  MENUS: '/api/menus',
  FORMS: '/api/forms',
  SESSIONS: '/api/sessions',
  TENANTS: '/api/tenants',
  SUBSCRIPTIONS: '/api/subscriptions',
  INVOICES: '/api/invoices',
  WEBHOOK_EVENTS: '/api/webhook-events',
  CREDIT_BALANCES: '/api/credit-balances',
  CREDIT_TRANSACTIONS: '/api/credit-transactions',
  PAYMENT_RETRIES: '/api/payment-retries',
  PAYWALLS: '/api/paywalls',
  SUPPORT_TICKETS: '/api/support-tickets',
  SUPPORT_MESSAGES: '/api/support-messages',
  AUDIT_LOGS: '/api/audit-logs',
  PERFORMANCE_METRICS: '/api/performance-metrics',
  USAGE_RECORDS: '/api/usage-records',
  HELP_ARTICLES: '/api/help-articles',
  VIDEOS: '/api/videos',
  VIDEO_REQUESTS: '/api/video-requests',
  VIDEO_PURCHASES: '/api/video-purchases',
  TRAINING_SESSIONS: '/api/training-sessions',
  INDUSTRY_TEMPLATES: '/api/industry-templates',
  BUSINESSES: '/api/businesses',
  BUSINESS_FEATURES: '/api/business-features',
  BRANDS: '/api/brands',
  CONTRACTS: '/api/contracts',
  COUPONS: '/api/coupons',
  GDPR_EXPORTS: '/api/gdpr-exports',
  GDPR_DELETIONS: '/api/gdpr-deletions',
  ENTERPRISE_ONBOARDINGS: '/api/enterprise-onboardings',
  FOLDERS: '/api/folders',
  PREFIXES: '/api/prefixes',
  SLA_VIOLATIONS: '/api/sla-violations',
  IP_WHITELISTS: '/api/ip-whitelists',
  API_KEYS: '/api/api-keys',
  MCP_AUTOMATION_LOGS: '/api/mcp-automation-logs',
  TENANT_BRANDING: '/api/tenant-branding',
  VERSIONS: '/api/versions',

  // Admin API paths
  ADMIN: '/admin',
  ADMIN_USERS: '/admin/collections/users',
  ADMIN_POSTS: '/admin/collections/posts',
  ADMIN_MEDIA: '/admin/collections/media',
  ADMIN_CATEGORIES: '/admin/collections/categories',
  ADMIN_PAGES: '/admin/collections/pages',
  ADMIN_CREATE_FIRST_USER: '/admin/create-first-user',

  // Health and utility paths
  HEALTH: '/api/health',
  SEED: '/api/seed',
} as const;

export type { ApiPath };

