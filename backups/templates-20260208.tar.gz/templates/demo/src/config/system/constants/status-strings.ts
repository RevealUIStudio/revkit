/**
 * Status String Constants
 *
 * Centralized constants for status values to avoid duplicate string literals.
 * All status strings used in conditionals, filters, and type definitions should use these constants.
 *
 * @module config/system/constants/status-strings
 * @example
 * ```typescript
 * import { STATUS } from '@/config/system/constants/status-strings';
 *
 * // Use in conditionals
 * if (subscription.status === STATUS.ACTIVE) {
 *   // ...
 * }
 *
 * // Use in filters
 * const activeSubscriptions = subscriptions.filter(
 *   s => s.status === STATUS.ACTIVE
 * );
 * ```
 */

import type { StatusValue } from '@revealui/core/shared-types';

export const STATUS = {
  // General status values
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  PENDING: 'pending',
  COMPLETED: 'completed',
  CANCELLED: 'canceled',
  CANCELLED_ALT: 'cancelled', // Alternative spelling
  FAILED: 'failed',
  SUCCESS: 'success',
  ERROR: 'error',
  WARNING: 'warning',
  INFO: 'info',

  // Subscription status values
  SUBSCRIPTION_ACTIVE: 'active',
  SUBSCRIPTION_TRIALING: 'trialing',
  SUBSCRIPTION_PAST_DUE: 'past_due',
  SUBSCRIPTION_CANCELLED: 'canceled',
  SUBSCRIPTION_UNPAID: 'unpaid',
  SUBSCRIPTION_INCOMPLETE: 'incomplete',
  SUBSCRIPTION_INCOMPLETE_EXPIRED: 'incomplete_expired',

  // Order status values
  ORDER_PENDING: 'pending',
  ORDER_PROCESSING: 'processing',
  ORDER_COMPLETED: 'completed',
  ORDER_SHIPPED: 'shipped',
  ORDER_DELIVERED: 'delivered',
  ORDER_CANCELLED: 'canceled',
  ORDER_REFUNDED: 'refunded',

  // Payment status values
  PAYMENT_PENDING: 'pending',
  PAYMENT_PROCESSING: 'processing',
  PAYMENT_SUCCEEDED: 'succeeded',
  PAYMENT_FAILED: 'failed',
  PAYMENT_REFUNDED: 'refunded',
  PAYMENT_CANCELLED: 'canceled',

  // Webhook status values
  WEBHOOK_PENDING: 'pending',
  WEBHOOK_PROCESSING: 'processing',
  WEBHOOK_SUCCESS: 'success',
  WEBHOOK_FAILED: 'failed',
  WEBHOOK_RETRYING: 'retrying',

  // Post status values
  POST_DRAFT: 'draft',
  POST_PUBLISHED: 'published',
  POST_ARCHIVED: 'archived',

  // Support ticket status values
  TICKET_OPEN: 'open',
  TICKET_IN_PROGRESS: 'in_progress',
  TICKET_RESOLVED: 'resolved',
  TICKET_CLOSED: 'closed',

  // GDPR request status values
  GDPR_PENDING: 'pending',
  GDPR_PROCESSING: 'processing',
  GDPR_COMPLETED: 'completed',
  GDPR_FAILED: 'failed',
} as const;

export type { StatusValue };

