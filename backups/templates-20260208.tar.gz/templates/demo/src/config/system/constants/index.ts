/**
 * Application Constants
 *
 * Centralized exports for application-wide constants including:
 * - Media prefix constants (allowed types, validation rules, error messages)
 * - Field descriptions and admin configuration for prefixes
 *
 * @module config/constants
 * @example
 * ```typescript
 * // Get allowed media types
 * import { ALLOWED_TYPES, DEFAULT_ALLOWED_TYPES } from '@/config/constants';
 *
 * // Get prefix validation rules
 * import { PREFIXES_VALIDATION } from '@/config/constants';
 * ```
 */

// Media prefix constants
export * from './prefixes.ts';

// Image constants
export * from './images.ts';

// Application defaults
export * from './defaults.ts';

// Collection name constants
export * from './collections.ts';

// API path constants
export * from './api-paths.ts';

// Status string constants
export * from './status-strings.ts';

// Error message constants
export * from './error-messages.ts';
