/**
 * Application Default Constants
 *
 * Centralized default values for application configuration including:
 * - Cache settings and limits
 * - Database connection pool configuration
 * - Rate limiting defaults
 * - Upload constraints
 *
 * @module config/constants/defaults
 */
export declare const CACHE_DEFAULTS: {
    readonly TTL: 3600;
    readonly MAX_SIZE: 100;
    readonly CLEANUP_INTERVAL: 300000;
};
export declare const getCacheMaxSize: () => number;
export declare const DATABASE_DEFAULTS: {
    readonly POOL_SIZE: 10;
    readonly CONNECTION_TIMEOUT: 30000;
    readonly IDLE_TIMEOUT: 300000;
    readonly MAX_CONNECTIONS: 20;
    readonly MAX_RETRIES: 3;
    readonly RETRY_DELAY: 1000;
};
export declare const getDatabasePoolConfig: (isDevelopment?: boolean) => {
    max: number;
    min: number;
    idleTimeoutMillis: 300000;
    connectionTimeoutMillis: 30000;
};
export declare const RATE_LIMIT_DEFAULTS: {
    readonly MAX_REQUESTS: 100;
    readonly WINDOW_MS: 900000;
    readonly SKIP_SUCCESSFUL_REQUESTS: false;
};
export declare const getRateLimitMaxRequests: () => number;
export declare const UPLOAD_DEFAULTS: {
    readonly MAX_FILE_SIZE: number;
    readonly ALLOWED_TYPES: readonly ["image/jpeg", "image/png", "image/webp", "image/gif"];
    readonly MAX_FILES: 5;
    readonly TEMP_DIR: "temp";
    readonly CDN_CACHE_MAX_AGE: 31536000;
};
//# sourceMappingURL=defaults.d.ts.map