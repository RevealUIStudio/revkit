/**
 * Image Constants
 * Fallback images and placeholders for the application
 */

/**
 * Placeholder image - 1x1 gray pixel as data URL
 * Used when no image is available to prevent 404 errors
 */
export const PLACEHOLDER_IMAGE =
  'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"%3E%3Crect width="400" height="400" fill="%23e5e5e5"/%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="system-ui" font-size="24" fill="%23a3a3a3"%3ENo Image%3C/text%3E%3C/svg%3E';

/**
 * Video placeholder image
 */
export const VIDEO_PLACEHOLDER =
  'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"%3E%3Crect width="400" height="400" fill="%23e5e5e5"/%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="system-ui" font-size="24" fill="%23a3a3a3"%3EVideo%3C/text%3E%3C/svg%3E';
