/**
 * Collection Name Constants
 *
 * Centralized constants for RevealUI Content Engine collection slugs to avoid duplicate string literals.
 * All collection names used in queries, relationships, and API calls should use these constants.
 *
 * @module config/system/constants/collections
 * @example
 * ```typescript
 * import { COLLECTIONS } from '@/config/system/constants/collections';
 *
 * // Use in queries
 * await revealui.find({
 *   collection: COLLECTIONS.USERS,
 * });
 *
 * // Use in relationships
 * {
 *   name: 'author',
 *   type: 'relationship',
 *   relationTo: COLLECTIONS.USERS,
 * }
 * ```
 */

import type { CollectionName } from '@revealui/core/shared-types';

export const COLLECTIONS = {
  API_KEYS: 'api-keys',
  AUDIT_LOGS: 'audit-logs',
  BRANDS: 'brands',
  BUSINESSES: 'businesses',
  BUSINESS_FEATURES: 'business-features',
  CARTS: 'carts',
  CATEGORIES: 'categories',
  CONTRACTS: 'contracts',
  COUPONS: 'coupons',
  CREDIT_BALANCES: 'credit-balances',
  CREDIT_TRANSACTIONS: 'credit-transactions',
  ENTERPRISE_ONBOARDINGS: 'enterprise-onboardings',
  FOLDERS: 'folders',
  GDPR_DELETIONS: 'gdpr-deletions',
  GDPR_EXPORTS: 'gdpr-exports',
  HELP_ARTICLES: 'help-articles',
  INDUSTRY_TEMPLATES: 'industry-templates',
  INVOICES: 'invoices',
  IP_WHITELISTS: 'ip-whitelists',
  MCP_AUTOMATION_LOGS: 'mcp-automation-logs',
  MEDIA: 'media',
  MENUS: 'menus',
  ORDERS: 'orders',
  PAGES: 'pages',
  PAYMENT_RETRIES: 'payment-retries',
  PAYWALLS: 'paywalls',
  PERFORMANCE_METRICS: 'performance-metrics',
  POSTS: 'posts',
  PREFIXES: 'prefixes',
  PRODUCTS: 'products',
  SESSIONS: 'sessions',
  SLA_VIOLATIONS: 'sla-violations',
  SUBSCRIPTIONS: 'subscriptions',
  SUPPORT_MESSAGES: 'support-messages',
  SUPPORT_TICKETS: 'support-tickets',
  TAGS: 'tags',
  TENANT_BRANDING: 'tenant-branding',
  TENANTS: 'tenants',
  TRAINING_SESSIONS: 'training-sessions',
  USAGE_RECORDS: 'usage-records',
  USERS: 'users',
  VERSIONS: 'versions',
  VIDEO_PURCHASES: 'video-purchases',
  VIDEO_REQUESTS: 'video-requests',
  VIDEOS: 'videos',
  WEBHOOK_EVENTS: 'webhook-events',
} as const;

export type { CollectionName };

