/**
 * Application Default Constants
 *
 * Centralized default values for application configuration including:
 * - Cache settings and limits
 * - Database connection pool configuration
 * - Rate limiting defaults
 * - Upload constraints
 *
 * @module config/constants/defaults
 */

// ======
// CACHE DEFAULTS
// ======

export const CACHE_DEFAULTS = {
  TTL: 3600, // 1 hour in seconds
  MAX_SIZE: 100, // Maximum number of items
  CLEANUP_INTERVAL: 300000, // 5 minutes in milliseconds
} as const;

export const getCacheMaxSize = (): number => {
  return Number.parseInt(process.env['CACHE_MAX_SIZE'] || String(CACHE_DEFAULTS.MAX_SIZE), 10);
};

// ======
// DATABASE DEFAULTS
// ======

export const DATABASE_DEFAULTS = {
  POOL_SIZE: 10,
  CONNECTION_TIMEOUT: 30000, // 30 seconds
  IDLE_TIMEOUT: 300000, // 5 minutes
  MAX_CONNECTIONS: 20,
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000, // 1 second
} as const;

export const getDatabasePoolConfig = (isDevelopment = false) => {
  return {
    max: isDevelopment ? 5 : DATABASE_DEFAULTS.MAX_CONNECTIONS,
    min: 1,
    idleTimeoutMillis: DATABASE_DEFAULTS.IDLE_TIMEOUT,
    connectionTimeoutMillis: DATABASE_DEFAULTS.CONNECTION_TIMEOUT,
  };
};

// ======
// RATE LIMITING DEFAULTS
// ======

export const RATE_LIMIT_DEFAULTS = {
  MAX_REQUESTS: 100,
  WINDOW_MS: 900000, // 15 minutes
  SKIP_SUCCESSFUL_REQUESTS: false,
} as const;

export const getRateLimitMaxRequests = (): number => {
  return Number.parseInt(
    process.env['RATE_LIMIT_MAX_REQUESTS'] || String(RATE_LIMIT_DEFAULTS.MAX_REQUESTS),
    10
  );
};

// ======
// UPLOAD DEFAULTS
// ======

export const UPLOAD_DEFAULTS = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  ALLOWED_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  MAX_FILES: 5,
  TEMP_DIR: 'temp',
  CDN_CACHE_MAX_AGE: 31536000, // 1 year in seconds
} as const;
