export const PREFIXES_COLLECTION = 'prefixes';

export const PREFIXES_ADMIN_CONFIG = {
  TITLE_FIELD: 'name',
  DEFAULT_COLUMNS: ['name', 'path', 'active'],
  GROUP: 'Media',
  DESCRIPTION: 'Manage media prefixes for organizing uploads',
};

export const PREFIXES_VALIDATION = {
  NAME: {
    MAX_LENGTH: 50,
    REQUIRED: 'Name is required',
  },
  PATH: {
    MAX_LENGTH: 100,
    TOO_LONG: 'Path is too long',
    INVALID_CHARS: /[^a-zA-Z0-9-_/]/,
    INVALID_CHARS_MSG:
      'Path can only contain letters, numbers, hyphens, underscores, and forward slashes',
  },
};

export const PREFIXES_FIELD_DESCRIPTIONS = {
  PATH: 'Optional path segment for organizing media within this prefix',
  ACTIVE: 'Whether this prefix is currently active',
  DESCRIPTION: 'Description of this prefix and its intended use',
  ALLOWED_TYPES: 'File types allowed for uploads in this prefix',
  MEDIA: 'Media files associated with this prefix',
};

export const PREFIXES_ERROR_MESSAGES = {
  NAME_EXISTS: 'A prefix with this name already exists',
};

export const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
export const DEFAULT_ALLOWED_TYPES = ['image/jpeg', 'image/png'];
export const MAX_MEDIA_PER_PREFIX = 100;
