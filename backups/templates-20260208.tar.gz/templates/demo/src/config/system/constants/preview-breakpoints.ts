/**
 * Live Preview Breakpoints Configuration
 *
 * Centralized breakpoint definitions for RevealUI Content Engine live preview functionality.
 * Used across collections to maintain consistency in preview experience.
 */

import type { PreviewBreakpoint } from '@revealui/core/shared-types';

/**
 * Standard breakpoints for live preview across all collections
 */
export const PREVIEW_BREAKPOINTS: PreviewBreakpoint[] = [
  {
    name: 'mobile',
    label: 'Mobile',
    width: 375,
    height: 667,
  },
  {
    name: 'tablet',
    label: 'Tablet',
    width: 768,
    height: 1024,
  },
  {
    name: 'desktop',
    label: 'Desktop',
    width: 1440,
    height: 900,
  },
];

/**
 * Get breakpoints for RevealUI Content Engine live preview configuration
 */
export function getLivePreviewBreakpoints(): PreviewBreakpoint[] {
  return PREVIEW_BREAKPOINTS;
}

/**
 * Get breakpoints for RevealUI Content Engine admin live preview configuration
 * (with different property names for admin config)
 */
export function getAdminLivePreviewBreakpoints() {
  return PREVIEW_BREAKPOINTS.map(bp => ({
    label: bp.label,
    name: bp.name,
    width: bp.width,
    height: bp.height,
  }));
}
