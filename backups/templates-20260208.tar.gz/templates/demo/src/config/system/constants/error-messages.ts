/**
 * Error Message Constants
 *
 * Centralized constants for common error messages to avoid duplicate string literals.
 * All error messages used in services, repositories, and API handlers should use these constants.
 *
 * For service-specific errors, see:
 * - @revealui/infrastructure/services/constants/service-errors.ts
 *
 * @module config/system/constants/error-messages
 * @example
 * ```typescript
 * import { ERROR_MESSAGES } from '@/config/system/constants/error-messages';
 *
 * // Use in error handling
 * throw new Error(ERROR_MESSAGES.NOT_FOUND);
 *
 * // Use in ServiceResult
 * return {
 *   success: false,
 *   error: ERROR_MESSAGES.VALIDATION_FAILED,
 * };
 * ```
 */

import type { ErrorMessage } from '@revealui/core/shared-types';

export const ERROR_MESSAGES = {
  // === NOT FOUND ERRORS ===
  NOT_FOUND: 'Resource not found',
  USER_NOT_FOUND: 'User not found',
  POST_NOT_FOUND: 'Post not found',
  ORDER_NOT_FOUND: 'Order not found',
  PRODUCT_NOT_FOUND: 'Product not found',
  CATEGORY_NOT_FOUND: 'Category not found',
  MEDIA_NOT_FOUND: 'Media not found',
  TENANT_NOT_FOUND: 'Tenant not found',
  SUBSCRIPTION_NOT_FOUND: 'Subscription not found',
  INVOICE_NOT_FOUND: 'Invoice not found',

  // === VALIDATION ERRORS ===
  VALIDATION_FAILED: 'Validation failed',
  INVALID_INPUT: 'Invalid input',
  INVALID_ID: 'Invalid ID',
  INVALID_EMAIL: 'Invalid email address',
  INVALID_STATUS: 'Invalid status',
  MISSING_REQUIRED_FIELD: 'Missing required field',
  INVALID_FORMAT: 'Invalid format',

  // === AUTHENTICATION & AUTHORIZATION ===
  UNAUTHORIZED: 'Unauthorized access',
  FORBIDDEN: 'Forbidden',
  AUTHENTICATION_FAILED: 'Authentication failed',
  INVALID_CREDENTIALS: 'Invalid credentials',
  SESSION_EXPIRED: 'Session expired',
  TOKEN_INVALID: 'Invalid token',
  TOKEN_EXPIRED: 'Token expired',

  // === OPERATION ERRORS ===
  OPERATION_FAILED: 'Operation failed',
  CREATE_FAILED: 'Failed to create resource',
  UPDATE_FAILED: 'Failed to update resource',
  DELETE_FAILED: 'Failed to delete resource',
  FETCH_FAILED: 'Failed to fetch resource',
  SAVE_FAILED: 'Failed to save resource',
  PROCESS_FAILED: 'Failed to process request',

  // === INITIALIZATION ERRORS ===
  NOT_INITIALIZED: 'Service not initialized',
  REVEAL_NOT_INITIALIZED: 'RevealUI not initialized',
  INITIALIZATION_FAILED: 'Failed to initialize service',

  // === PAYMENT ERRORS ===
  PAYMENT_FAILED: 'Payment failed',
  PAYMENT_PROCESSING_FAILED: 'Payment processing failed',
  INSUFFICIENT_FUNDS: 'Insufficient funds',
  PAYMENT_METHOD_INVALID: 'Invalid payment method',
  PAYMENT_DECLINED: 'Payment declined',

  // === SUBSCRIPTION ERRORS ===
  SUBSCRIPTION_ALREADY_EXISTS: 'Subscription already exists',
  SUBSCRIPTION_NOT_ACTIVE: 'Subscription is not active',
  SUBSCRIPTION_CANCELLED: 'Subscription has been cancelled',

  // === GENERAL ERRORS ===
  UNKNOWN_ERROR: 'Unknown error',
  INTERNAL_ERROR: 'Internal server error',
  SERVICE_UNAVAILABLE: 'Service unavailable',
  TIMEOUT: 'Request timeout',
  RATE_LIMIT_EXCEEDED: 'Rate limit exceeded',
  CONFLICT: 'Resource conflict',
  DUPLICATE_ENTRY: 'Duplicate entry',

  // === DATA ERRORS ===
  DATA_NOT_AVAILABLE: 'Data not available',
  INVALID_DATA: 'Invalid data',
  DATA_CORRUPTED: 'Data corrupted',
  MISSING_DATA: 'Missing data',

  // === NETWORK ERRORS ===
  NETWORK_ERROR: 'Network error',
  CONNECTION_FAILED: 'Connection failed',
  REQUEST_FAILED: 'Request failed',

  // === CONFIGURATION ERRORS ===
  CONFIGURATION_ERROR: 'Configuration error',
  MISSING_CONFIGURATION: 'Missing configuration',
  INVALID_CONFIGURATION: 'Invalid configuration',
} as const;

export type { ErrorMessage };

