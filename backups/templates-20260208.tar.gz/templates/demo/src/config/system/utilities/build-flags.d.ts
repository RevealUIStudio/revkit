export declare function isAnalyzerBuild(): boolean;
export declare function configureAnalyzerLogging(): void;
//# sourceMappingURL=build-flags.d.ts.map