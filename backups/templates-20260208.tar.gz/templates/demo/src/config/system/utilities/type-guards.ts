interface UserSession {
  id: number;
  userId: string;
  token: string;
  device?: string;
  expiresAt: string;
  lastActiveAt: string;
  isActive: boolean;
  updatedAt: string;
  createdAt: string;
}

/**
 * Type guard to check if a value is a UserSession object.
 * @param {unknown} value - The value to check
 * @returns {value is UserSession} True if the value is a UserSession
 */
export function isUserSession(value: unknown): value is UserSession {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'userId' in value &&
    'token' in value &&
    'device' in value &&
    'expiresAt' in value &&
    'lastActiveAt' in value &&
    'isActive' in value &&
    'updatedAt' in value &&
    'createdAt' in value &&
    typeof (value as UserSession).id === 'number' &&
    typeof (value as UserSession).userId === 'string' &&
    typeof (value as UserSession).token === 'string' &&
    typeof (value as UserSession).expiresAt === 'string' &&
    typeof (value as UserSession).lastActiveAt === 'string' &&
    typeof (value as UserSession).isActive === 'boolean' &&
    typeof (value as UserSession).updatedAt === 'string' &&
    typeof (value as UserSession).createdAt === 'string'
  );
}

/**
 * Type guard to check if a value is a valid string array.
 * @param {unknown} value - The value to check
 * @returns {value is string[]} True if the value is a string array
 */
export function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every(item => typeof item === 'string');
}

/**
 * Type guard to check if a value is a valid date string or Date object.
 * @param {unknown} value - The value to check
 * @returns {value is string | Date} True if the value is a valid date
 */
export function isValidDate(value: unknown): value is string | Date {
  if (value instanceof Date) return !Number.isNaN(value.getTime());
  if (typeof value === 'string') {
    const date = new Date(value);
    return !Number.isNaN(date.getTime());
  }
  return false;
}

/**
 * Type guard to check if a value is a valid URL string.
 * @param {unknown} value - The value to check
 * @returns {value is string} True if the value is a valid URL
 */
export function isValidURL(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

/**
 * Type guard to check if a value is a valid email string.
 * @param {unknown} value - The value to check
 * @returns {value is string} True if the value is a valid email
 */
export function isValidEmail(value: unknown): value is string {
  if (typeof value !== 'string') return false;

  try {
    // Use URL constructor for more robust email validation
    const emailUrl = new URL(`mailto:${value}`);
    const emailPath = emailUrl.pathname;

    // Check for @ symbol and domain structure
    if (!emailPath.includes('@') || emailPath.startsWith('@') || emailPath.endsWith('@')) {
      return false;
    }

    const [localPart, domain] = emailPath.split('@');
    return !!(
      localPart &&
      domain &&
      domain.includes('.') &&
      !domain.startsWith('.') &&
      !domain.endsWith('.')
    );
  } catch {
    return false;
  }
}

/**
 * Type guard to check if a value is a valid token string.
 * @param {unknown} value - The value to check
 * @returns {value is string} True if the value is a valid token
 */
export function isValidToken(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0;
}
