/**
 * Service Result Helpers
 *
 * Utilities for creating consistent service result objects.
 * Now uses Core's UnifiedResult internally for consistency.
 * Used across domain and infrastructure layers for consistent error handling.
 */

import { failure, success } from './result-helpers';
import type { Result } from './result-helpers';

/**
 * Create a successful service result using Core's Result pattern
 */
export function serviceSuccess<T>(data: T): Result<T, never> {
  return success(data);
}

/**
 * Create a failed service result using Core's Result pattern
 */
type DetailedError = Error & {
  code?: string;
  // Using Record<string, unknown> because error details structure varies by error type and cannot be strictly typed
  details?: Record<string, unknown>;
};

export function serviceFailure(error: string, code?: string): Result<never, Error> {
  const errorObj: DetailedError = new Error(error) as DetailedError;
  if (code) {
    errorObj.code = code;
  }
  return failure(errorObj);
}

/**
 * Create a successful service result with metrics
 */
export function serviceSuccessWithMetrics<T>(
  data: T,
  _metrics: { duration: number; timestamp: Date; [key: string]: unknown }
): Result<T, never> {
  // For now, return simple success - metrics can be handled at a higher level
  return success(data);
}

/**
 * Create a failed service result with additional details
 */
// Using Record<string, unknown> because error details structure varies by error type and cannot be strictly typed
export function serviceFailureWithDetails(
  error: string,
  details: Record<string, unknown>,
  code?: string
): Result<never, Error> {
  const errorObj: DetailedError = new Error(error) as DetailedError;
  if (code) {
    errorObj.code = code;
  }
  if (details) {
    errorObj.details = details;
  }
  return failure(errorObj);
}
