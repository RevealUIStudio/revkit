import { createHash, randomBytes, randomUUID } from 'node:crypto';
import type { Metadata } from 'next';

// Define OpenGraph type locally to avoid import issues
type OpenGraph = {
  title?: string;
  description?: string;
  url?: string;
  siteName?: string;
  images?: Array<{ url: string } | string>;
  type?:
    | 'website'
    | 'article'
    | 'book'
    | 'profile'
    | 'music.song'
    | 'music.album'
    | 'music.playlist'
    | 'music.radio_station'
    | 'video.movie'
    | 'video.episode'
    | 'video.tv_show'
    | 'video.other';
};

// ======
// GENERATION UTILITIES
// ======
// Utility functions for generating IDs, tokens, and other values

/**
 * Generate a UUID v4
 */
export function generateUUID(): string {
  return randomUUID();
}

/**
 * Generate a random string of specified length
 */
export function generateRandomString(
  length: Readonly<number>,
  charset: Readonly<string> = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
): string {
  let result = '';
  const charsetLength = charset.length;

  for (let i = 0; i < length; i++) {
    result += charset.charAt(Math.floor(Math.random() * charsetLength));
  }

  return result;
}

/**
 * Generate a random numeric string
 */
export function generateRandomNumeric(length: Readonly<number>): string {
  return generateRandomString(length, '0123456789');
}

/**
 * Generate a random alphanumeric string
 */
export function generateRandomAlphanumeric(length: Readonly<number>): string {
  return generateRandomString(
    length,
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  );
}

/**
 * Generate a random hex string
 */
export function generateRandomHex(length: Readonly<number>): string {
  return randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length);
}

/**
 * Generate a secure token
 */
export function generateSecureToken(length: Readonly<number> = 32): string {
  return randomBytes(length).toString('base64url');
}

/**
 * Generate a short ID (8 characters)
 */
export function generateShortId(): string {
  return generateRandomAlphanumeric(8);
}

/**
 * Generate a medium ID (16 characters)
 */
export function generateMediumId(): string {
  return generateRandomAlphanumeric(16);
}

/**
 * Generate a long ID (32 characters)
 */
export function generateLongId(): string {
  return generateRandomAlphanumeric(32);
}

/**
 * Generate a slug from text
 */
export function generateSlug(text: Readonly<string>): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/[\s_-]+/g, '-') // Replace spaces and underscores with hyphens
    .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
}

/**
 * Generate a unique slug with timestamp
 */
export function generateUniqueSlug(text: Readonly<string>): string {
  const baseSlug = generateSlug(text);
  const timestamp = Date.now().toString(36);
  return `${baseSlug}-${timestamp}`;
}

/**
 * Generate a correlation ID for tracking
 */
export function generateCorrelationId(): string {
  const timestamp = Date.now().toString(36);
  const random = generateRandomAlphanumeric(6);
  return `corr-${timestamp}-${random}`;
}

/**
 * Generate a session ID
 */
export function generateSessionId(): string {
  const timestamp = Date.now().toString(36);
  const random = generateRandomAlphanumeric(8);
  return `sess-${timestamp}-${random}`;
}

/**
 * Generate a request ID
 */
export function generateRequestId(): string {
  const timestamp = Date.now().toString(36);
  const random = generateRandomAlphanumeric(6);
  return `req-${timestamp}-${random}`;
}

/**
 * Generate a transaction ID
 */
export function generateTransactionId(): string {
  const timestamp = Date.now().toString(36);
  const random = generateRandomAlphanumeric(8);
  return `txn-${timestamp}-${random}`;
}

/**
 * Generate a reference number
 */
export function generateReferenceNumber(prefix: Readonly<string> = 'REF'): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = generateRandomNumeric(4);
  return `${prefix}-${timestamp}-${random}`;
}

/**
 * Generate an order number
 */
export function generateOrderNumber(): string {
  return generateReferenceNumber('ORD');
}

/**
 * Generate a product SKU
 */
export function generateSKU(prefix: Readonly<string> = 'SKU'): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = generateRandomAlphanumeric(4).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

/**
 * Generate a tracking number
 */
export function generateTrackingNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = generateRandomAlphanumeric(6).toUpperCase();
  return `TRK-${timestamp}-${random}`;
}

/**
 * Generate a coupon code
 */
export function generateCouponCode(length: Readonly<number> = 8): string {
  return generateRandomAlphanumeric(length).toUpperCase();
}

/**
 * Generate a password reset token
 */
export function generatePasswordResetToken(): string {
  return generateSecureToken(32);
}

/**
 * Generate an email verification token
 */
export function generateEmailVerificationToken(): string {
  return generateSecureToken(24);
}

/**
 * Generate an API key
 */
export function generateAPIKey(): string {
  const prefix = 'sk_';
  const key = generateSecureToken(32);
  return `${prefix}${key}`;
}

/**
 * Generate a webhook secret
 */
export function generateWebhookSecret(): string {
  return generateSecureToken(32);
}

/**
 * Generate a nonce for security
 */
export function generateNonce(): string {
  return generateSecureToken(16);
}

/**
 * Generate a challenge token
 */
export function generateChallengeToken(): string {
  return generateSecureToken(20);
}

/**
 * Generate a fingerprint
 */
export function generateFingerprint(data: Readonly<string>): string {
  const hash = createHash('sha256');
  hash.update(data);
  return hash.digest('hex').slice(0, 16);
}

/**
 * Generate a checksum
 */
export function generateChecksum(data: Readonly<string>): string {
  const hash = createHash('md5');
  hash.update(data);
  return hash.digest('hex');
}

/**
 * Generate a hash
 */
export function generateHash(
  data: Readonly<string>,
  algorithm: 'md5' | 'sha1' | 'sha256' | 'sha512' = 'sha256'
): string {
  const hash = createHash(algorithm);
  hash.update(data);
  return hash.digest('hex');
}

/**
 * Generate meta data for pages and posts
 */
export function generateMeta(
  data: Readonly<{
    title?: string;
    description?: string;
    image?: string;
    url?: string;
    type?:
      | 'website'
      | 'article'
      | 'book'
      | 'profile'
      | 'music.song'
      | 'music.album'
      | 'music.playlist'
      | 'music.radio_station'
      | 'video.movie'
      | 'video.episode'
      | 'video.tv_show'
      | 'video.other';
    siteName?: string;
    twitterCard?: 'summary_large_image' | 'summary' | 'player' | 'app';
    twitterSite?: string;
    twitterCreator?: string;
  }>
): Metadata {
  const {
    title,
    description,
    image,
    url,
    type = 'website' as const,
    siteName = 'reveal UI',
    twitterCard = 'summary_large_image' as const,
    twitterSite = '@reveal',
    twitterCreator = '@reveal',
  } = data;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      url,
      siteName,
      images: image ? [{ url: image }] : undefined,
      type,
    },
    twitter: {
      card: twitterCard,
      site: twitterSite,
      creator: twitterCreator,
      title,
      description,
      images: image ? [image] : undefined,
    },
  };
}

/**
 * Merge OpenGraph data with existing metadata
 */
export function mergeOpenGraph(
  existing: OpenGraph | null | undefined,
  newData: Readonly<{
    title?: string;
    description?: string;
    image?: string;
    url?: string;
    type?:
      | 'website'
      | 'article'
      | 'book'
      | 'profile'
      | 'music.song'
      | 'music.album'
      | 'music.playlist'
      | 'music.radio_station'
      | 'video.movie'
      | 'video.episode'
      | 'video.tv_show'
      | 'video.other';
    siteName?: string;
  }>
): OpenGraph {
  const merged: OpenGraph = {
    ...existing,
    ...newData,
  };

  // Ensure images are properly formatted
  if (newData.image) {
    merged.images = [...(existing?.images ?? []), { url: newData.image }];
  }

  return merged;
}
