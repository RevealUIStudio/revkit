/**
 * Result type helpers
 * Local implementation to replace broken @revealui/core export
 */

export type Result<T, E = Error> = 
  | { _tag: 'Success'; value: T }
  | { _tag: 'Failure'; error: E };

export function success<T>(value: T): Result<T, never> {
  return { _tag: 'Success', value };
}

export function failure<E>(error: E): Result<never, E> {
  return { _tag: 'Failure', error };
}

