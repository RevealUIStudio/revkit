/**
 * Error Handling Utilities
 *
 * Centralized error handling patterns to eliminate unused error variable warnings
 * and provide consistent error logging across the codebase.
 *
 * @module config/system/utilities/error-handling
 * @example
 * ```typescript
 * import { handleError, logError } from '@/config/system/utilities/error-handling';
 *
 * // When error needs to be logged
 * try {
 *   // ...
 * } catch (error) {
 *   handleError(error, { context: 'UserService.create' });
 * }
 *
 * // When error is truly unused (handled by circuit breaker, etc.)
 * try {
 *   // ...
 * } catch {
 *   // Error handled by circuit breaker - no action needed
 * }
 * ```
 */

import { createLogger } from '@/config/infrastructure/integrations/logging';

const logger = createLogger('ErrorHandling');

/**
 * Error context for logging
 */
export interface ErrorContext {
  context?: string;
  userId?: string;
  operation?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Handles an error with consistent logging
 *
 * @param error - The error to handle
 * @param context - Context information for logging
 * @returns The error (for re-throwing if needed)
 */
export function handleError(error: unknown, context?: ErrorContext): Error {
  const errorObj = error instanceof Error ? error : new Error(String(error));

  logger.error('Error occurred', {
    message: errorObj.message,
    stack: errorObj.stack,
    ...context,
  });

  return errorObj;
}

/**
 * Logs an error without throwing
 *
 * @param error - The error to log
 * @param context - Context information for logging
 */
export function logError(error: unknown, context?: ErrorContext): void {
  handleError(error, context);
}

/**
 * Handles an error silently (for cases where error is expected and handled)
 *
 * @param error - The error to handle silently
 * @param context - Optional context for debugging
 */
export function handleErrorSilently(error: unknown, context?: ErrorContext): void {
  if (process.env.NODE_ENV === 'development') {
    logger.debug('Error handled silently', {
      message: error instanceof Error ? error.message : String(error),
      ...context,
    });
  }
}

