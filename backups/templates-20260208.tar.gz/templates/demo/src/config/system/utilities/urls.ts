import { getEnvVarWithFallback } from '@/config/system/environment';
import type { EnvironmentVariables } from '@/contracts';

// ======
// URL UTILITIES
// ======
// URL utility functions for domain events

/**
 * Join URL path segments
 */
export function joinUrlPath(...segments: Readonly<string[]>): string {
  return segments
    .map(segment => segment.replace(/^\/+|\/+$/g, '')) // Remove leading/trailing slashes
    .filter(segment => segment.length > 0) // Remove empty segments
    .join('/');
}

/**
 * Create absolute URL from base and path
 */
export function createAbsoluteUrl(baseUrl: Readonly<string>, path: Readonly<string> = ''): string {
  const cleanBase = baseUrl.replace(/\/+$/, ''); // Remove trailing slashes
  const cleanPath = path.replace(/^\/+/, ''); // Remove leading slashes

  if (!cleanPath) {
    return cleanBase;
  }

  return `${cleanBase}/${cleanPath}`;
}

/**
 * Create relative URL from path
 */
export function createRelativeUrl(path: Readonly<string>): string {
  return path.startsWith('/') ? path : `/${path}`;
}

/**
 * Extract domain from URL
 */
export function extractDomain(url: Readonly<string>): string | null {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch {
    return null;
  }
}

/**
 * Extract path from URL
 */
export function extractPath(url: Readonly<string>): string | null {
  try {
    const urlObj = new URL(url);
    return urlObj.pathname;
  } catch {
    return null;
  }
}

/**
 * Extract query parameters from URL
 */
export function extractQueryParams(url: Readonly<string>): Record<string, string> {
  try {
    const urlObj = new URL(url);
    const params: Record<string, string> = {};

    urlObj.searchParams.forEach((value, key) => {
      params[key] = value;
    });

    return params;
  } catch {
    return {};
  }
}

/**
 * Add query parameters to URL
 */
export function addQueryParams(
  url: Readonly<string>,
  params: Readonly<Record<string, string>>
): string {
  try {
    const urlObj = new URL(url);

    Object.entries(params).forEach(([key, value]) => {
      urlObj.searchParams.set(key, value);
    });

    return urlObj.toString();
  } catch {
    return url;
  }
}

/**
 * Remove query parameters from URL
 */
export function removeQueryParams(url: Readonly<string>, params: Readonly<string[]>): string {
  try {
    const urlObj = new URL(url);

    params.forEach(param => {
      urlObj.searchParams.delete(param);
    });

    return urlObj.toString();
  } catch {
    return url;
  }
}

/**
 * Check if URL is absolute
 */
export function isAbsoluteUrl(url: Readonly<string>): boolean {
  return url.startsWith('http://') || url.startsWith('https://') || url.startsWith('//');
}

/**
 * Check if URL is relative
 */
export function isRelativeUrl(url: Readonly<string>): boolean {
  return !isAbsoluteUrl(url);
}

/**
 * Check if URL is internal (same domain)
 */
export function isInternalUrl(url: Readonly<string>, baseUrl: Readonly<string>): boolean {
  try {
    const urlDomain = extractDomain(url);
    const baseDomain = extractDomain(baseUrl);
    return urlDomain === baseDomain;
  } catch {
    return false;
  }
}

/**
 * Check if URL is external (different domain)
 */
export function isExternalUrl(url: Readonly<string>, baseUrl: Readonly<string>): boolean {
  return !isInternalUrl(url, baseUrl);
}

/**
 * Normalize URL (remove trailing slash, ensure protocol) - reveal Optimized
 */
export function normalizeUrl(
  url: Readonly<string>,
  defaultProtocol: Readonly<string> = 'https'
): string {
  let normalized = url.trim();

  // Add protocol if missing
  if (!normalized.startsWith('http://') && !normalized.startsWith('https://')) {
    normalized = `${defaultProtocol}://${normalized}`;
  }

  // Remove trailing slash
  normalized = normalized.replace(/\/+$/, '');

  return normalized;
}

/**
 * Create canonical URL
 */
export function createCanonicalUrl(baseUrl: Readonly<string>, path: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = path.replace(/^\/+/, '');
  return cleanPath ? `${normalizedBase}/${cleanPath}` : normalizedBase;
}

/**
 * Create sitemap URL
 */
export function createSitemapUrl(baseUrl: Readonly<string>, path: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, path);
}

/**
 * Create API URL
 */
export function createApiUrl(baseUrl: Readonly<string>, endpoint: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanEndpoint = endpoint.replace(/^\/+/, '');
  return `${normalizedBase}/api/${cleanEndpoint}`;
}

/**
 * Create admin URL
 */
export function createAdminUrl(baseUrl: Readonly<string>, path: Readonly<string> = ''): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = path.replace(/^\/+/, '');
  return cleanPath ? `${normalizedBase}/admin/${cleanPath}` : `${normalizedBase}/admin`;
}

/**
 * Create media URL
 */
export function createMediaUrl(baseUrl: Readonly<string>, mediaPath: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = mediaPath.replace(/^\/+/, '');
  return `${normalizedBase}/media/${cleanPath}`;
}

/**
 * Create asset URL
 */
export function createAssetUrl(baseUrl: Readonly<string>, assetPath: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = assetPath.replace(/^\/+/, '');
  return `${normalizedBase}/assets/${cleanPath}`;
}

/**
 * Create webhook URL
 */
export function createWebhookUrl(baseUrl: Readonly<string>, webhookPath: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = webhookPath.replace(/^\/+/, '');
  return `${normalizedBase}/webhooks/${cleanPath}`;
}

/**
 * Create callback URL
 */
export function createCallbackUrl(
  baseUrl: Readonly<string>,
  callbackPath: Readonly<string>
): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = callbackPath.replace(/^\/+/, '');
  return `${normalizedBase}/callback/${cleanPath}`;
}

/**
 * Create redirect URL
 */
export function createRedirectUrl(baseUrl: Readonly<string>, targetPath: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanPath = targetPath.replace(/^\/+/, '');
  return `${normalizedBase}/redirect?to=${encodeURIComponent(cleanPath)}`;
}

/**
 * Create pagination URL
 */
export function createPaginationUrl(
  baseUrl: Readonly<string>,
  path: Readonly<string>,
  page: Readonly<number>,
  limit: Readonly<number> = 10
): string {
  const url = createCanonicalUrl(baseUrl, path);
  return addQueryParams(url, {
    page: page.toString(),
    limit: limit.toString(),
  });
}

/**
 * Create search URL
 */
export function createSearchUrl(
  baseUrl: Readonly<string>,
  query: Readonly<string>,
  filters: Readonly<Record<string, string>> = {}
): string {
  const url = createCanonicalUrl(baseUrl, 'search');
  const params = { q: query, ...filters };
  return addQueryParams(url, params);
}

/**
 * Create filter URL
 */
export function createFilterUrl(
  baseUrl: Readonly<string>,
  path: Readonly<string>,
  filters: Readonly<Record<string, string>>
): string {
  const url = createCanonicalUrl(baseUrl, path);
  return addQueryParams(url, filters);
}

/**
 * Create sort URL
 */
export function createSortUrl(
  baseUrl: Readonly<string>,
  path: Readonly<string>,
  sortBy: Readonly<string>,
  sortOrder: 'asc' | 'desc' = 'desc'
): string {
  const url = createCanonicalUrl(baseUrl, path);
  return addQueryParams(url, {
    sort: `${sortOrder === 'desc' ? '-' : ''}${sortBy}`,
  });
}

/**
 * Create category URL
 */
export function createCategoryUrl(
  baseUrl: Readonly<string>,
  categorySlug: Readonly<string>
): string {
  return createCanonicalUrl(baseUrl, `category/${categorySlug}`);
}

/**
 * Create post URL
 */
export function createPostUrl(baseUrl: Readonly<string>, postSlug: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, `posts/${postSlug}`);
}

/**
 * Create page URL
 */
export function createPageUrl(baseUrl: Readonly<string>, pageSlug: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, pageSlug);
}

/**
 * Create user profile URL
 */
export function createUserProfileUrl(
  baseUrl: Readonly<string>,
  username: Readonly<string>
): string {
  return createCanonicalUrl(baseUrl, `user/${username}`);
}

/**
 * Create product URL
 */
export function createProductUrl(baseUrl: Readonly<string>, productSlug: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, `products/${productSlug}`);
}

/**
 * Create event URL
 */
export function createEventUrl(baseUrl: Readonly<string>, eventSlug: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, `events/${eventSlug}`);
}

/**
 * Create fight URL
 */
export function createFightUrl(baseUrl: Readonly<string>, fightSlug: Readonly<string>): string {
  return createCanonicalUrl(baseUrl, `fights/${fightSlug}`);
}

/**
 * Create YouTube video URL
 */
export function createYouTubeUrl(videoId: Readonly<string>): string {
  return `https://www.youtube.com/watch?v=${videoId}`;
}

/**
 * Extract YouTube video ID from URL using modern string methods
 */
export function extractYouTubeVideoId(url: Readonly<string>): string | null {
  try {
    const urlObj = new URL(url);

    // Handle youtube.com/watch?v=VIDEO_ID
    if (urlObj.hostname === 'www.youtube.com' && urlObj.pathname === '/watch') {
      return urlObj.searchParams.get('v') || null;
    }

    // Handle youtu.be/VIDEO_ID
    if (urlObj.hostname === 'youtu.be') {
      return urlObj.pathname.slice(1) || null; // Remove leading slash
    }

    // Handle youtube.com/embed/VIDEO_ID
    if (urlObj.hostname === 'www.youtube.com' && urlObj.pathname.startsWith('/embed/')) {
      return urlObj.pathname.split('/')[2] || null;
    }

    // Handle youtube.com/v/VIDEO_ID
    if (urlObj.hostname === 'www.youtube.com' && urlObj.pathname.startsWith('/v/')) {
      return urlObj.pathname.split('/')[2] || null;
    }

    return null;
  } catch {
    return null;
  }
}

/**
 * Create social media share URL
 */
export function createSocialShareUrl(
  platform: 'facebook' | 'twitter' | 'linkedin' | 'reddit',
  url: Readonly<string>,
  title?: string,
  _description?: string
): string {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = title ? encodeURIComponent(title) : '';
  switch (platform) {
    case 'facebook':
      return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
    case 'twitter':
      return `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`;
    case 'linkedin':
      return `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
    case 'reddit':
      return `https://reddit.com/submit?url=${encodedUrl}&title=${encodedTitle}`;
    default:
      return url;
  }
}

/**
 * Create email share URL
 */
export function createEmailShareUrl(
  url: Readonly<string>,
  subject?: string,
  body?: string
): string {
  const encodedUrl = encodeURIComponent(url);
  const encodedSubject = subject ? encodeURIComponent(subject) : '';
  const encodedBody = body ? encodeURIComponent(body) : '';

  return `mailto:?subject=${encodedSubject}&body=${encodedBody}%0A%0A${encodedUrl}`;
}

/**
 * Validate URL format
 */
export function isValidUrl(url: Readonly<string>): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

/**
 * Sanitize URL (remove potentially dangerous characters)
 */
export function sanitizeUrl(url: Readonly<string>): string {
  return url
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/javascript:/gi, '') // Remove javascript protocol
    .replace(/data:/gi, '') // Remove data protocol
    .trim();
}

/**
 * reveal-optimized URL validation with edge compatibility
 */
export function isValidrevealUrl(url: Readonly<string>): boolean {
  try {
    const urlObj = new URL(url);
    // reveal: Ensure URL uses web standards
    return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * reveal-optimized URL sanitization for edge compatibility
 */
export function sanitizerevealUrl(url: Readonly<string>): string {
  return url
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/javascript:/gi, '') // Remove javascript protocol
    .replace(/data:/gi, '') // Remove data protocol
    .replace(/vbscript:/gi, '') // Remove vbscript protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
}

/**
 * Create reveal-optimized API URL with edge compatibility
 */
export function createrevealApiUrl(baseUrl: Readonly<string>, endpoint: Readonly<string>): string {
  const normalizedBase = normalizeUrl(baseUrl);
  const cleanEndpoint = endpoint.replace(/^\/+/, '');
  return `${normalizedBase}/api/${cleanEndpoint}`;
}

/**
 * Get URL path segments
 */
export function getUrlPathSegments(url: Readonly<string>): string[] {
  try {
    const urlObj = new URL(url);
    return urlObj.pathname.split('/').filter(segment => segment.length > 0);
  } catch {
    return [];
  }
}

/**
 * Get URL file extension
 */
export function getUrlFileExtension(url: Readonly<string>): string | null {
  try {
    const urlObj = new URL(url);
    const { pathname } = urlObj;
    const lastDotIndex = pathname.lastIndexOf('.');

    if (lastDotIndex === -1) {
      return null;
    }

    return pathname.substring(lastDotIndex + 1).toLowerCase();
  } catch {
    return null;
  }
}

/**
 * Get server-side URL for the current environment
 * This function returns the appropriate server URL based on the environment
 */
export function getServerSideURL(): string {
  return getEnvVarWithFallback(
    'REVEAL_PUBLIC_SERVER_URL' as keyof EnvironmentVariables,
    'http://localhost:3000'
  );
}

/**
 * Get client-side URL for the current environment
 * This function returns the appropriate client URL based on the environment
 */
export function getClientSideURL(): string {
  return getEnvVarWithFallback(
    'REVEAL_PUBLIC_CLIENT_URL' as keyof EnvironmentVariables,
    'http://localhost:3000'
  );
}

/**
 * Get base URL for the current environment
 * This function returns the appropriate base URL based on the environment
 */
export function getBaseURL(): string {
  return getEnvVarWithFallback(
    'NEXT_PUBLIC_BASE_URL' as keyof EnvironmentVariables,
    'http://localhost:3000'
  );
}

/**
 * Generate preview path for content items
 * This function creates the appropriate preview URL path for different content types
 */
export function generatePreviewPath(
  slug: Readonly<string>,
  contentType: Readonly<string> = 'page'
): string {
  const cleanSlug = slug.replace(/^\/+|\/+$/g, ''); // Remove leading/trailing slashes

  switch (contentType) {
    case 'page':
      return cleanSlug === 'home' ? '/' : `/${cleanSlug}`;
    case 'post':
      return `/posts/${cleanSlug}`;
    case 'category':
      return `/category/${cleanSlug}`;
    case 'product':
      return `/products/${cleanSlug}`;
    case 'event':
      return `/events/${cleanSlug}`;
    case 'fight':
      return `/fights/${cleanSlug}`;
    default:
      return `/${cleanSlug}`;
  }
}
