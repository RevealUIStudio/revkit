const REVEAL_DISABLE_KEY = 'REVEAL_DISABLE_EXTERNAL_PLUGINS';
const REVEAL_DISABLE_OVERRIDE_KEY = 'REVEAL_DISABLE_EXTERNAL_PLUGINS_OVERRIDE';
const NEXT_PUBLIC_ANALYZER_FLAG = 'NEXT_PUBLIC_ANALYZER_BUILD';

let analyzerModeCache: boolean | undefined;

export function isAnalyzerBuild(): boolean {
  if (typeof analyzerModeCache === 'boolean') {
    return analyzerModeCache;
  }

  analyzerModeCache =
    process.env[REVEAL_DISABLE_OVERRIDE_KEY] === 'true' ||
    process.env[REVEAL_DISABLE_KEY] === 'true';

  return analyzerModeCache;
}

export function configureAnalyzerLogging(): void {
  const analyzerBuild = isAnalyzerBuild();

  if (analyzerBuild) {
    process.env[NEXT_PUBLIC_ANALYZER_FLAG] = 'true';
  } else if (!process.env[NEXT_PUBLIC_ANALYZER_FLAG]) {
    process.env[NEXT_PUBLIC_ANALYZER_FLAG] = 'false';
  }

  if (!analyzerBuild) {
    return;
  }

  const currentLevel = (process.env['LOG_LEVEL'] || '').toLowerCase();
  const shouldReduceNoise =
    !currentLevel ||
    currentLevel === 'debug' ||
    currentLevel === 'info' ||
    currentLevel === 'trace';

  if (shouldReduceNoise) {
    process.env['LOG_LEVEL'] = 'warn';
  }

  if (!process.env['REVEAL_LOG_LEVEL']) {
    process.env['REVEAL_LOG_LEVEL'] = process.env['LOG_LEVEL'];
  }
}
