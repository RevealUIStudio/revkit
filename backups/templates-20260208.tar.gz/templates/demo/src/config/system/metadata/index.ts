/**
 * Project Metadata
 *
 * Centralized location for framework configurations and project metadata.
 * These are JSON files that should be imported directly when needed.
 *
 * @module config/system/metadata
 * @example
 * ```typescript
 * // Import JSON metadata files directly
 * import frameworkConfig from '@/config/system/metadata/framework-config.json';
 * import versionMatrix from '@/config/system/metadata/version-matrix.json';
 * import projectStructure from '@/config/system/metadata/project-structure.json';
 * ```
 */

// Note: These are JSON files, so import them directly when needed:
// - framework-config.json - Framework and build tool configurations
// - version-matrix.json - Dependency version compatibility matrix
// - project-structure.json - Project structure and organization metadata
