/**
 * System Configuration
 *
 * Centralized exports for system-wide utilities and helpers including:
 * - Utility functions (dates, URLs, generation, type guards, results)
 * - Validation (configuration validators, domain validators)
 * - Error classes and error handling
 * - Constants (media prefixes, etc.)
 * - Metadata (framework config, version matrix, project structure)
 *
 * @module config/system
 * @example
 * ```typescript
 * // Date utilities
 * import { formatDateISO, getRelativeTime } from '@/config/system/utilities';
 *
 * // Generation utilities
 * import { generateUUID, generateSlug } from '@/config/system/utilities';
 *
 * // Validation
 * import { ValidationUtils } from '@/config/system/validators';
 * ValidationUtils.validateEmail('user@example.com');
 *
 * // Errors
 * import { ConfigurationError } from '@/config/system/errors';
 * ```
 */

// ===== Utilities =====

// Date utilities
export {
  formatDateISO,
  formatDateReadable,
  formatDateTimeReadable,
  getRelativeTime,
  parseDate,
  isToday,
  isYesterday,
  isFuture,
  isPast,
  startOfDay,
  endOfDay,
  addDays,
  subtractDays,
  getDaysBetween,
  isDateInRange,
  isValidDateString,
  getCurrentTimestamp,
  getCurrentDateISO,
  formatDuration,
} from './utilities/dates.ts';

// URL utilities
export {
  joinUrlPath,
  createAbsoluteUrl,
  createRelativeUrl,
  extractDomain,
  extractPath,
  extractQueryParams,
  addQueryParams,
  removeQueryParams,
  isAbsoluteUrl,
  isRelativeUrl,
  isInternalUrl,
  isExternalUrl,
  normalizeUrl,
  createCanonicalUrl,
  createSitemapUrl,
  createApiUrl,
  createAdminUrl,
  createMediaUrl,
  createAssetUrl,
  createWebhookUrl,
  createCallbackUrl,
  createRedirectUrl,
  createPaginationUrl,
  createSearchUrl,
  createFilterUrl,
  createSortUrl,
  createCategoryUrl,
  createPostUrl,
  createPageUrl,
  createUserProfileUrl,
  createProductUrl,
  createEventUrl,
  createFightUrl,
  createYouTubeUrl,
  extractYouTubeVideoId,
  createSocialShareUrl,
  createEmailShareUrl,
  isValidUrl,
  sanitizeUrl,
  getUrlPathSegments,
  getUrlFileExtension,
  getServerSideURL,
  getClientSideURL,
  getBaseURL,
  generatePreviewPath,
} from './utilities/urls.ts';

// Generation utilities
export {
  generateUUID,
  generateRandomString,
  generateRandomNumeric,
  generateRandomAlphanumeric,
  generateRandomHex,
  generateSecureToken,
  generateShortId,
  generateMediumId,
  generateLongId,
  generateSlug,
  generateUniqueSlug,
  generateCorrelationId,
  generateSessionId,
  generateRequestId,
  generateTransactionId,
  generateReferenceNumber,
  generateOrderNumber,
  generateSKU,
  generateTrackingNumber,
  generateCouponCode,
  generatePasswordResetToken,
  generateEmailVerificationToken,
  generateAPIKey,
  generateWebhookSecret,
  generateNonce,
  generateChallengeToken,
  generateFingerprint,
  generateChecksum,
  generateHash,
  generateMeta,
  mergeOpenGraph,
} from './utilities/generation.ts';

// Type guards
export {
  isUserSession,
  isStringArray,
  isValidDate,
  isValidURL,
  isValidEmail,
  isValidToken,
} from './utilities/type-guards.ts';

// Result helpers
export {
  serviceSuccess,
  serviceFailure,
  serviceSuccessWithMetrics,
  serviceFailureWithDetails,
} from './utilities/results.ts';

// ===== Validators =====

// Domain validators
export {
  validationSuccess,
  validationFailure,
  validateRequired,
  validateMinLength,
  validateMaxLength,
  validateEmail,
  ValidationUtils,
} from './validators/domain.ts';

// Configuration validators
export {
  configurationValidator,
  validateConfigWithRules,
  ValidationRules,
  type ValidationRule,
  type ValidationResult,
} from './validators/configuration.ts';

// ===== Constants =====
export {
  PREFIXES_COLLECTION,
  PREFIXES_ADMIN_CONFIG,
  PREFIXES_VALIDATION,
  PREFIXES_FIELD_DESCRIPTIONS,
  PREFIXES_ERROR_MESSAGES,
  ALLOWED_TYPES,
  DEFAULT_ALLOWED_TYPES,
  MAX_MEDIA_PER_PREFIX,
} from './constants/prefixes.ts';

// ===== Environment Utilities =====
export {
  getEnvVar,
  getEnvVarWithFallback,
  getBooleanEnvVar,
  getNumericEnvVar,
  validateEnvironment,
  getCurrentEnvironment,
  validateRequiredEnvVarsAtBuildTime,
} from './environment/index.ts';

// ===== Metadata =====
// Note: Metadata files are JSON and should be imported directly when needed
// - framework-config.json
// - version-matrix.json
// - project-structure.json
