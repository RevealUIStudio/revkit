export interface ValidationRule<T> {
  field: keyof T;
  validator: (value: unknown) => boolean;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  isValid: boolean;
  errors: Array<{ field: string; message: string; severity: 'error' | 'warning' }>;
  warnings: Array<{ field: string; message: string; severity: 'error' | 'warning' }>;
}

export class ConfigurationValidator {
  // Using Record<string, unknown> because configuration structure varies by configuration type and cannot be strictly typed
  validate<T extends Record<string, unknown>>(
    config: T,
    rules: ValidationRule<T>[]
  ): ValidationResult {
    const errors: ValidationResult['errors'] = [];
    const warnings: ValidationResult['warnings'] = [];

    for (const rule of rules) {
      const value = config[rule.field];
      if (!rule.validator(value)) {
        const issue = {
          field: String(rule.field),
          message: rule.message,
          severity: rule.severity,
        };
        if (rule.severity === 'error') {
          errors.push(issue);
        } else {
          warnings.push(issue);
        }
      }
    }

    return { isValid: errors.length === 0, errors, warnings };
  }
}

export const configurationValidator = new ConfigurationValidator();

export function requiredRule<T>(field: keyof T, message?: string): ValidationRule<T> {
  return {
    field,
    validator: value => value !== null && value !== undefined && value !== '',
    message: message ?? `Field '${String(field)}' is required`,
    severity: 'error',
  };
}

export const ValidationRules = {
  required: requiredRule,
} as const;

// Using Record<string, unknown> because configuration structure varies by configuration type and cannot be strictly typed
export function validateConfigWithRules<T extends Record<string, unknown>>(
  config: T,
  rules: ValidationRule<T>[]
): ValidationResult {
  return configurationValidator.validate(config, rules);
}
