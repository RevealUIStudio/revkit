export interface ValidationError {
  field: string;
  message: string;
  code?: string;
}

export interface ValidationResult<T> {
  isValid: boolean;
  data?: T;
  errors?: ValidationError[];
  warnings?: ValidationError[];
}

export function validationSuccess<T>(data: T): ValidationResult<T> {
  return { isValid: true, data };
}

export function validationFailure<T>(errors: ValidationError[]): ValidationResult<T> {
  return { isValid: false, errors };
}

export function validateRequired<T>(
  value: T | null | undefined,
  fieldName: string
): ValidationResult<T> {
  if (
    value === null ||
    value === undefined ||
    (typeof value === 'string' && value.trim().length === 0)
  ) {
    return validationFailure([{ field: fieldName, message: `${fieldName} is required` }]);
  }
  return validationSuccess(value);
}

export function validateMinLength(
  value: string,
  minLength: number,
  fieldName: string
): ValidationResult<string> {
  if (value.length < minLength) {
    return validationFailure([
      { field: fieldName, message: `${fieldName} must be at least ${minLength} characters long` },
    ]);
  }
  return validationSuccess(value);
}

export function validateMaxLength(
  value: string,
  maxLength: number,
  fieldName: string
): ValidationResult<string> {
  if (value.length > maxLength) {
    return validationFailure([
      {
        field: fieldName,
        message: `${fieldName} must be no more than ${maxLength} characters long`,
      },
    ]);
  }
  return validationSuccess(value);
}

export function validateEmail(email: string): ValidationResult<string> {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email)
    ? validationSuccess(email)
    : validationFailure([{ field: 'email', message: 'Invalid email format' }]);
}

// Array validation utilities
export function isEmptyArray(value: unknown): boolean {
  if (value === null || value === undefined) {
    return true;
  }
  if (!Array.isArray(value)) {
    return true;
  }
  return value.length === 0;
}

export function isNotEmptyArray(value: unknown): boolean {
  return !isEmptyArray(value);
}

export function validateArrayLength(value: unknown, maxLength: number): boolean {
  if (value === null || value === undefined) {
    return true; // Allow null/undefined
  }
  if (!Array.isArray(value)) {
    return false;
  }
  return value.length <= maxLength;
}

// Additional validation functions
export function validateSlug(slug: string): ValidationResult<string> {
  if (!slug || typeof slug !== 'string') {
    return validationFailure([{ field: 'slug', message: 'Slug is required' }]);
  }

  // Slug must be lowercase, alphanumeric with hyphens, no spaces
  const slugRegex = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
  if (!slugRegex.test(slug)) {
    return validationFailure([
      { field: 'slug', message: 'Slug must be lowercase alphanumeric with hyphens only' },
    ]);
  }

  // Cannot start or end with hyphen
  if (slug.startsWith('-') || slug.endsWith('-')) {
    return validationFailure([{ field: 'slug', message: 'Slug cannot start or end with hyphen' }]);
  }

  return validationSuccess(slug);
}

export function validateUsername(username: string): ValidationResult<string> {
  if (!username || typeof username !== 'string') {
    return validationFailure([{ field: 'username', message: 'Username is required' }]);
  }

  // Username can contain letters, numbers, underscores, and hyphens
  const usernameRegex = /^[a-zA-Z0-9_-]+$/;
  if (!usernameRegex.test(username)) {
    return validationFailure([
      {
        field: 'username',
        message: 'Username can only contain letters, numbers, underscores, and hyphens',
      },
    ]);
  }

  return validationSuccess(username);
}

export function validateRange(
  value: number,
  min: number,
  max: number,
  fieldName: string
): ValidationResult<number> {
  if (typeof value !== 'number' || Number.isNaN(value)) {
    return validationFailure([{ field: fieldName, message: `${fieldName} must be a number` }]);
  }

  if (value < min || value > max) {
    return validationFailure([
      { field: fieldName, message: `${fieldName} must be between ${min} and ${max}` },
    ]);
  }

  return validationSuccess(value);
}

export const ValidationUtils = {
  validateRequired(value: unknown, fieldName: string): void {
    const result = validateRequired(value, fieldName);
    if (!result.isValid) {
      throw new Error(result.errors?.[0]?.message ?? `${fieldName} is required`);
    }
  },
  validateEmail(email: string): void {
    const emailResult = validateEmail(email);
    if (!emailResult.isValid) {
      throw new Error(emailResult.errors?.[0]?.message ?? 'Invalid email format');
    }
  },
  validateSlug(slug: string): void {
    const slugResult = validateSlug(slug);
    if (!slugResult.isValid) {
      throw new Error(slugResult.errors?.[0]?.message ?? 'Invalid slug format');
    }
  },
  validateUsername(username: string): void {
    const usernameResult = validateUsername(username);
    if (!usernameResult.isValid) {
      throw new Error(usernameResult.errors?.[0]?.message ?? 'Invalid username format');
    }
  },
  validateRange(value: number, min: number, max: number, fieldName: string): void {
    const rangeResult = validateRange(value, min, max, fieldName);
    if (!rangeResult.isValid) {
      throw new Error(rangeResult.errors?.[0]?.message ?? `${fieldName} is out of range`);
    }
  },
} as const;
