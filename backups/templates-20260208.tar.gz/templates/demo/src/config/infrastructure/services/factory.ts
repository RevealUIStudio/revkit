import {
  getCategoryService as getContentCategoryService,
  getPostService as getContentPostService,
} from '@/features/content/services';
import { getRevealUIClient } from '@revealui/infrastructure/cms/utils/DatabaseConnection';
import { CategoryRepository } from '@revealui/infrastructure/data-access/repositories/CategoryRepository';
import { ContentManagementService } from '@/presentation/services/ContentManagementService';
import { HomePageService } from '@/presentation/services/HomePageService';
import { UserApplicationService } from '@/presentation/services/UserApplicationService';
import { UserManagementService } from '@/presentation/services/UserManagementService';
import { UserMediaService } from '@/presentation/services/UserMediaService';
import { UserServiceCoordinator } from '@/presentation/services/UserServiceCoordinator';
import type { CategoryService, PostService } from '@revealui/content';
import type { RevealUI } from '@revealui/content';

let initialized = false;
let revealuiRef: RevealUI | null = null;

const repositoryCache = new Map<string, unknown>();
const serviceCache = new Map<string, unknown>();

async function initialize(revealui?: RevealUI): Promise<void> {
  revealuiRef = revealui ?? (await getRevealUIClient());
  repositoryCache.clear();
  serviceCache.clear();
  initialized = true;
}

async function cleanup(): Promise<void> {
  repositoryCache.clear();
  serviceCache.clear();
  revealuiRef = null;
  initialized = false;
}

function ensureInitialized(): void {
  if (!initialized || !revealuiRef) {
    throw new Error('ServiceFactory.initialize must be called before accessing services.');
  }
}

function getCategoryRepositoryInternal(): CategoryRepository {
  ensureInitialized();
  if (!revealuiRef) {
    throw new Error('RevealUI reference is null - initialization failed');
  }
  if (!repositoryCache.has('category')) {
    repositoryCache.set('category', new CategoryRepository(revealuiRef));
  }
  return repositoryCache.get('category') as CategoryRepository;
}

function getServiceInstance<T>(key: string, factory: () => T): T {
  ensureInitialized();
  if (!serviceCache.has(key)) {
    serviceCache.set(key, factory());
  }
  return serviceCache.get(key) as T;
}

export const ServiceFactory = {
  initialize,
  cleanup,
  getCategoryRepository: getCategoryRepositoryInternal,
  // Use package services directly - these are async and use singleton pattern
  getCategoryService: async () => getContentCategoryService(revealuiRef),
  getPostService: async () => getContentPostService(revealuiRef),
  getContentManagementService: () =>
    getServiceInstance('content-service', () => new ContentManagementService()),
  getHomePageService: () => getServiceInstance('home-service', () => new HomePageService()),
  getUserService: () => getServiceInstance('user-service', () => new UserApplicationService()),
  getUserManagementService: () =>
    getServiceInstance('user-management-service', () => new UserManagementService()),
  getUserMediaService: () => getServiceInstance('user-media-service', () => new UserMediaService()),
  getUserServiceCoordinator: () =>
    getServiceInstance('user-coordinator', () => new UserServiceCoordinator()),
} as const;

export async function initializeServiceFactory(revealui?: RevealUI): Promise<void> {
  await ServiceFactory.initialize(revealui);
}

export async function cleanupServiceFactory(): Promise<void> {
  await ServiceFactory.cleanup();
}

export function getCategoryRepository(): CategoryRepository {
  return ServiceFactory.getCategoryRepository();
}
