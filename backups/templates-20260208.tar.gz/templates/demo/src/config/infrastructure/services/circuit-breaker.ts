import type { CircuitBreakerConfig, FailureDetectionStrategy } from '@revealui/core/shared-types';

export const circuitBreakerConfig: CircuitBreakerConfig = {
  failureThreshold: 5,
  resetTimeout: 30_000,
  monitorInterval: 1_000,
};

export class DefaultFailureDetectionStrategy implements FailureDetectionStrategy {
  isFailure(error: unknown): boolean {
    return error instanceof Error;
  }
}
