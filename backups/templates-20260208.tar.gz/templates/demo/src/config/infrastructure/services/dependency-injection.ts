export class DependencyInjectionContainer {
  private static instance: DependencyInjectionContainer | null = null;

  private constructor() {}

  static getInstance(): DependencyInjectionContainer {
    if (!DependencyInjectionContainer.instance) {
      DependencyInjectionContainer.instance = new DependencyInjectionContainer();
    }
    return DependencyInjectionContainer.instance;
  }

  async initialize(_revealui: unknown): Promise<void> {
    // no-op in strict-mode stub
  }

  getRepository<T>(_type: string): T {
    return undefined as unknown as T;
  }

  getApplicationService<T>(_type: string): T {
    return undefined as unknown as T;
  }

  async cleanup(): Promise<void> {
    // no-op
  }
}

export function getContainer(): DependencyInjectionContainer {
  return DependencyInjectionContainer.getInstance();
}

export function getRepository<T>(type: string): T {
  return getContainer().getRepository<T>(type);
}

export function getApplicationService<T>(type: string): T {
  return getContainer().getApplicationService<T>(type);
}
