/**
 * Service Configuration
 *
 * Centralized exports for service-related configurations including:
 * - Service factory (creates and manages service instances)
 * - Dependency injection container (DI/IoC container)
 * - Circuit breaker (fault tolerance configuration)
 * - Rate limiter (API rate limiting configuration)
 * - Encryption (encryption algorithm and key configuration)
 * - Service discovery (service registry and discovery)
 *
 * @module config/services
 * @example
 * ```typescript
 * // Get service from factory
 * import { ServiceFactory } from '@/config/services';
 * const postService = await ServiceFactory.getPostService();
 *
 * // Use dependency injection
 * import { getRepository } from '@/config/services';
 * const userRepo = getRepository('user');
 *
 * // Get rate limiter config
 * import { rateLimiterConfig } from '@/config/services';
 * ```
 */

// Service factory and DI
export * from './dependency-injection.ts';
export * from './factory.ts';

// Service infrastructure
export * from './circuit-breaker.ts';
export * from './discovery.ts';
export * from './encryption.ts';
export * from './rate-limiter.ts';
