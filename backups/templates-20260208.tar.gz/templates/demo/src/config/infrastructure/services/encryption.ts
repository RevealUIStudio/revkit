import type { EncryptionConfig } from '@revealui/core/shared-types';

export const encryptionConfig: EncryptionConfig = {
  algorithm: 'aes-256-gcm',
  keyLength: 32,
  saltRounds: 10,
};
