import type { ServiceDiscoveryConfig } from '@revealui/core/shared-types';

export const serviceDiscoveryConfig: ServiceDiscoveryConfig = {
  refreshInterval: 30_000,
  timeout: 5_000,
  retryAttempts: 3,
};
