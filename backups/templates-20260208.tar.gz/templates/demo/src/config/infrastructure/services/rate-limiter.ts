import type { RateLimiterConfig } from '@revealui/core/shared-types';

export const rateLimiterConfig: RateLimiterConfig = {
  enabled: true,
  windowMs: 900_000,
  max: 1000,
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
  message: 'Too many requests, please try again later.',
};
