export class ConfigurationCache<T> {
  constructor(private readonly supplier: () => Promise<T>) {}

  async get(): Promise<T> {
    return this.supplier();
  }
}
