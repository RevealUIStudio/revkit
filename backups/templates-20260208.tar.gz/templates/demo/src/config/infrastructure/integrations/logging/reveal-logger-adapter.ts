import type { RevealUILoggerAdapterConfig } from '@revealui/core/shared-types';

export const defaultRevealUILoggerAdapterConfig: RevealUILoggerAdapterConfig = {
  enabled: false,
};

export function createRevealUILoggerAdapter() {
  return {
    info: () => undefined,
    warn: () => undefined,
    error: () => undefined,
  };
}
