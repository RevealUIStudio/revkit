/**
 * RevealUI Content Engine Configuration Utilities
 *
 * Centralized exports for RevealUI Content Engine-specific configuration and helpers including:
 * - Request extraction (user ID, role, tenant ID, metadata)
 * - Query builders (find options, where clauses)
 * - Data sanitization (revealui data cleaning)
 * - Where clause helpers (published, draft filters)
 *
 * @module config/infrastructure/integrations/revealui
 * @example
 * ```typescript
 * // Extract data from RevealUI Content Engine request
 * import { extractUserIdFromReveal, extractUserRoleFromReveal } from '@/config/infrastructure/integrations/revealui';
 * const userId = extractUserIdFromReveal(req.revealui);
 *
 * // Create query options
 * import { createRevealQueryOptions, createPublishedWhere } from '@/config/infrastructure/integrations/revealui';
 * const options = createRevealQueryOptions({ where: createPublishedWhere() });
 * ```
 */

export * from './utilities.ts';
