export const revealuiRequestContext = {
  getClientIp: () => '127.0.0.1',
  getUserAgent: () => 'unknown',
};

export function withRevealUILogging<T>(operation: () => Promise<T>): Promise<T> {
  return operation();
}
