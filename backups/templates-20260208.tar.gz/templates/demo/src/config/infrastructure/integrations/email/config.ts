import { getEnvVarWithFallback } from '@/config/system/environment';
import type { EmailConfig } from '@/contracts';

/**
 * Default email configuration
 */
export const defaultEmailConfig: EmailConfig = {
  provider: getEnvVarWithFallback('EMAIL_PROVIDER', 'smtp') as EmailConfig['provider'],
  smtp: {
    host: getEnvVarWithFallback('SMTP_HOST', 'localhost'),
    port: Number.parseInt(getEnvVarWithFallback('SMTP_PORT', '587'), 10),
    secure: getEnvVarWithFallback('SMTP_SECURE', 'false') === 'true',
    username: getEnvVarWithFallback('SMTP_USERNAME', ''),
    password: getEnvVarWithFallback('SMTP_PASSWORD', ''),
  },
  from: getEnvVarWithFallback('FROM_EMAIL', 'noreply@reveal-ui.com'),
};
