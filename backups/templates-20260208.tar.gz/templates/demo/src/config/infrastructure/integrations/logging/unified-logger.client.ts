// Client-safe logger that doesn't use any Node.js APIs
export class ClientLogger {
  private context: string;

  constructor(context: string = 'client') {
    this.context = context;
  }

  info(message: string, data?: unknown): void {
    console.log(`[${this.context}] ${message}`, data);
  }

  warn(message: string, data?: unknown): void {
    console.warn(`[${this.context}] ${message}`, data);
  }

  error(message: string, data?: unknown): void {
    console.error(`[${this.context}] ${message}`, data);
  }

  debug(message: string, data?: unknown): void {
    if (process.env.NODE_ENV === 'development') {
      console.debug(`[${this.context}] ${message}`, data);
    }
  }
}

// Factory functions for client use
export function createContextLogger(context: string): ClientLogger {
  return new ClientLogger(context);
}

export function createServiceLogger(serviceName: string): ClientLogger {
  return new ClientLogger(`service:${serviceName}`);
}

// Default client logger instance
export const clientLogger = new ClientLogger('app');
