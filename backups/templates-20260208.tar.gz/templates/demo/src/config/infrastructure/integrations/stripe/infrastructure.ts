/**
 * Stripe Infrastructure as Code Configuration
 *
 * Defines all Stripe resources that should be created/managed via API.
 * This file serves as the single source of truth for Stripe infrastructure.
 *
 * Version controlled configuration ensures:
 * - Consistent environments (dev/staging/prod)
 * - Reproducible infrastructure
 * - No manual Dashboard clicking
 * - Easy disaster recovery
 *
 * Related Configuration:
 * - Payment Config: @/config/presentation/payment.ts
 *   Contains application-level payment provider configuration (keys, currency, provider)
 *   This file handles Stripe resource definitions (products, prices, webhooks),
 *   while the payment config file manages basic payment provider settings.
 */

/**
 * Webhook events that must be configured
 * These are automatically created when bootstrapping
 */
export const REQUIRED_WEBHOOK_EVENTS = [
  'product.created',
  'product.updated',
  'product.deleted',
  'price.updated',
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
  'checkout.session.completed',
  'payment_intent.succeeded',
  'payment_intent.payment_failed',
  'charge.succeeded',
  'invoice.created',
  'invoice.paid',
  'invoice.payment_failed',
  'invoice.upcoming',
  'customer.subscription.trial_will_end',
  'billing.usage_record.created',
] as const;

/**
 * Subscription tiers/products to create
 *
 * Implements utility-style hybrid pricing:
 * - Base subscription + included credits
 * - Metered billing for overage
 * - Outcome-based pricing for AI features
 * - 14-day trials for Starter and Pro
 * - Credit rollover for 1 month
 *
 * Add/modify products here and run bootstrap script to apply
 */
export const SUBSCRIPTION_PRODUCTS = [
  {
    id: 'starter',
    name: 'Starter Plan',
    description:
      'Perfect for individuals getting started. Includes 10,000 credits/month with metered billing for overage.',
    features: [
      '1 tenant/workspace',
      '5GB storage included',
      '1,000 API calls/month included',
      '100 AI workflow completions/month included',
      '10,000 credits/month included',
      'Metered billing for overage',
      'Email support (48h response)',
      '14-day free trial',
      'Credit rollover (1 month)',
    ],
    pricing: {
      monthly: {
        amount: 19.99,
        currency: 'usd' as const,
        interval: 'month' as const,
      },
      yearly: {
        amount: 199.0, // 2 months free
        currency: 'usd' as const,
        interval: 'year' as const,
      },
    },
    metadata: {
      tier: 'starter',
      includedCredits: '10000',
      overageRate: '0.001',
      trialDays: '14',
      creditRolloverMonths: '1',
      features: 'basic_content,email_support',
    },
  },
  {
    id: 'pro',
    name: 'Pro Plan',
    description:
      'For professionals and power users. Includes 50,000 credits/month with advanced features.',
    features: [
      '3 tenants/workspaces',
      '20GB storage included',
      '5,000 API calls/month included',
      '500 AI workflow completions/month included',
      '50,000 credits/month included',
      'Advanced analytics',
      'API access',
      'Custom branding',
      'Team collaboration',
      'Priority support (24h response)',
      '14-day free trial',
      'Credit rollover (1 month)',
    ],
    pricing: {
      monthly: {
        amount: 49.99,
        currency: 'usd' as const,
        interval: 'month' as const,
      },
      yearly: {
        amount: 499.0, // 2 months free
        currency: 'usd' as const,
        interval: 'year' as const,
      },
    },
    metadata: {
      tier: 'pro',
      includedCredits: '50000',
      overageRate: '0.001',
      trialDays: '14',
      creditRolloverMonths: '1',
      features:
        'basic_content,advanced_analytics,api_access,custom_branding,team_collaboration,priority_support',
    },
  },
  {
    id: 'business',
    name: 'Business Plan',
    description:
      'For established organizations. Includes 100,000 credits/month with 20% discount on overage.',
    features: [
      '10 tenants/workspaces',
      '100GB storage included',
      '20,000 API calls/month included',
      '2,000 AI workflow completions/month included',
      '100,000 credits/month included',
      '20% discount on overage rates',
      'SSO/SAML',
      'Audit logs',
      'RBAC',
      'Advanced analytics',
      'API access',
      'Custom branding',
      'Custom integrations',
      'Priority support (same-day response)',
      'Onboarding assistance',
      'Credit rollover (1 month)',
    ],
    pricing: {
      monthly: {
        amount: 199.0,
        currency: 'usd' as const,
        interval: 'month' as const,
      },
      yearly: {
        amount: 1999.0, // 2 months free
        currency: 'usd' as const,
        interval: 'year' as const,
      },
    },
    metadata: {
      tier: 'business',
      includedCredits: '100000',
      overageRate: '0.0008',
      trialDays: '0',
      creditRolloverMonths: '1',
      features:
        'advanced_content,advanced_analytics,api_access,custom_branding,sso_saml,audit_logs,rbac,custom_integrations,priority_support',
    },
  },
  {
    id: 'enterprise',
    name: 'Enterprise Plan',
    description:
      'Custom solutions for large organizations. Unlimited credits and custom feature development.',
    features: [
      'Unlimited everything',
      'Unlimited credits (no overage charges)',
      'On-premise deployment option',
      'Custom feature development (40 hours/month)',
      'Dedicated support team',
      '1-hour response SLA',
      'SLA guarantees',
      'Custom integrations',
      'Credit rollover (1 month)',
    ],
    pricing: {
      monthly: {
        amount: 20000.0,
        currency: 'usd' as const,
        interval: 'month' as const,
      },
      yearly: {
        amount: 200000.0, // 2 months free
        currency: 'usd' as const,
        interval: 'year' as const,
      },
    },
    metadata: {
      tier: 'enterprise',
      includedCredits: 'unlimited',
      overageRate: '0',
      trialDays: '0',
      creditRolloverMonths: '1',
      customFeatureHours: '40',
      features: 'all_features,on_premise,custom_development,dedicated_support,sla_guarantees',
    },
  },
] as const;

/**
 * One-time purchase products
 * For pay-per-view videos, merchandise, credit packs, etc.
 */
export const ONE_TIME_PRODUCTS = [
  {
    id: 'credit-pack-1k',
    name: 'Starter Credit Pack',
    description: '1,000 credits for metered usage',
    pricing: {
      amount: 10.0,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'credit_pack',
      credits: '1000',
      bonusPercent: '0',
    },
  },
  {
    id: 'credit-pack-6k',
    name: 'Growth Credit Pack',
    description: '6,000 credits (20% bonus) for metered usage',
    pricing: {
      amount: 50.0,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'credit_pack',
      credits: '6000',
      bonusPercent: '20',
    },
  },
  {
    id: 'credit-pack-30k',
    name: 'Business Credit Pack',
    description: '30,000 credits (50% bonus) for metered usage',
    pricing: {
      amount: 200.0,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'credit_pack',
      credits: '30000',
      bonusPercent: '50',
    },
  },
  {
    id: 'credit-pack-400k',
    name: 'Enterprise Credit Pack',
    description: '400,000 credits (100% bonus) for metered usage',
    pricing: {
      amount: 2000.0,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'credit_pack',
      credits: '400000',
      bonusPercent: '100',
    },
  },
  {
    id: 'video-rental',
    name: 'Video Rental',
    description: '48-hour rental access to premium video content',
    pricing: {
      amount: 4.99,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'rental',
      duration: '48hours',
    },
  },
  {
    id: 'video-purchase',
    name: 'Video Purchase',
    description: 'Lifetime access to premium video content',
    pricing: {
      amount: 9.99,
      currency: 'usd' as const,
    },
    metadata: {
      type: 'purchase',
      duration: 'lifetime',
    },
  },
] as const;

/**
 * Webhook endpoint configuration
 */
export function getWebhookEndpointConfig(serverUrl: string) {
  return {
    url: `${serverUrl}/api/revealui/stripe/webhooks`,
    description: 'RevealUI Content Engine Stripe Plugin - Managed by Infrastructure as Code',
    enabled_events: REQUIRED_WEBHOOK_EVENTS,
    metadata: {
      managedBy: 'infrastructure-as-code',
      environment: process.env.APP_ENV || 'development',
    },
  };
}

/**
 * Get environment-specific configuration
 */
export function getStripeInfrastructureConfig(
  environment: 'development' | 'staging' | 'production'
) {
  const baseUrl =
    environment === 'production'
      ? process.env.NEXT_PUBLIC_SERVER_URL || 'https://yourdomain.com'
      : environment === 'staging'
        ? process.env.STAGING_URL || 'https://staging.yourdomain.com'
        : 'http://localhost:3000';

  return {
    environment,
    webhookEndpoint: getWebhookEndpointConfig(baseUrl),
    subscriptionProducts: SUBSCRIPTION_PRODUCTS,
    oneTimeProducts: ONE_TIME_PRODUCTS,
  };
}

/**
 * Product ID mapping for easy reference in code
 */
export const PRODUCT_IDS = {
  STARTER: 'starter',
  PRO: 'pro',
  BUSINESS: 'business',
  ENTERPRISE: 'enterprise',
  CREDIT_PACK_1K: 'credit-pack-1k',
  CREDIT_PACK_6K: 'credit-pack-6k',
  CREDIT_PACK_30K: 'credit-pack-30k',
  CREDIT_PACK_400K: 'credit-pack-400k',
  VIDEO_RENTAL: 'video-rental',
  VIDEO_PURCHASE: 'video-purchase',
} as const;

export type ProductId = (typeof PRODUCT_IDS)[keyof typeof PRODUCT_IDS];
