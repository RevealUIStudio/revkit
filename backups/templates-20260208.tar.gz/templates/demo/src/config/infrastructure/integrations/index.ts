/**
 * Integrations Configuration
 *
 * Centralized exports for external service integrations including:
 * - Stripe payment infrastructure
 * - RevealUI Content Engine utilities
 * - Logging system (unified logger, client logger, RevealUI Content Engine adapter)
 * - Email configuration (SMTP, templates)
 * - MCP (Model Context Protocol) agent configuration
 *
 * @module config/infrastructure/integrations
 * @example
 * ```typescript
 * // Stripe infrastructure
 * import { PRODUCT_IDS } from '@/config/infrastructure/integrations/stripe';
 *
 * // RevealUI Content Engine utilities
 * import { extractUserIdFromReveal } from '@/config/infrastructure/integrations/revealui';
 *
 * // Logging
 * import { createContextLogger } from '@/config/infrastructure/integrations/logging';
 * const logger = createContextLogger('my-service');
 *
 * // Email config
 * import { defaultEmailConfig } from '@/config/infrastructure/integrations/email';
 *
 * // MCP agent config
 * import { getAllAgentConfigs } from '@/config/infrastructure/integrations/mcp';
 * ```
 */

// Stripe integration
export * from './stripe/infrastructure.ts';

// RevealUI Content Engine utilities
export * from './revealui/index.ts';

// Logging system
export * from './logging/index.ts';

// Email configuration
export type { EmailConfig } from '@/contracts';
export { defaultEmailConfig } from './email/config.ts';

// MCP integration
export * from './mcp/index.ts';
