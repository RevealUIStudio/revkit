/**
 * MCP Agent Configuration
 *
 * Configuration for Model Context Protocol (MCP) agents.
 * Defines agent types, configurations, and management functions.
 *
 * @module config/infrastructure/integrations/mcp
 */

import type { AgentConfig } from '@revealui/core/shared-types';

type AgentType = 'development' | 'user-facing' | 'coordination' | 'test';

export const developmentAgentConfigs: AgentConfig[] = [];
export const userFacingAgentConfigs: AgentConfig[] = [];
export const coordinationAgentConfigs: AgentConfig[] = [];
export const testAgentConfig: AgentConfig = {
  id: 'ping-pong-001',
  type: 'test',
  enabled: false,
};

export function getAllAgentConfigs(): AgentConfig[] {
  return [
    testAgentConfig,
    ...developmentAgentConfigs,
    ...userFacingAgentConfigs,
    ...coordinationAgentConfigs,
  ];
}

export function getEnabledAgentConfigs(): AgentConfig[] {
  return getAllAgentConfigs().filter(config => config.enabled);
}

export function getAgentConfig(agentId: string): AgentConfig | undefined {
  return getAllAgentConfigs().find(config => config.id === agentId);
}

export function getAgentConfigsByType(type: AgentType): AgentConfig[] {
  return getAllAgentConfigs().filter(config => config.type === type);
}
