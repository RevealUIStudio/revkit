// Logger factory for client/server compatibility
import {
  ClientLogger,
  createContextLogger as clientCreateContextLogger,
  createServiceLogger as clientCreateServiceLogger,
} from './unified-logger.client.ts';

// Export client logger types and utilities
export { ClientLogger };

// Factory functions that work in both environments
export async function createContextLogger(context: string) {
  if (typeof window !== 'undefined') {
    // Client-side
    return clientCreateContextLogger(context);
  }
  // Server-side
  const { createLogger } = await import('@revealui/core/logging');
  return createLogger(context);
}

export async function createServiceLogger(serviceName: string) {
  if (typeof window !== 'undefined') {
    // Client-side
    return clientCreateServiceLogger(serviceName);
  }
  // Server-side
  const { createLogger } = await import('@revealui/core/logging');
  return createLogger(serviceName);
}

// Default logger instance
export const logger = new ClientLogger('app');

// Synchronous devLogger that properly delegates to the real logger
interface LoggerMethods {
  info: (msg: string, data?: unknown) => void;
  warn: (msg: string, data?: unknown) => void;
  error: (msg: string, data?: unknown) => void;
  debug: (msg: string, data?: unknown) => void;
  setReveal?: (revealui: unknown) => void;
}

class DevLoggerProxy {
  private _realLogger: ClientLogger | LoggerMethods | null = null;
  private _isServer = typeof window === 'undefined';

  constructor() {
    if (!this._isServer) {
      this._realLogger = new ClientLogger('dev');
    }
  }

  async _ensureLogger() {
    if (this._isServer && !this._realLogger) {
      const { getLogger } = await import('@revealui/core/logging');
      this._realLogger = getLogger('dev');
    }
  }

  async info(message: string, data?: unknown) {
    await this._ensureLogger();
    if (this._realLogger && typeof this._realLogger === 'object' && 'info' in this._realLogger) {
      this._realLogger.info(message, data);
    } else {
      console.log(`[dev] ${message}`, data);
    }
  }

  async warn(message: string, data?: unknown) {
    await this._ensureLogger();
    if (this._realLogger && typeof this._realLogger === 'object' && 'warn' in this._realLogger) {
      this._realLogger.warn(message, data);
    } else {
      console.warn(`[dev] ${message}`, data);
    }
  }

  async error(message: string, data?: unknown) {
    await this._ensureLogger();
    if (this._realLogger && typeof this._realLogger === 'object' && 'error' in this._realLogger) {
      this._realLogger.error(message, data);
    } else {
      console.error(`[dev] ${message}`, data);
    }
  }

  async debug(message: string, data?: unknown) {
    await this._ensureLogger();
    if (this._realLogger && typeof this._realLogger === 'object' && 'debug' in this._realLogger) {
      this._realLogger.debug(message, data);
    } else {
      console.debug(`[dev] ${message}`, data);
    }
  }

  async setReveal(revealui: unknown) {
    await this._ensureLogger();
    if (
      this._realLogger &&
      typeof this._realLogger === 'object' &&
      'setReveal' in this._realLogger
    ) {
      (this._realLogger as LoggerMethods).setReveal?.(revealui);
    }
  }

  // Synchronous fallback methods for immediate use
  infoSync(message: string, data?: unknown) {
    if (this._realLogger && typeof this._realLogger === 'object' && 'info' in this._realLogger) {
      (this._realLogger as LoggerMethods).info(message, data);
    } else {
      console.log(`[dev] ${message}`, data);
    }
  }

  warnSync(message: string, data?: unknown) {
    if (this._realLogger && typeof this._realLogger === 'object' && 'warn' in this._realLogger) {
      (this._realLogger as LoggerMethods).warn(message, data);
    } else {
      console.warn(`[dev] ${message}`, data);
    }
  }

  errorSync(message: string, data?: unknown) {
    if (this._realLogger && typeof this._realLogger === 'object' && 'error' in this._realLogger) {
      (this._realLogger as LoggerMethods).error(message, data);
    } else {
      console.error(`[dev] ${message}`, data);
    }
  }

  debugSync(message: string, data?: unknown) {
    if (this._realLogger && typeof this._realLogger === 'object' && 'debug' in this._realLogger) {
      (this._realLogger as LoggerMethods).debug(message, data);
    } else {
      console.debug(`[dev] ${message}`, data);
    }
  }

  setRevealSync(revealui: unknown) {
    if (
      this._realLogger &&
      typeof this._realLogger === 'object' &&
      'setReveal' in this._realLogger
    ) {
      (this._realLogger as LoggerMethods).setReveal?.(revealui);
    }
  }
}

export const devLogger = new DevLoggerProxy();
