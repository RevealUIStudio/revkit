/**
 * Logging Configuration
 *
 * Centralized exports for all logging-related configurations and utilities including:
 * - Unified logger (server-side logging with Chalk styling)
 * - Client logger (browser-safe logging)
 * - Logger factory (client/server compatible logger creation)
 * - RevealUI Content Engine logger adapter (integrates RevealUI Content Engine with unified logging)
 *
 * All loggers use Chalk theming for consistent, colored output.
 *
 * @module config/infrastructure/integrations/logging
 * @example
 * ```typescript
 * // Server-side logging
 * import { createContextLogger } from '@/config/infrastructure/integrations/logging';
 * const logger = createContextLogger('my-service');
 * logger.info('Operation started');
 *
 * // Client-side logging
 * import { ClientLogger } from '@/config/infrastructure/integrations/logging';
 * const clientLogger = new ClientLogger('my-component');
 * clientLogger.info('Component mounted');
 * ```
 */

// Logger factory (client/server compatible)
export * from './logger.ts';

// Synchronous createLogger for backward compatibility
// Uses ClientLogger on both client and server for immediate return
import { ClientLogger } from './unified-logger.client.ts';
export function createLogger(context: string) {
  return new ClientLogger(context);
}

// Client-safe logger
export * from './unified-logger.client.ts';

// RevealUI Content Engine logger adapter
export * from './revealui-logger-adapter.ts';
