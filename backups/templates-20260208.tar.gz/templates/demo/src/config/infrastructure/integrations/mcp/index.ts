/**
 * MCP Integration Configuration
 *
 * Central export for MCP (Model Context Protocol) integration configuration
 *
 * @module config/infrastructure/integrations/mcp
 */

export * from './agent-configs';
