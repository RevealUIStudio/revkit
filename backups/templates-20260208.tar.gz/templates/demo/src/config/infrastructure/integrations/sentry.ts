import type { SentryConfig } from '@revealui/core/shared-types';

/**
 * Get Sentry configuration based on environment
 */
export function getSentryConfig(): SentryConfig {
  const environment = process.env.APP_ENV || 'development';
  const enabled = process.env.SENTRY_ENABLED === 'true' && environment !== 'development';

  return {
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN || '',
    environment: environment as SentryConfig['environment'],
    enabled,
    // Sample 100% of transactions in production for monitoring
    tracesSampleRate: environment === 'production' ? 1.0 : 0.1,
    // Sample 100% of profiles in production
    profilesSampleRate: environment === 'production' ? 1.0 : 0.1,
    // Capture 10% of sessions for replay
    replaysSessionSampleRate: 0.1,
    // Capture 100% of sessions with errors
    replaysOnErrorSampleRate: 1.0,
  };
}

/**
 * Initialize Sentry for error tracking
 * Call this in your root layout or instrumentation file
 */
export function initSentry() {
  const config = getSentryConfig();

  if (!config.enabled || !config.dsn) {
    console.log('Sentry disabled or DSN not configured');
    return;
  }

  // Sentry is initialized via sentry.client.config.ts and sentry.server.config.ts
  // This function is kept for backward compatibility but initialization
  // happens automatically when @sentry/nextjs is installed
  console.log('Sentry configuration ready for environment:', config.environment);
}

/**
 * Capture custom exception with context
 */
export function captureException(error: Error, context?: Record<string, unknown>) {
  const config = getSentryConfig();

  if (!config.enabled) {
    console.error('Error:', error, 'Context:', context);
    return;
  }

  // Dynamic import to avoid loading Sentry in development when disabled
  import('@sentry/nextjs')
    .then(Sentry => {
      Sentry.captureException(error, {
        extra: context,
      });
    })
    .catch(() => {
      // Sentry not available, fallback to console
      console.error('Sentry capture failed:', error, context);
    });
}

/**
 * Capture custom message with severity
 */
export function captureMessage(
  message: string,
  level: 'info' | 'warning' | 'error' = 'info',
  context?: Record<string, unknown>
) {
  const config = getSentryConfig();

  if (!config.enabled) {
    console.log(`[${level.toUpperCase()}]`, message, context);
    return;
  }

  // Dynamic import to avoid loading Sentry in development when disabled
  import('@sentry/nextjs')
    .then(Sentry => {
      Sentry.captureMessage(message, {
        level: level as 'info' | 'warning' | 'error' | 'fatal' | 'debug',
        extra: context,
      });
    })
    .catch(() => {
      // Sentry not available, fallback to console
      console.log(`[${level.toUpperCase()}]`, message, context);
    });
}

/**
 * Track payment-specific errors with high priority
 */
export function capturePaymentError(
  error: Error,
  context: {
    orderId?: string;
    cartId?: string;
    amount?: number;
    customerId?: string;
  }
) {
  captureException(error, {
    ...context,
    category: 'payment',
    priority: 'critical',
  });

  // Also send immediate alert (configure in Sentry dashboard)
  console.error('CRITICAL PAYMENT ERROR:', error, context);
}

/**
 * Track inventory errors
 */
export function captureInventoryError(
  error: Error,
  context: {
    productId: string;
    requestedQuantity: number;
    availableStock: number;
    orderId?: string;
  }
) {
  captureException(error, {
    ...context,
    category: 'inventory',
    priority: 'high',
  });
}

/**
 * Track webhook processing errors
 */
export function captureWebhookError(
  error: Error,
  context: {
    webhookId?: string;
    eventType: string;
    retryCount: number;
    stripeEventId?: string;
    processingTime?: number;
  }
) {
  captureException(error, {
    ...context,
    category: 'webhook',
    priority: 'high',
    tags: {
      webhook_event: context.eventType,
      retry_count: context.retryCount.toString(),
    },
  });
}

/**
 * Track email delivery errors
 */
export function captureEmailError(
  error: Error,
  context: {
    emailType: 'order_confirmation' | 'invoice' | 'support' | 'marketing';
    recipientEmail: string;
    templateId?: string;
    orderId?: string;
  }
) {
  captureException(error, {
    ...context,
    category: 'email',
    priority: 'medium',
    tags: {
      email_type: context.emailType,
      recipient: context.recipientEmail,
    },
  });
}

/**
 * Track database errors
 */
export function captureDatabaseError(
  error: Error,
  context: {
    operation: string;
    table?: string;
    query?: string;
    duration?: number;
  }
) {
  captureException(error, {
    ...context,
    category: 'database',
    priority: 'high',
    tags: {
      operation: context.operation,
      table: context.table || 'unknown',
    },
  });
}

/**
 * Track performance issues
 */
export function capturePerformanceIssue(
  message: string,
  context: {
    operation: string;
    duration: number;
    threshold: number;
    endpoint?: string;
    userId?: string;
  }
) {
  captureMessage(message, 'warning', {
    ...context,
    category: 'performance',
    priority: 'medium',
    tags: {
      operation: context.operation,
      endpoint: context.endpoint || 'unknown',
    },
  });
}

/**
 * Track business logic errors
 */
export function captureBusinessError(
  error: Error,
  context: {
    businessRule: string;
    userId?: string;
    orderId?: string;
    cartId?: string;
    additionalContext?: Record<string, unknown>;
  }
) {
  captureException(error, {
    ...context,
    category: 'business_logic',
    priority: 'medium',
    tags: {
      business_rule: context.businessRule,
    },
  });
}

/**
 * Track security events
 */
export function captureSecurityEvent(
  message: string,
  context: {
    eventType:
      | 'suspicious_activity'
      | 'unauthorized_access'
      | 'rate_limit_exceeded'
      | 'invalid_token';
    userId?: string;
    ipAddress?: string;
    userAgent?: string;
    endpoint?: string;
  }
) {
  captureMessage(message, 'warning', {
    ...context,
    category: 'security',
    priority: 'high',
    tags: {
      security_event: context.eventType,
      ip: context.ipAddress || 'unknown',
    },
  });
}

/**
 * Track system health issues
 */
export function captureSystemHealthIssue(
  message: string,
  context: {
    component: 'database' | 'stripe' | 'email' | 'storage' | 'webhook';
    status: 'degraded' | 'down' | 'slow';
    metrics?: Record<string, number>;
  }
) {
  captureMessage(message, 'error', {
    ...context,
    category: 'system_health',
    priority: context.status === 'down' ? 'critical' : 'high',
    tags: {
      component: context.component,
      status: context.status,
    },
  });
}

/**
 * Add breadcrumb for payment flow tracking
 */
export function addPaymentBreadcrumb(
  message: string,
  category: 'checkout' | 'payment' | 'webhook' | 'email',
  data?: Record<string, unknown>
) {
  const config = getSentryConfig();

  if (!config.enabled) {
    console.log(`[BREADCRUMB] ${category}: ${message}`, data);
    return;
  }

  // Dynamic import to avoid loading Sentry in development when disabled
  import('@sentry/nextjs')
    .then(Sentry => {
      Sentry.addBreadcrumb({
        message,
        category,
        data,
        level: 'info',
      });
    })
    .catch(() => {
      // Sentry not available, fallback to console
      console.log(`[BREADCRUMB] ${category}: ${message}`, data);
    });
}

/**
 * Set user context for better error tracking
 */
export function setUserContext(user: {
  id: string;
  email?: string;
  role?: string;
  subscription?: string;
}) {
  const config = getSentryConfig();

  if (!config.enabled) {
    console.log('User context:', user);
    return;
  }

  // Dynamic import to avoid loading Sentry in development when disabled
  import('@sentry/nextjs')
    .then(Sentry => {
      Sentry.setUser(user);
    })
    .catch(() => {
      // Sentry not available, fallback to console
      console.log('User context:', user);
    });
}

/**
 * Set transaction context for payment tracking
 */
export function setTransactionContext(transaction: {
  id: string;
  type: 'checkout' | 'payment' | 'refund' | 'subscription';
  amount?: number;
  currency?: string;
  status?: string;
}) {
  const config = getSentryConfig();

  if (!config.enabled) {
    console.log('Transaction context:', transaction);
    return;
  }

  // Dynamic import to avoid loading Sentry in development when disabled
  import('@sentry/nextjs')
    .then(Sentry => {
      Sentry.setContext('transaction', transaction);
    })
    .catch(() => {
      // Sentry not available, fallback to console
      console.log('Transaction context:', transaction);
    });
}
