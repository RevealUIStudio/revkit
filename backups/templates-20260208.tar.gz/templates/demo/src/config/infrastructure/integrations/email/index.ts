/**
 * Email Configuration
 *
 * Centralized exports for email-related configuration including:
 * - SMTP configuration
 * - Email templates
 * - Sender information
 *
 * @module config/infrastructure/integrations/email
 * @example
 * ```typescript
 * import { defaultEmailConfig } from '@/config/infrastructure/integrations/email';
 * ```
 */

export type { EmailConfig } from '@/contracts';
export { defaultEmailConfig } from './config.ts';
