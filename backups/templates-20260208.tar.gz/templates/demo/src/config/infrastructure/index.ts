/**
 * Infrastructure Configuration
 *
 * Centralized exports for infrastructure-related configurations including:
 * - Service factory and dependency injection
 * - Circuit breaker and fault tolerance
 * - Rate limiting
 * - Service discovery
 * - Performance optimization and caching
 * - External integrations (Stripe, RevealUI Content Engine, logging, email)
 * - Authentication configuration (JWT, sessions, OAuth)
 *
 * @module config/infrastructure
 * @example
 * ```typescript
 * // Get service from factory
 * import { ServiceFactory } from '@/config/infrastructure/services';
 * const postService = await ServiceFactory.getPostService();
 *
 * // Use configuration cache
 * import { configurationCache } from '@/config/infrastructure/performance';
 *
 * // Authentication config
 * import { defaultAuthConfig } from '@/config/infrastructure/identity';
 *
 * // Logging
 * import { createContextLogger } from '@/config/infrastructure/integrations/logging';
 * ```
 */

// Service infrastructure
export * from './services/index.ts';

// Performance optimization
export * from './performance/configuration-cache.ts';

// External integrations (Stripe, RevealUI Content Engine, logging, email)
export * from './integrations/index.ts';

// Authentication configuration
export type { AuthConfig } from '@/contracts';
export { defaultAuthConfig } from './identity/auth.ts';

// CMS configuration (RevealUI Content Engine globals)
export * from './cms/globals/index.ts';
