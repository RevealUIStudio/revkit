# RevealUI Globals

**Location**: `src/config/infrastructure/cms/globals/`

Globals are single documents (not collections) for site-wide settings and
configuration.

## What are Globals?

Unlike **Collections** (which store multiple documents), **Globals** store a
single document. Perfect for:

- Site settings
- App configuration
- Feature flags
- Theme settings
- SEO defaults

## Available Globals

### SiteSettings

Central location for all site-wide configuration.

**Access in code:**

```typescript
import { SiteSettingsService } from '@/domain/services/SiteSettingsService';

// Get all settings
const settings = await SiteSettingsService.getSettings();

// Get specific settings
const siteName = await SiteSettingsService.getSiteName();
const socialMedia = await SiteSettingsService.getSocialMedia();
const features = await SiteSettingsService.getFeatureFlags();

// Check feature flags
const isBlogEnabled = await SiteSettingsService.isFeatureEnabled('enableBlog');
const isMaintenanceMode = await SiteSettingsService.isMaintenanceMode();
```

**Admin access:** Navigate to RevealUI admin → Configuration → Site Settings

**Tabs:**

1. **General** - Site name, description, URLs, contact info
2. **Branding** - Logos, favicon, OG image
3. **Theme Colors** - Primary, secondary, accent colors (with color picker!)
4. **Social Media** - All social profile links
5. **Feature Flags** - Enable/disable site features

## Creating New Globals

```typescript
// src/infrastructure/globals/MyGlobal.ts
import type { GlobalConfig } from '@revealui/content';

export const MyGlobal: GlobalConfig = {
  slug: 'my-global',
  admin: {
    group: 'Configuration',
    description: 'My global settings',
  },
  access: {
    read: () => true,
    update: ({ req }) => {
      return req.user?.role === 'admin';
    },
  },
  fields: [
    {
      name: 'settingName',
      type: 'text',
      required: true,
    },
  ],
};
```

**Register in reveal.config.ts:**

```typescript
import { MyGlobal } from './infrastructure/globals/MyGlobal';

export default buildConfig({
  globals: [headerConfig, footerConfig, SiteSettings, MyGlobal],
});
```

## Collections vs Globals

| Feature   | Collections            | Globals                 |
| --------- | ---------------------- | ----------------------- |
| Documents | Multiple               | Single                  |
| Use Case  | Products, Posts, Users | Settings, Config        |
| API       | `/api/products`        | `/api/globals/settings` |
| Admin UI  | List view + Edit       | Direct Edit             |

## Best Practices

1. **Use Globals for singleton data** - If you only need one, use a Global
2. **Use tabs for organization** - Group related settings
3. **Add descriptions** - Help content editors understand each field
4. **Implement access control** - Usually only admins should update
5. **Create service classes** - Typed access from frontend code
6. **Cache results** - Globals don't change often, cache the data

## Caching Example

```typescript
import { unstable_cache } from 'next/cache';

export const getCachedSiteSettings = unstable_cache(
  async () => {
    return await SiteSettingsService.getSettings();
  },
  ['site-settings'],
  {
    revalidate: 3600, // 1 hour
    tags: ['site-settings'],
  }
);
```

## Existing Globals

- `headerConfig` - Header navigation configuration
- `footerConfig` - Footer content and links
- `site-settings` - New! All site-wide settings

## Feature Flag Usage

```typescript
// Check if shop is enabled
const shopEnabled = await SiteSettingsService.isFeatureEnabled('enableShop');

if (!shopEnabled) {
  return <div>Shop is currently disabled</div>;
}

// Check maintenance mode
const isMaintenance = await SiteSettingsService.isMaintenanceMode();

if (isMaintenance) {
  return <MaintenancePage />;
}
```

## Resources

- [RevealUI Globals Documentation](../README.md)
- [Access Control](../access/README.md)
- [Field Types](../fields/README.md)
