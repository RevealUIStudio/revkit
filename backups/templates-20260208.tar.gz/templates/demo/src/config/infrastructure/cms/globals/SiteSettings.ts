import type { GlobalConfig } from '@revealui/content';

export const SiteSettings: GlobalConfig = {
  slug: 'site-settings',
  admin: {
    group: 'Configuration',
    description: 'Manage global site settings and configuration',
  },
  access: {
    read: () => true,
    update: ({ req }) => {
      if (!req.user) return false;
      const adminRoles = ['super-admin', 'admin'];
      return adminRoles.includes(req.user.role);
    },
  },
  fields: [
    {
      type: 'tabs',
      tabs: [
        {
          label: 'General',
          fields: [
            {
              name: 'siteName',
              type: 'text',
              required: true,
              admin: {
                description: 'The name of your site',
              },
            },
            {
              name: 'siteDescription',
              type: 'textarea',
              maxLength: 200,
              admin: {
                description: 'Short description of your site for SEO',
              },
            },
            {
              name: 'siteUrl',
              type: 'text',
              required: true,
              admin: {
                description: 'Your site URL (e.g., https://example.com)',
              },
            },
            {
              name: 'contactEmail',
              type: 'email',
              required: true,
              admin: {
                description: 'Primary contact email',
              },
            },
            {
              name: 'supportEmail',
              type: 'email',
              admin: {
                description: 'Support/help email address',
              },
            },
            {
              name: 'phone',
              type: 'text',
              admin: {
                description: 'Contact phone number',
              },
            },
          ],
        },
        {
          label: 'Branding',
          fields: [
            {
              name: 'logo',
              type: 'upload',
              relationTo: 'media',
              required: true,
              admin: {
                description: 'Main site logo (light background)',
              },
            },
            {
              name: 'logoDark',
              type: 'upload',
              relationTo: 'media',
              admin: {
                description: 'Logo for dark backgrounds',
              },
            },
            {
              name: 'favicon',
              type: 'upload',
              relationTo: 'media',
              required: true,
              admin: {
                description: 'Site favicon (32x32 or 64x64)',
              },
            },
            {
              name: 'ogImage',
              type: 'upload',
              relationTo: 'media',
              admin: {
                description: 'Default Open Graph image for social sharing',
              },
            },
          ],
        },
        {
          label: 'Theme Colors',
          fields: [
            {
              name: 'colors',
              type: 'group',
              admin: {
                description: 'Customize your site color scheme',
              },
              fields: [
                {
                  name: 'primary',
                  type: 'text',
                  admin: {
                    components: {
                      Field: '/presentation/components/fields/ColorPicker',
                    },
                    description: 'Primary brand color',
                  },
                },
                {
                  name: 'secondary',
                  type: 'text',
                  admin: {
                    components: {
                      Field: '/presentation/components/fields/ColorPicker',
                    },
                    description: 'Secondary brand color',
                  },
                },
                {
                  name: 'accent',
                  type: 'text',
                  admin: {
                    components: {
                      Field: '/presentation/components/fields/ColorPicker',
                    },
                    description: 'Accent color for highlights and CTAs',
                  },
                },
              ],
            },
          ],
        },
        {
          label: 'Social Media',
          fields: [
            {
              name: 'socialMedia',
              type: 'group',
              admin: {
                description: 'Social media profile links',
              },
              fields: [
                {
                  name: 'twitter',
                  type: 'text',
                  admin: {
                    description: 'Twitter/X profile URL',
                  },
                },
                {
                  name: 'facebook',
                  type: 'text',
                  admin: {
                    description: 'Facebook page URL',
                  },
                },
                {
                  name: 'instagram',
                  type: 'text',
                  admin: {
                    description: 'Instagram profile URL',
                  },
                },
                {
                  name: 'linkedin',
                  type: 'text',
                  admin: {
                    description: 'LinkedIn company page URL',
                  },
                },
                {
                  name: 'youtube',
                  type: 'text',
                  admin: {
                    description: 'YouTube channel URL',
                  },
                },
                {
                  name: 'tiktok',
                  type: 'text',
                  admin: {
                    description: 'TikTok profile URL',
                  },
                },
              ],
            },
          ],
        },
        {
          label: 'Feature Flags',
          fields: [
            {
              name: 'features',
              type: 'group',
              admin: {
                description: 'Enable or disable site features',
              },
              fields: [
                {
                  name: 'enableBlog',
                  type: 'checkbox',
                  defaultValue: true,
                  admin: {
                    description: 'Enable blog/posts functionality',
                  },
                },
                {
                  name: 'enableShop',
                  type: 'checkbox',
                  defaultValue: true,
                  admin: {
                    description: 'Enable e-commerce shop',
                  },
                },
                {
                  name: 'enableMemberships',
                  type: 'checkbox',
                  defaultValue: true,
                  admin: {
                    description: 'Enable membership/subscription features',
                  },
                },
                {
                  name: 'enableComments',
                  type: 'checkbox',
                  defaultValue: false,
                  admin: {
                    description: 'Enable comments on posts and products',
                  },
                },
                {
                  name: 'maintenanceMode',
                  type: 'checkbox',
                  defaultValue: false,
                  admin: {
                    description: 'Put site in maintenance mode',
                  },
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
