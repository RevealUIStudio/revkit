/**
 * RevealUI Content Engine Globals Configuration
 *
 * Central export for RevealUI Content Engine global configurations
 *
 * @module config/infrastructure/cms/globals
 */

export { SiteSettings } from './SiteSettings.ts';
