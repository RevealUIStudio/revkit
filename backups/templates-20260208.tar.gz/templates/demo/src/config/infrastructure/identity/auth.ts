import { getBooleanEnvVar, getEnvVarWithFallback } from '@/config/system/environment';
import type { AuthConfig } from '@/contracts';

/**
 * Default authentication configuration
 */
export const defaultAuthConfig: AuthConfig = {
  jwt: {
    secret: getEnvVarWithFallback('JWT_SECRET', 'change-me'),
    expiresIn: getEnvVarWithFallback('JWT_EXPIRES_IN', '15m'),
    refreshExpiresIn: getEnvVarWithFallback('JWT_REFRESH_EXPIRES_IN', '7d'),
    issuer: getEnvVarWithFallback('JWT_ISSUER', 'reveal-ui'),
    audience: getEnvVarWithFallback('JWT_AUDIENCE', 'reveal-users'),
  },
  session: {
    secret: getEnvVarWithFallback('SESSION_SECRET', 'session-secret'),
    maxAge: Number.parseInt(getEnvVarWithFallback('SESSION_MAX_AGE', `${24 * 60 * 60 * 1000}`), 10),
    secure: getBooleanEnvVar('SESSION_SECURE', false),
    httpOnly: true,
    sameSite: 'strict',
  },
  password: {
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    saltRounds: 12,
  },
  twoFactor: {
    enabled: getBooleanEnvVar('TWO_FACTOR_ENABLED', false),
    issuer: getEnvVarWithFallback('TWO_FACTOR_ISSUER', 'reveal UI'),
    algorithm: 'sha1',
    digits: 6,
    period: 30,
    window: 1,
  },
  oauth: {
    google: {
      enabled: getBooleanEnvVar('GOOGLE_OAUTH_ENABLED', false),
      clientId: getEnvVarWithFallback('GOOGLE_CLIENT_ID', ''),
      clientSecret: getEnvVarWithFallback('GOOGLE_CLIENT_SECRET', ''),
      callbackUrl: getEnvVarWithFallback('GOOGLE_CALLBACK_URL', ''),
    },
    facebook: {
      enabled: getBooleanEnvVar('FACEBOOK_OAUTH_ENABLED', false),
      clientId: getEnvVarWithFallback('FACEBOOK_APP_ID', ''),
      clientSecret: getEnvVarWithFallback('FACEBOOK_APP_SECRET', ''),
      callbackUrl: getEnvVarWithFallback('FACEBOOK_CALLBACK_URL', ''),
    },
  },
};
