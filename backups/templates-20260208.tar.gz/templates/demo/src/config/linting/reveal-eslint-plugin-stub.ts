/**
 * Stub for reveal-eslint-plugin
 * 
 * This is a minimal stub to replace the external reveal-eslint-plugin
 * that was removed when external framework dependencies were eliminated.
 * 
 * All reveal rules are disabled (return empty objects) to prevent
 * ESLint errors while maintaining the config structure.
 */

import type { ESLint } from 'eslint';

const plugin: ESLint.Plugin = {
  meta: {
    name: 'reveal-eslint-plugin-stub',
    version: '0.0.0',
  },
  rules: {
    // All reveal rules disabled - return empty rule implementations
    'no-lib-folder-usage': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'enforce-contract-location': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'enforce-domain-boundaries': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'enforce-service-patterns': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'enforce-reveal-logging': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'require-comment-for-underscore-prefix': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'no-void-operator': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'no-revealui-manual-routes': {
      meta: {
        type: 'problem',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'require-comment-for-any-record': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
    'prefer-unified-contracts': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Stub rule - disabled',
        },
      },
      create: () => ({}),
    },
  },
};

export default plugin;

