/**
 * Database Configuration
 *
 * Configuration for database connection settings.
 *
 * @module config/presentation/database
 */

import type { DatabaseConfig } from '@revealui/core/shared-types';
import { getEnvVarWithFallback } from '@/config/system/environment';

/**
 * Default database configuration
 * Uses DATABASE_URL environment variable with fallback to local development database
 */
export const defaultDatabaseConfig: DatabaseConfig = {
  url: getEnvVarWithFallback('DATABASE_URL', 'postgresql://localhost:5432/reveal'),
};
