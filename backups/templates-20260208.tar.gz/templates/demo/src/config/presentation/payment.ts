/**
 * Payment Configuration
 *
 * Application-level payment configuration for payment providers.
 * This file defines the basic payment settings (provider, keys, currency).
 *
 * Related Configuration:
 * - Stripe Infrastructure: @/config/infrastructure/integrations/stripe/infrastructure.ts
 *   Contains Stripe-specific infrastructure as code (products, prices, webhooks)
 *   This file handles the application-level payment provider configuration,
 *   while the Stripe infrastructure file manages Stripe resource definitions.
 *
 * @module config/presentation/payment
 */

import type { PaymentConfig } from '@revealui/core/shared-types';
import { getEnvVarWithFallback } from './environment';

export const defaultPaymentConfig: PaymentConfig = {
  provider: 'stripe',
  publishableKey: getEnvVarWithFallback('STRIPE_PUBLISHABLE_KEY', ''),
  secretKey: getEnvVarWithFallback('STRIPE_SECRET_KEY', ''),
  webhookSecret: getEnvVarWithFallback('STRIPE_WEBHOOK_SECRET', ''),
  currency: getEnvVarWithFallback('STRIPE_DEFAULT_CURRENCY', 'usd'),
};
