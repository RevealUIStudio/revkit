/**
 * Presentation Layer Configuration
 *
 * Centralized exports for presentation layer configurations including:
 * - Analytics configuration (Google Analytics, custom analytics)
 * - Cache configuration (Redis, in-memory caching)
 * - Database configuration (PostgreSQL connection, pooling, migrations)
 * - Payment configuration (Stripe integration)
 * - Service configuration (health checks, logging, rate limiting)
 * - Storage configuration (file uploads, image processing)
 * - Theme configuration (admin theme, design tokens, navigation)
 *
 * Note: Authentication and email configs have moved to @/config/infrastructure/integrations and @/config/infrastructure/identity
 *
 * @module config/presentation
 * @example
 * ```typescript
 * // Import specific configuration
 * import { defaultCacheConfig } from '@/config/presentation/cache';
 *
 * // Import theme configuration
 * import { adminThemeConfig } from '@/config/presentation/theme';
 * ```
 */

export { defaultAnalyticsConfig } from './analytics.ts';
export { CACHE_KEYS, defaultCacheConfig } from './cache.ts';
export { defaultDatabaseConfig } from './database.ts';
export { defaultPaymentConfig } from './payment.ts';
export { defaultApplicationServiceConfig } from './service.ts';
export { defaultStorageConfig } from './storage.ts';

// Theme configuration
export * from './theme/index.ts';

// Environment configuration
export {
  APP_ENV,
  BLOB_READ_WRITE_TOKEN,
  DATABASE_URL,
  env,
  getBooleanEnvVar,
  getCurrentEnvironment,
  getEnvVar,
  getEnvVarWithFallback,
  getNumericEnvVar,
  LOG_LEVEL,
  REVEAL_PUBLIC_CLIENT_URL,
  REVEAL_PUBLIC_SERVER_URL,
  REVEAL_SECRET,
  validateEnvironment,
} from './environment.ts';

// Error classes
export {
  AppError,
  AuthenticationError,
  AuthorizationError,
  DatabaseError,
  ErrorCode,
  InfrastructureValidationError,
  NotFoundError,
} from './errors.ts';
