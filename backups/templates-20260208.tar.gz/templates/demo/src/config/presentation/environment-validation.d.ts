import type { EnvironmentVariables } from '@/contracts';
/**
 * Validates required environment variables
 * @param requiredVars - Array of required environment variable names
 * @returns Object containing validation result and missing variables
 */
export declare function validateEnvironmentVariables(requiredVars: readonly (keyof EnvironmentVariables)[]): {
    valid: boolean;
    missingVars: string[];
};
/**
 * Validates environment variables for database seeding
 * @returns Object containing validation result and missing variables
 */
export declare function validateSeedingEnvironmentVariables(): {
    valid: boolean;
    missingVars: string[];
};
/**
 * Logs missing environment variables in a user-friendly format
 * @param missingVars - Array of missing variable names
 */
export declare function logMissingEnvironmentVariables(missingVars: string[]): void;
/**
 * Validates and logs environment variables
 * @param requiredVars - Array of required environment variable names
 * @throws Error if validation fails
 */
export declare function validateAndLogEnvironmentVariables(requiredVars: readonly (keyof EnvironmentVariables)[]): void;
//# sourceMappingURL=environment-validation.d.ts.map