/**
 * Application Service Configuration
 *
 * Configuration for the application service including name, version, and environment.
 *
 * @module config/presentation/service
 */

import type { ApplicationServiceConfig } from '@revealui/core/shared-types';
import { getEnvVarWithFallback } from '@/config/system/environment';

/**
 * Default application service configuration
 * Uses APP_ENV environment variable for environment detection
 */
export const defaultApplicationServiceConfig: ApplicationServiceConfig = {
  name: 'revealUI',
  version: '1.0.0',
  environment: getEnvVarWithFallback('APP_ENV', 'development'),
};
