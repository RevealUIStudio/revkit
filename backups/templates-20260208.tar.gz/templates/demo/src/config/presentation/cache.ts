import type { CacheConfig } from '@revealui/core/shared-types';

/**
 * Default cache configuration
 * TTL in seconds, maxSize in number of entries
 */
export const defaultCacheConfig: CacheConfig = {
  ttl: 3600,
  maxSize: 1000,
};

/**
 * Cache key constants
 * Predefined keys for cache entries to ensure consistency
 */
export const CACHE_KEYS = {
  FIGHT_LIST: 'fight-list',
} as const;
