/**
 * Analytics Configuration
 *
 * Configuration for analytics tracking services including Google Analytics.
 *
 * @module config/presentation/analytics
 */

import type { AnalyticsConfig } from '@revealui/core/shared-types';
import { getEnvVarWithFallback } from '@/config/system/environment';

/**
 * Default analytics configuration
 * Uses environment variables for Google Analytics tracking ID
 */
export const defaultAnalyticsConfig: AnalyticsConfig = {
  googleAnalytics: {
    enabled: getEnvVarWithFallback('GA_TRACKING_ID', '') !== '',
    trackingId: getEnvVarWithFallback('GA_TRACKING_ID', ''),
  },
};
