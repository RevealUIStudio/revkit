import { RevealRedirects } from '@/presentation/components/navigation/RevealRedirects';

export const navigationConfig = {
  redirects: {
    component: RevealRedirects,
    props: {
      redirects: [
        {
          from: '/home',
          to: '/',
          statusCode: 301,
          preserveQuery: true,
        },
        {
          from: '/blog',
          to: '/posts',
          statusCode: 301,
          preserveQuery: true,
        },
      ],
    },
  },
  menu: {
    main: [
      {
        label: 'Home',
        href: '/',
      },
      {
        label: 'Posts',
        href: '/posts',
      },
      {
        label: 'Features',
        href: '/features',
      },
      {
        label: 'Pricing',
        href: '/pricing',
      },
      {
        label: 'Search',
        href: '/search',
      },
    ],
    footer: [
      {
        label: 'Privacy',
        href: '/privacy',
      },
      {
        label: 'Terms',
        href: '/terms',
      },
      {
        label: 'Contact',
        href: '/contact',
      },
      {
        label: 'Help',
        href: '/help',
      },
    ],
  },
};
