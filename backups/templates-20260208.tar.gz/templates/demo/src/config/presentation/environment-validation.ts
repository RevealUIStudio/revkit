import type { EnvironmentVariables } from '@/contracts';

/**
 * Validates required environment variables
 * @param requiredVars - Array of required environment variable names
 * @returns Object containing validation result and missing variables
 */
export function validateEnvironmentVariables(
  requiredVars: readonly (keyof EnvironmentVariables)[]
): {
  valid: boolean;
  missingVars: string[];
} {
  const missingVars = requiredVars.filter(varName => {
    const value = process.env[varName];
    return !value || value.trim() === '';
  });

  return {
    valid: missingVars.length === 0,
    missingVars,
  };
}

/**
 * Validates environment variables for database seeding
 * @returns Object containing validation result and missing variables
 */
export function validateSeedingEnvironmentVariables(): {
  valid: boolean;
  missingVars: string[];
} {
  const requiredVars = [
    'REVEAL_SUPERADMIN_EMAIL',
    'REVEAL_SUPERADMIN_PASSWORD',
    'REVEAL_SUPERADMIN_USERNAME',
    'REVEAL_SUPERADMIN_NAME',
  ] as const;

  return validateEnvironmentVariables(requiredVars);
}

/**
 * Logs missing environment variables in a user-friendly format
 * @param missingVars - Array of missing variable names
 */
export function logMissingEnvironmentVariables(missingVars: string[]): void {
  console.error('[ERROR] Missing required environment variables:');
  missingVars.forEach(varName => console.error(`   - ${varName}`));
  console.log('\n[IDEA] Set these in your .env file before seeding');
  console.log('   See .env.example for reference\n');
}

/**
 * Validates and logs environment variables
 * @param requiredVars - Array of required environment variable names
 * @throws Error if validation fails
 */
export function validateAndLogEnvironmentVariables(
  requiredVars: readonly (keyof EnvironmentVariables)[]
): void {
  const validation = validateEnvironmentVariables(requiredVars);

  if (!validation.valid) {
    logMissingEnvironmentVariables(validation.missingVars);
    throw new Error(`Missing required environment variables: ${validation.missingVars.join(', ')}`);
  }

  console.log('[OK] All required environment variables are set\n');
}
