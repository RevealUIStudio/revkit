/**
 * Presentation Layer Environment Configuration
 *
 * Presentation-specific environment variable exports and configuration.
 * For environment variable access utilities, see @/config/system/environment
 *
 * This module re-exports system environment utilities for backward compatibility
 * and provides presentation-layer-specific environment variable exports.
 *
 * @module config/presentation/environment
 */
export { getEnvVar, getEnvVarWithFallback, getBooleanEnvVar, getNumericEnvVar, validateEnvironment, getCurrentEnvironment, validateRequiredEnvVarsAtBuildTime, } from '@/config/system/environment';
export declare const env: any;
export declare const APP_ENV: any;
export declare const REVEALUI_PUBLIC_SERVER_URL: any;
export declare const REVEALUI_PUBLIC_CLIENT_URL: any;
export declare const DATABASE_URL: any;
export declare const REVEALUI_SECRET: any;
export declare const BLOB_READ_WRITE_TOKEN: any;
export declare const LOG_LEVEL: any;
//# sourceMappingURL=environment.d.ts.map