import { BaseError, EntityNotFoundError, ValidationError } from '@revealui/infrastructure';

export enum ErrorCode {
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  NOT_FOUND_ERROR = 'NOT_FOUND_ERROR',
  RUNTIME_ERROR = 'RUNTIME_ERROR',
  AUTHENTICATION_ERROR = 'AUTHENTICATION_ERROR',
  AUTHORIZATION_ERROR = 'AUTHORIZATION_ERROR',
  DATABASE_ERROR = 'DATABASE_ERROR',
  NETWORK_ERROR = 'NETWORK_ERROR',
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  RATE_LIMIT_ERROR = 'RATE_LIMIT_ERROR',
}

/**
 * Application-level error extending Core's BaseError
 * Used in presentation layer for application-specific errors
 */
export class AppError extends BaseError {
  constructor(
    public readonly code: ErrorCode,
    message: string,
    public readonly cause?: unknown
  ) {
    super(message, code);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Infrastructure validation error extending Core's ValidationError
 */
export class InfrastructureValidationError extends ValidationError {
  constructor(
    field: string,
    message: string,
    value?: unknown,
    public readonly cause?: unknown
  ) {
    super(field, message, value);
    this.name = 'InfrastructureValidationError';
  }
}

/**
 * Not found error extending Core's EntityNotFoundError
 */
export class NotFoundError extends EntityNotFoundError {
  constructor(
    entityType: string,
    entityId: string,
    public readonly cause?: unknown
  ) {
    super(entityType, entityId);
    this.name = 'NotFoundError';
  }
}

/**
 * Database error extending Core's BaseError
 */
export class DatabaseError extends BaseError {
  constructor(
    message: string,
    public readonly cause?: unknown
  ) {
    super(message, 'DATABASE_ERROR');
    this.name = 'DatabaseError';
  }
}

/**
 * Authentication error extending Core's BaseError
 */
export class AuthenticationError extends BaseError {
  constructor(
    message: string,
    public readonly cause?: unknown
  ) {
    super(message, 'AUTHENTICATION_ERROR');
    this.name = 'AuthenticationError';
  }
}

/**
 * Authorization error extending Core's BaseError
 */
export class AuthorizationError extends BaseError {
  constructor(
    message: string,
    public readonly cause?: unknown
  ) {
    super(message, 'AUTHORIZATION_ERROR');
    this.name = 'AuthorizationError';
  }
}
