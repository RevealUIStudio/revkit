# Configuration Architecture

**Location**: `src/config/`

This directory contains all application configuration organized by architectural
layers following Clean Architecture principles. It works in conjunction with the
Core foundation layer (`src/core/`) to provide a complete configuration and
foundation system.

## Directory Structure

```
src/config/
├── infrastructure/         # Technical infrastructure configs
├── presentation/          # Application-level configs
├── domain/                 # Business logic configs
└── system/                 # Shared utilities and constants

# Related Foundation Layer
src/core/                   # Foundation layer (see ../core/README.md)
├── result/                # Result pattern (used by config)
├── errors/                # Base error classes (extended by config)
├── validation/            # Base validators (extended by config)
├── types/                 # Common types
├── constants/             # System constants
└── interfaces/            # Base interfaces
```

## Core vs Config Relationship

**Core** (`src/core/`) provides foundation building blocks:

- Base interfaces and contracts
- Common type definitions
- Result patterns and error handling
- Base implementations (repository, service, adapter)
- System-wide constants
- Validation frameworks

**Config** (`src/config/`) provides environment-specific configurations:

- Environment variables and validation
- Infrastructure integrations
- Layer-specific utilities
- App-specific error classes (extends Core)
- Configuration validators (specialized)

## Layer Responsibilities

### Infrastructure Layer (`infrastructure/`)

**Purpose**: Technical concerns, external integrations, and infrastructure
services.

**Contents**:

- External integrations (Stripe, email providers, logging, RevealUI Content Engine)
- Infrastructure services (DI, circuit breaker, rate limiter)
- CMS configuration (RevealUI Content Engine globals)
- Auth implementation (JWT, OAuth, sessions)
- Performance optimization and caching

**Key Files**:

- `integrations/email/` - Email provider configuration
- `integrations/logging/` - Logging system configuration
- `integrations/stripe/` - Stripe payment configuration
- `services/` - Service factory and dependency injection
- `cms/globals/` - RevealUI Content Engine global configurations
- `identity/auth.ts` - Authentication configuration

**Usage**:

```typescript
import { defaultEmailConfig } from '@/config/infrastructure/integrations/email';
import { defaultAuthConfig } from '@/config/infrastructure/identity';
import { SiteSettings } from '@/config/infrastructure/cms/globals';
```

### Presentation Layer (`presentation/`)

**Purpose**: Application-level configurations, environment variables, and UI
settings.

**Contents**:

- Environment variables and validation
- Application service configuration
- Database configuration
- Analytics configuration
- Cache configuration
- Theme and UI configuration
- Error classes for app layer

**Key Files**:

- `environment.ts` - Environment variable management
- `database.ts` - Database connection configuration
- `analytics.ts` - Analytics tracking configuration
- `cache.ts` - Cache configuration
- `theme/` - UI theme and design tokens
- `errors.ts` - Application error classes

**Usage**:

```typescript
import { env, APP_ENV } from '@/config/presentation/environment';
import { defaultDatabaseConfig } from '@/config/presentation/database';
import { adminThemeConfig } from '@/config/presentation/theme';
```

### Domain Layer (`domain/`)

**Purpose**: Business logic and domain-specific configurations.

**Contents**:

- Identity configuration (roles, permissions, users)
- Domain configuration interface
- Business rules and policies

**Key Files**:

- `identity/roles/` - Role permissions and tiers
- `identity/users/` - User utilities and helpers
- `pricing/` - Pricing configuration (tiers, credits, outcomes)
- `ecommerce.ts` - Ecommerce business rules
- `index.ts` - Domain configuration interface

**Usage**:

```typescript
import {
  ROLE_PERMISSIONS,
  hasPermission,
} from '@/config/domain/identity/roles';
import { domainConfig } from '@/config/domain';
```

### System Layer (`system/`)

**Purpose**: Shared utilities, constants, and validators used across all layers.
**Note**: Extends Core's base implementations for consistency.

**Contents**:

- Date/URL/generation utilities
- Environment variable access utilities (cross-layer)
- Validators and type guards (extend Core's BaseValidator)
- Constants and defaults (re-export Core constants)
- Error handling utilities (extend Core's BaseError)
- Metadata (framework config, version matrix)

**Key Files**:

- `utilities/dates.ts` - Date manipulation utilities
- `utilities/urls.ts` - URL generation and manipulation
- `utilities/generation.ts` - ID/token generation
- `utilities/results.ts` - Service result helpers (uses Core's UnifiedResult)
- `environment/` - Environment variable access utilities (for all layers)
- `validators/` - Validation utilities (extend Core's BaseValidator)
- `constants/` - Application constants (re-export Core constants)
- `errors/` - Error handling utilities (extend Core's BaseError)

**Usage**:

```typescript
import {
  formatDateISO,
  getRelativeTime,
} from '@/config/system/utilities/dates';
import {
  generateUUID,
  generateSlug,
} from '@/config/system/utilities/generation';
import { getEnvVarWithFallback } from '@/config/system/environment';
import { ValidationUtils } from '@/config/system/validators';
```

## Main Entry Point

The `index.ts` file provides convenient exports for commonly used
configurations:

```typescript
import {
  // Environment
  env,
  APP_ENV,

  // Utilities
  cn,
  generateUUID,
  formatDateISO,

  // Domain
  domainConfig,
  ROLE_PERMISSIONS,

  // Infrastructure
  defaultAuthConfig,
} from '@/config';
```

## Core Integration

Config extends Core's foundation layer:

### Result Pattern Integration

```typescript
// Config results now use Core's UnifiedResult internally
import { serviceSuccess, serviceFailure } from '@/config';
// These functions return Core's Result<T, E> type

// For advanced Result operations, import directly from Core
import {
  Result,
  success,
  failure,
  isSuccess,
} from '@/core/result/UnifiedResult';
```

### Error Hierarchy

```typescript
// Config errors extend Core errors
import { AppError, DatabaseError } from '@/config/presentation/errors';
// These extend Core's BaseError

// For base error classes, import from Core
import { BaseError, DomainError } from '@/core/errors/ErrorTypes';
```

### Validation Framework

```typescript
// Config validators extend Core's BaseValidator
import { ValidationUtils } from '@/config/system/validators';
// These use simple validation utilities

// Note: Core validation framework has been removed.
// Use Contracts validation (Zod) instead: src/contracts/validation/
```

## Import Paths

### Best Practices

1. **Import from layer index files** when possible:

   ```typescript
   import { defaultEmailConfig } from '@/config/infrastructure/integrations/email';
   ```

2. **Use main index** for common utilities:

   ```typescript
   import { generateUUID, formatDateISO } from '@/config';
   ```

3. **Direct imports** for specific configurations:
   ```typescript
   import { SiteSettings } from '@/config/infrastructure/cms/globals/SiteSettings';
   ```

## Configuration Patterns

All configuration files follow a consistent pattern:

```typescript
// 1. Type definitions
export type ConfigName = { ... };

// 2. Default configuration
export const defaultConfig: ConfigName = { ... };

// 3. Environment-based config getter (if needed)
export function getConfig(): ConfigName { ... }

// 4. Validation (if needed)
export function validateConfig(config: ConfigName): boolean { ... }
```

## Environment Variables

Environment variable access utilities are in `system/environment/` for
cross-layer use:

```typescript
// For domain, infrastructure, and system layers
import { getEnvVarWithFallback, getBooleanEnvVar } from '@/config/system/environment';

// For presentation layer (includes presentation-specific exports)
import { env, APP_ENV, DATABASE_URL } from '@/config/presentation/environment';
```

**Important**: Domain and infrastructure layers should import from
`@/config/system/environment` to avoid layer dependency violations. Presentation
layer can use either location (re-exports are provided for backward
compatibility).

See `.env.example` for all available environment variables.

## Migrating from Old Paths

### Email Configuration

- **Old**: `@/config/infrastructure/email`
- **New**: `@/config/infrastructure/integrations/email`

### Payment Configuration

- **Old**: `@/config/infrastructure/payment`
- **New**: `@/config/presentation/payment`

### Storage Configuration

- **Old**: `@/config/infrastructure/storage`
- **New**: `@/config/presentation/storage`

### SiteSettings

- **Old**: `@/config/globals/SiteSettings`
- **New**: `@/config/infrastructure/cms/globals/SiteSettings`

### Image Constants

- **Old**: `@/config/constants/images`
- **New**: `@/config/system/constants/images`

### Pricing Configuration

- **Old**: `@/config/pricing/*`
- **New**: `@/config/domain/pricing/*` (tiers, credits, outcomes)

### MCP Configuration

- **Old**: `@/config/infrastructure/mcp/*`
- **New**: `@/config/infrastructure/integrations/mcp/*`

### Environment Variable Access

- **Old**: `@/config/presentation/environment` (for all layers)
- **New**:
  - `@/config/system/environment` - For domain, infrastructure, and system layers
  - `@/config/presentation/environment` - For presentation layer (re-exports system utilities + presentation-specific exports)

## Ecommerce Configuration

The ecommerce configuration provides centralized business rules for cart, order,
and product operations.

### Usage

```typescript
import {
  getEcommerceConfig,
  getTaxRate,
  calculateShippingCost,
} from '@/config/domain/ecommerce';

// Get full configuration
const config = getEcommerceConfig();

// Use specific configuration values
const taxRate = config.tax.defaultRate; // 0.08 (8%)
const freeShippingThreshold = config.shipping.freeShippingThreshold; // 50.00

// Use configuration functions
const regionalTaxRate = getTaxRate('US-CA'); // 0.10 (10% for California)
const shippingCost = calculateShippingCost(2.5, 'US', false); // Weight, region, express
```

### Configuration Structure

- **Tax Configuration**: Default rates, regional rates, exempt categories
- **Shipping Configuration**: Costs, free shipping thresholds, weight-based
rates
- **Currency Configuration**: Supported currencies, display settings
- **Order Configuration**: Number generation, limits, timeouts
- **Cart Configuration**: Timeouts, item limits, abandonment thresholds
- **Discount Configuration**: Limits, coupon settings, expiration rules

### Service Integration

```typescript
// In service implementations
export class CartApplicationService {
  async calculateTotals(cart: Cart): Promise<CartTotals> {
    const config = getEcommerceConfig();

    return CartDomainService.calculateTotals(
      cart.items,
      cart.appliedDiscounts,
      config.tax.defaultRate, // Use config instead of hardcoded values
      0 // Shipping calculated separately
    );
  }
}
```

## Architecture Principles

1. **Separation of Concerns**: Each layer has clear responsibilities
2. **Dependency Direction**: Inner layers don't depend on outer layers
3. **Configuration Isolation**: Configs are separated from business logic
4. **Type Safety**: All configs have TypeScript types
5. **Environment-Aware**: Configs adapt to development/production environments
6. **Core Integration**: Config extends Core's foundation for consistency
7. **Unified Patterns**: Use Core's Result pattern and error hierarchy

## Adding New Configuration

### Infrastructure Config

```typescript
// src/config/infrastructure/integrations/new-service/config.ts
export type NewServiceConfig = { ... };
export const defaultNewServiceConfig: NewServiceConfig = { ... };
```

### Presentation Config

```typescript
// src/config/presentation/new-feature.ts
export type NewFeatureConfig = { ... };
export const defaultNewFeatureConfig: NewFeatureConfig = { ... };
```

### Domain Config

```typescript
// src/config/domain/new-domain/index.ts
export type NewDomainConfig = { ... };
export const newDomainConfig: NewDomainConfig = { ... };
```

### System Utility

```typescript
// src/config/system/utilities/new-utility.ts
export function newUtility(): void { ... }
```

Then export from the appropriate index file.

## Testing

Configuration files should be tested for:

- Type safety
- Validation logic
- Environment-specific behavior
- Default values

## Resources

- [Core Foundation Layer](../core/README.md) - Foundation layer documentation
- [Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [TypeScript Config Best Practices](https://www.typescriptlang.org/docs/handbook/declaration-files/templates/module-d-ts.html)
- [Environment Variables](https://nextjs.org/docs/basic-features/environment-variables)
































