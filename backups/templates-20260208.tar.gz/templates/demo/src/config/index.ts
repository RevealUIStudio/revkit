/**
 * Configuration Index
 * Centralized entry point for commonly used configuration exports
 *
 * This file provides convenient re-exports of the most frequently used configurations
 * and utilities. For specific configurations, prefer importing directly from subdirectories:
 *
 * Layer Organization:
 * - @/config/presentation/* - Presentation layer (app config, environment, theme, errors)
 * - @/config/domain/* - Domain layer (business logic, identity, pricing, ecommerce)
 * - @/config/infrastructure/* - Infrastructure layer (services, integrations, auth, CMS)
 * - @/config/system/* - System layer (utilities, validators, constants, errors)
 *
 * Specific Directories:
 * - @/config/domain/identity/* - Domain identity (roles, users)
 * - @/config/domain/pricing/* - Pricing configuration (tiers, credits, outcomes)
 * - @/config/infrastructure/identity/* - Infrastructure identity (auth)
 * - @/config/infrastructure/integrations/* - External integrations (Stripe, RevealUI Content Engine, logging, email, MCP)
 * - @/config/infrastructure/services/* - Infrastructure services (DI, performance, circuit breaker)
 * - @/config/presentation/theme/* - Theme and UI configuration
 */

// ============================================================================
// PRESENTATION LAYER - Application-level configurations
// ============================================================================

// App configurations (environment variables, database, cache, analytics, payment, storage)
export * from './presentation/index.ts';

// UI utilities (re-exported from presentation layer for convenience)
// export { cn } from '@/presentation/styles/classnames';

// ============================================================================
// DOMAIN LAYER - Business logic and domain configurations
// ============================================================================

// Domain configuration (server/client URLs, environment detection)
export { DomainConfiguration, domainConfig } from './domain/index.ts';

// Identity and access management (roles, permissions, users)
export * from './domain/identity/roles/index.ts';
export * from './domain/identity/users/index.ts';

// ============================================================================
// SYSTEM LAYER - Shared utilities and helpers (Most Commonly Used)
// ============================================================================

// Result pattern helpers (service success/failure utilities)
export {
  serviceFailure,
  serviceFailureWithDetails,
  serviceSuccess,
  serviceSuccessWithMetrics,
} from './system/utilities/results.ts';

// Generation utilities (IDs, tokens, metadata, slugs)
export {
  generateMeta,
  generateRandomString,
  generateSecureToken,
  generateSlug,
  generateUUID,
} from './system/utilities/generation.ts';

// Date utilities (formatting, parsing, relative time)
export {
  formatDateISO,
  formatDateReadable,
  formatDateTimeReadable,
  getRelativeTime,
  parseDate,
} from './system/utilities/dates.ts';

// URL utilities (validation, normalization)
export { isValidUrl, normalizeUrl } from './system/utilities/urls.ts';

// Validation utilities (common validators)
export {
  ValidationUtils,
  validateRequired,
  validateMinLength,
  validateMaxLength,
  validateEmail,
} from './system/validators/domain.ts';

// ============================================================================
// INFRASTRUCTURE LAYER - Infrastructure services and integrations
// ============================================================================

// Logging (development logger)
export { devLogger } from './infrastructure/integrations/logging/logger.ts';

// ============================================================================
// CONSTANTS - Application-wide constants
// ============================================================================

// Cache configuration
export { CACHE_KEYS } from './presentation/cache.ts';

// Image constants (placeholders)
export { PLACEHOLDER_IMAGE, VIDEO_PLACEHOLDER } from './system/constants/images.ts';

// Media prefix constants (validation, admin config, error messages)
export {
  ALLOWED_TYPES,
  DEFAULT_ALLOWED_TYPES,
  MAX_MEDIA_PER_PREFIX,
  PREFIXES_ADMIN_CONFIG,
  PREFIXES_COLLECTION,
  PREFIXES_ERROR_MESSAGES,
  PREFIXES_FIELD_DESCRIPTIONS,
  PREFIXES_VALIDATION,
} from './system/constants/prefixes.ts';

// ============================================================================
// ADDITIONAL CONFIGURATIONS
// ============================================================================
//
// For less commonly used configurations, import directly from subdirectories:
//
// Domain Layer:
//   - Pricing: @/config/domain/pricing/* (tiers, credits, outcomes)
//   - Ecommerce: @/config/domain/ecommerce
//
// Infrastructure Layer:
//   - Auth: @/config/infrastructure/identity/* (JWT, OAuth, sessions)
//   - Integrations: @/config/infrastructure/integrations/* (Stripe, RevealUI Content Engine, logging, email, MCP)
//   - Services: @/config/infrastructure/services/* (DI, circuit breaker, rate limiter)
//   - CMS: @/config/infrastructure/cms/globals/* (RevealUI Content Engine globals)
//
// Presentation Layer:
//   - Theme: @/config/presentation/theme/* (admin theme, navigation, design tokens)
//
// System Layer:
//   - Advanced utilities: @/config/system/utilities/* (dates, URLs, generation, type guards)
//   - Validators: @/config/system/validators/* (configuration, domain)
//   - Errors: @/config/system/errors/* (configuration errors)
//   - Constants: @/config/system/constants/* (prefixes, images, defaults, preview breakpoints)
//   - Metadata: @/config/system/metadata/* (framework config, version matrix, project structure)
//
// ============================================================================
