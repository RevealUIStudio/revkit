import React from 'react';
import { AuthProvider } from '@/presentation/providers/AuthProvider';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Root layout should not render HTML tags
  // Let each route group handle its own HTML structure
  return <AuthProvider>{children}</AuthProvider>;
}
