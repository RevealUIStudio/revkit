// import actOfRejection from './actOfRejection.woff2.ts'
// import fightKid from './fightKid.woff2.ts'
// import fontBrushRegular from './fontBrushRegular.woff2.ts'
// import greatFighter from './greatFighter.woff2.ts'
// import karateChop from './karateChop.woff2.ts'
// import keylockFighter from './keylockFighter.woff2.ts'
// import playBold from './playBold.woff2.ts'
// import playRegular from './playRegular.woff2.ts'
// import singleFighter from './singleFighter.woff2.ts'

import localFont from 'next/font/local';

// Font files can be colocated inside of `app`
// Note: Adding fallback to work around Next.js/Turbopack font loading issue
const singleFighter = localFont({
  src: './singleFighter.woff2',
  display: 'swap',
  variable: '--font-single-fighter',
  fallback: ['sans-serif'],
});

const actOfRejection = localFont({
  src: './actOfRejection.woff2',
  display: 'swap',
  variable: '--font-act-of-rejection',
  fallback: ['sans-serif'],
});

const fightKid = localFont({
  src: './fightKid.woff2',
  display: 'swap',
  variable: '--font-fight-kid',
  fallback: ['sans-serif'],
});

const fontBrushRegular = localFont({
  src: './fontBrushRegular.woff2',
  display: 'swap',
  variable: '--font-brush-regular',
  fallback: ['sans-serif'],
});

const greatFighter = localFont({
  src: './greatFighter.woff2',
  display: 'swap',
  variable: '--font-great-fighter',
  fallback: ['sans-serif'],
});

const karateChop = localFont({
  src: './karateChop.woff2',
  display: 'swap',
  variable: '--font-karate-chop',
  fallback: ['sans-serif'],
});

const keylockFighter = localFont({
  src: './keylockFighter.woff2',
  display: 'swap',
  variable: '--font-keylock-fighter',
  fallback: ['sans-serif'],
});

const playBold = localFont({
  src: './playBold.woff2',
  display: 'swap',
  variable: '--font-play-bold',
  fallback: ['sans-serif'],
});

const playRegular = localFont({
  src: './playRegular.woff2',
  display: 'swap',
  variable: '--font-play-regular',
  fallback: ['sans-serif'],
});

export {
  actOfRejection,
  fightKid,
  fontBrushRegular,
  greatFighter,
  karateChop,
  keylockFighter,
  playBold,
  playRegular,
  singleFighter,
};
