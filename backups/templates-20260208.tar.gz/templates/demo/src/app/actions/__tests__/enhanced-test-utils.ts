/**
 * Enhanced Testing Utilities for Server Actions
 *
 * Comprehensive testing utilities for server actions with Next.js 16 and RevealUI Content Engine 3.
 * Includes mocking, validation, and performance testing.
 */

import { vi } from 'vitest';
import { z } from 'zod';
import type { PerformanceMetrics, TestContext, TestResult } from '@revealui/core/shared-types';

// ====================================================================
// TEST TYPES
// ====================================================================

interface MockChatInput {
  conversationId: string;
  message: string;
  userId: string;
  context?: {
    userHistory?: Array<{ role: string; content: string }>;
    systemPrompt?: string;
    temperature?: number;
    maxTokens?: number;
  };
}

interface MockContentGenerationInput {
  type: string;
  topic: string;
  description: string;
  tone: string;
  length: string;
  keywords: string[];
  targetAudience: string;
  userId: string;
  language: string;
  format: string;
}

interface MockContactInput {
  name: string;
  email: string;
  subject: string;
  message: string;
  company: string;
  phone: string;
  website: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  source: string;
}

const TEST_USER_ID = 'test-user-id';
const TEST_SESSION_ID = 'test-session-id';
const TEST_REQUEST_ID = 'test-request-id';
const TEST_EMAIL = 'test@example.com';
const TEST_IP_ADDRESS = '127.0.0.1';
const TEST_USER_AGENT = 'test-user-agent';
const TEST_ITEM_ID = 'test-id';
const TEST_ITEM_TITLE = 'Test Item';
const TEST_ITEM_CONTENT = 'Test content';

// ====================================================================
// MOCK UTILITIES
// ====================================================================

/**
 * Create mock context for testing
 */
export function createMockContext(overrides: Partial<TestContext> = {}): TestContext {
  return {
    user: {
      id: TEST_USER_ID,
      email: TEST_EMAIL,
      role: 'user',
    },
    session: {
      id: TEST_SESSION_ID,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    },
    requestId: TEST_REQUEST_ID,
    startTime: Date.now(),
    metadata: {
      ip: TEST_IP_ADDRESS,
      userAgent: TEST_USER_AGENT,
    },
    ...overrides,
  };
}

/**
 * Create mock RevealUI Content Engine instance
 */
export function createMockRevealui() {
  return {
    auth: vi.fn().mockResolvedValue({
      user: {
        id: TEST_USER_ID,
        email: TEST_EMAIL,
        role: 'user',
      },
      session: {
        id: TEST_SESSION_ID,
        expiresAt: new Date(),
      },
    }),
    findByID: vi.fn().mockResolvedValue({
      id: TEST_ITEM_ID,
      title: TEST_ITEM_TITLE,
      content: TEST_ITEM_CONTENT,
    }),
    find: vi.fn().mockResolvedValue({
      docs: [],
      totalDocs: 0,
      totalPages: 0,
      hasNextPage: false,
      hasPrevPage: false,
    }),
    create: vi.fn().mockResolvedValue({
      id: TEST_ITEM_ID,
      title: TEST_ITEM_TITLE,
      content: TEST_ITEM_CONTENT,
    }),
    update: vi.fn().mockResolvedValue({
      id: TEST_ITEM_ID,
      title: 'Updated Item',
      content: 'Updated content',
    }),
    delete: vi.fn().mockResolvedValue({
      id: TEST_ITEM_ID,
    }),
  };
}

/**
 * Create mock MCP service
 */
export function createMockMCPService() {
  return {
    initialize: vi.fn().mockResolvedValue(undefined),
    cleanup: vi.fn().mockResolvedValue(undefined),
    executeTask: vi.fn().mockResolvedValue({
      success: true,
      data: {
        response: 'Test response',
        tokens: 100,
        processingTime: 1000,
      },
    }),
    executeTaskStreaming: vi.fn().mockResolvedValue({
      success: true,
      data: {
        response: 'Test streaming response',
        tokens: 100,
        processingTime: 1000,
      },
    }),
    getAllAgentsStatus: vi.fn().mockReturnValue({
      agents: [],
      health: {},
      metrics: {},
      statistics: {},
    }),
    getStatistics: vi.fn().mockReturnValue({}),
    getAuditLog: vi.fn().mockResolvedValue([]),
    getPendingApprovals: vi.fn().mockResolvedValue([]),
    approveTask: vi.fn().mockResolvedValue({ success: true }),
    rejectTask: vi.fn().mockResolvedValue({ success: true }),
  };
}

// ====================================================================
// TEST SERVER ACTIONS
// ====================================================================

/**
 * Create test server action with minimal middleware
 */
// ====================================================================
// VALIDATION TESTING
// ====================================================================

/**
 * Test input validation
 */
export async function testInputValidation<T>(
  schema: z.ZodSchema<T>,
  validInput: T,
  invalidInputs: Array<{ input: unknown; expectedError: string }>
) {
  const results = {
    valid: false,
    invalid: [] as Array<{ input: unknown; expectedError: string; actualError?: string }>,
  };

  // Test valid input
  try {
    schema.parse(validInput);
    results.valid = true;
  } catch {
    results.valid = false;
  }

  // Test invalid inputs
  for (const testCase of invalidInputs) {
    try {
      schema.parse(testCase.input);
      results.invalid.push({
        input: testCase.input,
        expectedError: testCase.expectedError,
        actualError: 'No error thrown',
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const actualError = error.issues.map(issue => issue.message).join(', ');
        if (!actualError.includes(testCase.expectedError)) {
          results.invalid.push({
            input: testCase.input,
            expectedError: testCase.expectedError,
            actualError,
          });
        }
      }
    }
  }

  return results;
}

/**
 * Test server action with various inputs
 */
export async function testServerActionInputs<TInput, TOutput>(
  action: (input: TInput) => Promise<TestResult<TOutput>>,
  testCases: Array<{
    name: string;
    input: TInput;
    expectedSuccess: boolean;
    expectedError?: string;
  }>
) {
  const results = [];

  for (const testCase of testCases) {
    const startTime = Date.now();
    const startMemory = process.memoryUsage();

    try {
      const result = await action(testCase.input);
      const duration = Date.now() - startTime;
      const memoryUsage = process.memoryUsage().heapUsed - startMemory.heapUsed;

      results.push({
        name: testCase.name,
        success: result.success === testCase.expectedSuccess,
        expectedSuccess: testCase.expectedSuccess,
        actualSuccess: result.success,
        expectedError: testCase.expectedError,
        actualError: result.error,
        duration,
        memoryUsage,
      });
    } catch (error) {
      results.push({
        name: testCase.name,
        success: false,
        expectedSuccess: testCase.expectedSuccess,
        actualSuccess: false,
        expectedError: testCase.expectedError,
        actualError: error instanceof Error ? error.message : String(error),
        duration: Date.now() - startTime,
        memoryUsage: process.memoryUsage().heapUsed - startMemory.heapUsed,
      });
    }
  }

  return results;
}

// ====================================================================
// PERFORMANCE TESTING
// ====================================================================

/**
 * Test server action performance
 */
export async function testServerActionPerformance<TInput, TOutput>(
  action: (input: TInput) => Promise<TestResult<TOutput>>,
  input: TInput,
  iterations = 100
): Promise<PerformanceMetrics> {
  const results = [];
  let errorCount = 0;

  for (let i = 0; i < iterations; i++) {
    const startTime = Date.now();
    const startMemory = process.memoryUsage();

    try {
      const result = await action(input);
      const duration = Date.now() - startTime;
      const memoryUsage = process.memoryUsage().heapUsed - startMemory.heapUsed;

      results.push({
        duration,
        memoryUsage,
        success: result.success,
      });

      if (!result.success) {
        errorCount++;
      }
    } catch (_error) {
      errorCount++;
    }
  }

  const durations = results.map(r => r.duration);
  const memoryUsages = results.map(r => r.memoryUsage);

  return {
    duration: durations.reduce((a, b) => a + b, 0) / durations.length,
    memoryUsage: memoryUsages.reduce((a, b) => a + b, 0) / memoryUsages.length,
    cpuUsage: 0, // Would need additional monitoring
    requestCount: iterations,
    errorRate: errorCount / iterations,
  };
}

/**
 * Test server action under load
 */
export async function testServerActionLoad<TInput, TOutput>(
  action: (input: TInput) => Promise<TestResult<TOutput>>,
  input: TInput,
  concurrency = 10,
  totalRequests = 100
): Promise<PerformanceMetrics> {
  const results = [];
  let errorCount = 0;

  // Create batches of concurrent requests
  const batches = Math.ceil(totalRequests / concurrency);

  for (let batch = 0; batch < batches; batch++) {
    const batchSize = Math.min(concurrency, totalRequests - batch * concurrency);
    const batchPromises = [];

    for (let i = 0; i < batchSize; i++) {
      batchPromises.push(
        (async () => {
          const startTime = Date.now();
          const startMemory = process.memoryUsage();

          try {
            const result = await action(input);
            const duration = Date.now() - startTime;
            const memoryUsage = process.memoryUsage().heapUsed - startMemory.heapUsed;

            return {
              duration,
              memoryUsage,
              success: result.success,
            };
          } catch (_error) {
            errorCount++;
            return {
              duration: Date.now() - startTime,
              memoryUsage: process.memoryUsage().heapUsed - startMemory.heapUsed,
              success: false,
            };
          }
        })()
      );
    }

    const batchResults = await Promise.all(batchPromises);
    results.push(...batchResults);
  }

  const durations = results.map(r => r.duration);
  const memoryUsages = results.map(r => r.memoryUsage);

  return {
    duration: durations.reduce((a, b) => a + b, 0) / durations.length,
    memoryUsage: memoryUsages.reduce((a, b) => a + b, 0) / memoryUsages.length,
    cpuUsage: 0, // Would need additional monitoring
    requestCount: totalRequests,
    errorRate: errorCount / totalRequests,
  };
}

// ====================================================================
// INTEGRATION TESTING
// ====================================================================

/**
 * Test server action integration
 */
export async function testServerActionIntegration<TInput, TOutput>(
  action: (input: TInput) => Promise<TestResult<TOutput>>,
  input: TInput,
  expectedResult: Partial<TOutput>
): Promise<{
  success: boolean;
  actualResult?: TOutput;
  expectedResult: Partial<TOutput>;
  error?: string;
}> {
  try {
    const result = await action(input);

    if (!result.success) {
      return {
        success: false,
        expectedResult,
        ...(result.error ? { error: result.error } : {}),
      };
    }

    // Check if actual result matches expected result
    const matches = Object.keys(expectedResult).every(key => {
      const expected = expectedResult[key as keyof TOutput];
      const actual = result.data?.[key as keyof TOutput];
      return expected === actual;
    });

    return {
      success: matches,
      ...(result.data !== undefined ? { actualResult: result.data } : {}),
      expectedResult,
    };
  } catch (error) {
    return {
      success: false,
      expectedResult,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ====================================================================
// MOCK DATA GENERATORS
// ====================================================================

/**
 * Generate mock chat input
 */
export function generateMockChatInput(overrides: Partial<MockChatInput> = {}): MockChatInput {
  return {
    conversationId: 'test-conversation-id',
    message: 'Test message',
    userId: 'test-user-id',
    context: {
      userHistory: [],
      systemPrompt: 'You are a helpful assistant.',
      temperature: 0.7,
      maxTokens: 1000,
    },
    ...overrides,
  };
}

/**
 * Generate mock content generation input
 */
export function generateMockContentInput(
  overrides: Partial<MockContentGenerationInput> = {}
): MockContentGenerationInput {
  return {
    type: 'article',
    topic: 'Test topic',
    description: 'Test description',
    tone: 'professional',
    length: 'medium',
    keywords: ['test', 'example'],
    targetAudience: 'Developers',
    userId: 'test-user-id',
    language: 'en',
    format: 'plain',
    ...overrides,
  };
}

/**
 * Generate mock contact form input
 */
export function generateMockContactInput(
  overrides: Partial<MockContactInput> = {}
): MockContactInput {
  return {
    name: 'Test User',
    email: 'test@example.com',
    subject: 'Test Subject',
    message: 'Test message content',
    priority: 'medium',
    category: 'general',
    company: 'Test Company',
    phone: '+1234567890',
    website: 'https://example.com',
    source: 'website',
    ...overrides,
  };
}
