/**
 * Content Actions Tests
 *
 * Comprehensive tests for content generation server actions
 */

import { MCPService } from '@revealui/infrastructure/services/mcp/MCPService';
import * as securityMocks from '@revealui/dev/testing/utilities/mocks/security-mocks';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ContentGenerationInput } from '../content';
import { generateContent } from '../content';

// Mock dependencies
vi.mock('@revealui/infrastructure/services/mcp/MCPService');
vi.mock('revealui');
vi.mock('next/cache');
vi.mock('@revealui/dev/testing/utilities/mocks/security-mocks');

describe('Content Actions', () => {
  const mockInput: ContentGenerationInput = {
    type: 'blog-post',
    topic: 'Next.js 16 Features',
    title: 'Understanding Next.js 16',
    keywords: ['nextjs', 'react', 'server-actions'],
    tone: 'technical',
    length: 'medium',
    audience: 'developers',
    userId: 'user-123',
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe('generateContent', () => {
    it('should successfully generate content', async () => {
      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: true,
          data: {
            content: 'This is a comprehensive blog post about Next.js 16 features...',
            metadata: {
              wordCount: 500,
              readingTime: '3 minutes',
              topics: ['server-actions', 'streaming', 'performance'],
            },
          },
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 4,
        resetTime: Date.now() + 60000,
      });

      const result = await generateContent(mockInput);

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.content).toContain('Next.js 16 features');
        expect(result.data.metadata).toHaveProperty('wordCount');
        expect(result.data.metadata).toHaveProperty('readingTime');
      }
    });

    it('should handle different content types', async () => {
      const productInput: ContentGenerationInput = {
        ...mockInput,
        type: 'product-description',
        topic: 'AI-Powered Analytics Dashboard',
      };

      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: true,
          data: {
            content:
              'Transform your data into actionable insights with our AI-powered analytics dashboard...',
            metadata: {
              wordCount: 150,
              type: 'product-description',
            },
          },
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: productInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 4,
        resetTime: Date.now() + 60000,
      });

      const result = await generateContent(productInput);

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.content).toContain('analytics dashboard');
      }
    });

    it('should handle rate limiting', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: false,
        remaining: 0,
        resetTime: Date.now() + 30000,
      });

      const result = await generateContent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('Rate limit exceeded');
      }
    });

    it('should handle validation errors', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: false,
        error: 'Invalid content type',
      });

      const result = await generateContent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Invalid input');
        expect(result.details).toBe('Invalid content type');
      }
    });

    it('should handle MCP service failures', async () => {
      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: false,
          error: 'Content generation service unavailable',
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 4,
        resetTime: Date.now() + 60000,
      });

      const result = await generateContent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Content generation service unavailable');
      }
    });

    it('should work without userId (anonymous)', async () => {
      const anonymousInput = { ...mockInput, userId: undefined };

      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: true,
          data: {
            content: 'Generated content without user context...',
            metadata: {},
          },
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: anonymousInput,
      });

      const result = await generateContent(anonymousInput);

      expect(result.success).toBe(true);
    });
  });
});
