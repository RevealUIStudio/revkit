/**
 * Contact Actions Tests
 *
 * Comprehensive tests for contact form server actions
 */

import * as securityMocks from '@revealui/dev/testing/utilities/mocks/security-mocks';
import { getRevealUI } from '@revealui/content';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ContactFormInput } from '../contact';
import { submitContactForm } from '../contact';

// Mock dependencies
vi.mock('revealui');
vi.mock('next/cache');
vi.mock('@revealui/dev/testing/utilities/mocks/security-mocks');

describe('Contact Actions', () => {
  const mockInput: ContactFormInput = {
    name: 'John Doe',
    email: 'john@example.com',
    subject: 'Question about pricing',
    message: 'I would like to know more about your pricing plans for the enterprise tier.',
    priority: 'medium',
    category: 'sales',
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe('submitContactForm', () => {
    it('should successfully submit contact form', async () => {
      const mockRevealUI = {
        logger: {
          info: vi.fn(),
        },
        sendEmail: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(getRevealUI).mockResolvedValue(mockRevealUI);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkAnonymousRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 2,
        resetTime: Date.now() + 900000,
      });

      const result = await submitContactForm(mockInput);

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.message).toBe('Your message has been sent successfully');
      }

      // Verify email was sent
      expect(mockRevealUI.sendEmail).toHaveBeenCalledTimes(2); // Support team + user confirmation
    });

    it('should handle different priority levels', async () => {
      const criticalInput: ContactFormInput = {
        ...mockInput,
        priority: 'critical',
        subject: 'URGENT: System Down',
        message: 'Our production system is completely down and we need immediate assistance.',
      };

      const mockRevealUI = {
        logger: {
          info: vi.fn(),
        },
        sendEmail: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(getRevealUI).mockResolvedValue(mockRevealUI);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: criticalInput,
      });
      vi.mocked(securityMocks.checkAnonymousRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 2,
        resetTime: Date.now() + 900000,
      });

      const result = await submitContactForm(criticalInput);

      expect(result.success).toBe(true);

      // Verify critical priority email was sent
      expect(mockRevealUI.sendEmail).toHaveBeenCalledWith(
        expect.objectContaining({
          subject: expect.stringContaining('[CRITICAL]'),
        })
      );
    });

    it('should handle rate limiting', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.checkAnonymousRateLimit).mockResolvedValue({
        allowed: false,
        remaining: 0,
        resetTime: Date.now() + 300000,
      });

      const result = await submitContactForm(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('Rate limit exceeded');
      }
    });

    it('should handle validation errors', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: false,
        error: 'Invalid email format',
      });

      const result = await submitContactForm(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Invalid form data');
        expect(result.details).toBe('Invalid email format');
      }
    });

    it('should handle email sending failures', async () => {
      const mockRevealUI = {
        logger: {
          info: vi.fn(),
        },
        sendEmail: vi.fn().mockRejectedValue(new Error('Email service unavailable')),
      };

      vi.mocked(getRevealUI).mockResolvedValue(mockRevealUI);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkAnonymousRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 2,
        resetTime: Date.now() + 900000,
      });

      const result = await submitContactForm(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Failed to send message. Please try again or email us directly.');
      }
    });

    it('should sanitize input to prevent XSS', async () => {
      const maliciousInput: ContactFormInput = {
        name: 'John<script>alert("xss")</script>',
        email: 'john@example.com',
        subject: 'Test',
        message: 'Hello<script>alert("xss")</script>World',
        priority: 'low',
        category: 'general',
      };

      const sanitizedInput: ContactFormInput = {
        name: 'John',
        email: 'john@example.com',
        subject: 'Test',
        message: 'HelloWorld',
        priority: 'low',
        category: 'general',
      };

      const mockRevealUI = {
        logger: {
          info: vi.fn(),
        },
        sendEmail: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(getRevealUI).mockResolvedValue(mockRevealUI);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: sanitizedInput,
      });
      vi.mocked(securityMocks.checkAnonymousRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 2,
        resetTime: Date.now() + 900000,
      });

      const result = await submitContactForm(maliciousInput);

      expect(result.success).toBe(true);

      // Verify sanitized data was used
      expect(mockRevealUI.sendEmail).toHaveBeenCalledWith(
        expect.objectContaining({
          html: expect.not.stringContaining('<script>'),
        })
      );
    });
  });
});
