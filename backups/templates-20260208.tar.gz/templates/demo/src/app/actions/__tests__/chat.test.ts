/**
 * Chat Actions Tests
 *
 * Comprehensive tests for chat server actions
 */

import { MCPService } from '@revealui/infrastructure/services/mcp/MCPService';
import * as securityMocks from '@revealui/dev/testing/utilities/mocks/security-mocks';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ChatInput } from '../chat';
import { chatWithAgent, chatWithAgentStreaming } from '../chat';

// Mock dependencies
vi.mock('@revealui/infrastructure/services/mcp/MCPService');
vi.mock('revealui');
vi.mock('next/cache');
vi.mock('@revealui/dev/testing/utilities/mocks/security-mocks');

describe('Chat Actions', () => {
  const mockInput: ChatInput = {
    conversationId: 'test-conversation-123',
    message: 'Hello, how are you?',
    userId: 'user-123',
    context: {
      userHistory: [
        { role: 'user', content: 'Previous message' },
        { role: 'assistant', content: 'Previous response' },
      ],
    },
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe('chatWithAgent', () => {
    it('should successfully process a chat message', async () => {
      // Mock successful response
      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: true,
          data: {
            response: 'Hello! I am doing well, thank you for asking.',
            conversationId: 'test-conversation-123',
          },
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 9,
        resetTime: Date.now() + 60000,
      });

      const result = await chatWithAgent(mockInput);

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.response).toBe('Hello! I am doing well, thank you for asking.');
        expect(result.data.conversationId).toBe('test-conversation-123');
      }
    });

    it('should handle rate limiting', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: false,
        remaining: 0,
        resetTime: Date.now() + 30000,
      });

      const result = await chatWithAgent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('Rate limit exceeded');
      }
    });

    it('should handle invalid input', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: false,
        error: 'Invalid message format',
      });

      const result = await chatWithAgent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Invalid input');
        expect(result.details).toBe('Invalid message format');
      }
    });

    it('should handle MCP service errors', async () => {
      const mockMCPService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        executeTask: vi.fn().mockResolvedValue({
          success: false,
          error: 'MCP service unavailable',
        }),
        cleanup: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(MCPService).mockImplementation(() => mockMCPService);
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 9,
        resetTime: Date.now() + 60000,
      });

      const result = await chatWithAgent(mockInput);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('MCP service unavailable');
      }
    });
  });

  describe('chatWithAgentStreaming', () => {
    it('should create a streamable value', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: true,
        data: mockInput,
      });
      vi.mocked(securityMocks.checkUserRateLimit).mockResolvedValue({
        allowed: true,
        remaining: 9,
        resetTime: Date.now() + 60000,
      });

      const result = await chatWithAgentStreaming(mockInput);

      expect(result).toHaveProperty('stream');
      expect(result.stream).toBeDefined();
    });

    it('should handle streaming errors', async () => {
      vi.mocked(securityMocks.validateEnvironment).mockResolvedValue(undefined);
      vi.mocked(securityMocks.validateAndSanitizeInput).mockReturnValue({
        success: false,
        error: 'Invalid input for streaming',
      });

      const result = await chatWithAgentStreaming(mockInput);

      expect(result).toHaveProperty('stream');
      // The stream should be created even if there's an error
      expect(result.stream).toBeDefined();
    });
  });
});
