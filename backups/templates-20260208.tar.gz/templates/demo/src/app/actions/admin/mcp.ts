'use server';

import type {
  AgentsStatusResult,
  ApprovalActionResult,
  ApprovalsResult,
  AuditLogResult,
  ExecuteTaskResult,
} from '@revealui/core/shared-types';

/**
 * MCP Admin Actions
 *
 * Note: These actions are currently disabled. When enabled, they will require
 * admin authentication and proper MCP service integration.
 */

const DISABLED_MESSAGE = 'MCP admin actions are disabled in this build.';

export async function getMCPAgentsStatus(): Promise<AgentsStatusResult> {
  return { success: false, error: DISABLED_MESSAGE };
}

export async function executeMCPTask(): Promise<ExecuteTaskResult> {
  return { success: false, error: DISABLED_MESSAGE };
}

export async function getMCPAuditLog(): Promise<AuditLogResult> {
  return { success: false, error: DISABLED_MESSAGE };
}

export async function getPendingApprovals(): Promise<ApprovalsResult> {
  return { success: false, error: DISABLED_MESSAGE };
}

export async function handleApproval(): Promise<ApprovalActionResult> {
  return { success: false, error: DISABLED_MESSAGE };
}
