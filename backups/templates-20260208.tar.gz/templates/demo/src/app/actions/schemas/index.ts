import { z } from 'zod';

export const ServerActionSchemas = {
  chat: z.object({
    conversationId: z.string().min(1, 'Conversation ID is required'),
    message: z.string().min(1, 'Message is required'),
    userId: z.string().optional(),
  }),
  content: z.object({
    topic: z.string().min(1, 'Topic is required'),
    description: z.string().optional(),
  }),
  contact: z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email address'),
    subject: z.string().min(1, 'Subject is required'),
    message: z.string().min(1, 'Message is required'),
    priority: z.enum(['low', 'medium', 'high', 'critical']).optional(),
    category: z.enum(['general', 'support', 'sales', 'technical', 'billing']).optional(),
  }),
  recommendations: z.object({
    userId: z.string().optional(),
  }),
};

export type ServerActionSchemaRegistry = typeof ServerActionSchemas;
