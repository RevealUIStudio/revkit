'use server';

import { getCurrentUser } from '@revealui/infrastructure/actions/helpers/auth-context';
import { getRevealConfig } from '@/reveal.config';
import { createServerAction } from '@revealui/core/middleware/serverActions';
import { validateInput } from '@revealui/core/middleware/validation';
import { getRevealUI } from '@revealui/content';
import type { RecommendationRequest, RecommendationResult } from '@revealui/core/shared-types';
import { ServerActionSchemas } from './schemas';

const configPromise = getRevealConfig();

/**
 * Generate personalized recommendations
 *
 * Note: This is a basic implementation. For full MCP PersonalizationAgent integration,
 * this can be enhanced to use MCPService and PersonalizationAgent.
 */
export const generateRecommendations = createServerAction<
  RecommendationRequest,
  { recommendations: Array<{ id: string; title: string; reason: string }> }
>([validateInput(ServerActionSchemas.recommendations)], async (input, context) => {
  const revealui = await getRevealUI({ config: configPromise });

  // Get current user if not provided
  let userId = input.userId;
  if (!userId && context.user) {
    userId = context.user.id;
  } else if (!userId) {
    const user = await getCurrentUser();
    userId = user?.id ? String(user.id) : undefined;
  }

  revealui.logger.info('Recommendations request received', {
    requestId: context.requestId,
    userId,
  });

  // TODO: Integrate with MCPService PersonalizationAgent for full AI capabilities
  // For now, provide basic recommendations
  // In production, this should call:
  // - MCPService.getServer().getAgent('personalization-001')
  // - agent.executeTask({ type: 'recommendations', revealui: { userId } })

  // Basic recommendations (can be enhanced with AI integration)
  const recommendations = [
    {
      id: '1',
      title: 'Explore Premium Features',
      reason: 'Based on your usage patterns, you might benefit from premium features.',
    },
    {
      id: '2',
      title: 'Check Out New Templates',
      reason: 'New templates have been added that match your interests.',
    },
    {
      id: '3',
      title: 'Join Community Forum',
      reason: 'Connect with other users and share your experiences.',
    },
  ];

  return {
    recommendations,
  };
});
