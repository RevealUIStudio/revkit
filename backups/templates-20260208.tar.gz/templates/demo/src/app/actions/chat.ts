'use server';

import { getRevealConfig } from '@/reveal.config';
import { createServerAction } from '@revealui/core/middleware/serverActions';
import { validateInput } from '@revealui/core/middleware/validation';
import { getRevealUI } from '@revealui/content';
import type { ChatActionResult, ChatInput } from '@revealui/core/shared-types';
import { ServerActionSchemas } from './schemas';

const configPromise = getRevealConfig();

/**
 * Chat with AI agent
 *
 * Note: This is a basic implementation. For full MCP ChatbotAgent integration,
 * this can be enhanced to use MCPService and ChatbotAgent.
 *
 * Rate limiting should be handled at the application layer or via middleware
 * that can access request headers (IP-based rate limiting requires request context).
 */
export const chatWithAgent = createServerAction<
  ChatInput,
  { response: string; conversationId: string }
>([validateInput(ServerActionSchemas.chat)], async (input, context) => {
  const revealui = await getRevealUI({ config: configPromise });

  revealui.logger.info('Chat request received', {
    requestId: context.requestId,
    conversationId: input.conversationId,
    userId: input.userId,
    messageLength: input.message.length,
  });

  // TODO: Integrate with MCPService ChatbotAgent for full AI capabilities
  // For now, provide a basic response
  // In production, this should call:
  // - MCPService.getServer().getAgent('chatbot-001')
  // - agent.executeTask({ type: 'chat', revealui: { message, conversationId } })

  // Basic response (can be enhanced with AI integration)
  const response = `I received your message: "${input.message}". This is a basic chat implementation. To enable full AI capabilities, integrate with MCPService ChatbotAgent.`;

  return {
    response,
    conversationId: input.conversationId,
  };
});

/**
 * Chat with AI agent (streaming)
 *
 * Note: This is a basic implementation. For full streaming support,
 * integrate with MCPService ChatbotAgent streaming capabilities.
 *
 * Streaming version uses the validated chatWithAgent action internally.
 */
export async function chatWithAgentStreaming(
  input: ChatInput
): Promise<{ stream: { read: () => Promise<string> } }> {
  try {
    const revealui = await getRevealUI({ config: configPromise });

    revealui.logger.info('Streaming chat request received', {
      conversationId: input.conversationId,
      userId: input.userId,
    });

    // Validate using the same action (validation happens there)
    // TODO: Integrate with MCPService ChatbotAgent for streaming
    // For now, return a simple stream
    let sent = false;
    return {
      stream: {
        read: async () => {
          if (sent) {
            return '';
          }
          sent = true;
          const response = await chatWithAgent(input);
          return JSON.stringify(response);
        },
      },
    };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return {
      stream: {
        read: async () =>
          JSON.stringify({
            success: false,
            error: 'Failed to process streaming chat',
            details: errorMessage,
          }),
      },
    };
  }
}
