'use server';

import { RATE_LIMIT_DEFAULTS } from '@/config/system/constants/defaults';
import { getRevealConfig } from '@/reveal.config';
import { createServerAction } from '@revealui/core/middleware/serverActions';
import type { Middleware, MiddlewareContext } from '@revealui/core/middleware/types';
import { MiddlewareError } from '@revealui/core/middleware/types';
import { validateInput } from '@revealui/core/middleware/validation';
import { getRevealUI } from '@revealui/content';
import { ServerActionSchemas } from './schemas';
import type { ContactFormInput, ContactFormResult } from '@revealui/core/shared-types';

const configPromise = getRevealConfig();

// In-memory rate limiting (per-instance)
// TODO: Replace with RateLimiterService for production use across multiple instances
const submissions = new Map<string, { count: number; resetTime: number }>();

function checkRateLimit(identifier: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const windowMs = RATE_LIMIT_DEFAULTS.CONTACT_FORM_WINDOW;
  const maxSubmissions = RATE_LIMIT_DEFAULTS.CONTACT_FORM_MAX;

  // Clean up expired entries
  for (const [key, value] of submissions.entries()) {
    if (now > value.resetTime) {
      submissions.delete(key);
    }
  }

  const entry = submissions.get(identifier);

  if (!entry) {
    submissions.set(identifier, { count: 1, resetTime: now + windowMs });
    return { allowed: true, remaining: maxSubmissions - 1 };
  }

  if (now > entry.resetTime) {
    submissions.set(identifier, { count: 1, resetTime: now + windowMs });
    return { allowed: true, remaining: maxSubmissions - 1 };
  }

  if (entry.count >= maxSubmissions) {
    return { allowed: false, remaining: 0 };
  }

  entry.count++;
  return { allowed: true, remaining: maxSubmissions - entry.count };
}

/**
 * Rate limit middleware for contact form using email as identifier
 */
function rateLimitByEmail<T extends { email: string }>(): Middleware<MiddlewareContext, T> {
  return async (input: T, context: MiddlewareContext, next: () => Promise<any>) => {
    const rateLimit = checkRateLimit(input.email);
    if (!rateLimit.allowed) {
      try {
        const revealui = await getRevealUI({ config: configPromise });
        revealui.logger.warn('Rate limit exceeded for contact form', {
          email: input.email,
          requestId: context.requestId,
        });
      } catch {
        // RevealUI logging failed, continue with error
      }
      throw new MiddlewareError(
        'Too many submissions. Please try again later.',
        'RATE_LIMIT_EXCEEDED',
        429
      );
    }
    return next();
  };
}

export const submitContactForm = createServerAction<ContactFormInput, { message: string }>(
  [validateInput(ServerActionSchemas.contact), rateLimitByEmail<ContactFormInput>()],
  async (input, context) => {
    const revealui = await getRevealUI({ config: configPromise });

    const priority = input.priority ?? 'medium';
    const category = input.category ?? 'general';

    revealui.logger.info('Processing contact form submission', {
      requestId: context.requestId,
      name: input.name,
      email: input.email,
      subject: input.subject,
      priority,
      category,
    });

    // Send email notification to support team
    const supportEmail = process.env.SUPPORT_EMAIL ?? 'support@example.com';

    await revealui.sendEmail({
      to: supportEmail,
      subject: `[${priority.toUpperCase()}] ${category}: ${input.subject}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Priority:</strong> ${priority}</p>
        <p><strong>Category:</strong> ${category}</p>
        <p><strong>From:</strong> ${input.name} (${input.email})</p>
        <p><strong>Subject:</strong> ${input.subject}</p>
        <hr />
        <h3>Message:</h3>
        <p>${input.message.replace(/\n/g, '<br />')}</p>
        <hr />
        <p><small>Timestamp: ${new Date().toISOString()}</small></p>
      `,
    });

    // Send confirmation email to user
    await revealui.sendEmail({
      to: input.email,
      subject: `We received your message: ${input.subject}`,
      html: `
        <h2>Thank you for contacting us!</h2>
        <p>Hi ${input.name},</p>
        <p>We've received your message and our team will get back to you soon.</p>
        <h3>Your message:</h3>
        <p><strong>Subject:</strong> ${input.subject}</p>
        <p>${input.message.replace(/\n/g, '<br />')}</p>
        <hr />
        <p><strong>Expected response time:</strong></p>
        <ul>
          <li><strong>Critical:</strong> Within 1 hour</li>
          <li><strong>High:</strong> Within 4 hours</li>
          <li><strong>Medium:</strong> Within 24 hours</li>
          <li><strong>Low:</strong> Within 48 hours</li>
        </ul>
        <p>Best regards,<br />Support Team</p>
      `,
    });

    revealui.logger.info('Contact form processed successfully', {
      requestId: context.requestId,
      name: input.name,
      email: input.email,
      subject: input.subject,
    });

    return {
      message: 'Your message has been sent successfully',
    };
  }
);
