/**
 * Server Actions Index
 *
 * Centralized exports for all server actions in the application.
 *
 * Architecture:
 * - All server actions live in this directory (src/app/actions/)
 * - Follows Next.js 15/16 conventions for server actions
 * - Type-safe, streamable, and integrate seamlessly with React 19
 * - See docs/architecture/SERVER_ACTIONS_MIGRATION.md for migration guide
 *
 * Organization:
 * - Feature-specific actions: chat.ts, content.ts, recommendations.ts, contact.ts
 * - Admin actions: admin/mcp.ts
 * - All exports available from this index for easy importing
 *
 * Usage:
 * ```typescript
 * import { chatWithAgent, submitContactForm } from '@/app/actions';
 *
 * const result = await chatWithAgent({ message, conversationId });
 * const formResult = await submitContactForm({ name, email, message });
 * ```
 */

// Chat actions
export { chatWithAgent, chatWithAgentStreaming } from './chat';
export type { ChatInput, ChatActionResult } from './chat';

// Content generation actions
export { generateContent } from './content';
export type { ContentGenerationInput, ContentGenerationResult } from './content';

// Recommendations actions
export { generateRecommendations } from './recommendations';
export type { RecommendationRequest, RecommendationResult } from './recommendations';

// Contact form actions
export { submitContactForm } from './contact';
export type { ContactFormInput, ContactFormResult } from './contact';

// Admin MCP actions
export {
  executeMCPTask,
  getMCPAgentsStatus,
  getMCPAuditLog,
  getPendingApprovals,
  handleApproval,
} from './admin/mcp';
export type {
  AgentsStatusResult,
  ApprovalActionResult,
  AuditLogResult,
  ExecuteTaskResult,
} from './admin/mcp';
