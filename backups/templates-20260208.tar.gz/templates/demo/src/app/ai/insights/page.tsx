'use client';

import { useEffect, useState } from 'react';

type Job = { jobId: string; total: number; processed: number };

export default function InsightsPage() {
  const [jobId, setJobId] = useState('');
  const [job, setJob] = useState<Job | null>(null);

  useEffect(() => {
    if (!jobId) return;
    const id = setInterval(async () => {
      const res = await fetch(`/api/queues/lead-enrichment?jobId=${jobId}`);
      if (res.ok) {
        const data = (await res.json()) as Job;
        setJob(data);
      }
    }, 500);
    return () => clearInterval(id);
  }, [jobId]);

  return (
    <div className='mx-auto max-w-2xl p-6 space-y-4'>
      <h1 className='text-xl font-semibold'>AI Insights</h1>
      <p className='text-sm text-gray-500'>
        Polling a demo background job created by the lead-enrichment queue.
      </p>
      <div className='flex gap-2'>
        <input
          className='flex-1 rounded border px-3 py-2'
          placeholder='Paste a jobId'
          value={jobId}
          onChange={e => setJobId(e.target.value)}
        />
      </div>
      {job && (
        <div className='rounded border p-3 text-sm'>
          <div>Job: {job.jobId}</div>
          <div>
            Progress: {job.processed} / {job.total}
          </div>
          <div>{job.total > 0 ? `${Math.round((job.processed / job.total) * 100)}%` : '0%'}</div>
        </div>
      )}
    </div>
  );
}
