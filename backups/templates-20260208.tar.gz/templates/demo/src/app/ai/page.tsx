'use client';

import { chatWithAgentStreaming } from '@/app/actions';
import { useEffect, useRef, useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };

const PRESETS = [
  {
    title: 'Lead research',
    prompt: "Research this lead and propose next steps. Use enrichLead on 'sarah@sampleco.com'.",
  },
  {
    title: 'Draft outreach email',
    prompt: "Draft a personalized intro email for 'tom@contoso.com' based on enrichment.",
  },
  {
    title: 'Generate landing page',
    prompt:
      'Use generateUI to create a landing page for a new product launch. Make it conversion-focused with a hero, features, and CTA.',
  },
  {
    title: 'ICP fit check',
    prompt: "Does 'nina@vercel.com' match our ICP? Summarize reasons and risks.",
  },
  {
    title: 'Meeting brief',
    prompt: "Create a 3-bullet discovery brief for 'jane@acme.io' using enrichLead.",
  },
];

export default function AIDemoPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    containerRef.current?.scrollTo({ top: containerRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  // React Compiler automatically optimizes this function - no useCallback needed
  const send = async (prompt: string) => {
    setIsLoading(true);
    setMessages(prev => [...prev, { role: 'user', content: prompt }]);
    try {
      // Generate a conversation ID (in a real app, this would be managed per session)
      const conversationId = `conv-${Date.now()}-${Math.random().toString(36).substring(7)}`;

      // Use server action instead of fetch API
      const result = await chatWithAgentStreaming({
        conversationId,
        message: prompt,
      });

      // Read from stream
      let assistant = '';
      while (true) {
        const chunk = await result.stream.read();
        if (!chunk) break;

        try {
          const parsed = JSON.parse(chunk);
          if (parsed.success && parsed.data?.response) {
            assistant = parsed.data.response;
          } else if (parsed.error) {
            assistant = `Error: ${parsed.error}`;
            break;
          }
        } catch {
          // If not JSON, treat as plain text
          assistant += chunk;
        }

        setMessages(prev => {
          const next = [...prev];
          // Update last assistant message progressively
          const last = next[next.length - 1];
          if (last?.role === 'assistant') {
            last.content = assistant;
            return [...next];
          }
          return [...next, { role: 'assistant', content: assistant }];
        });
      }
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: `Error: ${err instanceof Error ? err.message : 'Failed to get response.'}`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className='mx-auto max-w-3xl p-6 space-y-6'>
      <h1 className='text-2xl font-semibold'>AI GTM Demo</h1>
      <p className='text-sm text-gray-500'>
        Streaming chat with tool-use (lead enrichment). Protected routes, background jobs, and
        observability are configured elsewhere in the app.
      </p>

      <div className='grid grid-cols-2 gap-2'>
        {PRESETS.map(p => (
          <button
            key={p.title}
            type='button'
            className='rounded border px-3 py-2 text-left hover:bg-gray-50'
            onClick={() => send(p.prompt)}
          >
            <strong className='block text-sm'>{p.title}</strong>
            <span className='block text-xs text-gray-500'>{p.prompt}</span>
          </button>
        ))}
      </div>

      <div ref={containerRef} className='h-80 overflow-auto rounded border bg-white p-3 text-sm'>
        {messages.map((m, i) => (
          <div key={`${m.role}-${i}-${m.content.substring(0, 20)}`} className='mb-3'>
            <div className='font-medium'>{m.role === 'user' ? 'You' : 'Assistant'}</div>
            <div className='whitespace-pre-wrap leading-relaxed'>{m.content}</div>
            {/* Lightweight v0 signal extraction for preview/code links */}
            {m.role === 'assistant' && /previewUrl\s*:\s*https?:/i.test(m.content) && (
              <div className='mt-2 text-xs'>
                <a
                  href={(m.content.match(/previewUrl\s*:\s*(https?:[^\s}]+)/i) || [])[1] || '#'}
                  target='_blank'
                  rel='noreferrer'
                  className='text-blue-600 underline'
                >
                  Open v0 preview
                </a>
              </div>
            )}
          </div>
        ))}
        {isLoading && <div className='text-gray-400'>Thinking…</div>}
      </div>

      <form
        className='flex gap-2'
        onSubmit={e => {
          e.preventDefault();
          if (!input.trim()) return;
          send(input.trim());
          setInput('');
        }}
      >
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder='Ask something (e.g., Use enrichLead on user@company.com)'
          className='flex-1 rounded border px-3 py-2'
        />
        <button
          disabled={isLoading}
          type='submit'
          className='rounded bg-black px-4 py-2 text-white disabled:opacity-50'
        >
          Send
        </button>
      </form>
    </div>
  );
}
