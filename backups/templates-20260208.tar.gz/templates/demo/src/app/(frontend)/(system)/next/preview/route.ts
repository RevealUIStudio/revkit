import { draftMode } from 'next/headers';
import { NextResponse } from 'next/server';

import type { NextRequest } from 'next/server';

/**
 * Preview route handler for RevealUI Content Engine
 * Enables draft mode when a valid preview token is provided
 */
export async function GET(req: NextRequest): Promise<Response> {
  const { searchParams } = new URL(req.url);
  const token = searchParams.get('token');
  const slug = searchParams.get('slug');
  const secret = process.env.REVEAL_SECRET;

  // Validate token
  if (!token || !secret) {
    return new NextResponse('Missing token or secret', { status: 401 });
  }

  // Verify token matches secret (simple validation)
  // In production, you may want to use a more secure token generation/validation
  if (token !== secret) {
    return new NextResponse('Invalid token', { status: 401 });
  }

  // Enable draft mode
  const draft = await draftMode();
  draft.enable();

  // Redirect to the preview URL or return success
  if (slug) {
    return NextResponse.redirect(new URL(slug, req.url));
  }

  return new NextResponse('Preview mode enabled', { status: 200 });
}
