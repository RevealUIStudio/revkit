import { generateMeta } from '@/config/system/utilities/generation';
import { getCurrentUser } from '@/features/users';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { BillingClient } from './BillingClient';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    description: 'View your billing information and download invoices',
    title: 'Billing & Invoices',
    url: '/account/billing',
  });
}

export default async function BillingPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?redirect=/account/billing');
  }

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-4xl'>
        {/* Header */}
        <div className='mb-8'>
          <h1 className='text-4xl font-bold mb-2'>Billing & Invoices</h1>
          <p className='text-muted-foreground'>
            Manage your payment methods, view invoices, and access billing history
          </p>
        </div>

        <BillingClient />
      </div>
    </div>
  );
}
