'use client';

import {
  addTicketMessageAction,
  createTicketAction,
  getMyTicketsAction,
  getTicketAction,
  getTicketMessagesAction,
} from '@/features/commerce/server/support-actions';
import type {
  SupportTicket,
  TicketCategory,
  TicketMessage,
  TicketStatus,
} from '@revealui/infrastructure/services/support/SupportTicketService';
import { Select } from '@/presentation/components/ui/client/select';
import { Textarea } from '@/presentation/components/ui/client/textarea';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/presentation/components/ui/primitives/dialog';
import { Input } from '@/presentation/components/ui/primitives/input';
import { Label } from '@/presentation/components/ui/primitives/label';
import { Badge } from '@/presentation/components/ui/server/badge';
import { HelpCircle, MessageSquare, Plus } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';

export function SupportClient() {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showTicketDialog, setShowTicketDialog] = useState(false);
  const [processing, setProcessing] = useState(false);

  // Form state
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<TicketCategory>('general');
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    loadTickets();
  }, []);

  async function loadTickets() {
    try {
      setLoading(true);
      setError(null);
      const result = await getMyTicketsAction({ limit: 50 });
      if (result.success && result.data) {
        setTickets(result.data);
      } else {
        setError(result.error ?? 'Failed to load tickets');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load tickets');
    } finally {
      setLoading(false);
    }
  }

  async function handleCreateTicket() {
    if (!subject.trim() || !description.trim()) {
      setError('Subject and description are required');
      return;
    }

    try {
      setProcessing(true);
      setError(null);
      const result = await createTicketAction(subject, description, category);
      if (result.success && result.data) {
        setTickets([result.data, ...tickets]);
        setShowCreateDialog(false);
        setSubject('');
        setDescription('');
        setCategory('general');
        // Open the new ticket
        await handleViewTicket(result.data.id);
      } else {
        setError(result.error ?? 'Failed to create ticket');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create ticket');
    } finally {
      setProcessing(false);
    }
  }

  async function handleViewTicket(ticketId: string) {
    try {
      setLoading(true);
      const [ticketResult, messagesResult] = await Promise.all([
        getTicketAction(ticketId),
        getTicketMessagesAction(ticketId),
      ]);

      if (ticketResult.success && ticketResult.data) {
        setSelectedTicket(ticketResult.data);
        setShowTicketDialog(true);
      }

      if (messagesResult.success && messagesResult.data) {
        setMessages(messagesResult.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load ticket');
    } finally {
      setLoading(false);
    }
  }

  async function handleAddMessage() {
    if (!selectedTicket || !newMessage.trim()) return;

    try {
      setProcessing(true);
      setError(null);
      const result = await addTicketMessageAction(selectedTicket.id, newMessage);
      if (result.success && result.data) {
        setMessages([...messages, result.data]);
        setNewMessage('');
        // Reload ticket to get updated status
        await loadTickets();
        const ticketResult = await getTicketAction(selectedTicket.id);
        if (ticketResult.success && ticketResult.data) {
          setSelectedTicket(ticketResult.data);
        }
      } else {
        setError(result.error ?? 'Failed to add message');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add message');
    } finally {
      setProcessing(false);
    }
  }

  function getStatusBadge(status: TicketStatus) {
    const colors = {
      open: 'bg-blue-100 text-blue-800 border-blue-200',
      in_progress: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      waiting_customer: 'bg-orange-100 text-orange-800 border-orange-200',
      resolved: 'bg-green-100 text-green-800 border-green-200',
      closed: 'bg-gray-100 text-gray-800 border-gray-200',
    };
    return <Badge className={colors[status] || colors.open}>{status.replace('_', ' ')}</Badge>;
  }

  function getPriorityBadge(priority: string) {
    const colors = {
      low: 'bg-gray-100 text-gray-800',
      medium: 'bg-blue-100 text-blue-800',
      high: 'bg-orange-100 text-orange-800',
      urgent: 'bg-red-100 text-red-800',
    };
    return (
      <Badge className={colors[priority as keyof typeof colors] || colors.medium}>{priority}</Badge>
    );
  }

  function formatDate(date: Date): string {
    return new Date(date).toLocaleString();
  }

  if (loading && tickets.length === 0) {
    return (
      <Card>
        <CardContent className='pt-6'>
          <p className='text-center text-muted-foreground'>Loading tickets...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className='space-y-6'>
      {error && (
        <Card className='border-destructive bg-destructive/10'>
          <CardContent className='pt-6'>
            <p className='text-sm text-destructive'>{error}</p>
          </CardContent>
        </Card>
      )}

      <div className='flex justify-between items-center'>
        <h2 className='text-2xl font-semibold'>My Tickets</h2>
        <Button onClick={() => setShowCreateDialog(true)}>
          <Plus className='h-4 w-4 mr-2' />
          New Ticket
        </Button>
      </div>

      {tickets.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No Tickets Yet</CardTitle>
            <CardDescription>
              You haven't created any support tickets. Create one to get help with any questions or
              issues.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className='h-4 w-4 mr-2' />
              Create Your First Ticket
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <div className='grid gap-4'>
          {tickets.map(ticket => (
            <Card
              key={ticket.id}
              className='hover:shadow-md transition-shadow cursor-pointer'
              onClick={() => handleViewTicket(ticket.id)}
            >
              <CardHeader>
                <div className='flex items-start justify-between'>
                  <div className='flex-1'>
                    <div className='flex items-center gap-2 mb-2'>
                      <CardTitle className='text-lg'>{ticket.subject}</CardTitle>
                      {getStatusBadge(ticket.status)}
                      {getPriorityBadge(ticket.priority)}
                    </div>
                    <CardDescription>
                      {ticket.ticketNumber} • {formatDate(ticket.createdAt)}
                    </CardDescription>
                  </div>
                  <MessageSquare className='h-5 w-5 text-muted-foreground' />
                </div>
              </CardHeader>
              <CardContent>
                <p className='text-sm text-muted-foreground line-clamp-2'>{ticket.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Ticket Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Support Ticket</DialogTitle>
            <DialogDescription>
              Describe your issue or question and we'll get back to you as soon as possible.
            </DialogDescription>
          </DialogHeader>
          <div className='space-y-4'>
            <div>
              <Label htmlFor='category'>Category</Label>
              <Select
                id='category'
                value={category}
                onChange={e => setCategory(e.target.value as TicketCategory)}
                options={[
                  { value: 'general', label: 'General' },
                  { value: 'technical', label: 'Technical' },
                  { value: 'billing', label: 'Billing' },
                  { value: 'account', label: 'Account' },
                  { value: 'feature_request', label: 'Feature Request' },
                  { value: 'bug_report', label: 'Bug Report' },
                ]}
              />
            </div>
            <div>
              <Label htmlFor='subject'>Subject</Label>
              <Input
                id='subject'
                value={subject}
                onChange={e => setSubject(e.target.value)}
                placeholder='Brief summary of your issue'
              />
            </div>
            <div>
              <Label htmlFor='description'>Description</Label>
              <Textarea
                id='description'
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder='Detailed description of your issue or question...'
                rows={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant='outline' onClick={() => setShowCreateDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateTicket} disabled={processing}>
              {processing ? 'Creating...' : 'Create Ticket'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Ticket Dialog */}
      <Dialog open={showTicketDialog} onOpenChange={setShowTicketDialog}>
        <DialogContent className='max-w-3xl max-h-[80vh] overflow-y-auto'>
          <DialogHeader>
            <div className='flex items-center justify-between'>
              <div>
                <DialogTitle>{selectedTicket?.subject}</DialogTitle>
                <DialogDescription>
                  {selectedTicket?.ticketNumber} • Created{' '}
                  {selectedTicket && formatDate(selectedTicket.createdAt)}
                </DialogDescription>
              </div>
              <div className='flex gap-2'>
                {selectedTicket && getStatusBadge(selectedTicket.status)}
                {selectedTicket && getPriorityBadge(selectedTicket.priority)}
              </div>
            </div>
          </DialogHeader>
          <div className='space-y-4'>
            <Card>
              <CardHeader>
                <CardTitle className='text-sm'>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-sm whitespace-pre-wrap'>{selectedTicket?.description}</p>
              </CardContent>
            </Card>

            <div className='space-y-3'>
              <h3 className='font-semibold'>Messages</h3>
              {messages.length === 0 ? (
                <p className='text-sm text-muted-foreground'>No messages yet</p>
              ) : (
                <div className='space-y-3'>
                  {messages.map(msg => (
                    <Card key={msg.id} className={msg.isFromAgent ? 'bg-muted' : ''}>
                      <CardHeader className='pb-2'>
                        <div className='flex justify-between items-center'>
                          <CardTitle className='text-sm'>
                            {msg.isFromAgent ? 'Support Agent' : 'You'}
                          </CardTitle>
                          <span className='text-xs text-muted-foreground'>
                            {formatDate(msg.createdAt)}
                          </span>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className='text-sm whitespace-pre-wrap'>{msg.message}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {selectedTicket &&
              (selectedTicket.status === 'open' ||
                selectedTicket.status === 'in_progress' ||
                selectedTicket.status === 'waiting_customer') && (
                <div className='space-y-2'>
                  <Label htmlFor='new-message'>Add a message</Label>
                  <Textarea
                    id='new-message'
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    placeholder='Type your message...'
                    rows={3}
                  />
                  <Button onClick={handleAddMessage} disabled={processing || !newMessage.trim()}>
                    {processing ? 'Sending...' : 'Send Message'}
                  </Button>
                </div>
              )}
          </div>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle className='flex items-center gap-2'>
            <HelpCircle className='h-5 w-5' />
            Need More Help?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className='text-sm text-muted-foreground mb-4'>
            Check out our help center for common questions and solutions, or contact us directly.
          </p>
          <div className='flex gap-3'>
            <Button asChild variant='outline'>
              <Link href='/help'>Visit Help Center</Link>
            </Button>
            <Button asChild variant='outline'>
              <a href='mailto:support@reveal.com'>Email Support</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
