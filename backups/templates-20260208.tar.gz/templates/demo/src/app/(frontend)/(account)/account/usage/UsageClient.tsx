'use client';

import {
  getMyCreditBalanceAction,
  getMyCreditTransactionsAction,
} from '@/features/commerce/server/credit-actions';
import type {
  CreditBalance,
  CreditTransaction,
} from '@revealui/infrastructure/services/billing/CreditService';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Badge } from '@/presentation/components/ui/server/badge';
import { Activity, CreditCard, TrendingDown, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';

export function UsageClient() {
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      setError(null);
      const [balanceResult, transactionsResult] = await Promise.all([
        getMyCreditBalanceAction(),
        getMyCreditTransactionsAction(50),
      ]);

      if (balanceResult.success && balanceResult.data) {
        setBalance(balanceResult.data);
      } else {
        setError(balanceResult.error ?? 'Failed to load credit balance');
      }

      if (transactionsResult.success && transactionsResult.data) {
        setTransactions(transactionsResult.data);
      } else {
        setError(transactionsResult.error ?? 'Failed to load transactions');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }

  function formatDate(date: Date): string {
    return new Date(date).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  function getTransactionTypeBadge(type: string) {
    const colors: Record<string, string> = {
      allocation: 'bg-green-100 text-green-800 border-green-200',
      purchase: 'bg-blue-100 text-blue-800 border-blue-200',
      consumption: 'bg-orange-100 text-orange-800 border-orange-200',
      refund: 'bg-purple-100 text-purple-800 border-purple-200',
      expiration: 'bg-red-100 text-red-800 border-red-200',
    };
    return (
      <Badge className={colors[type] || 'bg-gray-100 text-gray-800 border-gray-200'}>{type}</Badge>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className='pt-6'>
          <p className='text-center text-muted-foreground'>Loading usage data...</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className='border-destructive bg-destructive/10'>
        <CardContent className='pt-6'>
          <p className='text-sm text-destructive'>{error}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className='space-y-6'>
      {/* Balance Overview */}
      {balance && (
        <div className='grid gap-4 md:grid-cols-3'>
          <Card>
            <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
              <CardTitle className='text-sm font-medium'>Current Balance</CardTitle>
              <CreditCard className='h-4 w-4 text-muted-foreground' />
            </CardHeader>
            <CardContent>
              <div className='text-2xl font-bold'>{balance.balance.toLocaleString()}</div>
              <p className='text-xs text-muted-foreground'>Credits available</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
              <CardTitle className='text-sm font-medium'>Allocated This Period</CardTitle>
              <TrendingUp className='h-4 w-4 text-muted-foreground' />
            </CardHeader>
            <CardContent>
              <div className='text-2xl font-bold text-green-600'>
                {balance.allocated.toLocaleString()}
              </div>
              <p className='text-xs text-muted-foreground'>
                Period: {new Date(balance.periodStart).toLocaleDateString()} -{' '}
                {new Date(balance.periodEnd).toLocaleDateString()}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
              <CardTitle className='text-sm font-medium'>Consumed This Period</CardTitle>
              <TrendingDown className='h-4 w-4 text-muted-foreground' />
            </CardHeader>
            <CardContent>
              <div className='text-2xl font-bold text-orange-600'>
                {balance.consumed.toLocaleString()}
              </div>
              <p className='text-xs text-muted-foreground'>
                {balance.allocated > 0
                  ? `${((balance.consumed / balance.allocated) * 100).toFixed(1)}% of allocated`
                  : 'No allocation yet'}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle className='flex items-center gap-2'>
            <Activity className='h-5 w-5' />
            Transaction History
          </CardTitle>
          <CardDescription>Recent credit transactions and usage</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className='text-center py-8'>
              <p className='text-muted-foreground mb-4'>No transactions yet</p>
              <p className='text-sm text-muted-foreground mb-4'>
                Your credit transactions will appear here once you start using credits or purchasing
                credit packs.
              </p>
              <Button asChild variant='outline'>
                <Link href='/pricing'>View Plans</Link>
              </Button>
            </div>
          ) : (
            <div className='space-y-3'>
              {transactions.map(transaction => (
                <div
                  key={transaction.id}
                  className='flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors'
                >
                  <div className='flex-1'>
                    <div className='flex items-center gap-2 mb-1'>
                      {getTransactionTypeBadge(transaction.type)}
                      <span className='font-medium'>
                        {transaction.amount > 0 ? '+' : ''}
                        {transaction.amount.toLocaleString()}
                      </span>
                      <span className='text-sm text-muted-foreground'>credits</span>
                    </div>
                    <p className='text-sm text-muted-foreground'>{transaction.description}</p>
                    {transaction.category && (
                      <p className='text-xs text-muted-foreground mt-1'>
                        Category: {transaction.category}
                      </p>
                    )}
                  </div>
                  <div className='text-right'>
                    <p className='text-sm text-muted-foreground'>
                      {formatDate(transaction.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Help Section */}
      <Card>
        <CardHeader>
          <CardTitle>Need More Credits?</CardTitle>
          <CardDescription>
            Purchase credit packs or upgrade your plan to get more credits
          </CardDescription>
        </CardHeader>
        <CardContent className='flex gap-3'>
          <Button asChild>
            <Link href='/pricing'>View Plans</Link>
          </Button>
          <Button asChild variant='outline'>
            <a href='mailto:usage@reveal.com'>Contact Support</a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
