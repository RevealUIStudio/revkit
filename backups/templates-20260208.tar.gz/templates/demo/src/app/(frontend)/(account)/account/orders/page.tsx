import { generateMeta } from '@/config/system/utilities/generation.ts';
import { getOrdersByUser } from '@/features/commerce/server';
import { getCurrentUser } from '@/features/users';
import type { Order } from '@revealui/infrastructure/cms/db/reveal-types';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';

// User-specific content - always dynamic, no caching
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'My Orders - reveal UI',
    description: 'View your order history and track shipments',
    url: '/account/orders',
  });
}

function getStatusBadgeColor(status: string) {
  switch (status) {
    case 'confirmed':
    case 'delivered':
      return 'bg-green-100 text-green-800';
    case 'processing':
    case 'shipped':
      return 'bg-blue-100 text-blue-800';
    case 'pending':
      return 'bg-yellow-100 text-yellow-800';
    case 'cancelled':
    case 'refunded':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function OrderCard({ order }: { order: Order }) {
  return (
    <Card className='hover:shadow-lg transition-shadow'>
      <CardHeader>
        <div className='flex justify-between items-start'>
          <div>
            <CardTitle className='text-lg'>Order {order.orderNumber}</CardTitle>
            <CardDescription>
              Placed on {new Date(order.createdAt || '').toLocaleDateString()}
            </CardDescription>
          </div>
          <span
            className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadgeColor(
              order.status || 'pending'
            )}`}
          >
            {order.status?.charAt(0).toUpperCase() + order.status?.slice(1)}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className='space-y-2'>
          <div className='flex justify-between text-sm'>
            <span className='text-muted-foreground'>Items:</span>
            <span className='font-medium'>{order.items?.length || 0}</span>
          </div>
          <div className='flex justify-between text-sm'>
            <span className='text-muted-foreground'>Total:</span>
            <span className='font-bold'>${order.totals?.total?.toFixed(2)}</span>
          </div>
          {order.payment?.method && (
            <div className='flex justify-between text-sm'>
              <span className='text-muted-foreground'>Payment:</span>
              <span className='font-medium capitalize'>{order.payment.method}</span>
            </div>
          )}
          {order.fulfillmentStatus && (
            <div className='flex justify-between text-sm'>
              <span className='text-muted-foreground'>Fulfillment:</span>
              <span className='font-medium capitalize'>{order.fulfillmentStatus}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className='flex gap-2'>
        <Button variant='outline' size='sm' className='flex-1' asChild>
          <Link href={`/account/orders/${order.id}`}>View Details</Link>
        </Button>
        {order.status === 'shipped' && order.shipping?.trackingUrl && (
          <Button variant='UI' size='sm' className='flex-1' asChild>
            <Link href={order.shipping.trackingUrl} target='_blank' rel='noopener noreferrer'>
              Track Shipment
            </Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}

export default async function OrdersPage() {
  const user = await getCurrentUser();
  const ordersResult = user
    ? await getOrdersByUser(
        (await import('@revealui/content')).getRevealUI({
          config: (await import('@/reveal.config')).getRevealConfig() as any,
        }) as any,
        user.id
      )
    : { success: true, data: [] };
  const orders = (ordersResult.success ? (ordersResult.data as Order[]) : []) || [];

  return (
    <div className='min-h-screen py-8'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <h1 className='text-3xl font-bold mb-8'>My Orders</h1>

          {orders.length > 0 ? (
            <div className='space-y-4'>
              {orders.map(order => (
                <OrderCard key={order.id} order={order} />
              ))}
            </div>
          ) : (
            <Card>
              <CardHeader className='text-center'>
                <CardTitle>No Orders Yet</CardTitle>
                <CardDescription>
                  You haven't placed any orders yet. Start shopping to see your orders here.
                </CardDescription>
              </CardHeader>
              <CardContent className='flex justify-center py-8'>
                <svg
                  className='w-32 h-32 text-muted-foreground'
                  fill='none'
                  stroke='currentColor'
                  viewBox='0 0 24 24'
                  role='img'
                  aria-label='Shopping bag icon'
                >
                  <title>Shopping bag icon</title>
                  <path
                    strokeLinecap='round'
                    strokeLinejoin='round'
                    strokeWidth={1.5}
                    d='M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z'
                  />
                </svg>
              </CardContent>
              <CardFooter className='flex justify-center'>
                <Button asChild variant='UI' size='lg'>
                  <Link href='/shop'>Start Shopping</Link>
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
