import { generateMeta } from '@/config/system/utilities/generation';
import { getCurrentUser } from '@/features/users';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { UsageClient } from './UsageClient';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    description: 'View your usage statistics and credit balance',
    title: 'Usage & Credits | Account',
    url: '/account/usage',
  });
}

export default async function UsagePage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?redirect=/account/usage');
  }

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-6xl'>
        <div className='mb-8'>
          <h1 className='text-4xl font-bold mb-2'>Usage & Credits</h1>
          <p className='text-muted-foreground'>
            View your credit balance, transaction history, and usage statistics
          </p>
        </div>

        <UsageClient />
      </div>
    </div>
  );
}
