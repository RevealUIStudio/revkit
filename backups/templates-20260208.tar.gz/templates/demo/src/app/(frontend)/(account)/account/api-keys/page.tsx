/**
 * API Keys Page
 *
 * Customer portal page for managing API keys
 */

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Shield } from 'lucide-react';

export const metadata = {
  title: 'API Keys | Account',
  description: 'Manage your API keys and access tokens',
};

export default async function APIKeysPage() {
  return (
    <div className='container mx-auto px-4 max-w-6xl py-8'>
      <div className='mb-8'>
        <h1 className='text-4xl font-bold mb-2'>API Keys</h1>
        <p className='text-muted-foreground'>Programmatic access is currently unavailable</p>
      </div>

      <Card className='border-yellow-200 bg-yellow-50'>
        <CardHeader>
          <CardTitle className='flex items-center gap-2'>
            <Shield className='h-5 w-5 text-yellow-600' />
            API Access Unavailable
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className='text-sm text-muted-foreground mb-4'>
            We&rsquo;re rebuilding the developer portal. API key management will return after the
            new integrations ship. In the meantime you can review our pricing tiers or contact
            support for early-access requests.
          </CardDescription>
          <div className='flex gap-3'>
            <Button asChild>
              <a href='/pricing'>View Plans</a>
            </Button>
            <Button asChild variant='outline'>
              <a href='mailto:dev@reveal.com'>Contact Support</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
