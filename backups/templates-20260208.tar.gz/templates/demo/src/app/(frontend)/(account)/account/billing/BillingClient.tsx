'use client';

import { createPortalSessionAction } from '@/features/commerce/server/billing-actions';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { CreditCard, FileText, Receipt } from 'lucide-react';
import { useState } from 'react';

export function BillingClient() {
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleOpenPortal() {
    try {
      setProcessing(true);
      setError(null);

      const result = await createPortalSessionAction();

      if (result.success && result.data?.url) {
        // Redirect to Stripe Customer Portal
        window.location.href = result.data.url;
      } else {
        setError(result.error ?? 'Failed to open billing portal');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to open billing portal');
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className='space-y-6'>
      {error && (
        <Card className='border-destructive bg-destructive/10'>
          <CardContent className='pt-6'>
            <p className='text-sm text-destructive'>{error}</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className='flex items-center gap-2'>
            <CreditCard className='h-5 w-5' />
            Billing Portal
          </CardTitle>
          <CardDescription>
            Access the Stripe Customer Portal to manage your payment methods, view invoices, and
            update billing information.
          </CardDescription>
        </CardHeader>
        <CardContent className='space-y-4'>
          <p className='text-sm text-muted-foreground'>The billing portal allows you to:</p>
          <ul className='list-disc list-inside space-y-2 text-sm text-muted-foreground ml-2'>
            <li>Update your payment method</li>
            <li>View and download invoices</li>
            <li>Review billing history</li>
            <li>Update billing address</li>
            <li>Manage subscription settings</li>
          </ul>
          <div className='pt-4'>
            <Button
              onClick={handleOpenPortal}
              disabled={processing}
              size='lg'
              className='w-full sm:w-auto'
            >
              {processing ? (
                <span className='flex items-center gap-2'>
                  <span className='w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin' />
                  Opening Portal...
                </span>
              ) : (
                <span className='flex items-center gap-2'>
                  <Receipt className='h-4 w-4' />
                  Open Billing Portal
                </span>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className='flex items-center gap-2'>
            <FileText className='h-5 w-5' />
            Need Help?
          </CardTitle>
          <CardDescription>
            If you need assistance with billing or have questions about your invoices
          </CardDescription>
        </CardHeader>
        <CardContent className='space-y-3'>
          <p className='text-sm text-muted-foreground'>
            For billing questions or support, please contact our team:
          </p>
          <div className='flex gap-3 flex-wrap'>
            <Button asChild variant='outline'>
              <a href='mailto:billing@reveal.com'>Email Billing Support</a>
            </Button>
            <Button asChild variant='outline'>
              <a href='/pricing'>View Pricing Plans</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
