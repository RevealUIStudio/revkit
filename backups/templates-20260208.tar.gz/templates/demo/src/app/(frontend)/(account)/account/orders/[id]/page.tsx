import { Button as ClientButton } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function OrdersPage() {
  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-4xl'>
        <Card>
          <CardHeader>
            <CardTitle className='text-2xl'>Order History Unavailable</CardTitle>
            <CardDescription>
              We&rsquo;re migrating the commerce backend. Order details will return once the new
              services are online.
            </CardDescription>
          </CardHeader>
          <CardContent className='space-y-4'>
            <p className='text-sm text-muted-foreground'>
              In the meantime you can browse the catalog or contact support if you need help with an
              existing purchase.
            </p>
            <div className='flex gap-3'>
              <ClientButton asChild>
                <a href='/shop'>Browse Products</a>
              </ClientButton>
              <ClientButton asChild variant='outline'>
                <a href='mailto:support@reveal.com'>Contact Support</a>
              </ClientButton>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
