import { generateMeta } from '@/config/system/utilities/generation';
import { getCurrentUser } from '@/features/users';
import { Button as ClientButton } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { AccountClient } from './AccountClient';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'My Account',
    description: 'Manage your account, subscription, and settings',
    url: '/account',
  });
}

export default async function AccountPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?redirect=/account');
  }

  const safeName = user.name || 'there';

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-3xl space-y-8'>
        <AccountClient
          {...(user.name ? { userName: user.name } : {})}
          userRole={String(user.role || 'user')}
          isPremium={false}
          isNewUser={false}
        />

        <Card>
          <CardHeader>
            <CardTitle className='text-3xl'>Welcome back, {safeName}!</CardTitle>
            <CardDescription>
              The self-service account portal is being rebuilt. Until the new experience is ready,
              use the links below or reach out to our team for anything you need.
            </CardDescription>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Links</CardTitle>
            <CardDescription>Common account actions while we migrate the portal.</CardDescription>
          </CardHeader>
          <CardContent className='grid gap-3 sm:grid-cols-2'>
            <ClientButton asChild variant='outline' className='justify-start'>
              <a href='/account/profile'>Update profile details</a>
            </ClientButton>
            <ClientButton asChild variant='outline' className='justify-start'>
              <a href='/account/subscription'>Manage subscription</a>
            </ClientButton>
            <ClientButton asChild variant='outline' className='justify-start'>
              <a href='/account/billing'>Billing help</a>
            </ClientButton>
            <ClientButton asChild variant='outline' className='justify-start'>
              <a href='/account/support'>Contact support</a>
            </ClientButton>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Need something else?</CardTitle>
            <CardDescription>
              Our support crew can take care of subscription updates, refunds, and more.
            </CardDescription>
          </CardHeader>
          <CardContent className='flex gap-3'>
            <ClientButton asChild>
              <a href='mailto:account@reveal.com'>Email Account Support</a>
            </ClientButton>
            <ClientButton asChild variant='outline'>
              <a href='/help'>Browse Help Center</a>
            </ClientButton>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
