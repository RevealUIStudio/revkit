import { generateMeta } from '@/config/system/utilities/generation';
import { getCurrentUser } from '@/features/users';
import { getSubscriptionService } from '@revealui/infrastructure/services/billing/SubscriptionService';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { SubscriptionClient } from './SubscriptionClient';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    description: 'View and manage your subscription plan',
    title: 'Manage Subscription',
    url: '/account/subscription',
  });
}

export default async function SubscriptionPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?redirect=/account/subscription');
  }

  const subscriptionService = getSubscriptionService();
  await subscriptionService.initialize();
  const subscription = await subscriptionService.getSubscriptionByUser(user.id);

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-4xl'>
        <SubscriptionClient initialSubscription={subscription ?? undefined} />
      </div>
    </div>
  );
}
