'use client';

import { OnboardingChecklist } from '@/features/users/ui/OnboardingChecklist';
import { WelcomeModal } from '@/features/users/ui/WelcomeModal';
import { TourButton } from '@/presentation/demo/components/TourButton';
import { customerDashboardTourSteps } from '@/presentation/demo/tour-config';

interface AccountClientProps {
  userName?: string;
  userRole?: string;
  isPremium: boolean;
  isNewUser?: boolean;
}

export function AccountClient({ userName, userRole, isPremium, isNewUser }: AccountClientProps) {
  const welcomeProps = {
    ...(userName ? { userName } : {}),
    ...(userRole ? { userRole } : {}),
  };

  return (
    <>
      <WelcomeModal {...welcomeProps} />
      {!isPremium && (
        <div className='mb-6'>
          <OnboardingChecklist />
        </div>
      )}
      {/* Customer dashboard tour - auto-starts for new users */}
      <TourButton
        steps={customerDashboardTourSteps}
        storageKey='customer-dashboard-tour'
        buttonText='Dashboard Tour'
        position='bottom-right'
        autoStart={Boolean(isNewUser)}
      />
    </>
  );
}
