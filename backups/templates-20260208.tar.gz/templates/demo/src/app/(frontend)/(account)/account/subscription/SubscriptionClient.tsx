'use client';

import { createSubscriptionCheckoutAction } from '@/features/commerce/server/checkout-actions';
import type { Subscription } from '@revealui/infrastructure/services/billing/SubscriptionService';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Badge } from '@/presentation/components/ui/server/badge';
import Link from 'next/link';
import { useState } from 'react';

interface SubscriptionClientProps {
  initialSubscription?: Subscription;
}

export function SubscriptionClient({ initialSubscription }: SubscriptionClientProps) {
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubscribe(priceId: string) {
    try {
      setProcessing(true);
      setError(null);
      const result = await createSubscriptionCheckoutAction(priceId);

      if (result.success && result.data?.url) {
        // Redirect to Stripe checkout
        window.location.href = result.data.url;
      } else {
        setError(result.error ?? 'Failed to create subscription checkout');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start subscription');
    } finally {
      setProcessing(false);
    }
  }

  // Get Stripe price ID from environment (client-side access)
  const priceId =
    process.env.NEXT_PUBLIC_STRIPE_PRICE_ID || process.env.NEXT_PUBLIC_STRIPE_BASIC_PLAN_ID;

  if (!priceId) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className='text-2xl'>Subscription Management</CardTitle>
          <CardDescription>
            Subscription plans are being configured. Please check back soon or contact support.
          </CardDescription>
        </CardHeader>
        <CardContent className='space-y-4'>
          <p className='text-sm text-muted-foreground'>
            Our subscription system is being set up. In the meantime, you can contact us directly
            for subscription management.
          </p>
          <div className='flex gap-3'>
            <Button asChild variant='outline'>
              <a href='mailto:subscriptions@reveal.com'>Contact Subscriptions</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  function getStatusBadgeColor(status: string) {
    switch (status) {
      case 'active':
      case 'trialing':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'past_due':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'canceled':
      case 'unpaid':
      case 'incomplete_expired':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'incomplete':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }

  function formatDate(date: Date): string {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  function capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).replace(/_/g, ' ');
  }

  if (initialSubscription) {
    const isActive =
      initialSubscription.status === 'active' || initialSubscription.status === 'trialing';

    return (
      <Card>
        <CardHeader>
          <div className='flex items-center justify-between'>
            <div>
              <CardTitle className='text-2xl'>Current Subscription</CardTitle>
              <CardDescription>Manage your active subscription plan</CardDescription>
            </div>
            <Badge className={getStatusBadgeColor(initialSubscription.status)}>
              {capitalize(initialSubscription.status)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className='space-y-6'>
          {error && (
            <div className='p-4 bg-destructive/10 border border-destructive rounded-md'>
              <p className='text-sm text-destructive'>{error}</p>
            </div>
          )}

          <div className='grid gap-4 md:grid-cols-2'>
            <div className='space-y-1'>
              <p className='text-sm font-medium text-muted-foreground'>Plan</p>
              <p className='text-lg font-semibold capitalize'>{initialSubscription.tier}</p>
            </div>
            <div className='space-y-1'>
              <p className='text-sm font-medium text-muted-foreground'>Billing Period</p>
              <p className='text-lg font-semibold capitalize'>{initialSubscription.interval}</p>
            </div>
            <div className='space-y-1'>
              <p className='text-sm font-medium text-muted-foreground'>Current Period Start</p>
              <p className='text-base'>{formatDate(initialSubscription.currentPeriodStart)}</p>
            </div>
            <div className='space-y-1'>
              <p className='text-sm font-medium text-muted-foreground'>Current Period End</p>
              <p className='text-base'>{formatDate(initialSubscription.currentPeriodEnd)}</p>
            </div>
          </div>

          {initialSubscription.cancelAtPeriodEnd && (
            <div className='p-4 bg-yellow-50 border border-yellow-200 rounded-md'>
              <p className='text-sm text-yellow-800 font-medium'>
                This subscription will cancel at the end of the current billing period.
              </p>
            </div>
          )}

          <div className='pt-4 border-t space-y-3'>
            <p className='text-sm text-muted-foreground'>
              You can manage your subscription through Stripe&rsquo;s customer portal or contact
              support for assistance.
            </p>
            <div className='flex gap-3 flex-wrap'>
              <Button asChild variant='outline'>
                <Link href='/pricing'>View Plans</Link>
              </Button>
              <Button asChild variant='outline'>
                <a href='mailto:subscriptions@reveal.com'>Contact Support</a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className='text-2xl'>Manage Subscription</CardTitle>
        <CardDescription>Subscribe to a plan or manage your existing subscription</CardDescription>
      </CardHeader>
      <CardContent className='space-y-4'>
        {error && (
          <div className='p-4 bg-destructive/10 border border-destructive rounded-md'>
            <p className='text-sm text-destructive'>{error}</p>
          </div>
        )}

        <div className='space-y-3'>
          <p className='text-sm text-muted-foreground'>
            Choose a subscription plan to get started. You can manage or cancel your subscription
            anytime from your account settings.
          </p>

          <div className='flex gap-3 flex-wrap'>
            <Button onClick={() => handleSubscribe(priceId)} disabled={processing}>
              {processing ? 'Processing...' : 'Subscribe Now'}
            </Button>
            <Button asChild variant='outline'>
              <Link href='/pricing'>Compare Plans</Link>
            </Button>
          </div>
        </div>

        <div className='pt-4 border-t space-y-2 text-sm text-muted-foreground'>
          <p>
            Already have a subscription? You can manage it through Stripe&rsquo;s customer portal.
          </p>
          <p>
            Need help?{' '}
            <a href='mailto:subscriptions@reveal.com' className='text-primary underline'>
              Contact our support team
            </a>
            .
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
