import { generateMeta } from '@/config/system/utilities/generation';
import { getCurrentUser } from '@/features/users';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { SupportClient } from './SupportClient';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    description: 'Manage your support tickets',
    title: 'Support | Account',
    url: '/account/support',
  });
}

export default async function SupportPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?redirect=/account/support');
  }

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-6xl'>
        <div className='mb-8'>
          <h1 className='text-4xl font-bold mb-2'>Support Center</h1>
          <p className='text-muted-foreground'>
            Manage your support tickets, view status, and get help
          </p>
        </div>

        <SupportClient />
      </div>
    </div>
  );
}
