'use client';

import { getEnvVar } from '@/config/presentation/environment';
import { useSearchParams } from 'next/navigation';
import { useState } from 'react';

export default function UpgradePage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const searchParams = useSearchParams();

  // Get checkout type and parameters from URL
  const checkoutType = searchParams.get('type');
  const videoId = searchParams.get('videoId');
  const price = searchParams.get('price');

  const stripePriceId =
    getEnvVar('NEXT_PUBLIC_STRIPE_PRICE_ID') ?? getEnvVar('NEXT_PUBLIC_STRIPE_BASIC_PLAN_ID');

  async function startCheckout() {
    setLoading(true);
    setError(null);
    try {
      // For video purchases, we need a different approach since we removed the manual checkout route
      // The Stripe plugin should handle this through its built-in checkout system
      if (checkoutType === 'video' && videoId && price) {
        // For video purchases, redirect to subscription upgrade
        // The subscription will include access to all videos
        const res = await fetch('/api/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            priceId: stripePriceId,
            metadata: { videoId, purchaseType: 'video' },
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || 'Failed to start checkout');
        if (data?.url) {
          window.location.href = data.url as string;
          return;
        }
      } else {
        // Regular subscription upgrade
        const res = await fetch('/api/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || 'Failed to start checkout');
        if (data?.url) {
          window.location.href = data.url as string;
          return;
        }
      }
      throw new Error('Missing checkout URL');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className='max-w-xl mx-auto p-8'>
      <h1 className='text-2xl font-bold mb-2'>
        {checkoutType === 'video' ? 'Purchase Video Access' : 'Upgrade to Premium'}
      </h1>
      <p className='text-gray-600 mb-6'>
        {checkoutType === 'video'
          ? `Get access to this exclusive fight video${price ? ` for $${price}` : ''}.`
          : 'Get access to exclusive content and features.'}
      </p>

      {checkoutType === 'video' && videoId && (
        <div className='bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-6'>
          <p className='text-sm text-blue-800 dark:text-blue-200'>
            💡 <strong>Tip:</strong> Subscribe to Premium for unlimited access to all videos at a
            better value!
          </p>
        </div>
      )}

      {error ? <p className='text-red-600 mb-4'>{error}</p> : null}

      <button
        type='button'
        disabled={loading}
        onClick={startCheckout}
        className='px-6 py-3 rounded bg-black text-white disabled:opacity-50 w-full'
      >
        {loading
          ? 'Redirecting...'
          : checkoutType === 'video'
            ? 'Purchase Video Access'
            : 'Upgrade Now'}
      </button>
    </div>
  );
}
