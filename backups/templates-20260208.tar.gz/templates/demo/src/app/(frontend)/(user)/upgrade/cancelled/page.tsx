import Link from 'next/link';

export default function UpgradeCancelledPage() {
  return (
    <div className='max-w-xl mx-auto p-8 text-center'>
      <h1 className='text-2xl font-bold mb-2'>Checkout Cancelled</h1>
      <p className='text-gray-600 mb-6'>No charge was made. You can try again anytime.</p>
      <Link href='/upgrade' className='text-blue-600 underline'>
        Back to Upgrade
      </Link>
    </div>
  );
}
