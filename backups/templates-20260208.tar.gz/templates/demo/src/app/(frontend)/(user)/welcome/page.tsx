import { Button } from '@/presentation/components/ui/primitives/button';
import Link from 'next/link';
import { Suspense } from 'react';

function WelcomeContent() {
  return (
    <div className='min-h-screen bg-gradient-to-br from-background via-background to-brand-red/5 flex items-center justify-center p-6'>
      <div className='max-w-4xl w-full'>
        {/* Success Icon */}
        <div className='text-center mb-8'>
          <div className='inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-brand-red to-brand-orange rounded-full mb-6 animate-bounce'>
            <svg
              className='w-10 h-10 text-white'
              fill='none'
              stroke='currentColor'
              viewBox='0 0 24 24'
            >
              <path
                strokeLinecap='round'
                strokeLinejoin='round'
                strokeWidth={2}
                d='M5 13l4 4L19 7'
              />
            </svg>
          </div>
          <h1 className='text-4xl md:text-5xl font-bold text-foreground mb-4'>
            Welcome to reveal UI! [SUCCESS]
          </h1>
          <p className='text-xl text-muted-foreground mb-2'>Your payment was successful!</p>
          <p className='text-lg text-muted-foreground'>
            Get ready to experience everything we have to offer.
          </p>
        </div>

        {/* What Happens Next Card */}
        <div className='bg-card border border-border rounded-2xl shadow-xl p-8 mb-8'>
          <h2 className='text-2xl font-bold text-foreground mb-6 flex items-center gap-2'>
            <span className='text-3xl'>{'==>'}</span>
            What Happens Next
          </h2>
          <div className='space-y-6'>
            {/* Step 1 */}
            <div className='flex gap-4'>
              <div className='flex-shrink-0 w-10 h-10 bg-gradient-to-br from-brand-red to-brand-orange rounded-full flex items-center justify-center text-white font-bold'>
                1
              </div>
              <div>
                <h3 className='font-semibold text-foreground mb-1'>Access Your Dashboard</h3>
                <p className='text-muted-foreground text-sm'>
                  Log in to your admin dashboard to start managing your content and exploring
                  premium features.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className='flex gap-4'>
              <div className='flex-shrink-0 w-10 h-10 bg-gradient-to-br from-brand-orange to-brand-gold rounded-full flex items-center justify-center text-white font-bold'>
                2
              </div>
              <div>
                <h3 className='font-semibold text-foreground mb-1'>Take the Interactive Tour</h3>
                <p className='text-muted-foreground text-sm'>
                  We'll guide you through all the key features with a quick, interactive tour. It
                  only takes 2 minutes!
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className='flex gap-4'>
              <div className='flex-shrink-0 w-10 h-10 bg-gradient-to-br from-brand-gold to-brand-red rounded-full flex items-center justify-center text-white font-bold'>
                3
              </div>
              <div>
                <h3 className='font-semibold text-foreground mb-1'>Create Your First Content</h3>
                <p className='text-muted-foreground text-sm'>
                  Follow our onboarding checklist to publish your first post, upload media, and
                  configure your site.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className='flex gap-4'>
              <div className='flex-shrink-0 w-10 h-10 bg-gradient-to-br from-brand-red to-brand-orange rounded-full flex items-center justify-center text-white font-bold'>
                4
              </div>
              <div>
                <h3 className='font-semibold text-foreground mb-1'>Get Help Anytime</h3>
                <p className='text-muted-foreground text-sm'>
                  Access our comprehensive documentation, video tutorials, and in-app help system
                  whenever you need assistance.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Premium Features Highlight */}
        <div className='bg-gradient-to-br from-brand-red/10 via-brand-orange/10 to-brand-gold/10 border border-brand-red/20 rounded-2xl p-8 mb-8'>
          <h2 className='text-2xl font-bold text-foreground mb-4 flex items-center gap-2'>
            <span className='text-3xl'>[CUSTOM]</span>
            Your Premium Features
          </h2>
          <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
            <div className='flex items-start gap-3'>
              <div className='text-brand-red text-2xl'>[NOTE]</div>
              <div>
                <h4 className='font-semibold text-foreground'>Unlimited Posts</h4>
                <p className='text-sm text-muted-foreground'>Create as many posts as you need</p>
              </div>
            </div>
            <div className='flex items-start gap-3'>
              <div className='text-brand-orange text-2xl'>[DESIGN]</div>
              <div>
                <h4 className='font-semibold text-foreground'>Custom Branding</h4>
                <p className='text-sm text-muted-foreground'>Full theme customization</p>
              </div>
            </div>
            <div className='flex items-start gap-3'>
              <div className='text-brand-gold text-2xl'>[RESULTS]</div>
              <div>
                <h4 className='font-semibold text-foreground'>Analytics Dashboard</h4>
                <p className='text-sm text-muted-foreground'>Track your content performance</p>
              </div>
            </div>
            <div className='flex items-start gap-3'>
              <div className='text-brand-red text-2xl'>{'==>'}</div>
              <div>
                <h4 className='font-semibold text-foreground'>Priority Support</h4>
                <p className='text-sm text-muted-foreground'>Get help when you need it</p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className='flex flex-col sm:flex-row gap-4 justify-center items-center'>
          <Button asChild variant='UI' size='lg' className='w-full sm:w-auto'>
            <Link href='/admin'>Go to Dashboard →</Link>
          </Button>
          <Button asChild variant='outline' size='lg' className='w-full sm:w-auto'>
            <Link href='/'>Return to Home</Link>
          </Button>
        </div>

        {/* Help Text */}
        <p className='text-center text-sm text-muted-foreground mt-8'>
          Need help? Check out our{' '}
          <Link href='/docs' className='text-brand-red hover:underline'>
            documentation
          </Link>{' '}
          or contact support at{' '}
          <a href='mailto:support@reveal.com' className='text-brand-red hover:underline'>
            support@reveal.com
          </a>
        </p>
      </div>
    </div>
  );
}

export default function WelcomePage() {
  return (
    <Suspense
      fallback={
        <div className='min-h-screen flex items-center justify-center'>
          <div className='text-center'>
            <div className='w-16 h-16 border-4 border-brand-red border-t-transparent rounded-full animate-spin mx-auto mb-4' />
            <p className='text-muted-foreground'>Loading your welcome page...</p>
          </div>
        </div>
      }
    >
      <WelcomeContent />
    </Suspense>
  );
}
