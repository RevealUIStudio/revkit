import type { ReactNode } from 'react';

/**
 * User Flow Pages Layout
 *
 * Shared configuration for user lifecycle pages:
 * - Welcome, Upgrade flows
 *
 * These pages are dynamic and session-based, so no caching.
 */

// Dynamic pages - no caching (user-specific content)
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function UserFlowLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
