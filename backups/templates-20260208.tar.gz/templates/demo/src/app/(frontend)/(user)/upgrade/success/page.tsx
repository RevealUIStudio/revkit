'use client';

import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function UpgradeSuccessPage() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to welcome page after a brief delay
    const timer = setTimeout(() => {
      router.push('/welcome');
    }, 2000);

    return () => {
      clearTimeout(timer);
    };
  }, [router]);

  return (
    <div className='min-h-screen flex items-center justify-center p-8 bg-gradient-to-br from-background to-brand-red/5'>
      <div className='max-w-xl mx-auto text-center'>
        {/* Success Animation */}
        <div className='mb-8'>
          <div className='inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-brand-red to-brand-orange rounded-full animate-bounce'>
            <svg
              className='w-12 h-12 text-white'
              fill='none'
              stroke='currentColor'
              viewBox='0 0 24 24'
              aria-label='Success checkmark'
            >
              <title>Payment successful</title>
              <path
                strokeLinecap='round'
                strokeLinejoin='round'
                strokeWidth={3}
                d='M5 13l4 4L19 7'
              />
            </svg>
          </div>
        </div>

        <h1 className='text-3xl font-bold mb-4 text-foreground'>Payment Successful! [SUCCESS]</h1>
        <p className='text-lg text-muted-foreground mb-8'>
          Welcome to reveal UI Premium!
          <br />
          Redirecting you to get started...
        </p>

        {/* Loading indicator */}
        <div className='flex justify-center'>
          <div className='w-8 h-8 border-4 border-brand-red border-t-transparent rounded-full animate-spin' />
        </div>
      </div>
    </div>
  );
}
