import { generateMeta } from '@/config/system/utilities/generation.ts';
import type { Metadata } from 'next';
import { CartClient } from './CartClient';

// User cart - always dynamic, no caching
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Shopping Cart - reveal UI',
    description: 'Review your cart and proceed to checkout',
    url: '/cart',
  });
}

export default async function CartPage() {
  return (
    <div className='min-h-screen py-8'>
      <div className='container mx-auto px-4'>
        <CartClient />
      </div>
    </div>
  );
}
