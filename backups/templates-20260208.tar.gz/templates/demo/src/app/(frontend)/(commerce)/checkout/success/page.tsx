import { generateMeta } from '@/config/system/utilities/generation.ts';
import { CheckmarkAnimation } from '@/presentation/components/delight/CheckmarkAnimation';
import { SuccessConfetti } from '@/presentation/components/delight/SuccessConfetti';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';
import React, { Suspense } from 'react';

// Success page - dynamic (session-based)
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Order Confirmed - reveal UI',
    description: 'Your order has been successfully placed',
    url: '/checkout/success',
  });
}

type PageProps = {
  searchParams: Promise<{ session_id?: string }>;
};

export default async function CheckoutSuccessPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const sessionId = params.session_id;

  return (
    <>
      <Suspense fallback={null}>
        <SuccessConfetti />
      </Suspense>
      <div className='min-h-screen py-16 bg-linear-to-br from-background via-background to-green-50/30'>
        <div className='container mx-auto px-4'>
          <div className='max-w-2xl mx-auto'>
            <Card className='border-green-200 shadow-xl'>
              <CardHeader className='text-center pb-8'>
                <div className='flex justify-center mb-6'>
                  <CheckmarkAnimation />
                </div>
                <CardTitle className='text-4xl font-bold text-green-600 mb-2 animate-in fade-in slide-in-from-bottom-4 duration-500'>
                  Order Confirmed!
                </CardTitle>
                <CardDescription className='text-lg animate-in fade-in slide-in-from-bottom-4 duration-500 delay-150'>
                  Thank you for your purchase. We're preparing your order!
                </CardDescription>
              </CardHeader>
              <CardContent className='space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-300'>
                <div className='bg-green-50/50 border border-green-200 p-6 rounded-lg'>
                  <p className='text-center text-foreground mb-4 font-medium'>
                    ✉️ We've sent a confirmation email with your order details and tracking
                    information.
                  </p>
                  {sessionId && (
                    <p className='text-sm text-center text-muted-foreground font-mono bg-white/50 px-3 py-2 rounded border border-green-200 inline-block'>
                      Order Reference: {sessionId.slice(0, 20)}...
                    </p>
                  )}
                </div>
                <div className='space-y-4'>
                  <h3 className='font-semibold text-lg flex items-center gap-2'>
                    <span className='text-green-600'>📦</span>
                    What's Next?
                  </h3>
                  <ul className='space-y-3 text-sm'>
                    <li className='flex items-start gap-3 p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors'>
                      <span className='text-green-600 mt-0.5 text-lg'>✓</span>
                      <div>
                        <span className='font-medium block mb-1'>Email Confirmation</span>
                        <span className='text-muted-foreground'>
                          You'll receive an email confirmation shortly with all the details
                        </span>
                      </div>
                    </li>
                    <li className='flex items-start gap-3 p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors'>
                      <span className='text-green-600 mt-0.5 text-lg'>📬</span>
                      <div>
                        <span className='font-medium block mb-1'>Tracking Information</span>
                        <span className='text-muted-foreground'>
                          We'll send you tracking information once your order ships
                        </span>
                      </div>
                    </li>
                    <li className='flex items-start gap-3 p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors'>
                      <span className='text-green-600 mt-0.5 text-lg'>👤</span>
                      <div>
                        <span className='font-medium block mb-1'>Order Management</span>
                        <span className='text-muted-foreground'>
                          View your order status anytime in your account dashboard
                        </span>
                      </div>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter className='flex gap-3 pt-6 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-500'>
                <Button variant='UI' className='flex-1' size='lg' asChild>
                  <Link href='/account/orders'>View My Orders</Link>
                </Button>
                <Button variant='outline' className='flex-1' size='lg' asChild>
                  <Link href='/shop'>Continue Shopping</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
