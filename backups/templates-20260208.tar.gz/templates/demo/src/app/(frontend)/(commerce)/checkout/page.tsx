import { generateMeta } from '@/config/system/utilities/generation.ts';
import type { Metadata } from 'next';
import { CheckoutClient } from './CheckoutClient';

// Checkout flow - always dynamic, no caching
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Checkout - reveal UI',
    description: 'Complete your purchase',
    url: '/checkout',
  });
}

export default async function CheckoutPage() {
  return (
    <div className='min-h-screen py-8'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <h1 className='text-3xl font-bold mb-8'>Checkout</h1>
          <CheckoutClient />
        </div>
      </div>
    </div>
  );
}
