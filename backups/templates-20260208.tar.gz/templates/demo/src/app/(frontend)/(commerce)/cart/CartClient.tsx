'use client';

import {
  clearCartAction,
  getOrCreateCartAction,
  removeFromCartAction,
} from '@/features/commerce/server/cart-actions';
import { createCheckoutSessionAction } from '@/features/commerce/server/checkout-actions';
import type { Cart as RevealUICart } from '@revealui/infrastructure/cms/db/reveal-types';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import Link from 'next/link';
import { useEffect, useState } from 'react';

export function CartClient() {
  const [cart, setCart] = useState<RevealUICart | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    loadCart();
  }, []);

  async function loadCart() {
    try {
      setLoading(true);
      setError(null);
      const result = await getOrCreateCartAction();
      if (result.success && result.data) {
        setCart(result.data);
      } else {
        setError(result.error ?? 'Failed to load cart');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load cart');
    } finally {
      setLoading(false);
    }
  }

  async function handleCheckout() {
    if (!cart?.id) return;

    try {
      setProcessing(true);
      setError(null);

      // Add a brief visual feedback
      const button = document.querySelector('[data-checkout-button]');
      if (button) {
        button.classList.add('animate-pulse');
      }

      const result = await createCheckoutSessionAction(cart.id);

      if (result.success && result.data?.url) {
        // Small delay for user feedback before redirect
        await new Promise(resolve => setTimeout(resolve, 300));
        // Redirect to Stripe checkout
        window.location.href = result.data.url;
      } else {
        setError(result.error ?? 'Failed to create checkout session');
        if (button) {
          button.classList.remove('animate-pulse');
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to checkout');
    } finally {
      setProcessing(false);
    }
  }

  async function handleRemoveItem(productId: string, variantId?: string) {
    if (!cart?.id) return;

    try {
      setProcessing(true);

      // Optimistic update for better UX
      const itemIndex = cart.items?.findIndex(
        item => item.productId === productId && item.variantId === variantId
      );

      if (itemIndex !== undefined && itemIndex >= 0 && cart.items) {
        const updatedItems = [...cart.items];
        updatedItems.splice(itemIndex, 1);

        // Optimistically update cart
        setCart({
          ...cart,
          items: updatedItems,
        });
      }

      const result = await removeFromCartAction(cart.id, { productId, variantId });

      if (result.success && result.data) {
        setCart(result.data);
      } else {
        // Revert on error
        setCart(cart);
        setError(result.error ?? 'Failed to remove item');
      }
    } catch (err) {
      // Revert on error
      if (cart) setCart(cart);
      setError(err instanceof Error ? err.message : 'Failed to remove item');
    } finally {
      setProcessing(false);
    }
  }

  async function handleClearCart() {
    if (!cart?.id) return;

    try {
      setProcessing(true);
      const result = await clearCartAction(cart.id);

      if (result.success && result.data) {
        setCart(result.data);
      } else {
        setError(result.error ?? 'Failed to clear cart');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to clear cart');
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <div className='max-w-4xl mx-auto py-8'>
        <div className='text-center py-12'>
          <p className='text-muted-foreground'>Loading cart...</p>
        </div>
      </div>
    );
  }

  if (error && !cart) {
    return (
      <div className='max-w-4xl mx-auto py-8'>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={loadCart}>Retry</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const items = cart?.items ?? [];
  const totals = cart?.totals ?? { subtotal: 0, tax: 0, shipping: 0, total: 0 };

  if (items.length === 0) {
    return (
      <div className='max-w-4xl mx-auto py-8'>
        <Card>
          <CardHeader>
            <CardTitle>Your Cart is Empty</CardTitle>
            <CardDescription>Add some items to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href='/shop'>Browse Products</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className='max-w-4xl mx-auto py-8'>
      <div className='flex justify-between items-center mb-8'>
        <h1 className='text-3xl font-bold'>Shopping Cart</h1>
        {items.length > 0 && (
          <Button variant='outline' onClick={handleClearCart} disabled={processing}>
            Clear Cart
          </Button>
        )}
      </div>

      {error && (
        <Card className='mb-4 border-destructive'>
          <CardContent className='pt-6'>
            <p className='text-destructive text-sm'>{error}</p>
          </CardContent>
        </Card>
      )}

      <div className='grid gap-6 md:grid-cols-3'>
        <div className='md:col-span-2 space-y-4'>
          {items.map((item, index) => (
            <Card key={item.productId ?? index}>
              <CardContent className='pt-6'>
                <div className='flex justify-between items-start'>
                  <div>
                    <h3 className='font-semibold'>Product {item.productId}</h3>
                    {item.variantId && (
                      <p className='text-sm text-muted-foreground'>Variant: {item.variantId}</p>
                    )}
                    <p className='text-sm text-muted-foreground'>Quantity: {item.quantity ?? 1}</p>
                    {item.price && (
                      <p className='font-medium mt-2'>
                        ${((item.price as number) * (item.quantity ?? 1)).toFixed(2)}
                      </p>
                    )}
                  </div>
                  <Button
                    variant='ghost'
                    size='sm'
                    onClick={() => handleRemoveItem(item.productId, item.variantId)}
                    disabled={processing}
                  >
                    Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className='space-y-4'>
              <div className='flex justify-between text-sm'>
                <span>Subtotal</span>
                <span>${((totals.subtotal as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='flex justify-between text-sm'>
                <span>Tax</span>
                <span>${((totals.tax as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='flex justify-between text-sm'>
                <span>Shipping</span>
                <span>${((totals.shipping as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='border-t pt-4 flex justify-between font-bold'>
                <span>Total</span>
                <span>${((totals.total as number) ?? 0).toFixed(2)}</span>
              </div>
              <Button
                className='w-full transition-all hover:scale-[1.02] active:scale-[0.98]'
                onClick={handleCheckout}
                disabled={processing || items.length === 0}
                data-checkout-button
              >
                {processing ? (
                  <span className='flex items-center gap-2'>
                    <span className='w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin' />
                    Processing...
                  </span>
                ) : (
                  <span className='flex items-center gap-2'>
                    Proceed to Checkout
                    <svg
                      className='w-4 h-4'
                      fill='none'
                      stroke='currentColor'
                      viewBox='0 0 24 24'
                      role='img'
                      aria-label='Arrow right'
                    >
                      <path
                        strokeLinecap='round'
                        strokeLinejoin='round'
                        strokeWidth={2}
                        d='M13 7l5 5m0 0l-5 5m5-5H6'
                      />
                    </svg>
                  </span>
                )}
              </Button>
              <Button variant='outline' className='w-full' asChild>
                <Link href='/shop'>Continue Shopping</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
