import { generateMeta } from '@/config/system/utilities/generation.ts';
import { type Product, getCategories, getProducts } from '@/features/commerce';
import { PageLoading } from '@/presentation/components/ui/PageLoading';
import { ErrorBoundary } from '@/presentation/components/ui/client/ErrorBoundary';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { Suspense } from 'react';

// Product listing with ISR
export const dynamic = 'force-static';
export const revalidate = 300; // Revalidate every 5 minutes

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Shop - reveal UI Merch',
    description: 'Official reveal UI merchandise - t-shirts, hoodies, accessories, and more',
    url: '/shop',
  });
}

// Data fetching functions now imported from @/features/commerce

function ProductCard({ product }: { product: Product }) {
  const PLACEHOLDER_IMAGE =
    'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"%3E%3Crect width="400" height="400" fill="%23e5e5e5"/%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="system-ui" font-size="24" fill="%23a3a3a3"%3ENo Image%3C/text%3E%3C/svg%3E';
  const featuredImage = typeof product.featuredImage === 'object' ? product.featuredImage : null;
  const imageUrl = featuredImage?.url || PLACEHOLDER_IMAGE;

  const basePrice = product.pricing?.basePrice || 0;
  const compareAtPrice = product.pricing?.compareAtPrice;
  const hasDiscount = compareAtPrice && compareAtPrice > basePrice;

  return (
    <Card className='group hover:shadow-lg transition-shadow'>
      <CardHeader className='p-0'>
        <Link href={`/shop/${product.slug}`}>
          <div className='relative aspect-square overflow-hidden rounded-t-lg'>
            <Image
              src={imageUrl}
              alt={featuredImage?.alt || product.title || 'Product'}
              fill
              className='object-cover group-hover:scale-105 transition-transform duration-300'
              sizes='(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw'
            />
            {product.featured && (
              <div className='absolute top-2 right-2 bg-brand-red-600 text-white px-2 py-1 rounded text-xs font-bold'>
                Featured
              </div>
            )}
            {hasDiscount && (
              <div className='absolute top-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-bold'>
                Sale
              </div>
            )}
            {product.productType === 'digital' && (
              <div className='absolute bottom-2 left-2 bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold'>
                Digital
              </div>
            )}
          </div>
        </Link>
      </CardHeader>
      <CardContent className='p-4'>
        <Link href={`/shop/${product.slug}`}>
          <CardTitle className='text-lg mb-2 hover:text-brand-red-600 transition-colors'>
            {product.title}
          </CardTitle>
        </Link>
        {product.shortDescription && (
          <CardDescription className='line-clamp-2'>{product.shortDescription}</CardDescription>
        )}
      </CardContent>
      <CardFooter className='p-4 pt-0 flex justify-between items-center'>
        <div className='flex flex-col'>
          {hasDiscount && (
            <span className='text-sm text-muted-foreground line-through'>
              ${compareAtPrice?.toFixed(2)}
            </span>
          )}
          <span className={`text-lg font-bold ${hasDiscount ? 'text-green-600' : ''}`}>
            ${basePrice.toFixed(2)}
          </span>
        </div>
        <Button asChild variant='UI' size='sm'>
          <Link href={`/shop/${product.slug}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

async function ProductsList() {
  const productsResult = await getProducts();
  const products = productsResult.docs || [];

  if (products.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No products available</CardTitle>
          <CardDescription>Check back soon for new merchandise!</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <>
      <div className='text-sm text-muted-foreground mb-6'>
        {productsResult.totalDocs || 0} products found
      </div>
      <div
        className='grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
        data-tour='product-grid'
      >
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </>
  );
}

export default async function ShopPage() {
  const categories = await getCategories();

  return (
    <div className='min-h-screen'>
      {/* Hero Section */}
      <section className='bg-gradient-to-br from-brand-red-950 to-brand-red-900 text-white py-16'>
        <div className='container mx-auto px-4'>
          <div className='max-w-3xl mx-auto text-center'>
            <h1 className='text-4xl md:text-5xl font-bold mb-4'>Official Merch Store</h1>
            <p className='text-xl text-brand-red-100'>
              Rep the reveal UI with our exclusive merchandise
            </p>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className='py-12'>
        <div className='container mx-auto px-4'>
          {/* Filter Bar */}
          <div className='mb-8 flex flex-wrap gap-4 items-center justify-between'>
            <div className='flex gap-2 flex-wrap'>
              <Button variant='outline' size='sm'>
                All Products
              </Button>
              <Button variant='ghost' size='sm'>
                Apparel
              </Button>
              <Button variant='ghost' size='sm'>
                Accessories
              </Button>
              <Button variant='ghost' size='sm'>
                Digital
              </Button>
            </div>
          </div>

          {/* Products Grid */}
          <ErrorBoundary>
            <Suspense fallback={<PageLoading />}>
              <ProductsList />
            </Suspense>
          </ErrorBoundary>
        </div>
      </section>

      {/* Featured Categories */}
      {categories.length > 0 && (
        <section className='py-12 bg-muted/30'>
          <div className='container mx-auto px-4'>
            <h2 className='text-3xl font-bold mb-8 text-center'>Shop by Category</h2>
            <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-4'>
              {categories.slice(0, 4).map(category => (
                <Card key={category.id} className='hover:shadow-lg transition-shadow'>
                  <CardHeader>
                    <CardTitle className='text-lg'>{category.title}</CardTitle>
                  </CardHeader>
                  <CardFooter>
                    <Button variant='outline' size='sm' className='w-full'>
                      Browse
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
