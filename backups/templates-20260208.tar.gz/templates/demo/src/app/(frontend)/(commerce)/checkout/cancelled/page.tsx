import { generateMeta } from '@/config/system/utilities/generation.ts';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';

// Cancelled page - dynamic
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Checkout Cancelled - reveal UI',
    description: 'Your checkout was cancelled',
    url: '/checkout/cancelled',
  });
}

export default async function CheckoutCancelledPage() {
  return (
    <div className='min-h-screen py-16'>
      <div className='container mx-auto px-4'>
        <div className='max-w-2xl mx-auto'>
          <Card>
            <CardHeader className='text-center'>
              <div className='flex justify-center mb-4'>
                <div className='w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center'>
                  <svg
                    className='w-8 h-8 text-yellow-600'
                    fill='none'
                    stroke='currentColor'
                    viewBox='0 0 24 24'
                    role='img'
                    aria-label='Warning icon'
                  >
                    <title>Warning icon</title>
                    <path
                      strokeLinecap='round'
                      strokeLinejoin='round'
                      strokeWidth={2}
                      d='M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'
                    />
                  </svg>
                </div>
              </div>
              <CardTitle className='text-2xl'>Checkout Cancelled</CardTitle>
              <CardDescription className='text-lg'>Your order was not completed</CardDescription>
            </CardHeader>
            <CardContent className='space-y-4'>
              <div className='bg-muted/50 p-6 rounded-lg text-center'>
                <p className='text-muted-foreground mb-2'>
                  No worries! Your cart has been saved and you can complete your purchase anytime.
                </p>
                <p className='text-sm text-muted-foreground'>
                  If you encountered any issues during checkout, please contact our support team.
                </p>
              </div>
            </CardContent>
            <CardFooter className='flex gap-2'>
              <Button variant='UI' className='flex-1' asChild>
                <Link href='/cart'>Return to Cart</Link>
              </Button>
              <Button variant='outline' className='flex-1' asChild>
                <Link href='/shop'>Continue Shopping</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
