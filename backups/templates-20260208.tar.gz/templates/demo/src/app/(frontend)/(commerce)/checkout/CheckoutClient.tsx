'use client';

import { getOrCreateCartAction } from '@/features/commerce/server/cart-actions';
import { createCheckoutSessionAction } from '@/features/commerce/server/checkout-actions';
import type { Cart as RevealUICart } from '@revealui/infrastructure/cms/db/revealui-types';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';

export function CheckoutClient() {
  const searchParams = useSearchParams();
  const cartId = searchParams?.get('cartId');
  const [cart, setCart] = useState<RevealUICart | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadCart();
  }, [cartId]);

  async function loadCart() {
    try {
      setLoading(true);
      setError(null);
      const result = await getOrCreateCartAction();

      if (result.success && result.data) {
        setCart(result.data);
      } else {
        setError(result.error ?? 'Failed to load cart');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load cart');
    } finally {
      setLoading(false);
    }
  }

  async function handleCheckout() {
    if (!cart?.id) {
      setError('No cart available. Please add items to your cart first.');
      return;
    }

    try {
      setProcessing(true);
      setError(null);

      // Add visual feedback
      const button = document.querySelector('[data-checkout-button]');
      if (button) {
        button.classList.add('animate-pulse');
      }

      const result = await createCheckoutSessionAction(cart.id);

      if (result.success && result.data?.url) {
        // Small delay for visual feedback
        await new Promise(resolve => setTimeout(resolve, 300));
        // Redirect to Stripe checkout
        window.location.href = result.data.url;
      } else {
        setError(result.error ?? 'Failed to create checkout session');
        if (button) {
          button.classList.remove('animate-pulse');
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to checkout');
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <div className='max-w-2xl mx-auto space-y-6'>
        <Card>
          <CardContent className='pt-6'>
            <p className='text-center text-muted-foreground'>Loading checkout...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error && !cart) {
    return (
      <div className='max-w-2xl mx-auto space-y-6'>
        <Card>
          <CardHeader>
            <CardTitle>Checkout Error</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent className='space-y-3'>
            <Button onClick={loadCart}>Retry</Button>
            <Button asChild variant='outline'>
              <Link href='/cart'>View Cart</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const items = cart?.items ?? [];
  const totals = cart?.totals ?? { subtotal: 0, tax: 0, shipping: 0, total: 0 };

  if (items.length === 0) {
    return (
      <div className='max-w-2xl mx-auto space-y-6'>
        <Card>
          <CardHeader>
            <CardTitle>Your Cart is Empty</CardTitle>
            <CardDescription>Add items to your cart before checking out</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href='/shop'>Browse Products</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className='max-w-2xl mx-auto space-y-6'>
      <Card>
        <CardHeader>
          <CardTitle>Checkout</CardTitle>
          <CardDescription>Review your order and complete your purchase</CardDescription>
        </CardHeader>
        <CardContent className='space-y-6'>
          {error && (
            <div className='p-4 bg-destructive/10 border border-destructive rounded-md'>
              <p className='text-sm text-destructive'>{error}</p>
            </div>
          )}

          <div className='space-y-4'>
            <h3 className='font-semibold'>Order Summary</h3>
            <div className='space-y-2 text-sm'>
              {items.map((item, index) => (
                <div key={item.productId ?? index} className='flex justify-between'>
                  <span>
                    Product {item.productId} {item.variantId && `(${item.variantId})`} ×{' '}
                    {item.quantity ?? 1}
                  </span>
                  {item.price && (
                    <span>${((item.price as number) * (item.quantity ?? 1)).toFixed(2)}</span>
                  )}
                </div>
              ))}
            </div>
            <div className='border-t pt-4 space-y-2 text-sm'>
              <div className='flex justify-between'>
                <span>Subtotal</span>
                <span>${((totals.subtotal as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='flex justify-between'>
                <span>Tax</span>
                <span>${((totals.tax as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='flex justify-between'>
                <span>Shipping</span>
                <span>${((totals.shipping as number) ?? 0).toFixed(2)}</span>
              </div>
              <div className='flex justify-between font-bold pt-2 border-t'>
                <span>Total</span>
                <span>${((totals.total as number) ?? 0).toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className='space-y-3'>
            <Button
              className='w-full transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl'
              onClick={handleCheckout}
              disabled={processing || items.length === 0}
              size='lg'
              data-checkout-button
            >
              {processing ? (
                <span className='flex items-center justify-center gap-2'>
                  <span className='w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin' />
                  Processing...
                </span>
              ) : (
                <span className='flex items-center justify-center gap-2'>
                  Complete Purchase
                  <svg
                    className='w-5 h-5'
                    fill='none'
                    stroke='currentColor'
                    viewBox='0 0 24 24'
                    role='img'
                    aria-label='Arrow right'
                  >
                    <path
                      strokeLinecap='round'
                      strokeLinejoin='round'
                      strokeWidth={2}
                      d='M13 7l5 5m0 0l-5 5m5-5H6'
                    />
                  </svg>
                </span>
              )}
            </Button>
            <Button asChild variant='outline' className='w-full'>
              <Link href='/cart'>Back to Cart</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
