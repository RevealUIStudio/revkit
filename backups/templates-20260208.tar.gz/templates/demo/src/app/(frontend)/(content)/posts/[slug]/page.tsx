import { generateMeta } from '@/config/system/utilities/generation';
import type { Metadata } from 'next';
import Link from 'next/link';

export const dynamic = 'force-static';
export const revalidate = 600;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Stories - reveal UI',
    description: 'Fight breakdowns, behind-the-scenes, and product updates.',
    url: '/posts',
  });
}

export default function PostsPage() {
  return (
    <div className='container mx-auto max-w-3xl px-4 py-12 space-y-6'>
      <h1 className='text-4xl font-bold'>Stories Coming Soon</h1>
      <p className='text-muted-foreground'>
        We&rsquo;re rebuilding the publishing pipeline for long-form fight coverage. Legacy posts
        are offline while we migrate the CMS.
      </p>
      <div className='flex gap-3'>
        <Link
          href='/shop'
          className='rounded-md bg-brand-red-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-red-700'
        >
          Explore products
        </Link>
        <Link
          href='mailto:editorial@reveal.com'
          className='rounded-md border border-input px-5 py-3 text-sm font-semibold text-foreground transition hover:bg-muted/60'
        >
          Contact editorial
        </Link>
      </div>
    </div>
  );
}
