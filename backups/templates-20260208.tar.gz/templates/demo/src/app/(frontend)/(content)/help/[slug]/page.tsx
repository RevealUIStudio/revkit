import { isAnalyzerBuild } from '@/config/system/utilities/build-flags';
import { generateMeta } from '@/config/system/utilities/generation';
import { getFeaturedHelpArticles } from '@/features/help';
import { AnalyzerModeBanner } from '@/presentation/components/system/AnalyzerModeBanner';
import { PageLoading } from '@/presentation/components/ui/PageLoading';
import { ErrorBoundary } from '@/presentation/components/ui/client/ErrorBoundary';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import {
  BookOpen as BookOpenIcon,
  CreditCard as CreditCardIcon,
  HelpCircle as HelpCircleIcon,
  MessageSquare as MessageSquareIcon,
  Rocket as RocketIcon,
  Settings as SettingsIcon,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Suspense } from 'react';

type FeaturedArticle = Awaited<ReturnType<typeof getFeaturedHelpArticles>>[number];

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Help Center',
    description: 'Find answers to common questions and learn how to use our platform',
    url: '/help',
  });
}

async function FeaturedArticlesList() {
  const analyzerMode = isAnalyzerBuild();
  const featuredArticles: FeaturedArticle[] = analyzerMode ? [] : await getFeaturedHelpArticles(6);

  if (featuredArticles.length === 0) {
    return null;
  }

  return (
    <div className='mb-12'>
      <h2 className='text-2xl font-bold mb-6'>Popular Articles</h2>
      <div className='grid md:grid-cols-2 lg:grid-cols-3 gap-6'>
        {featuredArticles.map(article => (
          <Link key={article.id} href={`/help/${article.slug}`}>
            <Card className='h-full hover:border-brand-red-600 transition-colors cursor-pointer'>
              <CardHeader>
                <CardTitle className='text-base'>{article.title}</CardTitle>
                <CardDescription className='text-sm'>{article.excerpt}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className='text-xs text-muted-foreground'>{article.viewCount} views</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default async function HelpPage() {
  const analyzerMode = isAnalyzerBuild();
  const categories = [
    {
      id: 'getting-started',
      name: 'Getting Started',
      icon: <RocketIcon className='h-6 w-6' />,
      description: 'Learn the basics and set up your account',
      count: 8,
    },
    {
      id: 'billing',
      name: 'Account & Billing',
      icon: <CreditCardIcon className='h-6 w-6' />,
      description: 'Manage subscriptions, payments, and billing',
      count: 12,
    },
    {
      id: 'features',
      name: 'Features & Usage',
      icon: <SettingsIcon className='h-6 w-6' />,
      description: 'Discover features and how to use them',
      count: 15,
    },
    {
      id: 'technical',
      name: 'Technical Support',
      icon: <HelpCircleIcon className='h-6 w-6' />,
      description: 'Technical issues and troubleshooting',
      count: 10,
    },
  ];

  const faqs = [
    {
      question: 'How do I upgrade my subscription?',
      answer:
        'Visit your account dashboard and click on "Manage Subscription". From there, you can view available plans and upgrade instantly. Changes take effect immediately.',
    },
    {
      question: 'Can I cancel my subscription anytime?',
      answer:
        "Yes! You can cancel your subscription at any time from your account settings. You'll retain access until the end of your current billing period.",
    },
    {
      question: 'How do I reset my password?',
      answer:
        'Click on "Forgot Password" on the login page. Enter your email address and we\'ll send you a password reset link.',
    },
    {
      question: 'What payment methods do you accept?',
      answer:
        'We accept all major credit cards (Visa, Mastercard, American Express, Discover) through our secure payment processor, Stripe.',
    },
    {
      question: 'How do I contact customer support?',
      answer:
        'You can reach our support team via the contact form on this page, or email us at support@example.com. We typically respond within 24 hours.',
    },
    {
      question: 'Do you offer refunds?',
      answer:
        "Yes, we offer a 30-day money-back guarantee. If you're not satisfied with your subscription, contact support within 30 days for a full refund.",
    },
    {
      question: 'Can I change my email address?',
      answer:
        "Yes, you can update your email address from your account settings. You'll need to verify the new email address before the change takes effect.",
    },
    {
      question: 'Is my data secure?',
      answer:
        'Absolutely. We use industry-standard encryption and security measures to protect your data. All payments are processed securely through Stripe.',
    },
  ];

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-6xl'>
        {/* Header */}
        <div className='text-center mb-12'>
          <div className='inline-flex items-center justify-center w-16 h-16 bg-brand-red-600 rounded-full mb-4'>
            <BookOpenIcon className='h-8 w-8 text-white' />
          </div>
          <h1 className='text-4xl md:text-5xl font-bold mb-4'>How Can We Help?</h1>
          <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
            Find answers to common questions or browse our help articles by category
          </p>
          {analyzerMode && <AnalyzerModeBanner />}
        </div>

        {/* Search Bar */}
        <Card className='mb-12 max-w-3xl mx-auto'>
          <CardContent className='p-6'>
            <form action='/help/search' method='GET' className='flex gap-3'>
              <input
                type='text'
                name='q'
                placeholder='Search for help articles...'
                className='flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
              />
              <button
                type='submit'
                className='px-6 py-3 bg-brand-red-600 text-white rounded-lg hover:bg-brand-red-700 transition-colors'
              >
                Search
              </button>
            </form>
          </CardContent>
        </Card>

        {/* Categories */}
        <div className='mb-12'>
          <h2 className='text-2xl font-bold mb-6'>Browse by Category</h2>
          <div className='grid md:grid-cols-2 lg:grid-cols-4 gap-6'>
            {categories.map(category => (
              <Link key={category.id} href={`/help/category/${category.id}`}>
                <Card className='h-full hover:border-brand-red-600 transition-colors cursor-pointer'>
                  <CardHeader>
                    <div className='mb-3 text-brand-red-600'>{category.icon}</div>
                    <CardTitle className='text-lg'>{category.name}</CardTitle>
                    <CardDescription>{category.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className='text-sm text-muted-foreground'>{category.count} articles</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Featured Articles */}
        <ErrorBoundary>
          <Suspense fallback={<PageLoading />}>
            <FeaturedArticlesList />
          </Suspense>
        </ErrorBoundary>

        {/* FAQ Section */}
        <div className='mb-12'>
          <h2 className='text-2xl font-bold mb-6'>Frequently Asked Questions</h2>
          <div className='space-y-4'>
            {faqs.map(faq => (
              <Card key={faq.question}>
                <CardHeader>
                  <CardTitle className='text-lg flex items-start gap-3'>
                    <HelpCircleIcon className='h-5 w-5 text-brand-red-600 shrink-0 mt-0.5' />
                    {faq.question}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className='text-muted-foreground'>{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <Card className='bg-linear-to-br from-brand-red-50 to-white border-brand-red-200'>
          <CardHeader>
            <div className='flex items-center gap-3'>
              <MessageSquareIcon className='h-6 w-6 text-brand-red-600' />
              <div>
                <CardTitle>Still Need Help?</CardTitle>
                <CardDescription>Our support team is here to assist you</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className='text-sm text-muted-foreground mb-4'>
              Can't find what you're looking for? Contact our support team and we'll be happy to
              help.
            </p>
            <a href='/contact'>
              <button
                type='button'
                className='px-6 py-3 bg-brand-red-600 text-white rounded-lg hover:bg-brand-red-700 transition-colors'
              >
                Contact Support
              </button>
            </a>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
