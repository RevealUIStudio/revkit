import { isAnalyzerBuild } from '@/config/system/utilities/build-flags';
import { generateMeta } from '@/config/system/utilities/generation.ts';
import { SearchBar } from '@/features/search/ui/SearchBar';
import { getRevealConfig } from '@/reveal.config';
import { VideoCard } from '@/presentation/components/media/VideoCard';
import { AnalyzerModeBanner } from '@/presentation/components/system/AnalyzerModeBanner';
import { PageLoading } from '@/presentation/components/ui/PageLoading';
import { ErrorBoundary } from '@/presentation/components/ui/client/ErrorBoundary';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import { draftMode } from 'next/headers';
import Link from 'next/link';
import { getRevealUI } from '@revealui/content';
import { Suspense } from 'react';

// Content listing with ISR
export const dynamic = 'force-static';
export const revalidate = 300; // Revalidate every 5 minutes (more frequent for listings)

interface PageProps {
  searchParams: Promise<{
    category?: string;
    search?: string;
    sort?: string;
  }>;
}

type RevealUIClient = Awaited<ReturnType<typeof getRevealUI>>;
type RevealUIFindArgs = Parameters<RevealUIClient['find']>[0];
type RevealUIWhereInput = NonNullable<RevealUIFindArgs['where']>;

async function getVideos(
  searchParams: { category?: string; search?: string; sort?: string },
  draft = false
) {
  'use cache';

  const analyzerMode = isAnalyzerBuild();

  const emptyVideos = {
    docs: [],
    totalDocs: 0,
    limit: 50,
    totalPages: 0,
    page: 1,
    pagingCounter: 1,
    hasPrevPage: false,
    hasNextPage: false,
    prevPage: null,
    nextPage: null,
  };

  // Skip cache for draft mode to enable live preview
  if (draft) {
    try {
      const config = await getRevealConfig();
      const revealui = await getRevealUI({ config });

      const where: RevealUIWhereInput = {
        _status: { equals: 'published' },
      };

      if (searchParams.search) {
        where.or = [
          { title: { contains: searchParams.search } },
          { description: { contains: searchParams.search } },
        ];
      }

      let sort = '-createdAt';
      if (searchParams.sort === 'oldest') {
        sort = 'createdAt';
      } else if (searchParams.sort === 'title') {
        sort = 'title';
      } else if (searchParams.sort === 'views') {
        sort = '-mux.duration';
      }

      const videos = await revealui.find({
        collection: 'videos',
        where,
        sort,
        depth: 1,
        limit: 50,
        draft,
      });

      return videos;
    } catch {
      // Error handled by returning empty videos
      return emptyVideos;
    }
  }

  if (analyzerMode) {
    return emptyVideos;
  }

  try {
    const config = await getRevealConfig();
    const revealui = await getRevealUI({ config });

    const where: RevealUIWhereInput = {
      _status: { equals: 'published' },
    };

    // Filter by search query
    if (searchParams.search) {
      where.or = [
        { title: { contains: searchParams.search } },
        { description: { contains: searchParams.search } },
      ];
    }

    // Sort options
    let sort = '-createdAt'; // Default: newest first
    if (searchParams.sort === 'oldest') {
      sort = 'createdAt';
    } else if (searchParams.sort === 'title') {
      sort = 'title';
    } else if (searchParams.sort === 'views') {
      // Sort by view count (analytics.views field on posts/videos)
      // Note: Videos collection needs analytics.views field added for this to work fully
      sort = '-analytics.views';
    }

    const videos = await revealui.find({
      collection: 'videos',
      where,
      sort,
      depth: 1,
      limit: 50,
    });

    return videos;
  } catch {
    // Error handled by returning empty videos
    return emptyVideos;
  }
}

async function getVideoCategories(draft = false) {
  'use cache';

  const analyzerMode = isAnalyzerBuild();

  // Skip cache for draft mode
  if (draft) {
    try {
      const config = await getRevealConfig();
      const revealui = await getRevealUI({ config });

      const tags = await revealui.find({
        collection: 'tags',
        limit: 100,
        sort: 'name',
        draft,
      });

      return tags.docs;
    } catch {
      // Error handled by returning empty array
      return [];
    }
  }

  if (analyzerMode) {
    return [];
  }

  try {
    const config = await getRevealConfig();
    const revealui = await getRevealUI({ config });

    const tags = await revealui.find({
      collection: 'tags',
      limit: 100,
      sort: 'name',
    });

    return tags.docs;
  } catch {
    // Error handled by returning empty array
    return [];
  }
}

async function VideoCategories({ searchParams }: { searchParams: { category?: string } }) {
  const { isEnabled: draft } = await draftMode();
  const categories = await getVideoCategories(draft);

  if (categories.length === 0) {
    return null;
  }

  return (
    <div className='flex flex-wrap gap-2 justify-center'>
      <Link href='/videos'>
        <Button variant={!searchParams.category ? 'UI' : 'outline'} size='sm'>
          All Videos
        </Button>
      </Link>
      {categories.slice(0, 8).map(category => (
        <Link key={category.id} href={`/videos?category=${category.slug}`}>
          <Button variant={searchParams.category === category.slug ? 'UI' : 'outline'} size='sm'>
            {category.title}
          </Button>
        </Link>
      ))}
    </div>
  );
}

async function VideosCount({
  searchParams,
}: {
  searchParams: { category?: string; search?: string; sort?: string };
}) {
  const { isEnabled: draft } = await draftMode();
  const videos = await getVideos(searchParams, draft);

  return (
    <div>
      <p className='text-muted-foreground'>
        {videos.totalDocs} {videos.totalDocs === 1 ? 'video' : 'videos'} found
      </p>
    </div>
  );
}

async function VideosList({
  searchParams,
}: {
  searchParams: { category?: string; search?: string; sort?: string };
}) {
  const { isEnabled: draft } = await draftMode();
  const videos = await getVideos(searchParams, draft);

  if (videos.docs.length === 0) {
    return (
      <Card className='max-w-2xl mx-auto'>
        <CardHeader className='text-center'>
          <CardTitle>No videos found</CardTitle>
          <CardDescription>
            {searchParams.search
              ? `No videos match "${searchParams.search}". Try a different search term.`
              : 'No videos have been published yet. Check back soon!'}
          </CardDescription>
          {searchParams.search && (
            <div className='mt-4'>
              <Button asChild variant='UI'>
                <Link href='/videos'>View All Videos</Link>
              </Button>
            </div>
          )}
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className='grid gap-8 md:grid-cols-2 lg:grid-cols-3'>
      {videos.docs.map(video => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
}

export default async function VideosPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const analyzerMode = isAnalyzerBuild();

  return (
    <div className='min-h-screen bg-background'>
      {/* Hero Section */}
      <section className='relative py-16 bg-linear-to-b from-muted/50 to-background'>
        <div className='container mx-auto px-4'>
          <div className='max-w-4xl mx-auto text-center'>
            <h1 className='text-5xl md:text-6xl font-bold mb-6 text-foreground'>Fight Videos</h1>
            <p className='text-xl text-muted-foreground mb-8'>
              Watch epic battles, exclusive drone footage, and highlights from reveal UI
            </p>

            {analyzerMode && <AnalyzerModeBanner />}

            {/* Search Bar */}
            <div className='max-w-2xl mx-auto mb-8'>
              <SearchBar placeholder='Search fight videos...' defaultValue={params.search} />
            </div>

            {/* Category Filter Pills */}
            <ErrorBoundary>
              <Suspense fallback={<PageLoading />}>
                <VideoCategories searchParams={params} />
              </Suspense>
            </ErrorBoundary>
          </div>
        </div>
      </section>

      {/* Sort Options */}
      <section className='py-6 border-b border-border'>
        <div className='container mx-auto px-4'>
          <div className='flex flex-col md:flex-row justify-between items-start md:items-center gap-4'>
            <ErrorBoundary>
              <Suspense fallback={<div className='text-muted-foreground'>Loading...</div>}>
                <VideosCount searchParams={params} />
              </Suspense>
            </ErrorBoundary>

            <div className='flex gap-2 items-center'>
              <span className='text-sm text-muted-foreground'>Sort by:</span>
              <Link href='/videos?sort=newest'>
                <Button
                  variant={!params.sort || params.sort === 'newest' ? 'UI' : 'ghost'}
                  size='sm'
                >
                  Newest
                </Button>
              </Link>
              <Link href='/videos?sort=oldest'>
                <Button variant={params.sort === 'oldest' ? 'UI' : 'ghost'} size='sm'>
                  Oldest
                </Button>
              </Link>
              <Link href='/videos?sort=title'>
                <Button variant={params.sort === 'title' ? 'UI' : 'ghost'} size='sm'>
                  Title
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Videos Grid */}
      <section className='py-12'>
        <div className='container mx-auto px-4'>
          <ErrorBoundary>
            <Suspense fallback={<PageLoading />}>
              <VideosList searchParams={params} />
            </Suspense>
          </ErrorBoundary>
        </div>
      </section>

      {/* CTA Section */}
      <section className='py-16 bg-muted/30'>
        <div className='container mx-auto px-4'>
          <div className='max-w-3xl mx-auto text-center'>
            <h2 className='text-3xl font-bold mb-4 text-foreground'>
              Want Professional Drone Footage?
            </h2>
            <p className='text-lg text-muted-foreground mb-8'>
              We offer custom aerial videography services for real estate, events, and commercial
              projects.
            </p>
            <div className='flex gap-4 justify-center flex-wrap'>
              <Button asChild variant='UI' size='lg'>
                <Link href='/services/video'>View Services</Link>
              </Button>
              <Button asChild variant='outline' size='lg'>
                <Link href='/contact'>Get a Quote</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export async function generateMetadata({ searchParams }: PageProps): Promise<Metadata> {
  const params = await searchParams;
  const title = params.search
    ? `Search: ${params.search} - Fight Videos`
    : 'Fight Videos - reveal UI';

  const description = params.search
    ? `Search results for "${params.search}" in our fight video library`
    : 'Watch epic fights, exclusive drone footage, and highlights from reveal UI. Professional combat sports videos.';

  const meta = generateMeta({
    title,
    description,
    url: '/videos',
    type: 'website',
  });

  return meta;
}
