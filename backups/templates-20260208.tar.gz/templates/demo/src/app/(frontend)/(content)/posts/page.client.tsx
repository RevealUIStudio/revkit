'use client';

import { useTheme } from '@/presentation/providers/ThemeProvider.ts';
import React, { useEffect } from 'react';

const PageClient: React.FC = () => {
  // Force the header to be light mode
  const { setTheme } = useTheme();

  useEffect(() => {
    setTheme('light');
  }, [setTheme]);
  return <React.Fragment />;
};

export default PageClient;
