import { isAnalyzerBuild } from '@/config/system/utilities/build-flags';
import { searchPosts } from '@/features/search';
import { SearchBar } from '@/features/search/ui/SearchBar';
import { PostCard } from '@/presentation/components/content/PostCard';
import { AnalyzerModeBanner } from '@/presentation/components/system/AnalyzerModeBanner';
import { PageLoading } from '@/presentation/components/ui/PageLoading';
import { ErrorBoundary } from '@/presentation/components/ui/client/ErrorBoundary';
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import { Suspense } from 'react';

export const dynamic = 'force-dynamic';
export const revalidate = 0; // No caching for search results

interface SearchPageProps {
  searchParams: Promise<{ q?: string }>;
}

async function SearchResults({ query }: { query: string }) {
  const analyzerMode = isAnalyzerBuild();
  const results = analyzerMode ? [] : await searchPosts(query);

  if (results.length === 0) {
    return (
      <Card className='max-w-2xl mx-auto'>
        <CardHeader>
          <CardTitle>No Results Found</CardTitle>
          <CardDescription>
            Try searching with different keywords or browse our{' '}
            <a
              href='/posts'
              className='text-brand-red-600 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-red-600 focus-visible:ring-offset-2 rounded-md'
            >
              latest posts
            </a>
            .
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <>
      <div className='mb-8'>
        <p className='text-lg text-theme-text opacity-80'>
          Found {results.length} result{results.length === 1 ? '' : 's'} for &quot;{query}&quot;
        </p>
      </div>
      <div className='grid gap-6 md:grid-cols-2 lg:grid-cols-3'>
        {results.map(post => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </>
  );
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const params = await searchParams;
  const query = params.q || '';
  const analyzerMode = isAnalyzerBuild();

  return (
    <div className='pt-24 pb-24 bg-theme'>
      <div className='container mx-auto px-4'>
        <div className='mb-12'>
          <h1 className='text-4xl font-bold mb-6 text-theme-text'>Search</h1>
          <div className='max-w-2xl'>
            <SearchBar placeholder='Search posts, categories, tags...' />
          </div>
          {analyzerMode && <AnalyzerModeBanner />}
        </div>

        {!query ? (
          <Card className='max-w-2xl mx-auto'>
            <CardHeader>
              <CardTitle>Start Searching</CardTitle>
              <CardDescription>
                Enter a search term above to find posts, articles, and updates from reveal UI.
              </CardDescription>
            </CardHeader>
          </Card>
        ) : (
          <ErrorBoundary>
            <Suspense fallback={<PageLoading />}>
              <SearchResults query={query} />
            </Suspense>
          </ErrorBoundary>
        )}
      </div>
    </div>
  );
}

export function generateMetadata(): Metadata {
  return {
    title: 'Search - reveal UI',
    description: 'Search for posts, articles, and updates from reveal UI.',
  };
}
