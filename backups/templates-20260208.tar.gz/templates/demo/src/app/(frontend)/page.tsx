import { generateMeta } from '@/config/system/utilities/generation';
import type { Metadata } from 'next';
import Link from 'next/link';
import { ExampleSelector } from '@/components/ExampleSelector';

export const dynamic = 'force-static';
export const revalidate = 600;

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'reveal UI',
    description: 'Immersive combat sports storytelling for web and video.',
    url: '/',
  });
}

export default function HomePage() {
  return (
    <main className='space-y-16 pb-24'>
      {/* Example Selector */}
      <section className='bg-white border-b border-gray-200 py-4'>
        <div className='mx-auto max-w-4xl px-6'>
          <div className='flex items-center justify-between'>
            <div>
              <h2 className='text-lg font-semibold text-gray-900'>RevealUI Examples</h2>
              <p className='text-sm text-gray-600'>Choose an example to explore different features and use cases</p>
            </div>
            <ExampleSelector />
          </div>
        </div>
      </section>

      <section className='relative overflow-hidden bg-gradient-to-br from-black via-brand-red-900 to-black text-white'>
        <div className='absolute inset-0 opacity-40 bg-[url("/textures/noise.png")] mix-blend-overlay' />
        <div className='relative mx-auto flex max-w-5xl flex-col gap-6 px-6 py-24 text-center'>
          <p className='text-sm font-semibold uppercase tracking-[0.3em] text-brand-orange-200'>
            reveal UI studios
          </p>
          <h1 className='text-4xl font-black tracking-tight md:text-6xl'>
            Building cinematic fight experiences for the web.
          </h1>
          <p className='mx-auto max-w-2xl text-base text-white/80 md:text-lg'>
            We&rsquo;re rolling out the next wave of live storytelling, analytics, and fan
            engagement. The new platform is almost here—jump on the list and we&rsquo;ll keep you in
            the loop.
          </p>
          <div className='flex flex-col items-center justify-center gap-4 sm:flex-row'>
            <Link
              href='mailto:hello@reveal.com'
              className='rounded-full bg-white px-6 py-3 text-sm font-semibold text-black transition hover:bg-white/90'
            >
              Talk to the team
            </Link>
            <Link
              href='/pricing'
              className='rounded-full border border-white/40 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10'
            >
              View upcoming plans
            </Link>
          </div>
        </div>
      </section>

      <section className='mx-auto max-w-4xl px-6'>
        <div className='space-y-6 rounded-3xl border border-border/50 bg-card/60 p-8 shadow-lg backdrop-blur'>
          <p className='text-sm font-semibold uppercase tracking-[0.25em] text-muted-foreground'>
            Platform status
          </p>
          <div className='grid gap-6 md:grid-cols-2'>
            <div>
              <h2 className='text-xl font-semibold text-foreground'>Account & Billing</h2>
              <p className='text-sm text-muted-foreground'>
                Self-service management is offline while we migrate customers to the new stack.
                Email
                <a href='mailto:account@reveal.com' className='ml-1 underline underline-offset-4'>
                  account@reveal.com
                </a>
                &nbsp;and the crew will sort you out immediately.
              </p>
            </div>
            <div>
              <h2 className='text-xl font-semibold text-foreground'>Commerce & Streaming</h2>
              <p className='text-sm text-muted-foreground'>
                Checkout and live streams are relaunching soon. For manual orders or event access,
                email{' '}
                <a href='mailto:sales@reveal.com' className='underline underline-offset-4'>
                  sales@reveal.com
                </a>
                .
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className='mx-auto max-w-5xl px-6'>
        <div className='rounded-3xl border border-border bg-background/80 p-8 backdrop-blur'>
          <h2 className='text-2xl font-semibold text-foreground'>What&rsquo;s coming next</h2>
          <ul className='mt-6 grid gap-4 text-sm text-muted-foreground md:grid-cols-2'>
            <li className='rounded-2xl border border-border/60 bg-card/60 p-4'>
              • Personalized fight dashboards with real-time scoring and analytics.
            </li>
            <li className='rounded-2xl border border-border/60 bg-card/60 p-4'>
              • Creator toolkit for publishing fight commentary, breakdowns, and behind-the-scenes
              drops.
            </li>
            <li className='rounded-2xl border border-border/60 bg-card/60 p-4'>
              • New streaming pipeline with Dolby Vision support and multi-angle replays.
            </li>
            <li className='rounded-2xl border border-border/60 bg-card/60 p-4'>
              • API-access for partners integrating fight data into their own experiences.
            </li>
          </ul>
        </div>
      </section>
    </main>
  );
}
