// Helper function to safely extract data from ServiceResult
export function extractData<T>(result: unknown): T | null {
  const resultObj = result as { success?: unknown; data?: T } | null;
  if (
    resultObj &&
    typeof resultObj === 'object' &&
    'success' in resultObj &&
    Boolean(resultObj.success) &&
    'data' in resultObj
  ) {
    return resultObj.data || null;
  }
  return null;
}
