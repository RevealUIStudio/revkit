import { generateMeta } from '@/config/system/utilities/generation';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Shipping Policy',
    description: 'Shipping information, costs, and delivery times for reveal UI orders',
    url: '/shipping-policy',
  });
}

export default function ShippingPolicyPage() {
  const lastUpdated = 'October 16, 2025';
  const supportEmail = 'shipping@reveal-UI.com';

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <Card>
            <CardHeader>
              <CardTitle className='text-3xl'>Shipping Policy</CardTitle>
              <p className='text-sm text-muted-foreground mt-2'>Last Updated: {lastUpdated}</p>
            </CardHeader>
            <CardContent className='prose prose-sm max-w-none'>
              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>1. Shipping Methods & Costs</h2>

                <div className='bg-muted/50 p-4 rounded-lg mb-4'>
                  <h3 className='text-lg font-semibold mb-2'>Standard Shipping - $5.99</h3>
                  <ul className='mb-0'>
                    <li>Delivery Time: 5-7 business days</li>
                    <li>Tracking included</li>
                    <li>Available for all domestic orders</li>
                  </ul>
                </div>

                <div className='bg-muted/50 p-4 rounded-lg'>
                  <h3 className='text-lg font-semibold mb-2'>Express Shipping - $12.99</h3>
                  <ul className='mb-0'>
                    <li>Delivery Time: 2-3 business days</li>
                    <li>Tracking included</li>
                    <li>Priority handling</li>
                  </ul>
                </div>

                <div className='mt-4 p-4 bg-green-50 border-l-4 border-green-600 rounded'>
                  <p className='text-sm font-semibold text-green-800 mb-1'>FREE Shipping</p>
                  <p className='text-sm text-green-700 mb-0'>
                    Orders over $50 qualify for free standard shipping!
                  </p>
                </div>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>2. Processing Time</h2>
                <p>
                  Orders are typically processed within 1-2 business days after payment is
                  confirmed. You will receive an email notification when your order ships, including
                  tracking information.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>Processing Delays</h3>
                <p>Processing times may be extended during:</p>
                <ul>
                  <li>High-volume sale periods</li>
                  <li>Holidays and weekends</li>
                  <li>Custom or personalized orders</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>3. Shipping Destinations</h2>

                <h3 className='text-xl font-semibold mb-2'>
                  3.1 Domestic Shipping (United States)
                </h3>
                <p>
                  We ship to all 50 states, including Alaska and Hawaii. Please note that Alaska,
                  Hawaii, and US territories may have longer delivery times and additional shipping
                  costs.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.2 International Shipping</h3>
                <p>We currently ship to the following countries:</p>
                <ul>
                  <li>Canada</li>
                  <li>United Kingdom</li>
                  <li>Australia</li>
                </ul>
                <p className='mt-2'>
                  International shipping costs and delivery times vary by destination. Customs fees,
                  duties, and taxes are the responsibility of the recipient.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.3 PO Boxes & APO/FPO</h3>
                <p>
                  We ship to PO Boxes and military addresses (APO/FPO). Standard shipping only is
                  available for these destinations.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>4. Order Tracking</h2>
                <p>Once your order ships, you will receive:</p>
                <ul>
                  <li>Email confirmation with tracking number</li>
                  <li>Link to carrier tracking page</li>
                  <li>Estimated delivery date</li>
                </ul>
                <p className='mt-2'>
                  You can also track your order by logging into your account and viewing your order
                  history.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>5. Delivery Issues</h2>

                <h3 className='text-xl font-semibold mb-2'>5.1 Lost Packages</h3>
                <p>If tracking shows your package as delivered but you haven't received it:</p>
                <ol>
                  <li>Check with neighbors and household members</li>
                  <li>Verify the shipping address on your order</li>
                  <li>Wait 24-48 hours (sometimes carriers mark as delivered early)</li>
                  <li>Contact us if still not received after 48 hours</li>
                </ol>

                <h3 className='text-xl font-semibold mb-2 mt-4'>5.2 Damaged in Transit</h3>
                <p>If your package arrives damaged:</p>
                <ul>
                  <li>Take photos of the damaged packaging and product</li>
                  <li>Contact us within 7 days of delivery</li>
                  <li>We will send a replacement or issue a full refund</li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>5.3 Wrong Address</h3>
                <p>
                  Please verify your shipping address before completing checkout. We are not
                  responsible for orders shipped to incorrect addresses provided by the customer.
                  Address changes cannot be made once the order has shipped.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>6. Shipping Restrictions</h2>
                <p>Certain products may have shipping restrictions based on:</p>
                <ul>
                  <li>Size or weight limitations</li>
                  <li>Hazardous materials regulations</li>
                  <li>International customs restrictions</li>
                  <li>State or local laws</li>
                </ul>
                <p className='mt-2'>
                  Any restrictions will be displayed on the product page before checkout.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>
                  7. Customs and Import Duties (International)
                </h2>
                <p>International customers are responsible for:</p>
                <ul>
                  <li>All customs fees, duties, and taxes</li>
                  <li>Providing accurate customs information</li>
                  <li>Clearing packages through customs</li>
                </ul>
                <p className='mt-2'>
                  We are not responsible for packages held by customs or refused due to unpaid fees.
                  Refused packages will not be refunded.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>8. Holiday Shipping</h2>
                <p>During peak holiday seasons:</p>
                <ul>
                  <li>Order early to ensure delivery before holidays</li>
                  <li>Processing times may be longer</li>
                  <li>Carrier delays are common</li>
                  <li>Cutoff dates will be announced on our website</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>9. Multiple Shipments</h2>
                <p>Orders containing multiple items may ship in separate packages:</p>
                <ul>
                  <li>Each package will have its own tracking number</li>
                  <li>You will receive separate tracking emails</li>
                  <li>This helps us get your order to you faster</li>
                  <li>No additional shipping charges apply</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>10. Contact Us</h2>
                <p>For shipping-related questions or issues, please contact us:</p>
                <div className='mt-4 p-4 bg-muted rounded-lg'>
                  <p>
                    <strong>Shipping Department</strong>
                  </p>
                  <p className='mt-2'>
                    Email:{' '}
                    <a
                      href={`mailto:${supportEmail}`}
                      className='text-brand-red-600 hover:underline'
                    >
                      {supportEmail}
                    </a>
                  </p>
                  <p className='mt-2'>
                    Please include your order number in all shipping inquiries.
                  </p>
                </div>
              </section>

              <div className='mt-8 p-4 bg-muted rounded-lg'>
                <p className='text-sm text-muted-foreground'>
                  This shipping policy was last updated on {lastUpdated}. Shipping rates, methods,
                  and delivery times are subject to change. Please review this page before placing
                  your order.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
