import { generateMeta } from '@/config/system/utilities/generation';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Privacy Policy',
    description: 'Learn how reveal UI collects, uses, and protects your personal information',
    url: '/privacy-policy',
  });
}

export default function PrivacyPolicyPage() {
  const lastUpdated = 'October 16, 2025';
  const companyName = 'reveal UI';
  const supportEmail = 'privacy@reveal-UI.com';

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <Card>
            <CardHeader>
              <CardTitle className='text-3xl'>Privacy Policy</CardTitle>
              <p className='text-sm text-muted-foreground mt-2'>Last Updated: {lastUpdated}</p>
            </CardHeader>
            <CardContent className='prose prose-sm max-w-none'>
              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>1. Introduction</h2>
                <p>
                  {companyName} (&quot;we,&quot; &quot;us,&quot; or &quot;our&quot;) is committed to
                  protecting your privacy. This Privacy Policy explains how we collect, use,
                  disclose, and safeguard your information when you visit our website or make a
                  purchase.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>2. Information We Collect</h2>

                <h3 className='text-xl font-semibold mb-2'>2.1 Personal Information</h3>
                <p>We collect the following personal information when you:</p>
                <ul>
                  <li>Create an account: Name, email address, password</li>
                  <li>Make a purchase: Billing and shipping address, phone number</li>
                  <li>Contact us: Name, email, message content</li>
                  <li>Subscribe to our newsletter: Email address</li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>2.2 Payment Information</h3>
                <p>
                  Payment information (credit card numbers) is processed securely by Stripe, our
                  payment processor. We do not store complete credit card information on our
                  servers.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>
                  2.3 Automatically Collected Information
                </h3>
                <ul>
                  <li>IP address and browser type</li>
                  <li>Device information and operating system</li>
                  <li>Cookies and similar tracking technologies</li>
                  <li>Pages visited and time spent on our website</li>
                  <li>Referring website addresses</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>3. How We Use Your Information</h2>
                <p>We use collected information to:</p>
                <ul>
                  <li>Process and fulfill your orders</li>
                  <li>Send order confirmations and shipping notifications</li>
                  <li>Respond to customer service requests</li>
                  <li>Improve our website and customer experience</li>
                  <li>Send marketing communications (with your consent)</li>
                  <li>Prevent fraud and enhance security</li>
                  <li>Comply with legal obligations</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>4. Information Sharing</h2>
                <p>We may share your information with:</p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.1 Service Providers</h3>
                <ul>
                  <li>
                    <strong>Stripe:</strong> Payment processing
                  </li>
                  <li>
                    <strong>Vercel:</strong> Website hosting and infrastructure
                  </li>
                  <li>
                    <strong>Resend:</strong> Email delivery
                  </li>
                  <li>
                    <strong>Shipping carriers:</strong> Order fulfillment
                  </li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.2 Legal Requirements</h3>
                <p>
                  We may disclose your information if required by law or in response to valid
                  requests by public authorities (e.g., court orders, subpoenas).
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.3 Business Transfers</h3>
                <p>
                  In the event of a merger, acquisition, or sale of assets, your information may be
                  transferred to the acquiring entity.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>5. Data Security</h2>
                <p>
                  We implement appropriate technical and organizational security measures to protect
                  your personal information against unauthorized access, alteration, disclosure, or
                  destruction. These measures include:
                </p>
                <ul>
                  <li>SSL/TLS encryption for data in transit</li>
                  <li>Encrypted database connections</li>
                  <li>Secure payment processing via Stripe (PCI-DSS compliant)</li>
                  <li>Regular security audits and updates</li>
                  <li>Access controls and authentication</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>6. Your Rights</h2>
                <p>Depending on your location, you may have the following rights:</p>
                <ul>
                  <li>
                    <strong>Access:</strong> Request a copy of your personal data
                  </li>
                  <li>
                    <strong>Rectification:</strong> Request correction of inaccurate data
                  </li>
                  <li>
                    <strong>Erasure:</strong> Request deletion of your data
                  </li>
                  <li>
                    <strong>Portability:</strong> Request transfer of your data
                  </li>
                  <li>
                    <strong>Objection:</strong> Object to processing of your data
                  </li>
                  <li>
                    <strong>Withdrawal:</strong> Withdraw consent at any time
                  </li>
                </ul>
                <p className='mt-2'>
                  To exercise these rights, contact us at{' '}
                  <a href={`mailto:${supportEmail}`} className='text-brand-red-600 hover:underline'>
                    {supportEmail}
                  </a>
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>7. Cookies and Tracking</h2>
                <p>
                  We use cookies and similar technologies to enhance your browsing experience,
                  analyze site traffic, and remember your preferences. You can control cookies
                  through your browser settings.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>Types of Cookies We Use:</h3>
                <ul>
                  <li>
                    <strong>Essential:</strong> Required for website functionality
                  </li>
                  <li>
                    <strong>Analytics:</strong> Help us understand usage patterns
                  </li>
                  <li>
                    <strong>Marketing:</strong> Used for targeted advertising (with consent)
                  </li>
                  <li>
                    <strong>Preferences:</strong> Remember your settings
                  </li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>8. Data Retention</h2>
                <p>
                  We retain your personal information for as long as necessary to fulfill the
                  purposes outlined in this privacy policy, unless a longer retention period is
                  required by law. Order information is retained for a minimum of 7 years for tax
                  and accounting purposes.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>9. Children's Privacy</h2>
                <p>
                  Our services are not directed to individuals under 18 years of age. We do not
                  knowingly collect personal information from children. If you believe we have
                  collected information from a child, please contact us immediately.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>10. International Data Transfers</h2>
                <p>
                  Your information may be transferred to and maintained on servers located outside
                  your state, province, country, or other governmental jurisdiction. By using our
                  services, you consent to this transfer.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>11. Third-Party Links</h2>
                <p>
                  Our website may contain links to third-party websites. We are not responsible for
                  the privacy practices of these external sites. We encourage you to read their
                  privacy policies.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>12. Updates to This Policy</h2>
                <p>
                  We may update this Privacy Policy from time to time. We will notify you of any
                  changes by posting the new policy on this page and updating the &quot;Last
                  Updated&quot; date.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>13. Contact Us</h2>
                <p>
                  If you have questions or concerns about this Privacy Policy or our data practices,
                  please contact us at:
                </p>
                <p className='mt-2'>
                  Email:{' '}
                  <a href={`mailto:${supportEmail}`} className='text-brand-red-600 hover:underline'>
                    {supportEmail}
                  </a>
                </p>
              </section>

              <div className='mt-8 p-4 bg-blue-50 border-l-4 border-blue-600 rounded'>
                <p className='text-sm font-semibold mb-2'>GDPR & CCPA Compliance</p>
                <p className='text-sm text-muted-foreground'>
                  We comply with the General Data Protection Regulation (GDPR) and California
                  Consumer Privacy Act (CCPA). If you are a resident of the EU or California, you
                  have additional rights regarding your personal data. Contact us to exercise these
                  rights.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
