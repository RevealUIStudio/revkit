import { generateMeta } from '@/config/system/utilities/generation';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Refund & Return Policy',
    description: 'Learn about our refund and return policy for reveal UI products',
    url: '/refund-policy',
  });
}

export default function RefundPolicyPage() {
  const lastUpdated = 'October 16, 2025';
  const supportEmail = 'returns@reveal-UI.com';
  const returnWindow = '30 days';

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <Card>
            <CardHeader>
              <CardTitle className='text-3xl'>Refund & Return Policy</CardTitle>
              <p className='text-sm text-muted-foreground mt-2'>Last Updated: {lastUpdated}</p>
            </CardHeader>
            <CardContent className='prose prose-sm max-w-none'>
              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>1. Return Window</h2>
                <p>
                  You have {returnWindow} from the date of delivery to return eligible items for a
                  refund or exchange. Items must be unused, in original condition, and in original
                  packaging.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>2. Eligible Items</h2>

                <h3 className='text-xl font-semibold mb-2'>2.1 Returnable Items</h3>
                <ul>
                  <li>Unworn apparel with original tags attached</li>
                  <li>Unopened accessories in original packaging</li>
                  <li>Non-personalized items</li>
                  <li>Items not marked as final sale</li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>2.2 Non-Returnable Items</h3>
                <ul>
                  <li>Digital products and video access</li>
                  <li>Personalized or custom-made items</li>
                  <li>Items marked as final sale or clearance</li>
                  <li>Worn or used items</li>
                  <li>Items without original packaging or tags</li>
                  <li>Gift cards</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>3. Return Process</h2>

                <h3 className='text-xl font-semibold mb-2'>3.1 How to Initiate a Return</h3>
                <ol>
                  <li>Log into your account and go to Order History</li>
                  <li>Select the order you wish to return</li>
                  <li>Click &quot;Request Return&quot; and select items</li>
                  <li>Provide reason for return</li>
                  <li>Receive return authorization and shipping label</li>
                </ol>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.2 Return Shipping</h3>
                <p>
                  <strong>Free Returns:</strong> We provide free return shipping labels for
                  defective or incorrect items.
                </p>
                <p className='mt-2'>
                  <strong>Customer Returns:</strong> Return shipping costs are deducted from your
                  refund unless the item is defective or we made an error.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.3 Return Inspection</h3>
                <p>
                  Once we receive your return, we will inspect it within 2-3 business days. You will
                  receive an email notification with the inspection results.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>4. Refunds</h2>

                <h3 className='text-xl font-semibold mb-2'>4.1 Refund Processing Time</h3>
                <ul>
                  <li>Approved refunds are processed within 5-7 business days</li>
                  <li>Refunds are issued to the original payment method</li>
                  <li>Bank processing may take additional 5-10 business days</li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.2 Partial Refunds</h3>
                <p>Partial refunds may be issued for:</p>
                <ul>
                  <li>Items showing signs of use or wear</li>
                  <li>Items missing original packaging or tags</li>
                  <li>Items returned after the {returnWindow} window (at our discretion)</li>
                </ul>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.3 Refund Exceptions</h3>
                <p>
                  Sale items and clearance products can only be returned if defective. Digital
                  products are non-refundable once accessed.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>5. Exchanges</h2>
                <p>If you need to exchange an item for a different size or color:</p>
                <ol>
                  <li>Initiate a return following the standard process</li>
                  <li>Place a new order for the desired item</li>
                  <li>Refund will be processed once we receive your return</li>
                </ol>
                <p className='mt-2'>
                  <strong>Tip:</strong> To ensure availability, place your new order before
                  returning the original item.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>6. Damaged or Defective Items</h2>
                <p>If you receive a damaged or defective item:</p>
                <ol>
                  <li>Contact us within 7 days of delivery</li>
                  <li>Provide photos of the damage or defect</li>
                  <li>We will arrange for replacement or full refund</li>
                  <li>We will cover return shipping costs</li>
                </ol>
                <p className='mt-2'>
                  Email us at{' '}
                  <a href={`mailto:${supportEmail}`} className='text-brand-red-600 hover:underline'>
                    {supportEmail}
                  </a>{' '}
                  with your order number and photos.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>7. Incorrect Orders</h2>
                <p>If you receive an incorrect item:</p>
                <ul>
                  <li>We will send you the correct item at no charge</li>
                  <li>We will provide a prepaid return label for the incorrect item</li>
                  <li>You will receive a full refund if the correct item is unavailable</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>8. Cancellations</h2>
                <p>
                  You may cancel your order before it ships by contacting us immediately. Once an
                  order has shipped, you must follow our standard return process.
                </p>
                <p className='mt-2'>
                  To cancel an order, email{' '}
                  <a href={`mailto:${supportEmail}`} className='text-brand-red-600 hover:underline'>
                    {supportEmail}
                  </a>{' '}
                  with your order number.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>9. Restocking Fee</h2>
                <p>
                  We do not charge restocking fees for standard returns. However, a restocking fee
                  may apply to:
                </p>
                <ul>
                  <li>Large or heavy items requiring special handling</li>
                  <li>Custom or personalized items (if returnable)</li>
                  <li>Items returned without authorization</li>
                </ul>
                <p className='mt-2'>
                  Any restocking fees will be communicated before you complete your return.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>10. Contact Us</h2>
                <p>For questions about returns, refunds, or this policy, please contact us:</p>
                <div className='mt-4 p-4 bg-muted rounded-lg'>
                  <p>
                    <strong>Returns Department</strong>
                  </p>
                  <p className='mt-2'>
                    Email:{' '}
                    <a
                      href={`mailto:${supportEmail}`}
                      className='text-brand-red-600 hover:underline'
                    >
                      {supportEmail}
                    </a>
                  </p>
                  <p className='mt-1'>
                    Include your order number and reason for return in all communications.
                  </p>
                </div>
              </section>

              <div className='mt-8 p-4 bg-muted rounded-lg'>
                <p className='text-sm text-muted-foreground'>
                  This refund policy was last updated on {lastUpdated}. We reserve the right to
                  modify this policy at any time. Please review it periodically for changes.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
