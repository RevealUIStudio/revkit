import { getEnvVarWithFallback } from '@/config/presentation/environment';
import { generateMeta } from '@/config/system/utilities/generation';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Terms of Service',
    description: 'Terms and conditions for using reveal UI services and products',
    url: '/terms-of-service',
  });
}

export default function TermsOfServicePage() {
  const lastUpdated = 'October 16, 2025';
  const companyName = 'reveal UI';
  const websiteUrl = getEnvVarWithFallback('NEXT_PUBLIC_SERVER_URL', 'https://reveal-UI.com');
  const supportEmail = 'support@reveal-UI.com';

  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4'>
        <div className='max-w-4xl mx-auto'>
          <Card>
            <CardHeader>
              <CardTitle className='text-3xl'>Terms of Service</CardTitle>
              <p className='text-sm text-muted-foreground mt-2'>Last Updated: {lastUpdated}</p>
            </CardHeader>
            <CardContent className='prose prose-sm max-w-none'>
              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>1. Acceptance of Terms</h2>
                <p>
                  By accessing and using {companyName} (&quot;we,&quot; &quot;us,&quot; or
                  &quot;our&quot;) website and services, you accept and agree to be bound by the
                  terms and provision of this agreement.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>2. Use of Services</h2>
                <h3 className='text-xl font-semibold mb-2'>2.1 Eligibility</h3>
                <p>
                  You must be at least 18 years old to make purchases on our website. By making a
                  purchase, you represent that you meet this age requirement.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>2.2 Account Registration</h3>
                <p>
                  You may need to create an account to access certain features. You are responsible
                  for maintaining the confidentiality of your account credentials and for all
                  activities that occur under your account.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>2.3 Prohibited Activities</h3>
                <ul>
                  <li>Fraudulent purchases or chargebacks</li>
                  <li>Unauthorized use of payment methods</li>
                  <li>Reselling products without authorization</li>
                  <li>Misuse of discount codes or promotions</li>
                  <li>Automated scraping or data collection</li>
                </ul>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>3. Products and Pricing</h2>
                <h3 className='text-xl font-semibold mb-2'>3.1 Product Information</h3>
                <p>
                  We strive to provide accurate product descriptions, images, and pricing. However,
                  we do not warrant that product descriptions or other content is accurate,
                  complete, reliable, current, or error-free.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.2 Pricing</h3>
                <p>
                  All prices are in USD unless otherwise stated. Prices are subject to change
                  without notice. We reserve the right to modify or discontinue products at any
                  time.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>3.3 Tax</h3>
                <p>
                  Applicable sales tax will be calculated and added to your order total at checkout
                  based on your shipping address.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>4. Orders and Payment</h2>
                <h3 className='text-xl font-semibold mb-2'>4.1 Order Processing</h3>
                <p>
                  All orders are subject to acceptance and availability. We reserve the right to
                  refuse or cancel any order for any reason, including but not limited to product
                  availability, errors in pricing or product information, or suspected fraud.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.2 Payment</h3>
                <p>
                  Payment is processed securely through Stripe. We do not store your credit card
                  information. All transactions must be authorized before we ship your order.
                </p>

                <h3 className='text-xl font-semibold mb-2 mt-4'>4.3 Order Confirmation</h3>
                <p>
                  You will receive an email confirmation once your order is placed. This email is
                  not an acceptance of your order; it is simply confirmation that we received it.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>5. Shipping and Delivery</h2>
                <p>
                  Shipping costs and delivery times vary based on your location and selected
                  shipping method. We are not responsible for delays caused by shipping carriers.
                  Please see our{' '}
                  <a href='/shipping-policy' className='text-brand-red-600 hover:underline'>
                    Shipping Policy
                  </a>{' '}
                  for complete details.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>6. Returns and Refunds</h2>
                <p>
                  Our return and refund policy is detailed in our{' '}
                  <a href='/refund-policy' className='text-brand-red-600 hover:underline'>
                    Refund Policy
                  </a>
                  . Please review it carefully before making a purchase.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>7. Intellectual Property</h2>
                <p>
                  All content on this website, including but not limited to text, graphics, logos,
                  images, and software, is the property of {companyName} and is protected by
                  copyright, trademark, and other intellectual property laws.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>8. Limitation of Liability</h2>
                <p>
                  To the maximum extent permitted by law, {companyName} shall not be liable for any
                  indirect, incidental, special, consequential, or punitive damages, or any loss of
                  profits or revenues, whether incurred directly or indirectly.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>9. Privacy</h2>
                <p>
                  Your use of our website is also governed by our{' '}
                  <a href='/privacy-policy' className='text-brand-red-600 hover:underline'>
                    Privacy Policy
                  </a>
                  . Please review our Privacy Policy to understand our practices.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>10. Modifications to Terms</h2>
                <p>
                  We reserve the right to modify these terms at any time. Changes will be effective
                  immediately upon posting to the website. Your continued use of our services after
                  changes are posted constitutes your acceptance of the modified terms.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>11. Governing Law</h2>
                <p>
                  These terms shall be governed by and construed in accordance with the laws of the
                  United States, without regard to its conflict of law provisions.
                </p>
              </section>

              <section className='mb-8'>
                <h2 className='text-2xl font-semibold mb-4'>12. Contact Information</h2>
                <p>If you have any questions about these Terms of Service, please contact us at:</p>
                <p className='mt-2'>
                  Email:{' '}
                  <a href={`mailto:${supportEmail}`} className='text-brand-red-600 hover:underline'>
                    {supportEmail}
                  </a>
                  <br />
                  Website:{' '}
                  <a href={websiteUrl} className='text-brand-red-600 hover:underline'>
                    {websiteUrl}
                  </a>
                </p>
              </section>

              <div className='mt-8 p-4 bg-muted rounded-lg'>
                <p className='text-sm text-muted-foreground'>
                  These terms were last updated on {lastUpdated}. By using our website and services,
                  you acknowledge that you have read and understood these terms and agree to be
                  bound by them.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
