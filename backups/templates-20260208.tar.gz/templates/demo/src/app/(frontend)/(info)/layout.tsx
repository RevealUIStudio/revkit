import type { ReactNode } from 'react';

/**
 * Informational Pages Layout
 *
 * Shared configuration for legal and informational pages:
 * - Privacy Policy, Terms of Service, Refund Policy, Shipping Policy
 *
 * These pages change very rarely, so we use the longest revalidation time.
 */

// Static legal pages with 24-hour revalidation (almost never change)
export const revalidate = 86400; // 24 hours

export default function InfoLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
