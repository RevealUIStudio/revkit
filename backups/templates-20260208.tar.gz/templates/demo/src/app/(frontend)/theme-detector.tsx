'use client';

import { useEffect } from 'react';

/**
 * System Dark Mode Detector for Frontend
 *
 * Automatically detects system color scheme preference and applies
 * data-theme attribute to HTML element.
 *
 * Respects manual theme selection if set, otherwise follows system preference.
 */
export function FrontendThemeDetector() {
  useEffect(() => {
    function applySystemTheme() {
      // Check if user has manually set a theme
      const manualTheme = localStorage.getItem('theme');

      if (manualTheme === 'light' || manualTheme === 'dark') {
        // User has manually selected a theme, respect it
        document.documentElement.setAttribute('data-theme', manualTheme);
        document.documentElement.setAttribute('data-frontend-theme', manualTheme);
        document.documentElement.classList.toggle('dark', manualTheme === 'dark');
        return;
      }

      // No manual selection, use system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const theme = prefersDark ? 'dark' : 'light';

      document.documentElement.setAttribute('data-theme', theme);
      document.documentElement.setAttribute('data-frontend-theme', theme);
      document.documentElement.classList.toggle('dark', theme === 'dark');

      // Also set color-scheme for browser UI
      document.documentElement.style.colorScheme = theme;
    }

    // Apply theme immediately
    applySystemTheme();

    // Listen for system theme changes
    const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const handleThemeChange = (e: MediaQueryListEvent) => {
      // Only update if user hasn't manually set a theme
      const manualTheme = localStorage.getItem('theme');
      if (!manualTheme) {
        const theme = e.matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.setAttribute('data-frontend-theme', theme);
        document.documentElement.classList.toggle('dark', theme === 'dark');
        document.documentElement.style.colorScheme = theme;
      }
    };

    // Modern browsers
    darkModeQuery.addEventListener('change', handleThemeChange);

    // Cleanup
    return () => {
      darkModeQuery.removeEventListener('change', handleThemeChange);
    };
  }, []);

  return null; // This component doesn't render anything
}
