import React from 'react';
import { mergeOpenGraph } from '@/config/system/utilities/generation.ts';
import { getServerSideURL } from '@/config/system/utilities/urls.ts';
import { AdminBar } from '@revealui/content/admin/src/admin-bar';
import { Footer } from '@/presentation/components/branding/Footer/Component';
import { LivePreviewListener } from '@/presentation/components/navigation/LivePreviewListener';
import { MainNavigation } from '@/presentation/components/navigation/MainNavigation';
import '@/presentation/demo/styles/tour-styles.css';
import { AppProviders } from '@/presentation/providers/AppProviders';
import { ThemeScript } from '@/presentation/providers/ThemeProvider';
import type { Metadata } from 'next';
import { draftMode } from 'next/headers';
// Temporarily disable font imports to work around Next.js/Turbopack bug
// TODO: Re-enable when Next.js fixes the font loading issue
// import {
//   actOfRejection,
//   fightKid,
//   fontBrushRegular,
//   greatFighter,
//   karateChop,
//   keylockFighter,
//   playBold,
//   playRegular,
//   singleFighter,
// } from '../fonts';
import './globals.css';

export default async function FrontendLayout({ children }: { children: React.ReactNode }) {
  const { isEnabled } = await draftMode();

  // Temporarily disable font variables to work around Next.js/Turbopack bug
  // Fonts will fall back to system fonts defined in CSS
  // TODO: Re-enable when Next.js fixes the font loading issue
  const fontVariables = '';
  // const fontVariables = [
  //   singleFighter.variable,
  //   actOfRejection.variable,
  //   fightKid.variable,
  //   fontBrushRegular.variable,
  //   greatFighter.variable,
  //   karateChop.variable,
  //   keylockFighter.variable,
  //   playBold.variable,
  //   playRegular.variable,
  // ].join(' ');

  return (
    <html lang='en' suppressHydrationWarning={true} className={fontVariables}>
      <head suppressHydrationWarning={true}>
        <ThemeScript defaultTheme='system' storageKey='theme' />
        <link href='/favicon.ico' rel='icon' sizes='32x32' />
        <link href='/icon.svg' rel='icon' sizes='64x64' type='image/svg+xml' />
      </head>
      <body suppressHydrationWarning={true}>
        <AppProviders enablePreview={isEnabled}>
          <div className='min-h-screen flex flex-col'>
            <AdminBar />
            <LivePreviewListener>
              <MainNavigation />
              <main className='flex-1'>{children}</main>
              <Footer />
            </LivePreviewListener>
          </div>
        </AppProviders>
      </body>
    </html>
  );
}

export const metadata: Metadata = {
  metadataBase: new URL(getServerSideURL()),
  openGraph: mergeOpenGraph(undefined, {
    title: 'reveal UI',
    description: 'Settle it in the yard.',
    type: 'website',
  }),
};
