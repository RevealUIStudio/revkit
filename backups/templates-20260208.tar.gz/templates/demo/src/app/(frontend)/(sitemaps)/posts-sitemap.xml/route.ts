import { getEnvVar } from '@/config/presentation/environment';
import { getRevealUIClient } from '@revealui/infrastructure/cms/utils/DatabaseConnection';
import { unstable_cache } from 'next/cache';
import type { SelectType } from '@revealui/content';

const getPostsSitemap = unstable_cache(
  async () => {
    const SITE_URL =
      getEnvVar('NEXT_PUBLIC_SERVER_URL') ??
      getEnvVar('VERCEL_PROJECT_PRODUCTION_URL') ??
      'https://revealUI.com';

    const select: SelectType = { slug: true, updatedAt: true };
    const revealui = await getRevealUIClient();
    const results = await revealui.find({
      collection: 'posts',
      overrideAccess: false,
      draft: false,
      depth: 0,
      limit: 1000,
      pagination: false,
      select,
      where: {
        _status: { equals: 'published' },
      },
    });

    const dateFallback = new Date().toISOString();

    const sitemap = results.docs
      ? results.docs
          .filter(post => Boolean(post?.slug))
          .map(post => ({
            loc: `${SITE_URL}/posts/${post?.slug}`,
            lastmod: post.updatedAt ?? dateFallback,
          }))
      : [];

    return sitemap;
  },
  ['posts-sitemap'],
  {
    tags: ['posts-sitemap'],
  }
);

export async function GET() {
  const sitemap = await getPostsSitemap();

  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${sitemap
    .map(item => {
      const lastmod = item.lastmod
        ? new Date(item.lastmod).toISOString()
        : new Date().toISOString();
      return `\n  <url>\n    <loc>${item.loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n  </url>`;
    })
    .join('')}\n</urlset>`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=600',
    },
  });
}
