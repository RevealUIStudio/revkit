import { getEnvVar } from '@/config/presentation/environment';
import { getRevealUIClient } from '@revealui/infrastructure/cms/utils/DatabaseConnection';
import { unstable_cache } from 'next/cache';
import type { SelectType } from '@revealui/content';

const getPagesSitemap = unstable_cache(
  async () => {
    const SITE_URL =
      getEnvVar('NEXT_PUBLIC_SERVER_URL') ??
      getEnvVar('VERCEL_PROJECT_PRODUCTION_URL') ??
      'https://revealUI.com';

    const select: SelectType = { slug: true, updatedAt: true };

    const revealui = await getRevealUIClient();
    const results = await revealui.find({
      collection: 'pages',
      draft: false,
      pagination: false,
      depth: 0,
      limit: 1000,
      select,
      where: {
        _status: { equals: 'published' },
      },
    });

    const dateFallback = new Date().toISOString();

    const defaultSitemap = [
      {
        loc: `${SITE_URL}/search`,
        lastmod: dateFallback,
      },
      {
        loc: `${SITE_URL}/posts`,
        lastmod: dateFallback,
      },
    ];

    const sitemap = results.docs
      ? results.docs
          .filter(page => Boolean(page?.slug))
          .map(page => {
            return {
              loc: page?.slug === 'home' ? `${SITE_URL}/` : `${SITE_URL}/${page?.slug}`,
              lastmod: page.updatedAt ?? dateFallback,
            };
          })
      : [];

    return [...defaultSitemap, ...sitemap];
  },
  ['pages-sitemap'],
  {
    tags: ['pages-sitemap'],
  }
);

export async function GET() {
  const sitemap = await getPagesSitemap();

  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${sitemap
    .map(item => {
      const lastmod = item.lastmod
        ? new Date(item.lastmod).toISOString()
        : new Date().toISOString();
      return `\n  <url>\n    <loc>${item.loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n  </url>`;
    })
    .join('')}\n</urlset>`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=600',
    },
  });
}
