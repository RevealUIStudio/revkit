'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  ConvergenceSpaceDashboard,
  REVEALUI_INTELLIGENCES,
  REVEALUI_WORKFLOW_PRESETS,
  ALL_DOMAIN_INTELLIGENCES,
  DOMAIN_WORKFLOW_PRESETS,
  detectDomainTaskType,
  getDomainIntelligenceForTask,
  type IntelligenceEntity,
  type ResonanceMessage,
  type TrustAnalysis,
  type RoutingDecision,
} from '@revealui/mcp/resonance-messaging';

export default function ResonanceChatDemoPage() {
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [intelligences, setIntelligences] = useState<IntelligenceEntity[]>([]);
  const [resonanceField, setResonanceField] = useState<any>(null);
  const [trustAnalysis, setTrustAnalysis] = useState<TrustAnalysis | null>(null);
  const [recentMessages, setRecentMessages] = useState<ResonanceMessage[]>([]);
  const [routingHistory, setRoutingHistory] = useState<RoutingDecision[]>([]);
  const [convergenceMetrics, setConvergenceMetrics] = useState({
    resonanceScore: 0,
    trustStability: 0.8,
    intelligenceDiversity: 0,
    convergenceDepth: 1,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<string>('contentCreation');
  const [selectedDomain, setSelectedDomain] = useState<string>('healthcare');
  const [customTask, setCustomTask] = useState('');
  const [detectedDomain, setDetectedDomain] = useState<string>('general');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Demo data generation
  useEffect(() => {
    generateDemoData();
  }, [selectedPreset]);

  const generateDemoData = () => {
    // Generate mock intelligences based on preset
    const presetIntelligences = REVEALUI_WORKFLOW_PRESETS[selectedPreset as keyof typeof REVEALUI_WORKFLOW_PRESETS] || [];
    const mockIntelligences: IntelligenceEntity[] = presetIntelligences.map(id => {
      const template = REVEALUI_INTELLIGENCES.find(intel => intel.id === id);
      return {
        ...template!,
        coordinates: Array.from({ length: 3333 }, () => (Math.random() - 0.5) * 2),
        convergenceStrength: 0.7 + Math.random() * 0.3,
      };
    });

    setIntelligences(mockIntelligences);

    // Generate mock resonance field
    setResonanceField({
      dimensions: 3333,
      attractors: mockIntelligences.map((intel, i) => ({
        position: intel.coordinates,
        strength: intel.convergenceStrength,
        intelligenceIds: [intel.id],
        convergenceType: i % 3 === 0 ? 'harmonic' : i % 3 === 1 ? 'orthogonal' : 'emergent',
      })),
      harmonicPatterns: Array.from({ length: 3 }, (_, i) => ({
        frequency: 0.1 + i * 0.2,
        amplitude: 0.5 + Math.random() * 0.5,
        phase: Math.random() * 2 * Math.PI,
        contributingIntelligences: mockIntelligences.slice(0, i + 2).map(intel => intel.id),
      })),
    });

    // Generate mock trust analysis
    setTrustAnalysis({
      overallStability: 0.85,
      strongestRelationships: [],
      weakestRelationships: [],
      evolutionRate: 0.05,
      convergencePotential: 0.9,
      trustClusters: [presetIntelligences],
    });

    // Generate mock messages
    const mockMessages: ResonanceMessage[] = Array.from({ length: 8 }, (_, i) => ({
      id: `msg_${i}`,
      conversationId: 'demo_conv',
      senderId: mockIntelligences[i % mockIntelligences.length]?.id || 'unknown',
      content: generateMockMessage(i, mockIntelligences),
      resonanceField: {},
      trustContext: {
        matrix: [],
        relationships: [],
        evolutionRate: 0.1,
        stabilityIndex: 0.8,
      },
      convergencePath: mockIntelligences.slice(0, Math.min(3, mockIntelligences.length)),
      timestamp: new Date(Date.now() - (8 - i) * 60000),
      metadata: {
        processingTime: 100 + Math.random() * 200,
        resonanceScore: 0.7 + Math.random() * 0.3,
        convergenceDepth: Math.floor(Math.random() * 4) + 1,
        intelligenceTypes: ['hybrid', 'ai', 'human'],
      },
    }));

    setRecentMessages(mockMessages);

    // Generate mock routing history
    const mockRouting: RoutingDecision[] = Array.from({ length: 5 }, (_, i) => ({
      primaryRecipients: mockIntelligences.slice(0, 2).map(intel => intel.id),
      secondaryRecipients: mockIntelligences.slice(2, 4).map(intel => intel.id),
      routingPath: mockIntelligences.slice(0, 3),
      confidence: 0.8 + Math.random() * 0.2,
      reasoning: [
        'High trust affinity detected',
        'Capability match with content creation requirements',
        'Previous successful collaboration history',
      ],
      convergenceScore: 0.85 + Math.random() * 0.15,
      expectedLatency: 150,
    }));

    setRoutingHistory(mockRouting);

    // Set conversation ID
    setActiveConversation(`resonance_demo_${selectedPreset}_${Date.now()}`);
  };

  const generateMockMessage = (index: number, intelligences: IntelligenceEntity[]): string => {
    const messages = [
      "I've analyzed the content structure and identified key optimization opportunities for better engagement.",
      "The UI design looks great! I've added some accessibility improvements and performance optimizations.",
      "Security scan complete. Found 2 low-priority vulnerabilities that should be addressed in the next sprint.",
      "Performance analysis shows 40% improvement potential through bundle optimization and lazy loading.",
      "Based on user behavior data, I recommend adjusting the content strategy to focus more on interactive elements.",
      "Code review complete. The implementation follows best practices with room for some architectural improvements.",
      "SEO analysis indicates strong keyword opportunities in the technical documentation section.",
      "User experience testing revealed some friction points in the onboarding flow that we should address.",
    ];

    return messages[index % messages.length];
  };

  const handlePresetChange = (preset: string) => {
    setSelectedPreset(preset);
  };

  const handleCustomTaskAnalysis = () => {
    if (!customTask.trim()) return;

    const detected = detectDomainTaskType(customTask);
    setDetectedDomain(detected);

    const recommendedIntelligences = getDomainIntelligenceForTask(customTask);
    const mockIntelligences: IntelligenceEntity[] = recommendedIntelligences.map(id => {
      const template = ALL_DOMAIN_INTELLIGENCES.find(intel => intel.id === id);
      return {
        ...template!,
        coordinates: Array.from({ length: 3333 }, () => (Math.random() - 0.5) * 2),
        convergenceStrength: 0.7 + Math.random() * 0.3,
      };
    });

    setIntelligences(mockIntelligences);
    setActiveConversation(`custom_task_${Date.now()}`);
  };

  const handleDomainChange = (domain: string) => {
    setSelectedDomain(domain);
    const domainPreset = DOMAIN_WORKFLOW_PRESETS[domain as keyof typeof DOMAIN_WORKFLOW_PRESETS];
    if (domainPreset) {
      const mockIntelligences: IntelligenceEntity[] = domainPreset.intelligences.map(id => {
        const template = ALL_DOMAIN_INTELLIGENCES.find(intel => intel.id === id);
        return {
          ...template!,
          coordinates: Array.from({ length: 3333 }, () => (Math.random() - 0.5) * 2),
          convergenceStrength: 0.7 + Math.random() * 0.3,
        };
      });
      setIntelligences(mockIntelligences);
      setActiveConversation(`domain_demo_${domain}_${Date.now()}`);
    }
  };

  const startDemoConversation = async () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      generateDemoData();
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-4">
            🌟 Resonance Messaging Demo
          </h1>
          <p className="text-xl text-purple-200 mb-2">
            Experience 3333D Intelligence Convergence in Action
          </p>
          <p className="text-lg text-purple-300 max-w-4xl mx-auto">
            Watch as specialized AI intelligences collaborate through harmonic resonance fields,
            dynamically routing messages based on trust relationships and capability complementarity.
          </p>
        </div>

        {/* Control Panel */}
        <div className="bg-black/30 rounded-xl p-6 mb-8">
          <div className="grid md:grid-cols-3 gap-6">
            {/* CMS Workflow Selection */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">CMS Workflows</h3>
              <div className="grid grid-cols-1 gap-3">
                {Object.entries(REVEALUI_WORKFLOW_PRESETS).map(([key, intelligences]) => (
                  <button
                    key={key}
                    onClick={() => handlePresetChange(key)}
                    className={`p-3 rounded-lg text-left transition-all ${
                      selectedPreset === key
                        ? 'bg-blue-600 text-white'
                        : 'bg-blue-900/50 text-blue-200 hover:bg-blue-800/50'
                    }`}
                  >
                    <div className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1')}</div>
                    <div className="text-sm opacity-75">{intelligences.length} intelligences</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Domain Specialist Selection */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Domain Specialists</h3>
              <div className="grid grid-cols-1 gap-3">
                {Object.entries(DOMAIN_WORKFLOW_PRESETS).map(([key, preset]) => (
                  <button
                    key={key}
                    onClick={() => handleDomainChange(key)}
                    className={`p-3 rounded-lg text-left transition-all ${
                      selectedDomain === key
                        ? 'bg-green-600 text-white'
                        : 'bg-green-900/50 text-green-200 hover:bg-green-800/50'
                    }`}
                  >
                    <div className="font-medium">{preset.name}</div>
                    <div className="text-sm opacity-75">{preset.intelligences.length} specialists</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Task Analysis */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">AI Task Analysis</h3>
              <div className="space-y-3">
                <textarea
                  value={customTask}
                  onChange={(e) => setCustomTask(e.target.value)}
                  placeholder="Describe any task and watch AI automatically select the right specialists..."
                  className="w-full p-3 bg-black/50 border border-purple-500/30 rounded-lg text-white placeholder-purple-400 focus:border-purple-400 focus:outline-none"
                  rows={4}
                />
                {detectedDomain !== 'general' && (
                  <div className="text-sm text-purple-300">
                    Detected domain: <span className="font-medium capitalize">{detectedDomain}</span>
                  </div>
                )}
                <button
                  onClick={handleCustomTaskAnalysis}
                  className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors"
                >
                  🚀 Analyze & Select AI Specialists
                </button>
              </div>
            </div>
          </div>

          {/* Start Demo Button */}
          <div className="mt-6 text-center">
            <button
              onClick={startDemoConversation}
              disabled={isLoading}
              className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 px-8 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all disabled:opacity-50"
            >
              {isLoading ? '🌟 Initializing Resonance Field...' : '🚀 Start Resonance Conversation'}
            </button>
          </div>
        </div>

        {/* Main Demo Interface */}
        {activeConversation && intelligences.length > 0 ? (
          <div className="bg-black/20 rounded-xl p-6">
            <ConvergenceSpaceDashboard
              conversationId={activeConversation}
              intelligences={intelligences}
              resonanceField={resonanceField}
              trustAnalysis={trustAnalysis!}
              recentMessages={recentMessages}
              routingHistory={routingHistory}
              convergenceMetrics={convergenceMetrics}
              onIntelligenceSelect={(intelligence) => {
                console.log('Selected intelligence:', intelligence);
              }}
            />
          </div>
        ) : (
          <div className="bg-black/20 rounded-xl p-12 text-center">
            <div className="text-6xl mb-4">🌟</div>
            <h3 className="text-2xl font-bold text-white mb-4">Ready to Experience Resonance?</h3>
            <p className="text-purple-200 mb-6 max-w-2xl mx-auto">
              Select a workflow preset above or describe a custom task to see how multiple AI intelligences
              collaborate through dynamic resonance fields, trust-based routing, and harmonic convergence.
            </p>
            <div className="grid md:grid-cols-4 gap-4 max-w-5xl mx-auto">
              <div className="bg-purple-900/30 rounded-lg p-4">
                <div className="text-2xl mb-2">🧬</div>
                <div className="text-white font-semibold">Multi-Intelligence</div>
                <div className="text-purple-300 text-sm">30+ specialized AI entities</div>
              </div>
              <div className="bg-blue-900/30 rounded-lg p-4">
                <div className="text-2xl mb-2">🌊</div>
                <div className="text-blue-300 font-semibold">Resonance Fields</div>
                <div className="text-blue-400 text-sm">3333D convergence spaces</div>
              </div>
              <div className="bg-green-900/30 rounded-lg p-4">
                <div className="text-2xl mb-2">🤝</div>
                <div className="text-green-300 font-semibold">Trust Dynamics</div>
                <div className="text-green-400 text-sm">Evolving relationships</div>
              </div>
              <div className="bg-orange-900/30 rounded-lg p-4">
                <div className="text-2xl mb-2">🎯</div>
                <div className="text-orange-300 font-semibold">Domain Specialists</div>
                <div className="text-orange-400 text-sm">Healthcare, Finance, Research, Legal</div>
              </div>
            </div>

            {/* Domain Showcase */}
            <div className="mt-8 grid md:grid-cols-6 gap-3 max-w-6xl mx-auto">
              {[
                { domain: 'Healthcare', count: 5, icon: '🏥' },
                { domain: 'Finance', count: 5, icon: '💰' },
                { domain: 'Research', count: 5, icon: '🔬' },
                { domain: 'Creative', count: 5, icon: '🎨' },
                { domain: 'Education', count: 5, icon: '📚' },
                { domain: 'Legal', count: 5, icon: '⚖️' },
              ].map(({ domain, count, icon }) => (
                <div key={domain} className="bg-black/20 rounded-lg p-3 text-center">
                  <div className="text-2xl mb-1">{icon}</div>
                  <div className="text-white font-medium text-sm">{domain}</div>
                  <div className="text-purple-300 text-xs">{count} specialists</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer Info */}
        <div className="mt-12 text-center text-purple-300">
          <p className="mb-2">
            This demo showcases the Resonance Field Algorithm in action, where traditional messaging
            becomes intelligent convergence.
          </p>
          <p className="text-sm opacity-75">
            Built with the mathematical foundation for the next era of AI collaboration 🌟
          </p>
        </div>
      </div>
    </div>
  );
}