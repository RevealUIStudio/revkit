/**
 * Base Components Showcase
 * Interactive gallery of essential everyday components
 */

'use client';

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Input } from '@/presentation/components/ui/primitives/input';
import { Badge } from '@/presentation/components/ui/server/badge';
import Link from 'next/link';
import { useState } from 'react';

export default function BaseComponentsShowcase() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('buttons');

  const copyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className='min-h-screen bg-gray-50'>
      {/* Header */}
      <div className='bg-white border-b sticky top-0 z-10'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6'>
          <Link
            href='/showcase'
            className='text-brand-red-600 hover:text-brand-red-700 mb-2 inline-block'
          >
            ← Back to Showcase
          </Link>
          <h1 className='text-4xl font-bold'>Base Components</h1>
          <p className='text-gray-600 mt-2'>
            Essential everyday components (Button, Input, Card, Form)
          </p>
        </div>
      </div>

      {/* Content */}
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16'>
        {/* Navigation Tabs */}
        <div className='flex gap-2 mb-8 overflow-x-auto'>
          {['buttons', 'inputs', 'cards', 'badges'].map(tab => (
            <button
              type='button'
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-brand-red-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Button Section */}
        {activeTab === 'buttons' && (
          <div className='space-y-8'>
            <Card>
              <CardHeader>
                <CardTitle>Button Variants</CardTitle>
                <CardDescription>
                  8 variants for different use cases - primary for main actions, secondary for
                  supporting actions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className='space-y-6'>
                  {/* Variant Row */}
                  <div>
                    <h4 className='font-semibold mb-3'>Variants</h4>
                    <div className='flex flex-wrap gap-3'>
                      <Button variant='primary'>Primary</Button>
                      <Button variant='secondary'>Secondary</Button>
                      <Button variant='accent'>Accent</Button>
                      <Button variant='professional'>Professional</Button>
                      <Button variant='destructive'>Destructive</Button>
                      <Button variant='outline'>Outline</Button>
                      <Button variant='ghost'>Ghost</Button>
                      <Button variant='link'>Link</Button>
                    </div>
                  </div>

                  {/* Size Row */}
                  <div>
                    <h4 className='font-semibold mb-3'>Sizes</h4>
                    <div className='flex flex-wrap items-center gap-3'>
                      <Button variant='primary' size='sm'>
                        Small
                      </Button>
                      <Button variant='primary' size='default'>
                        Default
                      </Button>
                      <Button variant='primary' size='lg'>
                        Large
                      </Button>
                      <Button variant='primary' size='xl'>
                        Extra Large
                      </Button>
                    </div>
                  </div>

                  {/* States */}
                  <div>
                    <h4 className='font-semibold mb-3'>States</h4>
                    <div className='flex flex-wrap gap-3'>
                      <Button variant='primary'>Default</Button>
                      <Button variant='primary' disabled>
                        Disabled
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className='flex-col items-start gap-4'>
                <div className='w-full'>
                  <p className='text-sm font-medium mb-2'>Code Example</p>
                  <div className='bg-gray-900 text-gray-100 p-4 rounded-lg relative'>
                    <pre className='text-sm overflow-x-auto'>
                      {`<Button variant="primary" size="lg">
  Start Free Trial
</Button>`}
                    </pre>
                    <button
                      type='button'
                      onClick={() =>
                        copyCode(
                          'button',
                          '<Button variant="primary" size="lg">Start Free Trial</Button>'
                        )
                      }
                      className='absolute top-2 right-2 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs'
                    >
                      {copiedCode === 'button' ? '✓ Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-4 w-full text-sm'>
                  <div>
                    <p className='font-medium mb-1'>Use Cases:</p>
                    <ul className='list-disc list-inside text-gray-600 space-y-1'>
                      <li>Primary CTAs (variant="primary")</li>
                      <li>Form submissions</li>
                      <li>Page actions</li>
                    </ul>
                  </div>
                  <div>
                    <p className='font-medium mb-1'>Best Practices:</p>
                    <ul className='list-disc list-inside text-gray-600 space-y-1'>
                      <li>Use primary for main action</li>
                      <li>Use lg or xl size for hero CTAs</li>
                      <li>Keep button text short</li>
                    </ul>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        )}

        {/* Input Section */}
        {activeTab === 'inputs' && (
          <div className='space-y-8'>
            <Card>
              <CardHeader>
                <CardTitle>Input Fields</CardTitle>
                <CardDescription>
                  Text entry fields with labels, validation, and multiple types
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className='space-y-6 max-w-md'>
                  <Input label='Full Name' placeholder='John Doe' />
                  <Input label='Email Address' type='email' placeholder='john@example.com' />
                  <Input label='Password' type='password' placeholder='••••••••' />
                  <Input
                    label='Username'
                    placeholder='Choose a username'
                    description='Must be unique and at least 3 characters'
                  />
                  <Input label='Required Field' required placeholder='This field is required' />
                </div>
              </CardContent>
              <CardFooter className='flex-col items-start gap-4'>
                <div className='w-full'>
                  <p className='text-sm font-medium mb-2'>Code Example</p>
                  <div className='bg-gray-900 text-gray-100 p-4 rounded-lg relative'>
                    <pre className='text-sm overflow-x-auto'>
                      {`<Input
  label="Email Address"
  type="email"
  placeholder="you@example.com"
  required
/>`}
                    </pre>
                    <button
                      type='button'
                      onClick={() =>
                        copyCode(
                          'input',
                          '<Input label="Email Address" type="email" placeholder="you@example.com" required />'
                        )
                      }
                      className='absolute top-2 right-2 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs'
                    >
                      {copiedCode === 'input' ? '✓ Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-4 w-full text-sm'>
                  <div>
                    <p className='font-medium mb-1'>Use Cases:</p>
                    <ul className='list-disc list-inside text-gray-600 space-y-1'>
                      <li>Contact forms</li>
                      <li>Login/signup forms</li>
                      <li>Search bars</li>
                      <li>Settings pages</li>
                    </ul>
                  </div>
                  <div>
                    <p className='font-medium mb-1'>Input Types:</p>
                    <ul className='list-disc list-inside text-gray-600 space-y-1'>
                      <li>text, email, password</li>
                      <li>number, tel, url</li>
                      <li>date, time, datetime-local</li>
                      <li>search</li>
                    </ul>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        )}

        {/* Card Section */}
        {activeTab === 'cards' && (
          <div className='space-y-8'>
            <Card>
              <CardHeader>
                <CardTitle>Card Components</CardTitle>
                <CardDescription>
                  Content containers with multiple variants and styles
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'>
                  <Card>
                    <CardHeader>
                      <CardTitle>Default Card</CardTitle>
                      <CardDescription>Standard white card</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Perfect for most content containers.</p>
                    </CardContent>
                    <CardFooter>
                      <Button variant='link'>Learn More →</Button>
                    </CardFooter>
                  </Card>

                  <Card variant='elevated'>
                    <CardHeader>
                      <CardTitle>Elevated Card</CardTitle>
                      <CardDescription>With shadow effect</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Great for feature showcases.</p>
                    </CardContent>
                    <CardFooter>
                      <Button variant='link'>Learn More →</Button>
                    </CardFooter>
                  </Card>

                  <Card variant='bordered'>
                    <CardHeader>
                      <CardTitle>Primary Card</CardTitle>
                      <CardDescription>Combat Red themed</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Use for brand-focused content.</p>
                    </CardContent>
                    <CardFooter>
                      <Button variant='link'>Learn More →</Button>
                    </CardFooter>
                  </Card>

                  <Card variant='flat'>
                    <CardHeader>
                      <CardTitle>Secondary Card</CardTitle>
                      <CardDescription>Fight Orange themed</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Energetic content sections.</p>
                    </CardContent>
                  </Card>

                  <Card variant='default'>
                    <CardHeader>
                      <CardTitle>Accent Card</CardTitle>
                      <CardDescription>Victory Gold themed</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Premium/VIP content.</p>
                    </CardContent>
                  </Card>

                  <Card variant='interactive'>
                    <CardHeader>
                      <CardTitle>Professional Card</CardTitle>
                      <CardDescription>Deep Blue themed</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className='text-gray-600'>Enterprise/B2B content.</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
              <CardFooter className='flex-col items-start gap-4'>
                <div className='w-full'>
                  <p className='text-sm font-medium mb-2'>Code Example</p>
                  <div className='bg-gray-900 text-gray-100 p-4 rounded-lg relative'>
                    <pre className='text-sm overflow-x-auto'>
                      {`<Card variant="elevated">
  <CardHeader>
    <CardTitle>Feature Title</CardTitle>
    <CardDescription>Brief description</CardDescription>
  </CardHeader>
  <CardContent>
    <p>Main content here...</p>
  </CardContent>
  <CardFooter>
    <Button variant="primary">Action</Button>
  </CardFooter>
</Card>`}
                    </pre>
                    <button
                      type='button'
                      onClick={() => copyCode('card', '<Card variant="elevated">...')}
                      className='absolute top-2 right-2 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs'
                    >
                      {copiedCode === 'card' ? '✓ Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        )}

        {/* Badge Section */}
        {activeTab === 'badges' && (
          <div className='space-y-8'>
            <Card>
              <CardHeader>
                <CardTitle>Badges</CardTitle>
                <CardDescription>Small labels for status, tags, and categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className='space-y-6'>
                  <div>
                    <h4 className='font-semibold mb-3'>Variants</h4>
                    <div className='flex flex-wrap gap-3'>
                      <Badge>Default</Badge>
                      <Badge variant='primary'>Primary</Badge>
                      <Badge variant='secondary'>Secondary</Badge>
                      <Badge variant='success'>Success</Badge>
                      <Badge variant='warning'>Warning</Badge>
                      <Badge variant='error'>Error</Badge>
                    </div>
                  </div>

                  <div>
                    <h4 className='font-semibold mb-3'>Real World Examples</h4>
                    <div className='space-y-4'>
                      <div className='flex items-center gap-2'>
                        <span className='text-gray-700'>Product status:</span>
                        <Badge variant='primary'>New</Badge>
                        <Badge variant='warning'>Sale</Badge>
                        <Badge variant='success'>In Stock</Badge>
                      </div>
                      <div className='flex items-center gap-2'>
                        <span className='text-gray-700'>Pricing tier:</span>
                        <Badge variant='warning'>Most Popular</Badge>
                        <Badge variant='primary'>Best Value</Badge>
                      </div>
                      <div className='flex items-center gap-2'>
                        <span className='text-gray-700'>User status:</span>
                        <Badge variant='success'>Active</Badge>
                        <Badge variant='error'>Suspended</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className='flex-col items-start gap-4'>
                <div className='w-full'>
                  <p className='text-sm font-medium mb-2'>Code Example</p>
                  <div className='bg-gray-900 text-gray-100 p-4 rounded-lg relative'>
                    <pre className='text-sm overflow-x-auto'>
                      {`<Badge variant="primary">New</Badge>
<Badge variant="warning">Most Popular</Badge>`}
                    </pre>
                    <button
                      type='button'
                      onClick={() => copyCode('badge', '<Badge variant="primary">New</Badge>')}
                      className='absolute top-2 right-2 px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs'
                    >
                      {copiedCode === 'badge' ? '✓ Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        )}

        {/* Navigation */}
        <div className='mt-12 flex justify-between'>
          <Button variant='outline' asChild>
            <Link href='/showcase'>← Back to Showcase</Link>
          </Button>
          <Button variant='primary' asChild>
            <Link href='/showcase/advanced'>View Advanced Components →</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
