'use client';

import React, { Suspense } from 'react';
import dynamic from 'next/dynamic';

// Dynamically import the RFA demo to avoid SSR issues
const RFADemo = dynamic(() => import('@/components/rfa/RFADemo'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center min-h-[600px]">
      <div className="text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-400 mx-auto mb-4"></div>
        <p className="text-white text-xl">Initializing Enhanced Resonance Field Algorithm...</p>
        <p className="text-blue-300 text-sm mt-2">Loading vacuum correlations and geometric validations...</p>
      </div>
    </div>
  )
});

export default function RFADemoPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            🌟 Enhanced Resonance Field Algorithm
          </h1>
          <p className="text-xl text-blue-200 mb-2">
            Physics-Grounded Intelligence Convergence in 3333D Spaces
          </p>
          <p className="text-lg text-blue-300 max-w-4xl mx-auto">
            Experience the next evolution of collaborative intelligence, powered by vacuum fluctuations,
            Hawking thermodynamics, and geometric confinement from fundamental physics.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-4 text-sm">
            <span className="bg-blue-500/20 text-blue-200 px-3 py-1 rounded-full">
              🧲 Vacuum Correlations
            </span>
            <span className="bg-purple-500/20 text-purple-200 px-3 py-1 rounded-full">
              🌡️ Hawking Validation
            </span>
            <span className="bg-pink-500/20 text-pink-200 px-3 py-1 rounded-full">
              📐 Geometric Confinement
            </span>
            <span className="bg-green-500/20 text-green-200 px-3 py-1 rounded-full">
              🔄 Multi-Scale Screening
            </span>
            <span className="bg-orange-500/20 text-orange-200 px-3 py-1 rounded-full">
              🌌 3D Visualization
            </span>
            <span className="bg-teal-500/20 text-teal-200 px-3 py-1 rounded-full">
              📡 Real-time Streaming
            </span>
          </div>
        </div>

        {/* Main Demo */}
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-white text-xl">Loading Enhanced RFA Demo...</div>
          </div>
        }>
          <RFADemo />
        </Suspense>

        {/* Footer Info */}
        <div className="mt-12 text-center">
          <div className="bg-black/20 backdrop-blur-sm rounded-xl p-6 max-w-4xl mx-auto">
            <h3 className="text-xl font-bold text-white mb-4">🔬 Technical Foundation</h3>
            <div className="grid md:grid-cols-2 gap-6 text-left">
              <div>
                <h4 className="text-blue-300 font-semibold mb-2">📚 Based on Research</h4>
                <p className="text-blue-200 text-sm">
                  "Extending Einstein-Rosen's Geometric Vision: Vacuum Fluctuations-Induced Curvature
                  as the Source of Mass, Gravity and Nuclear Confinement" by Haramein et al.
                </p>
              </div>
              <div>
                <h4 className="text-purple-300 font-semibold mb-2">🎯 Algorithm Features</h4>
                <ul className="text-purple-200 text-sm space-y-1">
                  <li>• Vacuum fluctuation correlation functions</li>
                  <li>• Hierarchical screening mechanisms</li>
                  <li>• Hawking temperature validation</li>
                  <li>• Klein-Gordon geometric confinement</li>
                  <li>• Multi-phase field evolution</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}