/**
 * Component Showcase - Main Landing Page
 * Custom lightweight component gallery (replaces Storybook)
 */

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import Link from 'next/link';

export const metadata = {
  title: 'Component Showcase | RevealUI',
  description: 'Interactive component gallery for marketing and design teams',
};

export default function ShowcasePage() {
  const sections = [
    {
      title: 'Base Components',
      href: '/showcase/base',
      description: 'Essential everyday components (Button, Input, Card, Form)',
      icon: '🧱',
      count: '7 components',
      color: 'from-brand-red-500 to-brand-red-600',
    },
    {
      title: 'Advanced Components',
      href: '/showcase/advanced',
      description: 'Complex features (Table, Layouts, Navigation, Advanced Selection)',
      icon: '⚡',
      count: '8 components',
      color: 'from-brand-orange-500 to-brand-orange-600',
    },
    {
      title: 'Brand Colors',
      href: '/showcase/colors',
      description: 'Interactive color palette with all brand colors and shades',
      icon: '🎨',
      count: '66 colors',
      color: 'from-brand-gold-500 to-brand-gold-600',
    },
    {
      title: 'Typography',
      href: '/showcase/typography',
      description: 'Font system, sizes, weights, and text styles',
      icon: '✍️',
      count: 'Complete system',
      color: 'from-brand-blue-700 to-brand-blue-900',
    },
    {
      title: 'Page Layouts',
      href: '/showcase/layouts',
      description: 'Common page templates and layout patterns',
      icon: '📐',
      count: '9 templates',
      color: 'from-gray-700 to-gray-900',
    },
  ];

  return (
    <div className='min-h-screen bg-gray-50'>
      {/* Hero */}
      <div className='bg-linear-to-br from-brand-red-600 to-brand-orange-500 text-white py-20'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8'>
          <h1 className='text-5xl font-bold mb-4'>Component Showcase</h1>
          <p className='text-2xl mb-8 opacity-90'>
            Interactive component gallery for marketing and design teams
          </p>
          <div className='flex gap-4'>
            <Button variant='accent' size='lg' asChild>
              <Link href='/showcase/base'>Explore Components</Link>
            </Button>
            <Button
              variant='outline'
              size='lg'
              asChild
              className='text-white border-white hover:bg-white/10'
            >
              <Link href='/docs/design-system/MARKETING_DESIGN_GUIDE.md'>Read Docs</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16'>
        {/* Stats */}
        <div className='grid grid-cols-1 md:grid-cols-4 gap-6 mb-16'>
          <Card>
            <CardContent className='pt-6'>
              <div className='text-4xl font-bold text-brand-red-600 mb-2'>44</div>
              <p className='text-gray-600'>Total Components</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className='pt-6'>
              <div className='text-4xl font-bold text-brand-orange-600 mb-2'>200+</div>
              <p className='text-gray-600'>Component Variants</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className='pt-6'>
              <div className='text-4xl font-bold text-brand-gold-600 mb-2'>66</div>
              <p className='text-gray-600'>Brand Colors</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className='pt-6'>
              <div className='text-4xl font-bold text-brand-blue-900 mb-2'>100%</div>
              <p className='text-gray-600'>Accessible</p>
            </CardContent>
          </Card>
        </div>

        {/* Sections */}
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'>
          {sections.map(section => (
            <Link key={section.href} href={section.href}>
              <Card className='h-full hover:shadow-lg transition-shadow cursor-pointer'>
                <CardHeader>
                  <div
                    className={`w-16 h-16 rounded-lg bg-gradient-to-br ${section.color} flex items-center justify-center text-3xl mb-4`}
                  >
                    {section.icon}
                  </div>
                  <CardTitle className='text-2xl'>{section.title}</CardTitle>
                  <CardDescription className='text-base'>{section.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className='text-sm text-gray-500'>{section.count}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Features */}
        <div className='mt-20'>
          <h2 className='text-3xl font-bold text-center mb-12'>Why Use Our Showcase?</h2>
          <div className='grid grid-cols-1 md:grid-cols-3 gap-8'>
            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>⚡</div>
                <CardTitle>Lightning Fast</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  No bloat, no external dependencies. Pure Next.js pages with instant load times.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>🎯</div>
                <CardTitle>Purpose-Built</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  Designed specifically for marketing and design teams, not developers.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>📱</div>
                <CardTitle>Mobile Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  Toggle mobile view to see how components look on all devices.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>📋</div>
                <CardTitle>Copy Code</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  Copy-paste ready code examples for every component and variant.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>🎨</div>
                <CardTitle>Interactive</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  Test variants, sizes, and colors live. See changes instantly.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className='text-4xl mb-2'>🌙</div>
                <CardTitle>Dark Mode</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-gray-600'>
                  Toggle dark mode to see how components look in both themes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className='mt-20 text-center bg-gray-100 rounded-lg py-16 px-8'>
          <h2 className='text-3xl font-bold mb-4'>Ready to Build?</h2>
          <p className='text-xl text-gray-600 mb-8'>
            Start with our pre-built components and ship campaigns 15x faster
          </p>
          <div className='flex gap-4 justify-center'>
            <Button variant='primary' size='lg' asChild>
              <Link href='/showcase/base'>Browse Components</Link>
            </Button>
            <Button variant='secondary' size='lg' asChild>
              <Link href='/showcase/colors'>Explore Colors</Link>
            </Button>
          </div>
        </div>

        {/* Documentation Links */}
        <div className='mt-16'>
          <h3 className='text-2xl font-bold mb-6'>Documentation</h3>
          <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
            <Card>
              <CardHeader>
                <CardTitle>Marketing Design Guide</CardTitle>
                <CardDescription>Quick reference for daily use</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant='link' asChild>
                  <a href='/docs/design-system/MARKETING_DESIGN_GUIDE.md'>Read Guide →</a>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Brand Component Library</CardTitle>
                <CardDescription>Complete component catalog</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant='link' asChild>
                  <a href='/docs/design-system/BRAND_COMPONENT_LIBRARY.md'>View Library →</a>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Brand Colors Reference</CardTitle>
                <CardDescription>All colors with usage guidelines</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant='link' asChild>
                  <a href='/docs/design-system/BRAND_COLORS_REFERENCE.md'>View Colors →</a>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Page Templates</CardTitle>
                <CardDescription>Common marketing layouts</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant='link' asChild>
                  <a href='/docs/design-system/PAGE_TEMPLATES.md'>View Templates →</a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className='bg-gray-900 text-white py-12 mt-20'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center'>
          <p className='text-gray-400'>Custom component showcase built specifically for RevealUI</p>
          <p className='text-sm text-gray-500 mt-2'>
            No Storybook bloat • Zero external dependencies • Lightweight & Fast
          </p>
        </div>
      </div>
    </div>
  );
}
