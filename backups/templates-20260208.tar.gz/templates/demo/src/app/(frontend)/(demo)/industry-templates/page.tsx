import { IndustryTemplateDisplay } from '@/presentation/components/ui/client/IndustryTemplateDisplay';
import { IndustryTemplateProvider } from '@/presentation/components/ui/client/IndustryTemplateProvider';
import { IndustryTemplateTester } from '@/presentation/components/ui/client/IndustryTemplateTester';

export default function IndustryTemplatesPage() {
  return (
    <div className='min-h-screen bg-gray-50 py-8'>
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8'>
        <div className='text-center mb-12'>
          <h1 className='text-4xl font-bold text-gray-900 mb-4'>Industry Templates</h1>
          <p className='text-xl text-gray-600 max-w-3xl mx-auto'>
            Explore industry-specific configurations and workflows designed to streamline your
            business operations. Each template provides customized terminology, color schemes, and
            workflow configurations.
          </p>
        </div>

        {/* Template Tester Section */}
        <div className='mb-16 bg-white rounded-lg shadow-lg p-8'>
          <h2 className='text-3xl font-bold text-gray-900 mb-6 text-center'>
            Template Customization Tool
          </h2>
          <p className='text-gray-600 text-center mb-8 max-w-2xl mx-auto'>
            Use the IndustryTemplateTester to customize your industry template in real-time. Modify
            terminology, colors, workflows, and integrations to match your specific business needs.
          </p>

          <div className='grid grid-cols-1 lg:grid-cols-2 gap-8'>
            {/* Technology & Software Template Tester */}
            <div>
              <h3 className='text-xl font-semibold text-gray-900 mb-4'>Technology & Software</h3>
              <IndustryTemplateProvider industry='technology-software'>
                <IndustryTemplateTester className='max-h-96 overflow-y-auto' />
              </IndustryTemplateProvider>
            </div>

            {/* Fitness & Martial Arts Template Tester */}
            <div>
              <h3 className='text-xl font-semibold text-gray-900 mb-4'>Fitness & Martial Arts</h3>
              <IndustryTemplateProvider industry='fitness-martial-arts'>
                <IndustryTemplateTester className='max-h-96 overflow-y-auto' />
              </IndustryTemplateProvider>
            </div>
          </div>
        </div>

        <div className='grid grid-cols-1 lg:grid-cols-2 gap-8'>
          {/* Fitness & Martial Arts Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='bg-red-600 p-6 text-white'>
              <h2 className='text-2xl font-bold'>Fitness & Martial Arts</h2>
              <p className='text-red-100 mt-2'>Optimized for gyms, dojos, and fitness centers</p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='fitness-martial-arts'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>

          {/* Healthcare & Medical Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='bg-green-600 p-6 text-white'>
              <h2 className='text-2xl font-bold'>Healthcare & Medical</h2>
              <p className='text-green-100 mt-2'>
                Designed for clinics, hospitals, and medical practices
              </p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='healthcare-medical'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>

          {/* Technology & Software Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='bg-blue-600 p-6 text-white'>
              <h2 className='text-2xl font-bold'>Technology & Software</h2>
              <p className='text-blue-100 mt-2'>Tailored for SaaS companies and tech startups</p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='technology-software'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>

          {/* E-commerce & Retail Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='bg-purple-600 p-6 text-white'>
              <h2 className='text-2xl font-bold'>E-commerce & Retail</h2>
              <p className='text-purple-100 mt-2'>Built for online stores and retail businesses</p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='ecommerce-retail'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>

          {/* Education & Training Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='card-branded'>
              <h2 className='text-2xl font-bold'>Education & Training</h2>
              <p className='opacity-90 mt-2'>
                Perfect for schools, training centers, and online learning
              </p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='education-training'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>

          {/* Creative & Design Template */}
          <div className='bg-white rounded-lg shadow-lg overflow-hidden'>
            <div className='bg-pink-600 p-6 text-white'>
              <h2 className='text-2xl font-bold'>Creative & Design</h2>
              <p className='text-pink-100 mt-2'>
                Crafted for design agencies and creative professionals
              </p>
            </div>
            <div className='p-6'>
              <IndustryTemplateProvider industry='creative-design'>
                <IndustryTemplateDisplay showWorkflows={true} showIntegrations={true} />
              </IndustryTemplateProvider>
            </div>
          </div>
        </div>

        {/* Template Comparison */}
        <div className='mt-16 bg-white rounded-lg shadow-lg p-8'>
          <h2 className='text-3xl font-bold text-gray-900 mb-8 text-center'>Template Comparison</h2>

          <div className='overflow-x-auto'>
            <table className='min-w-full divide-y divide-gray-200'>
              <thead className='bg-gray-50'>
                <tr>
                  <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                    Feature
                  </th>
                  <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                    Fitness & Martial Arts
                  </th>
                  <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                    Healthcare & Medical
                  </th>
                  <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                    Technology & Software
                  </th>
                  <th className='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>
                    E-commerce & Retail
                  </th>
                </tr>
              </thead>
              <tbody className='bg-white divide-y divide-gray-200'>
                <tr>
                  <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                    Users
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Students</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Patients</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Users</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Customers</td>
                </tr>
                <tr>
                  <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                    Products
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Classes</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Services</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Software</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Products</td>
                </tr>
                <tr>
                  <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                    Events
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Sessions</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                    Appointments
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Updates</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Promotions</td>
                </tr>
                <tr>
                  <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                    Revenue
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Enrollments</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Billings</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Licenses</td>
                  <td className='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>Sales</td>
                </tr>
                <tr>
                  <td className='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>
                    Primary Color
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap'>
                    <div className='flex items-center gap-2'>
                      <div className='w-4 h-4 bg-red-600 rounded' />
                      <span className='text-sm text-gray-500'>#DC2626</span>
                    </div>
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap'>
                    <div className='flex items-center gap-2'>
                      <div className='w-4 h-4 bg-green-600 rounded' />
                      <span className='text-sm text-gray-500'>#059669</span>
                    </div>
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap'>
                    <div className='flex items-center gap-2'>
                      <div className='w-4 h-4 bg-blue-600 rounded' />
                      <span className='text-sm text-gray-500'>#3B82F6</span>
                    </div>
                  </td>
                  <td className='px-6 py-4 whitespace-nowrap'>
                    <div className='flex items-center gap-2'>
                      <div className='w-4 h-4 bg-red-600 rounded' />
                      <span className='text-sm text-gray-500'>#DC2626</span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* How to Use */}
        <div className='mt-16 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-8'>
          <h2 className='text-3xl font-bold text-gray-900 mb-6 text-center'>
            How to Use Industry Templates
          </h2>

          <div className='grid grid-cols-1 md:grid-cols-3 gap-6'>
            <div className='text-center'>
              <div className='w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4'>
                <span className='text-2xl font-bold text-blue-600'>1</span>
              </div>
              <h3 className='text-lg font-semibold text-gray-900 mb-2'>Choose Your Industry</h3>
              <p className='text-gray-600'>
                Select the industry template that best matches your business type and requirements.
              </p>
            </div>

            <div className='text-center'>
              <div className='w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4'>
                <span className='text-2xl font-bold text-blue-600'>2</span>
              </div>
              <h3 className='text-lg font-semibold text-gray-900 mb-2'>Customize Settings</h3>
              <p className='text-gray-600'>
                Use the IndustryTemplateTester to modify terminology, colors, workflows, and
                integrations in real-time.
              </p>
            </div>

            <div className='text-center'>
              <div className='w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4'>
                <span className='text-2xl font-bold text-blue-600'>3</span>
              </div>
              <h3 className='text-lg font-semibold text-gray-900 mb-2'>Apply to Your App</h3>
              <p className='text-gray-600'>
                Use the template configuration to automatically style and configure your
                application.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
