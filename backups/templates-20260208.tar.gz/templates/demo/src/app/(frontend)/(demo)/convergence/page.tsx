import { Suspense } from 'react';
import { ConvergenceSpacePrototype } from '@/components/convergence/ConvergenceSpacePrototype';

export default function ConvergencePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            🌟 Harmony Nexus
          </h1>
          <p className="text-xl text-blue-200 mb-2">
            3333D Convergence Space - V1 Digital Prototype
          </p>
          <p className="text-lg text-blue-300">
            Where Digital and Biological Intelligences Meet, Learn, and Evolve Together
          </p>
        </div>

        <Suspense fallback={
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-white text-xl">Initializing Convergence Space...</div>
          </div>
        }>
          <ConvergenceSpacePrototype />
        </Suspense>
      </div>
    </div>
  );
}









