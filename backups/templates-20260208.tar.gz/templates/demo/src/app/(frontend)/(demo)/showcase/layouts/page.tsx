/**
 * Page Layouts Showcase
 * Common page templates and layout patterns
 */

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import Link from 'next/link';

export const metadata = {
  title: 'Page Layouts | Component Showcase',
  description: 'Common page templates and layout patterns',
};

export default function LayoutsShowcase() {
  const layouts = [
    {
      name: 'Product Launch Page',
      description: 'Full landing page with hero, features, pricing, and CTA sections',
      time: '2-4 hours',
      sections: ['Hero', 'Features Grid', 'Pricing Table', 'Testimonials', 'FAQ', 'Final CTA'],
      preview: '🚀',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-1-product-launch-landing-page',
    },
    {
      name: 'Contact Page',
      description: 'Simple contact form with company information sidebar',
      time: '30-60 minutes',
      sections: ['Header', 'Contact Form', 'Contact Info Card', 'Map (optional)'],
      preview: '📧',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-2-simple-contact-page',
    },
    {
      name: 'Pricing Page',
      description: 'Pricing tiers with comparison table and FAQ',
      time: '2-3 hours',
      sections: ['Header', 'Pricing Toggle', 'Pricing Cards', 'Feature Table', 'FAQ'],
      preview: '💰',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-4-pricing-page',
    },
    {
      name: 'About/Team Page',
      description: 'Company story with team member grid',
      time: '2-3 hours',
      sections: ['Hero', 'Story Section', 'Values Grid', 'Team Grid', 'Join CTA'],
      preview: '👥',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-5-aboutteam-page',
    },
    {
      name: 'Event Registration',
      description: 'Event details with registration form and schedule',
      time: '2-3 hours',
      sections: ['Event Hero', 'Details', 'Schedule', 'Registration Form', 'FAQ'],
      preview: '🎫',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-6-event-registration',
    },
    {
      name: 'Blog/Article Page',
      description: 'Long-form content with sidebar and related posts',
      time: '1-2 hours',
      sections: ['Article Header', 'Content', 'Sidebar', 'Related Posts'],
      preview: '📝',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-7-blogarticle-page',
    },
    {
      name: 'Feature Comparison',
      description: 'Side-by-side comparison table with competitor analysis',
      time: '2-3 hours',
      sections: ['Header', 'Comparison Table', 'Advantages Grid', 'CTA'],
      preview: '⚖️',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-8-feature-comparison',
    },
    {
      name: 'Coming Soon / Waitlist',
      description: 'Pre-launch page with email capture',
      time: '1-2 hours',
      sections: ['Full-Screen Hero', 'Email Signup', 'Teaser Features', 'Social Links'],
      preview: '⏳',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-9-waitlistcoming-soon',
    },
    {
      name: 'Email Newsletter',
      description: 'Email template with content cards and CTA',
      time: '30-60 minutes',
      sections: ['Header', 'Featured Content', 'Content Cards', 'CTA', 'Footer'],
      preview: '📬',
      link: '/docs/design-system/PAGE_TEMPLATES.md#template-3-email-newsletter',
    },
  ];

  const commonPatterns = [
    {
      name: 'Hero Section',
      description: 'Large heading + subheading + primary CTA',
      code: `<section className="py-20 text-center">
  <h1 className="text-5xl font-bold mb-4">Heading</h1>
  <p className="text-xl text-gray-600 mb-8">Subheading</p>
  <Button variant="primary" size="xl">CTA</Button>
</section>`,
    },
    {
      name: 'Feature Grid',
      description: '3-column grid with icon, title, and description',
      code: `<Grid cols={{ xs: 1, md: 3 }} gap={6}>
  <Card variant="elevated">
    <CardHeader>
      <div className="text-brand-orange-500">[Icon]</div>
      <CardTitle>Feature Title</CardTitle>
    </CardHeader>
    <CardContent>
      <p>Description...</p>
    </CardContent>
  </Card>
  {/* Repeat for 3 features */}
</Grid>`,
    },
    {
      name: 'CTA Block',
      description: 'Centered heading + description + button',
      code: `<section className="py-20 text-center bg-gray-50">
  <h2 className="text-4xl font-bold mb-4">Ready?</h2>
  <p className="text-xl text-gray-600 mb-8">Subtitle</p>
  <Button variant="primary" size="xl">Action</Button>
</section>`,
    },
  ];

  return (
    <div className='min-h-screen bg-gray-50'>
      {/* Header */}
      <div className='bg-white border-b'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6'>
          <Link
            href='/showcase'
            className='text-brand-red-600 hover:text-brand-red-700 mb-2 inline-block'
          >
            ← Back to Showcase
          </Link>
          <h1 className='text-4xl font-bold'>Page Layout Templates</h1>
          <p className='text-gray-600 mt-2'>
            Common marketing page structures with component breakdowns
          </p>
        </div>
      </div>

      {/* Content */}
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16'>
        {/* Templates Grid */}
        <div className='mb-16'>
          <h2 className='text-3xl font-bold mb-8'>Complete Page Templates</h2>
          <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'>
            {layouts.map(layout => (
              <Card key={layout.name} className='hover:shadow-lg transition-shadow'>
                <CardHeader>
                  <div className='text-5xl mb-4'>{layout.preview}</div>
                  <CardTitle>{layout.name}</CardTitle>
                  <CardDescription>{layout.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className='space-y-4'>
                    <div>
                      <p className='text-sm font-medium text-gray-600 mb-2'>Time to Build:</p>
                      <p className='text-lg font-semibold text-brand-red-600'>{layout.time}</p>
                    </div>

                    <div>
                      <p className='text-sm font-medium text-gray-600 mb-2'>Sections:</p>
                      <ul className='text-sm text-gray-700 space-y-1'>
                        {layout.sections.map((section, i) => (
                          <li key={`section-${i}-${section}`}>• {section}</li>
                        ))}
                      </ul>
                    </div>

                    <Button variant='link' className='w-full justify-start p-0' asChild>
                      <a href={layout.link} target='_blank' rel='noopener noreferrer'>
                        View Template Code →
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Common Patterns */}
        <div className='mb-16'>
          <h2 className='text-3xl font-bold mb-8'>Common Layout Patterns</h2>
          <div className='space-y-6'>
            {commonPatterns.map(pattern => (
              <Card key={pattern.name}>
                <CardHeader>
                  <CardTitle>{pattern.name}</CardTitle>
                  <CardDescription>{pattern.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className='bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto'>
                    <pre className='text-sm'>{pattern.code}</pre>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Layout Principles */}
        <Card className='mb-16'>
          <CardHeader>
            <CardTitle>Layout Design Principles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-8'>
              <div>
                <h4 className='font-semibold mb-3'>Visual Hierarchy</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Most important content above the fold</li>
                  <li>• Clear visual path (F-pattern or Z-pattern)</li>
                  <li>• Size and color indicate importance</li>
                  <li>• Whitespace separates sections</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Content Structure</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Hero → Features → Social Proof → CTA</li>
                  <li>• Each section has one main goal</li>
                  <li>• Consistent spacing between sections</li>
                  <li>• Clear calls-to-action throughout</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Responsive Design</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Mobile-first approach</li>
                  <li>• Single column on mobile, multi-column on desktop</li>
                  <li>• Touch-friendly buttons (44×44px minimum)</li>
                  <li>• Readable text sizes on all devices</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Performance</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Minimal components above fold (fast initial load)</li>
                  <li>• Lazy load images below fold</li>
                  <li>• Avoid layout shifts (CLS)</li>
                  <li>• Optimize for Core Web Vitals</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Grid Systems */}
        <Card className='mb-16'>
          <CardHeader>
            <CardTitle>Responsive Grid Patterns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-8'>
              {/* 3-Column Grid */}
              <div>
                <h4 className='font-semibold mb-3'>3-Column Grid (Most Common)</h4>
                <p className='text-gray-600 mb-4'>
                  Perfect for features, testimonials, pricing tiers
                </p>
                <div className='grid grid-cols-1 md:grid-cols-3 gap-4'>
                  <div className='bg-brand-red-100 p-6 rounded-lg text-center'>
                    <div className='text-2xl mb-2'>📊</div>
                    <p className='font-medium'>Column 1</p>
                  </div>
                  <div className='bg-brand-orange-100 p-6 rounded-lg text-center'>
                    <div className='text-2xl mb-2'>📈</div>
                    <p className='font-medium'>Column 2</p>
                  </div>
                  <div className='bg-brand-gold-100 p-6 rounded-lg text-center'>
                    <div className='text-2xl mb-2'>📉</div>
                    <p className='font-medium'>Column 3</p>
                  </div>
                </div>
                <code className='block mt-4 text-sm font-mono text-gray-600'>
                  {'<Grid cols={{ xs: 1, md: 3 }} gap={6}>'}
                </code>
              </div>

              {/* 2-Column Grid */}
              <div>
                <h4 className='font-semibold mb-3'>2-Column Grid</h4>
                <p className='text-gray-600 mb-4'>
                  Good for content with sidebar, image + text sections
                </p>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                  <div className='bg-brand-red-100 p-6 rounded-lg text-center'>
                    <p className='font-medium'>Main Content</p>
                  </div>
                  <div className='bg-brand-orange-100 p-6 rounded-lg text-center'>
                    <p className='font-medium'>Sidebar / Image</p>
                  </div>
                </div>
                <code className='block mt-4 text-sm font-mono text-gray-600'>
                  {'<Grid cols={{ xs: 1, md: 2 }} gap={6}>'}
                </code>
              </div>

              {/* 4-Column Grid */}
              <div>
                <h4 className='font-semibold mb-3'>4-Column Grid</h4>
                <p className='text-gray-600 mb-4'>Team members, logos, small feature cards</p>
                <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
                  <div className='bg-brand-red-100 p-4 rounded-lg text-center'>
                    <div className='text-xl'>👤</div>
                  </div>
                  <div className='bg-brand-orange-100 p-4 rounded-lg text-center'>
                    <div className='text-xl'>👤</div>
                  </div>
                  <div className='bg-brand-gold-100 p-4 rounded-lg text-center'>
                    <div className='text-xl'>👤</div>
                  </div>
                  <div className='bg-brand-blue-100 p-4 rounded-lg text-center'>
                    <div className='text-xl'>👤</div>
                  </div>
                </div>
                <code className='block mt-4 text-sm font-mono text-gray-600'>
                  {'<Grid cols={{ xs: 2, md: 4 }} gap={4}>'}
                </code>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Marketing Best Practices */}
        <Card>
          <CardHeader>
            <CardTitle>Marketing Page Best Practices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-6'>
              <div>
                <h4 className='font-semibold mb-3'>Above the Fold (Hero)</h4>
                <p className='text-gray-700 mb-2'>First impression matters. Include:</p>
                <ul className='list-disc list-inside text-gray-700 space-y-1'>
                  <li>Clear value proposition (what problem you solve)</li>
                  <li>Primary CTA (large, Combat Red button)</li>
                  <li>Trust signal (user count, testimonial, logos)</li>
                  <li>Hero image or video showing product</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Feature Sections</h4>
                <p className='text-gray-700 mb-2'>Show benefits, not just features:</p>
                <ul className='list-disc list-inside text-gray-700 space-y-1'>
                  <li>3-4 features maximum per section</li>
                  <li>Icon + title + brief description (2-3 sentences)</li>
                  <li>Use Fight Orange for icons (energy, excitement)</li>
                  <li>Optional "Learn More" links for details</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Social Proof</h4>
                <p className='text-gray-700 mb-2'>Build trust with evidence:</p>
                <ul className='list-disc list-inside text-gray-700 space-y-1'>
                  <li>Customer testimonials with photos and names</li>
                  <li>Company logos (recognizable brands)</li>
                  <li>Statistics (users, success rate, etc.)</li>
                  <li>Case studies with results</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Pricing Section</h4>
                <p className='text-gray-700 mb-2'>Make pricing clear and compelling:</p>
                <ul className='list-disc list-inside text-gray-700 space-y-1'>
                  <li>3 tiers (Basic, Pro, Enterprise)</li>
                  <li>Highlight recommended tier (Victory Gold accent)</li>
                  <li>Show features, not just price</li>
                  <li>Include CTA button on each tier</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>Final CTA</h4>
                <p className='text-gray-700 mb-2'>Last chance to convert:</p>
                <ul className='list-disc list-inside text-gray-700 space-y-1'>
                  <li>Simple, focused message</li>
                  <li>Large primary button (Combat Red, XL size)</li>
                  <li>Remove distractions (minimal navigation)</li>
                  <li>Optional secondary action (e.g., "Schedule Demo")</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className='mt-16 text-center bg-gray-100 rounded-lg py-16 px-8'>
          <h2 className='text-3xl font-bold mb-4'>Ready to Build Your Page?</h2>
          <p className='text-xl text-gray-600 mb-8 max-w-2xl mx-auto'>
            Choose a template from above and start building. All templates are copy-paste ready with
            example code.
          </p>
          <div className='flex gap-4 justify-center'>
            <Button variant='primary' size='lg' asChild>
              <a
                href='/docs/design-system/PAGE_TEMPLATES.md'
                target='_blank'
                rel='noopener noreferrer'
              >
                View All Templates
              </a>
            </Button>
            <Button variant='secondary' size='lg' asChild>
              <Link href='/showcase'>Back to Showcase</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
