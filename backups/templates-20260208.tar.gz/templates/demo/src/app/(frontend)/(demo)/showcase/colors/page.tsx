/**
 * Brand Colors Showcase
 * Interactive color palette with copy-paste hex codes
 */

'use client';

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Badge } from '@/presentation/components/ui/server/badge';
import Link from 'next/link';
import { useState } from 'react';

export default function ColorsShowcase() {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  const copyToClipboard = (color: string, hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(color);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  const brandColors = [
    {
      name: 'Combat Red',
      description: 'Main brand color for primary CTAs and urgent actions',
      usage: 'Primary buttons, important alerts, main brand moments',
      shades: [
        { shade: '50', hex: '#fef2f2', usage: 'Subtle backgrounds' },
        { shade: '100', hex: '#fee2e2', usage: 'Hover states' },
        { shade: '200', hex: '#fecaca', usage: 'Badges' },
        { shade: '300', hex: '#fca5a5', usage: 'Medium light' },
        { shade: '400', hex: '#f87171', usage: 'Medium' },
        { shade: '500', hex: '#ef4444', usage: 'Standard red' },
        { shade: '600', hex: '#dc2626', usage: 'PRIMARY ⭐', primary: true },
        { shade: '700', hex: '#b91c1c', usage: 'Hover states' },
        { shade: '800', hex: '#991b1b', usage: 'Dark' },
        { shade: '900', hex: '#7f1d1d', usage: 'Very dark' },
        { shade: '950', hex: '#450a0a', usage: 'Dark mode' },
      ],
    },
    {
      name: 'Fight Orange',
      description: 'Secondary brand color for energy and excitement',
      usage: 'Secondary buttons, energy moments, accent elements',
      shades: [
        { shade: '50', hex: '#fff7ed', usage: 'Subtle backgrounds' },
        { shade: '100', hex: '#ffedd5', usage: 'Very light' },
        { shade: '200', hex: '#fed7aa', usage: 'Light' },
        { shade: '300', hex: '#fdba74', usage: 'Medium light' },
        { shade: '400', hex: '#fb923c', usage: 'Medium' },
        { shade: '500', hex: '#f97316', usage: 'SECONDARY ⭐', primary: true },
        { shade: '600', hex: '#ea580c', usage: 'Darker' },
        { shade: '700', hex: '#c2410c', usage: 'Dark' },
        { shade: '800', hex: '#9a3412', usage: 'Very dark' },
        { shade: '900', hex: '#7c2d12', usage: 'Almost black' },
        { shade: '950', hex: '#431407', usage: 'Dark mode' },
      ],
    },
    {
      name: 'Victory Gold',
      description: 'Accent color for achievements and premium features',
      usage: 'Achievement badges, premium highlights, success moments',
      shades: [
        { shade: '50', hex: '#fffbeb', usage: 'Luxury backgrounds' },
        { shade: '100', hex: '#fef3c7', usage: 'Very light' },
        { shade: '200', hex: '#fde68a', usage: 'Light badges' },
        { shade: '300', hex: '#fcd34d', usage: 'Medium light' },
        { shade: '400', hex: '#fbbf24', usage: 'Medium' },
        { shade: '500', hex: '#f59e0b', usage: 'ACCENT ⭐', primary: true },
        { shade: '600', hex: '#d97706', usage: 'Richer' },
        { shade: '700', hex: '#b45309', usage: 'Dark' },
        { shade: '800', hex: '#92400e', usage: 'Very dark' },
        { shade: '900', hex: '#78350f', usage: 'Almost black' },
        { shade: '950', hex: '#451a03', usage: 'Dark mode' },
      ],
    },
    {
      name: 'Deep Blue',
      description: 'Professional color for trust and enterprise',
      usage: 'Professional/B2B content, trust signals, corporate',
      shades: [
        { shade: '50', hex: '#eff6ff', usage: 'Professional backgrounds' },
        { shade: '100', hex: '#dbeafe', usage: 'Very light' },
        { shade: '200', hex: '#bfdbfe', usage: 'Light' },
        { shade: '300', hex: '#93c5fd', usage: 'Medium light' },
        { shade: '400', hex: '#60a5fa', usage: 'Medium' },
        { shade: '500', hex: '#3b82f6', usage: 'Standard blue' },
        { shade: '600', hex: '#2563eb', usage: 'Bright' },
        { shade: '700', hex: '#1d4ed8', usage: 'Rich' },
        { shade: '800', hex: '#1e40af', usage: 'Dark' },
        { shade: '900', hex: '#1e3a8a', usage: 'PROFESSIONAL ⭐', primary: true },
        { shade: '950', hex: '#172554', usage: 'Dark mode' },
      ],
    },
    {
      name: 'Steel Gray',
      description: 'Neutral color for text and backgrounds',
      usage: 'Body text, secondary information, subtle elements',
      shades: [
        { shade: '50', hex: '#f8fafc', usage: 'Subtle backgrounds' },
        { shade: '100', hex: '#f1f5f9', usage: 'Very light' },
        { shade: '200', hex: '#e2e8f0', usage: 'Borders' },
        { shade: '300', hex: '#cbd5e1', usage: 'Medium light' },
        { shade: '400', hex: '#94a3b8', usage: 'Medium' },
        { shade: '500', hex: '#64748b', usage: 'NEUTRAL ⭐', primary: true },
        { shade: '600', hex: '#475569', usage: 'Darker text' },
        { shade: '700', hex: '#334155', usage: 'Dark text' },
        { shade: '800', hex: '#1e293b', usage: 'Very dark' },
        { shade: '900', hex: '#0f172a', usage: 'Almost black' },
        { shade: '950', hex: '#020617', usage: 'Pure dark' },
      ],
    },
  ];

  const semanticColors = [
    { name: 'Success', hex: '#22c55e', usage: 'Success messages, confirmations' },
    { name: 'Warning', hex: '#f59e0b', usage: 'Caution messages, important notices' },
    { name: 'Error', hex: '#dc2626', usage: 'Error messages, destructive actions' },
    { name: 'Info', hex: '#3b82f6', usage: 'Informational messages, tips' },
  ];

  return (
    <div className='min-h-screen bg-gray-50'>
      {/* Header */}
      <div className='bg-white border-b'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6'>
          <div className='flex items-center justify-between'>
            <div>
              <Link
                href='/showcase'
                className='text-brand-red-600 hover:text-brand-red-700 mb-2 inline-block'
              >
                ← Back to Showcase
              </Link>
              <h1 className='text-4xl font-bold'>Brand Colors</h1>
              <p className='text-gray-600 mt-2'>
                Interactive color palette with all brand colors and shades
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16'>
        {/* Quick Reference */}
        <Card className='mb-12'>
          <CardHeader>
            <CardTitle>Quick Color Reference</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='grid grid-cols-1 md:grid-cols-5 gap-4'>
              <div>
                <div className='w-full h-20 rounded-lg' style={{ backgroundColor: '#dc2626' }} />
                <p className='font-medium mt-2'>Combat Red</p>
                <p className='text-sm text-gray-600'>#dc2626</p>
                <p className='text-xs text-gray-500 mt-1'>Primary CTAs</p>
              </div>
              <div>
                <div className='w-full h-20 rounded-lg' style={{ backgroundColor: '#f97316' }} />
                <p className='font-medium mt-2'>Fight Orange</p>
                <p className='text-sm text-gray-600'>#f97316</p>
                <p className='text-xs text-gray-500 mt-1'>Secondary actions</p>
              </div>
              <div>
                <div className='w-full h-20 rounded-lg' style={{ backgroundColor: '#f59e0b' }} />
                <p className='font-medium mt-2'>Victory Gold</p>
                <p className='text-sm text-gray-600'>#f59e0b</p>
                <p className='text-xs text-gray-500 mt-1'>Achievements</p>
              </div>
              <div>
                <div className='w-full h-20 rounded-lg' style={{ backgroundColor: '#1e3a8a' }} />
                <p className='font-medium mt-2 text-white'>Deep Blue</p>
                <p className='text-sm text-gray-200'>#1e3a8a</p>
                <p className='text-xs text-gray-300 mt-1'>Professional</p>
              </div>
              <div>
                <div className='w-full h-20 rounded-lg' style={{ backgroundColor: '#64748b' }} />
                <p className='font-medium mt-2'>Steel Gray</p>
                <p className='text-sm text-gray-600'>#64748b</p>
                <p className='text-xs text-gray-500 mt-1'>Neutral</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Full Palettes */}
        {brandColors.map(color => (
          <Card key={color.name} className='mb-8'>
            <CardHeader>
              <div className='flex items-center justify-between'>
                <div>
                  <CardTitle className='text-2xl'>{color.name}</CardTitle>
                  <p className='text-gray-600 mt-2'>{color.description}</p>
                  <p className='text-sm text-gray-500 mt-1'>
                    <strong>Use for:</strong> {color.usage}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className='grid grid-cols-1 md:grid-cols-11 gap-2'>
                {color.shades.map(shade => (
                  <div key={shade.shade}>
                    <button
                      onClick={() => copyToClipboard(`${color.name}-${shade.shade}`, shade.hex)}
                      className='w-full rounded-lg overflow-hidden group cursor-pointer transition-transform hover:scale-105'
                    >
                      <div
                        className='h-24 flex items-center justify-center relative'
                        style={{ backgroundColor: shade.hex }}
                      >
                        {shade.primary && <Badge className='absolute top-2'>⭐</Badge>}
                        <span
                          className={`text-xs font-medium ${parseInt(shade.shade) >= 500 ? 'text-white' : 'text-gray-900'}`}
                        >
                          {shade.shade}
                        </span>
                      </div>
                    </button>
                    <div className='mt-2 text-center'>
                      <p className='text-xs font-mono text-gray-600'>{shade.hex}</p>
                      <p className='text-xs text-gray-500 mt-1'>{shade.usage}</p>
                      {copiedColor === `${color.name}-${shade.shade}` && (
                        <p className='text-xs text-green-600 mt-1'>Copied!</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Semantic Colors */}
        <Card className='mt-12'>
          <CardHeader>
            <CardTitle>Semantic Colors</CardTitle>
            <p className='text-gray-600 mt-2'>Contextual colors for feedback and states</p>
          </CardHeader>
          <CardContent>
            <div className='grid grid-cols-1 md:grid-cols-4 gap-6'>
              {semanticColors.map(color => (
                <button
                  key={color.name}
                  onClick={() => copyToClipboard(color.name, color.hex)}
                  className='text-left group cursor-pointer'
                >
                  <div
                    className='w-full h-32 rounded-lg flex items-center justify-center transition-transform group-hover:scale-105'
                    style={{ backgroundColor: color.hex }}
                  >
                    <span className='text-white font-bold text-xl'>{color.name}</span>
                  </div>
                  <p className='font-medium mt-3'>{color.name}</p>
                  <p className='text-sm font-mono text-gray-600'>{color.hex}</p>
                  <p className='text-xs text-gray-500 mt-1'>{color.usage}</p>
                  {copiedColor === color.name && (
                    <p className='text-xs text-green-600 mt-1'>Copied!</p>
                  )}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Usage Guidelines */}
        <Card className='mt-12'>
          <CardHeader>
            <CardTitle>Usage Guidelines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-4'>
              <div>
                <h4 className='font-semibold mb-2'>✅ DO</h4>
                <ul className='list-disc list-inside space-y-1 text-gray-700'>
                  <li>Use Combat Red (600) for primary CTAs</li>
                  <li>Use Fight Orange (500) for secondary actions</li>
                  <li>Use Victory Gold (500) for achievements and premium features</li>
                  <li>Use Deep Blue (900) for professional/enterprise content</li>
                  <li>Use Steel Gray (700) for body text</li>
                  <li>Check contrast ratios for accessibility</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-2'>❌ DON'T</h4>
                <ul className='list-disc list-inside space-y-1 text-gray-700'>
                  <li>Mix more than 3 colors in one section</li>
                  <li>Use bright colors for large text areas</li>
                  <li>Put light text on light backgrounds (poor contrast)</li>
                  <li>Create custom colors outside the palette</li>
                  <li>Ignore accessibility guidelines</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className='mt-12 text-center'>
          <Button variant='primary' size='lg' asChild>
            <Link href='/showcase'>Back to Showcase</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
