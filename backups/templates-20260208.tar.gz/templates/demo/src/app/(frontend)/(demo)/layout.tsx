import type { ReactNode } from 'react';

/**
 * Demo & Showcase Pages Layout
 *
 * Shared configuration for development and demonstration pages:
 * - Component Showcase, Catalyst Test, Industry Templates
 *
 * These are internal demo pages that can be cached longer
 * or excluded from production builds if needed.
 */

// Static demo pages with 1-hour revalidation
export const revalidate = 3600;

// Optional: Add metadata to prevent indexing demo pages
export const metadata = {
  robots: {
    index: false,
    follow: false,
  },
};

export default function DemoLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
