/**
 * Advanced Components Showcase
 * Redirects to catalyst-test page which showcases advanced components
 */

import { redirect } from 'next/navigation';

export default function AdvancedComponentsShowcase() {
  // Redirect to the existing catalyst test page which showcases advanced components
  redirect('/catalyst-test');
}
