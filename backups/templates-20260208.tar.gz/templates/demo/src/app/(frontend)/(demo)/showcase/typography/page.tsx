/**
 * Typography Showcase
 * Font system, sizes, weights, and text styles
 */

import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import Link from 'next/link';

export const metadata = {
  title: 'Typography | Component Showcase',
  description: 'Font system, sizes, weights, and text styles',
};

export default function TypographyShowcase() {
  const fontSizes = [
    { name: 'text-xs', size: '0.75rem (12px)', example: 'Extra small text for fine print' },
    { name: 'text-sm', size: '0.875rem (14px)', example: 'Small text for secondary content' },
    { name: 'text-base', size: '1rem (16px)', example: 'Base text for body content' },
    { name: 'text-lg', size: '1.125rem (18px)', example: 'Large text for emphasis' },
    { name: 'text-xl', size: '1.25rem (20px)', example: 'Extra large text for subheadings' },
    { name: 'text-2xl', size: '1.5rem (24px)', example: 'Section titles' },
    { name: 'text-3xl', size: '1.875rem (30px)', example: 'Page headings' },
    { name: 'text-4xl', size: '2.25rem (36px)', example: 'Hero section headings' },
    { name: 'text-5xl', size: '3rem (48px)', example: 'Large hero text' },
    { name: 'text-6xl', size: '3.75rem (60px)', example: 'Extra large hero text' },
    { name: 'text-7xl', size: '4.5rem (72px)', example: 'Maximum hero text' },
  ];

  const fontWeights = [
    { name: 'font-light', weight: '300', text: 'Light weight (rarely used)' },
    { name: 'font-normal', weight: '400', text: 'Normal weight for body text' },
    { name: 'font-medium', weight: '500', text: 'Medium weight for emphasis' },
    { name: 'font-semibold', weight: '600', text: 'Semibold for headings' },
    { name: 'font-bold', weight: '700', text: 'Bold for strong emphasis' },
    { name: 'font-extrabold', weight: '800', text: 'Extra bold for impact' },
  ];

  return (
    <div className='min-h-screen bg-gray-50'>
      {/* Header */}
      <div className='bg-white border-b'>
        <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6'>
          <Link
            href='/showcase'
            className='text-brand-red-600 hover:text-brand-red-700 mb-2 inline-block'
          >
            ← Back to Showcase
          </Link>
          <h1 className='text-4xl font-bold'>Typography System</h1>
          <p className='text-gray-600 mt-2'>Font system, sizes, weights, and text styles</p>
        </div>
      </div>

      {/* Content */}
      <div className='max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16'>
        {/* Font Family */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Font Family</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-4'>
              <div>
                <p className='text-sm font-medium text-gray-600 mb-2'>Primary Font (sans-serif)</p>
                <p className='text-4xl font-medium'>The quick brown fox jumps over the lazy dog</p>
                <p className='text-sm text-gray-500 mt-2 font-mono'>
                  font-family: system-ui, -apple-system, sans-serif
                </p>
              </div>

              <div className='pt-6 border-t'>
                <p className='text-sm font-medium text-gray-600 mb-2'>Monospace Font (code)</p>
                <p className='text-2xl font-mono'>The quick brown fox jumps over the lazy dog</p>
                <p className='text-sm text-gray-500 mt-2 font-mono'>
                  font-family: 'Courier New', monospace
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Font Sizes */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Font Sizes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-6'>
              {fontSizes.map(size => (
                <div key={size.name} className='border-b pb-4 last:border-0'>
                  <div className='flex items-baseline justify-between mb-2'>
                    <code className='text-sm font-mono text-brand-red-600'>{size.name}</code>
                    <span className='text-sm text-gray-500'>{size.size}</span>
                  </div>
                  <p className={size.name}>{size.example}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Font Weights */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Font Weights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-4'>
              {fontWeights.map(weight => (
                <div
                  key={weight.name}
                  className='flex items-center justify-between border-b pb-3 last:border-0'
                >
                  <div>
                    <code className='text-sm font-mono text-brand-red-600'>{weight.name}</code>
                    <span className='text-sm text-gray-500 ml-4'>({weight.weight})</span>
                  </div>
                  <p className={`${weight.name} text-xl`}>{weight.text}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Text Colors */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Text Colors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-4'>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  text-gray-900
                </code>
                <p className='text-gray-900 text-2xl'>Primary heading text (darkest)</p>
              </div>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  text-gray-700
                </code>
                <p className='text-gray-700 text-xl'>Body text (readable, comfortable)</p>
              </div>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  text-gray-600
                </code>
                <p className='text-gray-600 text-lg'>Secondary text (descriptions)</p>
              </div>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  text-gray-500
                </code>
                <p className='text-gray-500'>Tertiary text (metadata, timestamps)</p>
              </div>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  text-gray-400
                </code>
                <p className='text-gray-400'>Placeholder text (very subtle)</p>
              </div>
            </div>

            <div className='mt-8 pt-8 border-t'>
              <h4 className='font-semibold mb-4'>Brand Colors</h4>
              <div className='space-y-3'>
                <p className='text-brand-red-600 text-xl font-semibold'>
                  Combat Red text (primary brand)
                </p>
                <p className='text-brand-orange-500 text-xl font-semibold'>
                  Fight Orange text (secondary)
                </p>
                <p className='text-brand-gold-600 text-xl font-semibold'>
                  Victory Gold text (accent)
                </p>
                <p className='text-brand-blue-900 text-xl font-semibold'>
                  Deep Blue text (professional)
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Headings Hierarchy */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Heading Hierarchy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-6'>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h1>'} - Page Title
                </code>
                <h1 className='text-5xl font-bold'>This is a main page heading (H1)</h1>
                <p className='text-sm text-gray-500 mt-2'>text-5xl font-bold • Use once per page</p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h2>'} - Section Title
                </code>
                <h2 className='text-4xl font-bold'>This is a section heading (H2)</h2>
                <p className='text-sm text-gray-500 mt-2'>text-4xl font-bold • Major sections</p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h3>'} - Subsection Title
                </code>
                <h3 className='text-3xl font-semibold'>This is a subsection heading (H3)</h3>
                <p className='text-sm text-gray-500 mt-2'>text-3xl font-semibold • Subsections</p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h4>'} - Minor Heading
                </code>
                <h4 className='text-2xl font-semibold'>This is a minor heading (H4)</h4>
                <p className='text-sm text-gray-500 mt-2'>text-2xl font-semibold • Card titles</p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h5>'} - Small Heading
                </code>
                <h5 className='text-xl font-medium'>This is a small heading (H5)</h5>
                <p className='text-sm text-gray-500 mt-2'>text-xl font-medium • Small sections</p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  {'<h6>'} - Smallest Heading
                </code>
                <h6 className='text-lg font-medium'>This is the smallest heading (H6)</h6>
                <p className='text-sm text-gray-500 mt-2'>text-lg font-medium • Rarely used</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Common Text Patterns */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Common Text Patterns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-8'>
              {/* Hero Text */}
              <div className='bg-gradient-to-r from-brand-red-600 to-brand-orange-500 text-white p-8 rounded-lg'>
                <h1 className='text-6xl font-bold mb-4'>Hero Section Heading</h1>
                <p className='text-2xl mb-6 opacity-90'>
                  Compelling subheading that explains value proposition
                </p>
                <Button variant='accent' size='xl'>
                  Get Started Now
                </Button>
              </div>

              {/* Feature Description */}
              <div>
                <h3 className='text-2xl font-bold text-gray-900 mb-2'>Feature Title</h3>
                <p className='text-gray-600 text-lg'>
                  Feature description that explains benefits and key points. Keep it concise and
                  scannable.
                </p>
              </div>

              {/* Body Text */}
              <div>
                <h4 className='text-xl font-semibold text-gray-900 mb-3'>
                  Article or Blog Content
                </h4>
                <p className='text-gray-700 text-base leading-relaxed mb-4'>
                  This is standard body text with comfortable line height (leading-relaxed). It's
                  perfect for longer-form content like blog posts, articles, or documentation. The
                  text-gray-700 color provides excellent readability without being too harsh.
                </p>
                <p className='text-gray-700 text-base leading-relaxed'>
                  Multiple paragraphs should have space between them (mb-4) to improve readability.
                  This helps readers process information in digestible chunks.
                </p>
              </div>

              {/* Small Print */}
              <div>
                <p className='text-gray-500 text-sm'>
                  * This is small print text, perfect for disclaimers, legal notices, or metadata.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Line Height */}
        <Card className='mb-8'>
          <CardHeader>
            <CardTitle>Line Height (Leading)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='space-y-6'>
              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  leading-tight
                </code>
                <p className='leading-tight text-gray-700'>
                  Tight line height for headings and short text. Creates a compact, dense
                  appearance. Use for display text and headings where readability isn't as critical.
                </p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  leading-normal (default)
                </code>
                <p className='leading-normal text-gray-700'>
                  Normal line height (1.5) is the default. Good for most body text and general
                  content. Provides a balance between compactness and readability.
                </p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  leading-relaxed (recommended for body)
                </code>
                <p className='leading-relaxed text-gray-700'>
                  Relaxed line height (1.625) is best for longer-form content like articles and blog
                  posts. The extra spacing makes text easier to read and less tiring on the eyes.
                  This is our recommended setting for body content.
                </p>
              </div>

              <div>
                <code className='text-sm font-mono text-brand-red-600 mb-2 block'>
                  leading-loose
                </code>
                <p className='leading-loose text-gray-700'>
                  Loose line height (2) creates very spacious text. Use sparingly for special
                  emphasis or short quotes where you want extra breathing room.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Usage Guidelines */}
        <Card>
          <CardHeader>
            <CardTitle>Typography Best Practices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-8'>
              <div>
                <h4 className='font-semibold mb-3'>✅ DO</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Use text-gray-900 for headings (maximum contrast)</li>
                  <li>• Use text-gray-700 for body text (comfortable readability)</li>
                  <li>• Use leading-relaxed for paragraphs (easier reading)</li>
                  <li>• Limit to 2-3 font sizes per section</li>
                  <li>• Use bold weight (font-bold) for emphasis</li>
                  <li>• Keep line length under 75 characters</li>
                </ul>
              </div>

              <div>
                <h4 className='font-semibold mb-3'>❌ DON'T</h4>
                <ul className='space-y-2 text-gray-700'>
                  <li>• Use too many font sizes (creates visual chaos)</li>
                  <li>• Use light weights for body text (hard to read)</li>
                  <li>• Use all caps for long text (slows reading)</li>
                  <li>• Use pure black (#000) on pure white (too harsh)</li>
                  <li>• Use small text ({'<'} 14px) for body content</li>
                  <li>• Mix multiple font families</li>
                </ul>
              </div>
            </div>

            <div className='mt-8 pt-8 border-t'>
              <h4 className='font-semibold mb-3'>Marketing Use Cases</h4>
              <div className='grid grid-cols-1 md:grid-cols-3 gap-6'>
                <div>
                  <p className='font-medium mb-2'>Hero Sections</p>
                  <p className='text-sm text-gray-600'>
                    text-5xl to text-7xl, font-bold, short and impactful
                  </p>
                </div>
                <div>
                  <p className='font-medium mb-2'>Feature Descriptions</p>
                  <p className='text-sm text-gray-600'>
                    text-lg to text-xl, leading-relaxed, easy to scan
                  </p>
                </div>
                <div>
                  <p className='font-medium mb-2'>CTAs</p>
                  <p className='text-sm text-gray-600'>
                    text-base to text-lg, font-semibold, action-oriented
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className='mt-12 flex justify-between'>
          <Button variant='outline' asChild>
            <Link href='/showcase'>← Back to Showcase</Link>
          </Button>
          <Button variant='primary' asChild>
            <Link href='/showcase/layouts'>View Page Layouts →</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
