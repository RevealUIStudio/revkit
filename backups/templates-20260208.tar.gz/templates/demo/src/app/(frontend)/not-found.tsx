import { Button } from '@/presentation/components/ui/primitives/button';
import Link from 'next/link';

export default function NotFound() {
  return (
    <div className='container py-28'>
      <div className='prose max-w-none'>
        <h1 className='mb-0 text-6xl font-bold text-gray-900 dark:text-gray-100'>404</h1>
        <p className='mb-4 text-lg text-gray-600 dark:text-gray-400'>
          This page could not be found.
        </p>
      </div>
      <Link href='/'>
        <Button variant='default' size='lg' className='mt-6'>
          Go home
        </Button>
      </Link>
    </div>
  );
}
