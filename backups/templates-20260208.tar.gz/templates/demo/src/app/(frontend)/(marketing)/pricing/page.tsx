import { generateMeta } from '@/config/system/utilities/generation';
import { PricingCards } from '@/features/commerce/ui/PricingCards';
import { Button as ClientButton } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import { Check as CheckIcon } from 'lucide-react';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Pricing Plans',
    description: 'Choose the perfect plan for your needs. Start free, upgrade anytime.',
    url: '/pricing',
  });
}

const faqs = [
  {
    question: 'Can I change my plan later?',
    answer:
      'Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately, and we will prorate any charges.',
  },
  {
    question: 'What payment methods do you accept?',
    answer:
      'We accept all major credit cards (Visa, Mastercard, American Express, Discover) through our secure payment processor, Stripe.',
  },
  {
    question: 'Is there a free trial?',
    answer:
      'Yes! Starter and Pro plans include a 14-day free trial. The Free plan is available forever with no credit card required. You can upgrade to Starter, Pro, Business, or Enterprise at any time to access additional features.',
  },
  {
    question: 'Can I cancel anytime?',
    answer:
      'Absolutely. You can cancel your subscription at any time from your account settings. You will continue to have access until the end of your billing period.',
  },
  {
    question: 'Do you offer refunds?',
    answer:
      'Yes, we offer a 30-day money-back guarantee. If you are not satisfied with your subscription, contact support within 30 days for a full refund.',
  },
  {
    question: 'What happens when I cancel?',
    answer:
      'When you cancel, you will retain access to premium features until the end of your current billing period. After that, you will be moved to the Free plan.',
  },
  {
    question: 'Are there any hidden fees?',
    answer:
      'No hidden fees! The price you see is what you pay. Taxes may apply based on your location, but we will show the final amount before you confirm.',
  },
  {
    question: 'Can I get a discount for annual billing?',
    answer:
      'Yes! Annual plans save you 20% compared to monthly billing. Contact our sales team for enterprise pricing and volume discounts.',
  },
];

export default function PricingPage() {
  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4'>
        {/* Header */}
        <div className='text-center mb-12'>
          <h1 className='text-4xl md:text-5xl font-bold mb-4'>Choose Your Perfect Plan</h1>
          <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
            Start free, upgrade anytime. All plans include our core features with no hidden fees.
          </p>
        </div>

        {/* Pricing Cards */}
        <PricingCards />

        {/* Feature Comparison Table */}
        <div className='max-w-7xl mx-auto mb-16'>
          <h2 className='text-3xl font-bold text-center mb-8'>Compare All Features</h2>
          <Card>
            <CardContent className='p-6'>
              <div className='overflow-x-auto'>
                <table className='w-full'>
                  <thead>
                    <tr className='border-b'>
                      <th className='text-left py-3 px-4 font-semibold'>Feature</th>
                      <th className='text-center py-3 px-4 font-semibold'>Free</th>
                      <th className='text-center py-3 px-4 font-semibold'>
                        Starter
                        <br />
                        <span className='text-sm font-normal text-muted-foreground'>$19.99/mo</span>
                      </th>
                      <th className='text-center py-3 px-4 font-semibold'>
                        Pro
                        <br />
                        <span className='text-sm font-normal text-muted-foreground'>$49.99/mo</span>
                      </th>
                      <th className='text-center py-3 px-4 font-semibold'>
                        Business
                        <br />
                        <span className='text-sm font-normal text-muted-foreground'>$199/mo</span>
                      </th>
                      <th className='text-center py-3 px-4 font-semibold'>Enterprise</th>
                    </tr>
                  </thead>
                  <tbody className='divide-y'>
                    <tr>
                      <td className='py-3 px-4'>Public content access</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>
                        Credits/month
                        <br />
                        <span className='text-xs text-muted-foreground'>
                          (Overage: $0.001/credit)
                        </span>
                      </td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        10,000
                        <br />
                        <span className='text-xs text-muted-foreground'>(Rollover: 1 month)</span>
                      </td>
                      <td className='text-center py-3 px-4'>
                        50,000
                        <br />
                        <span className='text-xs text-muted-foreground'>(Rollover: 1 month)</span>
                      </td>
                      <td className='text-center py-3 px-4'>
                        250,000
                        <br />
                        <span className='text-xs text-muted-foreground'>(Rollover: 1 month)</span>
                      </td>
                      <td className='text-center py-3 px-4'>
                        Unlimited
                        <br />
                        <span className='text-xs text-muted-foreground'>(No overage)</span>
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Workspaces</td>
                      <td className='text-center py-3 px-4'>1</td>
                      <td className='text-center py-3 px-4'>1</td>
                      <td className='text-center py-3 px-4'>3</td>
                      <td className='text-center py-3 px-4'>10</td>
                      <td className='text-center py-3 px-4'>Unlimited</td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Storage</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>5GB</td>
                      <td className='text-center py-3 px-4'>20GB</td>
                      <td className='text-center py-3 px-4'>100GB</td>
                      <td className='text-center py-3 px-4'>Unlimited</td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Ad-free experience</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>API access</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Advanced analytics</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Custom branding</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>SSO/SAML</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>On-premise option</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>
                        <CheckIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                      </td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Support response time</td>
                      <td className='text-center py-3 px-4'>48h</td>
                      <td className='text-center py-3 px-4'>48h</td>
                      <td className='text-center py-3 px-4'>24h</td>
                      <td className='text-center py-3 px-4'>Same-day</td>
                      <td className='text-center py-3 px-4'>1 hour</td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Free trial</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>14 days</td>
                      <td className='text-center py-3 px-4'>14 days</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>—</td>
                    </tr>
                    <tr>
                      <td className='py-3 px-4'>Credit rollover</td>
                      <td className='text-center py-3 px-4'>—</td>
                      <td className='text-center py-3 px-4'>1 month</td>
                      <td className='text-center py-3 px-4'>1 month</td>
                      <td className='text-center py-3 px-4'>1 month</td>
                      <td className='text-center py-3 px-4'>1 month</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* How Billing Works */}
        <div className='max-w-4xl mx-auto mb-16'>
          <h2 className='text-3xl font-bold text-center mb-6'>How Billing Works</h2>
          <Card>
            <CardContent className='p-6 space-y-3 text-sm text-muted-foreground'>
              <p>
                Base subscription includes a monthly credit allocation. If you exceed your included
                credits, overage is billed at your tier's rate.
              </p>
              <ul className='list-disc pl-6 space-y-2'>
                <li>
                  Starter overage example: 10,000 extra credits × $0.001 = <strong>$10</strong>
                </li>
                <li>
                  Pro overage example: 50,000 extra credits × $0.001 = <strong>$50</strong>
                </li>
                <li>
                  Business overage example: 100,000 extra credits × $0.0008 = <strong>$80</strong>
                </li>
              </ul>
              <p>
                Yearly plans are billed upfront and include a discount (effective monthly pricing is
                shown on the cards).
              </p>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className='max-w-3xl mx-auto'>
          <h2 className='text-3xl font-bold text-center mb-8'>Frequently Asked Questions</h2>
          <div className='space-y-4'>
            {faqs.map(faq => (
              <Card key={faq.question}>
                <CardHeader>
                  <CardTitle className='text-lg'>{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className='text-muted-foreground'>{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className='text-center mt-16'>
          <h2 className='text-2xl font-bold mb-4'>Still have questions?</h2>
          <p className='text-muted-foreground mb-6'>
            Our team is here to help. Contact us anytime.
          </p>
          <ClientButton variant='outline' asChild>
            <a href='/contact'>Contact Support</a>
          </ClientButton>
        </div>
      </div>
    </div>
  );
}
