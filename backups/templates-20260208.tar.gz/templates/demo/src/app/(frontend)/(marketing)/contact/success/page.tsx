import { generateMeta } from '@/config/system/utilities/generation';
import { Button as ClientButton } from '@/presentation/components/ui/primitives/button';
import { Card, CardContent } from '@/presentation/components/ui/primitives/card';
import { CheckCircle2 as CheckCircle2Icon } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Message Sent Successfully',
    description: "Your message has been received. We'll get back to you soon!",
    url: '/contact/success',
  });
}

export default function ContactSuccessPage() {
  return (
    <div className='min-h-screen py-12 bg-muted/30 flex items-center justify-center'>
      <div className='container mx-auto px-4 max-w-2xl'>
        <Card>
          <CardContent className='py-12'>
            <div className='text-center'>
              <div className='inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6'>
                <CheckCircle2Icon className='h-10 w-10 text-green-600' />
              </div>

              <h1 className='text-3xl font-bold mb-4'>Message Sent Successfully!</h1>

              <p className='text-lg text-muted-foreground mb-6'>
                Thank you for reaching out. We've received your message and will respond to you as
                soon as possible.
              </p>

              <div className='bg-muted/50 rounded-lg p-6 mb-8 text-left'>
                <h2 className='font-semibold mb-3'>What happens next?</h2>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li className='flex items-start gap-2'>
                    <span className='text-brand-red-600 mt-0.5'>1.</span>
                    <span>You'll receive a confirmation email with a copy of your message</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-brand-red-600 mt-0.5'>2.</span>
                    <span>Our support team will review your inquiry</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-brand-red-600 mt-0.5'>3.</span>
                    <span>
                      We'll respond to the email address you provided within our standard response
                      times
                    </span>
                  </li>
                </ul>
              </div>

              <div className='flex flex-col sm:flex-row gap-3 justify-center'>
                <ClientButton asChild>
                  <Link href='/'>Return Home</Link>
                </ClientButton>
                <ClientButton asChild variant='outline'>
                  <Link href='/help'>Browse Help Center</Link>
                </ClientButton>
              </div>

              <p className='text-sm text-muted-foreground mt-8'>
                Need immediate assistance?{' '}
                <a href='mailto:support@example.com' className='text-brand-red-600 hover:underline'>
                  Email us directly
                </a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
