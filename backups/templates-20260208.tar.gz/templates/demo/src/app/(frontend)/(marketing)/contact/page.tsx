import { generateMeta } from '@/config/system/utilities/generation';
import { Button as ClientButton } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import {
  Clock as ClockIcon,
  Mail as MailIcon,
  MessageSquare as MessageSquareIcon,
} from 'lucide-react';
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Contact Support',
    description: "Get in touch with our support team. We're here to help!",
    url: '/contact',
  });
}

export default function ContactPage() {
  return (
    <div className='min-h-screen py-12 bg-muted/30'>
      <div className='container mx-auto px-4 max-w-5xl'>
        {/* Header */}
        <div className='text-center mb-12'>
          <div className='inline-flex items-center justify-center w-16 h-16 bg-brand-red-600 rounded-full mb-4'>
            <MessageSquareIcon className='h-8 w-8 text-white' />
          </div>
          <h1 className='text-4xl md:text-5xl font-bold mb-4'>Contact Support</h1>
          <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
            Have a question or need help? Fill out the form below and our team will get back to you
            as soon as possible.
          </p>
        </div>

        <div className='grid lg:grid-cols-3 gap-8'>
          {/* Contact Form */}
          <div className='lg:col-span-2'>
            <Card>
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>
                  Fill out the form below and we'll respond within 24 hours
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form action='/api/contact/submit' method='POST' className='space-y-6'>
                  {/* Name */}
                  <div>
                    <label htmlFor='name' className='block text-sm font-medium mb-2'>
                      Your Name *
                    </label>
                    <input
                      type='text'
                      id='name'
                      name='name'
                      required
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
                      placeholder='John Doe'
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor='email' className='block text-sm font-medium mb-2'>
                      Email Address *
                    </label>
                    <input
                      type='email'
                      id='email'
                      name='email'
                      required
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
                      placeholder='john@example.com'
                    />
                  </div>

                  {/* Subject */}
                  <div>
                    <label htmlFor='subject' className='block text-sm font-medium mb-2'>
                      Subject *
                    </label>
                    <input
                      type='text'
                      id='subject'
                      name='subject'
                      required
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
                      placeholder='How can we help?'
                    />
                  </div>

                  {/* Priority */}
                  <div>
                    <label htmlFor='priority' className='block text-sm font-medium mb-2'>
                      Priority
                    </label>
                    <select
                      id='priority'
                      name='priority'
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
                    >
                      <option value='low'>Low - General inquiry</option>
                      <option value='medium'>Medium - Need assistance</option>
                      <option value='high'>High - Urgent issue</option>
                      <option value='critical'>Critical - Service down</option>
                    </select>
                  </div>

                  {/* Category */}
                  <div>
                    <label htmlFor='category' className='block text-sm font-medium mb-2'>
                      Category
                    </label>
                    <select
                      id='category'
                      name='category'
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600'
                    >
                      <option value='general'>General Question</option>
                      <option value='technical'>Technical Support</option>
                      <option value='billing'>Billing & Subscriptions</option>
                      <option value='account'>Account Issues</option>
                      <option value='feature'>Feature Request</option>
                      <option value='bug'>Bug Report</option>
                      <option value='other'>Other</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor='message' className='block text-sm font-medium mb-2'>
                      Message *
                    </label>
                    <textarea
                      id='message'
                      name='message'
                      required
                      rows={6}
                      className='w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-red-600 resize-none'
                      placeholder='Please provide as much detail as possible...'
                    />
                    <p className='text-xs text-muted-foreground mt-2'>
                      Include any error messages, screenshots, or relevant details
                    </p>
                  </div>

                  {/* Submit Button */}
                  <ClientButton type='submit' className='w-full' size='lg'>
                    Send Message
                  </ClientButton>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Info */}
          <div className='space-y-6'>
            {/* Response Time */}
            <Card>
              <CardHeader>
                <CardTitle className='flex items-center gap-2 text-lg'>
                  <ClockIcon className='h-5 w-5 text-brand-red-600' />
                  Response Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-sm text-muted-foreground mb-3'>We typically respond within:</p>
                <ul className='space-y-2 text-sm'>
                  <li className='flex items-center gap-2'>
                    <span className='w-2 h-2 bg-red-500 rounded-full' />
                    <span>
                      <strong>Critical:</strong> 1 hour
                    </span>
                  </li>
                  <li className='flex items-center gap-2'>
                    <span className='w-2 h-2 bg-orange-500 rounded-full' />
                    <span>
                      <strong>High:</strong> 4 hours
                    </span>
                  </li>
                  <li className='flex items-center gap-2'>
                    <span className='w-2 h-2 bg-yellow-500 rounded-full' />
                    <span>
                      <strong>Medium:</strong> 24 hours
                    </span>
                  </li>
                  <li className='flex items-center gap-2'>
                    <span className='w-2 h-2 bg-green-500 rounded-full' />
                    <span>
                      <strong>Low:</strong> 48 hours
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Email Direct */}
            <Card>
              <CardHeader>
                <CardTitle className='flex items-center gap-2 text-lg'>
                  <MailIcon className='h-5 w-5 text-brand-red-600' />
                  Email Us Directly
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-sm text-muted-foreground mb-3'>
                  Prefer email? Reach out directly:
                </p>
                <ul className='space-y-2 text-sm'>
                  <li>
                    <strong>General Support:</strong>
                    <br />
                    <a
                      href='mailto:support@example.com'
                      className='text-brand-red-600 hover:underline'
                    >
                      support@example.com
                    </a>
                  </li>
                  <li>
                    <strong>Billing:</strong>
                    <br />
                    <a
                      href='mailto:billing@example.com'
                      className='text-brand-red-600 hover:underline'
                    >
                      billing@example.com
                    </a>
                  </li>
                  <li>
                    <strong>Technical:</strong>
                    <br />
                    <a
                      href='mailto:tech@example.com'
                      className='text-brand-red-600 hover:underline'
                    >
                      tech@example.com
                    </a>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Help Center Link */}
            <Card className='bg-brand-red-50 border-brand-red-200'>
              <CardHeader>
                <CardTitle className='text-lg'>Need Quick Answers?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-sm text-muted-foreground mb-4'>
                  Check out our help center for instant answers to common questions.
                </p>
                <ClientButton asChild variant='outline' className='w-full'>
                  <a href='/help'>Visit Help Center</a>
                </ClientButton>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
