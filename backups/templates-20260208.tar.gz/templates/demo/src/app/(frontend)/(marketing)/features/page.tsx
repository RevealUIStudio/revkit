import { generateMeta } from '@/config/system/utilities/generation';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import {
  Bell as BellIcon,
  CheckCircle as CheckCircleIcon,
  Download as DownloadIcon,
  Headphones as HeadphonesIcon,
  ShieldCheck as ShieldCheckIcon,
  TrendingUp as TrendingUpIcon,
  Users as UsersIcon,
  Video as VideoIcon,
  Zap as ZapIcon,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';

export async function generateMetadata(): Promise<Metadata> {
  return generateMeta({
    title: 'Features - Unlock Premium Content & Benefits',
    description:
      'Discover all the features available with reveal UI. From premium video content to community features and more.',
    url: '/features',
  });
}

const features = [
  {
    icon: <VideoIcon className='h-8 w-8' />,
    title: 'Premium Video Library',
    description:
      'Access 500+ exclusive fight videos, training sessions, and behind-the-scenes content in crystal-clear HD quality.',
    benefits: [
      'Full fight videos (5-15 minutes)',
      'Exclusive interviews with fighters',
      'Training session recordings',
      'Championship events live streams',
      'Behind-the-scenes footage',
    ],
    tier: 'premium',
  },
  {
    icon: <UsersIcon className='h-8 w-8' />,
    title: 'Community Access',
    description:
      'Join a thriving community of 10,000+ fight enthusiasts, share insights, and connect with fellow members.',
    benefits: [
      'Member-only discussion forums',
      'Direct messaging with fighters',
      'Community events and meetups',
      'Exclusive member badges',
      'Early access to announcements',
    ],
    tier: 'free',
  },
  {
    icon: <ShieldCheckIcon className='h-8 w-8' />,
    title: 'Ad-Free Experience',
    description:
      'Enjoy uninterrupted viewing with zero ads. Focus on the content that matters without distractions.',
    benefits: [
      'No pre-roll ads on videos',
      'No banner advertisements',
      'Clean, distraction-free interface',
      'Faster page load times',
      'Better mobile experience',
    ],
    tier: 'premium',
  },
  {
    icon: <TrendingUpIcon className='h-8 w-8' />,
    title: 'Advanced Analytics',
    description:
      'Track your engagement, view detailed stats, and get insights into your viewing patterns and preferences.',
    benefits: [
      'Personal viewing statistics',
      'Engagement metrics dashboard',
      'Content recommendations',
      'Watch history tracking',
      'Favorite fighters tracking',
    ],
    tier: 'pro',
  },
  {
    icon: <BellIcon className='h-8 w-8' />,
    title: 'Priority Notifications',
    description:
      'Get instant alerts for new content, upcoming events, and exclusive announcements before anyone else.',
    benefits: [
      'Push notifications for new fights',
      'Email alerts for favorites',
      'Early access to ticket sales',
      'Exclusive content previews',
      'Personalized recommendations',
    ],
    tier: 'premium',
  },
  {
    icon: <DownloadIcon className='h-8 w-8' />,
    title: 'Offline Downloads',
    description:
      'Download videos to watch offline anytime, anywhere. Perfect for travel or areas with limited connectivity.',
    benefits: [
      'Download up to 50 videos',
      'Watch without internet',
      'HD quality downloads',
      'Auto-sync across devices',
      'Manage downloaded content',
    ],
    tier: 'premium',
  },
  {
    icon: <HeadphonesIcon className='h-8 w-8' />,
    title: 'Priority Support',
    description:
      'Get help when you need it with dedicated priority support. Our team responds within hours, not days.',
    benefits: [
      'Email support (24-hour response)',
      '24/7 chat support (Pro)',
      'Dedicated account manager (Pro)',
      'Phone support (Pro)',
      'Priority bug fixes',
    ],
    tier: 'premium',
  },
  {
    icon: <ZapIcon className='h-8 w-8' />,
    title: 'API Access',
    description:
      'Integrate with your own tools and apps. Full REST API access for Pro members to build custom integrations.',
    benefits: [
      'RESTful API endpoints',
      'Webhook integrations',
      'Custom app development',
      'Real-time data access',
      'Comprehensive documentation',
    ],
    tier: 'pro',
  },
];

const useCases = [
  {
    title: 'Fight Fans & Enthusiasts',
    description:
      'Watch exclusive fights, learn techniques, and connect with the combat sports community.',
    features: ['Full fight library', 'Training videos', 'Community access'],
  },
  {
    title: 'Aspiring Fighters',
    description:
      'Study professional fights, analyze techniques, and learn from the best in the business.',
    features: ['HD fight footage', 'Technique breakdowns', 'Training sessions'],
  },
  {
    title: 'Trainers & Coaches',
    description:
      'Use our extensive video library as a teaching tool to train the next generation of fighters.',
    features: ['Educational content', 'Technique analysis', 'Download for training'],
  },
];

export default function FeaturesPage() {
  return (
    <div className='min-h-screen bg-muted/30'>
      {/* Hero Section */}
      <section className='py-16 bg-gradient-to-br from-brand-red-600 to-brand-red-700 text-white'>
        <div className='container mx-auto px-4 text-center'>
          <h1 className='text-4xl md:text-5xl font-bold mb-6'>
            Everything You Need in One Platform
          </h1>
          <p className='text-xl text-white/90 max-w-3xl mx-auto mb-8'>
            Premium video content, thriving community, and powerful features designed for combat
            sports enthusiasts.
          </p>
          <div className='flex gap-4 justify-center flex-wrap'>
            <Button asChild variant='secondary' size='lg'>
              <Link href='/pricing'>View Pricing</Link>
            </Button>
            <Button
              asChild
              variant='outline'
              size='lg'
              className='bg-white/10 border-white text-white hover:bg-white/20'
            >
              <Link href='/contact'>Contact Sales</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className='py-16 bg-background'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-3xl md:text-4xl font-bold mb-4'>Powerful Features</h2>
            <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
              Everything you need to enjoy premium combat sports content and connect with the
              community
            </p>
          </div>

          <div className='grid gap-8 md:grid-cols-2 lg:grid-cols-3'>
            {features.map((feature, index) => (
              <Card
                key={`feature-${index}-${feature.title}`}
                className='hover:border-brand-red-600 transition-colors'
              >
                <CardHeader>
                  <div className='w-16 h-16 bg-brand-red-100 rounded-lg flex items-center justify-center mb-4 text-brand-red-600'>
                    {feature.icon}
                  </div>
                  <div className='flex items-center justify-between mb-2'>
                    <CardTitle className='text-xl'>{feature.title}</CardTitle>
                    <span
                      className={`text-xs px-2 py-1 rounded-full font-medium ${
                        feature.tier === 'pro'
                          ? 'bg-purple-100 text-purple-700'
                          : feature.tier === 'premium'
                            ? 'bg-brand-red-100 text-brand-red-700'
                            : 'bg-green-100 text-green-700'
                      }`}
                    >
                      {feature.tier === 'pro'
                        ? 'Pro'
                        : feature.tier === 'premium'
                          ? 'Premium'
                          : 'Free'}
                    </span>
                  </div>
                  <CardDescription className='text-base'>{feature.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className='space-y-2'>
                    {feature.benefits.map((benefit, i) => (
                      <li
                        key={`benefit-${index}-${i}-${benefit}`}
                        className='flex items-start gap-2 text-sm'
                      >
                        <CheckCircleIcon className='h-4 w-4 text-brand-red-600 flex-shrink-0 mt-0.5' />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className='py-16 bg-muted/30'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-3xl md:text-4xl font-bold mb-4'>Perfect For</h2>
            <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
              Whether you're a fan, fighter, or trainer, we have features tailored to your needs
            </p>
          </div>

          <div className='grid gap-8 md:grid-cols-3 max-w-5xl mx-auto'>
            {useCases.map((useCase, index) => (
              <Card key={useCase.title || index}>
                <CardHeader>
                  <CardTitle className='text-xl mb-2'>{useCase.title}</CardTitle>
                  <CardDescription className='text-base'>{useCase.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className='space-y-2'>
                    {useCase.features.map(feature => (
                      <li key={feature} className='flex items-center gap-2 text-sm'>
                        <CheckCircleIcon className='h-4 w-4 text-brand-red-600' />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className='py-16 bg-background'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-3xl md:text-4xl font-bold mb-4'>Compare Plans</h2>
            <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
              See what's included in each plan and choose the one that's right for you
            </p>
          </div>

          <div className='max-w-5xl mx-auto'>
            <Card>
              <CardContent className='p-6'>
                <div className='overflow-x-auto'>
                  <table className='w-full'>
                    <thead>
                      <tr className='border-b'>
                        <th className='text-left py-4 px-4 font-semibold'>Feature</th>
                        <th className='text-center py-4 px-4 font-semibold'>Free</th>
                        <th className='text-center py-4 px-4 font-semibold'>
                          Starter
                          <br />
                          <span className='text-sm font-normal text-muted-foreground'>
                            $19.99/mo
                          </span>
                        </th>
                        <th className='text-center py-4 px-4 font-semibold'>
                          Pro
                          <br />
                          <span className='text-sm font-normal text-muted-foreground'>
                            $49.99/mo
                          </span>
                        </th>
                        <th className='text-center py-4 px-4 font-semibold'>
                          Business
                          <br />
                          <span className='text-sm font-normal text-muted-foreground'>$199/mo</span>
                        </th>
                        <th className='text-center py-4 px-4 font-semibold'>Enterprise</th>
                      </tr>
                    </thead>
                    <tbody className='divide-y'>
                      <tr>
                        <td className='py-3 px-4'>Premium video library</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Credits/month</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>10,000</td>
                        <td className='text-center py-3 px-4'>50,000</td>
                        <td className='text-center py-3 px-4'>100,000</td>
                        <td className='text-center py-3 px-4'>Unlimited</td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Ad-free experience</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>HD video streaming</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Offline downloads</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Priority email support</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Advanced analytics</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>API access</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Custom branding</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>SSO/SAML</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>On-premise option</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>
                          <CheckCircleIcon className='h-5 w-5 text-brand-red-600 mx-auto' />
                        </td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Support response time</td>
                        <td className='text-center py-3 px-4'>48h</td>
                        <td className='text-center py-3 px-4'>48h</td>
                        <td className='text-center py-3 px-4'>24h</td>
                        <td className='text-center py-3 px-4'>Same-day</td>
                        <td className='text-center py-3 px-4'>1 hour</td>
                      </tr>
                      <tr>
                        <td className='py-3 px-4'>Free trial</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>14 days</td>
                        <td className='text-center py-3 px-4'>14 days</td>
                        <td className='text-center py-3 px-4'>—</td>
                        <td className='text-center py-3 px-4'>—</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className='py-16 bg-muted/30'>
        <div className='container mx-auto px-4 max-w-4xl'>
          <div className='text-center mb-12'>
            <h2 className='text-3xl md:text-4xl font-bold mb-4'>Common Questions</h2>
            <p className='text-lg text-muted-foreground'>
              Everything you need to know about our features
            </p>
          </div>

          <div className='space-y-4'>
            <Card>
              <CardHeader>
                <CardTitle className='text-lg'>What's included in the free plan?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-muted-foreground'>
                  The free plan includes access to public content, community features, and basic
                  support. It's perfect for trying out the platform before upgrading.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className='text-lg'>
                  Can I download videos for offline viewing?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-muted-foreground'>
                  Yes! Premium and Pro members can download up to 50 videos to watch offline on any
                  device. Perfect for travel or areas with poor connectivity.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className='text-lg'>
                  What's the difference between Starter, Pro, and Business?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-muted-foreground'>
                  Starter includes 10,000 credits/month with basic features. Pro adds 50,000
                  credits/month, advanced analytics, API access, and team collaboration. Business
                  includes 100,000 credits/month, SSO/SAML, audit logs, RBAC, and same-day support.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className='text-lg'>How do I access the API?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className='text-muted-foreground'>
                  API access is available exclusively to Pro members. Once you subscribe to Pro,
                  you'll receive API credentials and documentation via email.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className='py-16 bg-background'>
        <div className='container mx-auto px-4'>
          <Card className='bg-gradient-to-br from-brand-red-600 to-brand-red-700 text-white border-0 max-w-4xl mx-auto'>
            <CardContent className='py-12 text-center'>
              <h2 className='text-3xl md:text-4xl font-bold mb-4'>Ready to Get Started?</h2>
              <p className='text-xl mb-8 text-white/90 max-w-2xl mx-auto'>
                Choose the plan that works for you. Start free, upgrade anytime.
              </p>
              <div className='flex gap-4 justify-center flex-wrap'>
                <Button asChild variant='secondary' size='lg'>
                  <Link href='/pricing'>View Pricing Plans</Link>
                </Button>
                <Button
                  asChild
                  variant='outline'
                  size='lg'
                  className='bg-white/10 border-white text-white hover:bg-white/20'
                >
                  <Link href='/help'>Learn More</Link>
                </Button>
              </div>
              <p className='text-sm mt-6 text-white/80'>
                ✓ 30-day money-back guarantee • ✓ Cancel anytime • ✓ No hidden fees
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
