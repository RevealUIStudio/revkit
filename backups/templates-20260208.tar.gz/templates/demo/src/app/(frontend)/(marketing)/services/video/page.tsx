import { generateMeta } from '@/config/system/utilities/generation.ts';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';

// Inherits revalidate: 3600 from (marketing)/layout.tsx

export default async function VideoServicesPage() {
  return (
    <div className='min-h-screen bg-background'>
      {/* Hero Section */}
      <section className='relative py-20 bg-gradient-to-b from-brand-red-600/10 to-background'>
        <div className='container mx-auto px-4'>
          <div className='max-w-4xl mx-auto text-center'>
            <div className='inline-block mb-4 px-4 py-2 bg-brand-red-600/20 text-brand-red-600 rounded-full text-sm font-semibold'>
              Professional Videography Services
            </div>
            <h1 className='text-5xl md:text-6xl font-bold mb-6 text-foreground'>
              Aerial & Ground Video Production
            </h1>
            <p className='text-xl text-muted-foreground mb-8'>
              Professional drone and ground-level videography for real estate, events, commercial
              projects, and more. Powered by cutting-edge technology.
            </p>
            <div className='flex gap-4 justify-center flex-wrap'>
              <Button asChild variant='UI' size='lg'>
                <Link href='/services/video/request'>Get a Free Quote</Link>
              </Button>
              <Button asChild variant='outline' size='lg'>
                <Link href='/videos'>View Our Portfolio</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className='py-16'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-4xl font-bold mb-4'>What We Offer</h2>
            <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
              From stunning aerial shots to professional ground footage, we deliver high-quality
              video content for any need.
            </p>
          </div>

          <div className='grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto'>
            {/* Drone Videography */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[DRONE]</div>
                <CardTitle>Aerial Drone Footage</CardTitle>
                <CardDescription>
                  Stunning bird's-eye views and cinematic aerial shots
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- 4K resolution recording</li>
                  <li>- Smooth stabilized footage</li>
                  <li>- Up to 30 minutes flight time</li>
                  <li>- Professional color grading</li>
                  <li>- Licensed and insured pilots</li>
                </ul>
              </CardContent>
            </Card>

            {/* Event Coverage */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[VIDEO]</div>
                <CardTitle>Event Coverage</CardTitle>
                <CardDescription>Capture every moment of your special event</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- Weddings and celebrations</li>
                  <li>- Sports tournaments</li>
                  <li>- Concerts and festivals</li>
                  <li>- Corporate events</li>
                  <li>- Full-day coverage options</li>
                </ul>
              </CardContent>
            </Card>

            {/* Real Estate */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[PROPERTY]</div>
                <CardTitle>Real Estate</CardTitle>
                <CardDescription>Showcase properties from every angle</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- Aerial property tours</li>
                  <li>- Interior walk throughs</li>
                  <li>- Neighborhood overviews</li>
                  <li>- Fast 48-hour turnaround</li>
                  <li>- Multiple format exports</li>
                </ul>
              </CardContent>
            </Card>

            {/* Commercial */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[BUSINESS]</div>
                <CardTitle>Commercial Projects</CardTitle>
                <CardDescription>Professional video for your business</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- Product demonstrations</li>
                  <li>- Company overviews</li>
                  <li>- Marketing campaigns</li>
                  <li>- Social media content</li>
                  <li>- Custom editing packages</li>
                </ul>
              </CardContent>
            </Card>

            {/* Inspections */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[INSPECT]</div>
                <CardTitle>Inspections & Surveys</CardTitle>
                <CardDescription>Detailed visual documentation</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- Roof and building inspections</li>
                  <li>- Construction site monitoring</li>
                  <li>- Agricultural surveys</li>
                  <li>- Infrastructure assessment</li>
                  <li>- Thermal imaging available</li>
                </ul>
              </CardContent>
            </Card>

            {/* Custom Projects */}
            <Card className='border-2 hover:border-brand-red-600/50 transition-colors'>
              <CardHeader>
                <div className='text-4xl mb-4'>[CUSTOM]</div>
                <CardTitle>Custom Projects</CardTitle>
                <CardDescription>Tailored solutions for unique needs</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>- Documentary filming</li>
                  <li>- Promotional videos</li>
                  <li>- Time-lapse sequences</li>
                  <li>- Multi-location shoots</li>
                  <li>- Collaborative planning</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Tiers */}
      <section className='py-16 bg-muted/30'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-4xl font-bold mb-4'>Simple, Transparent Pricing</h2>
            <p className='text-lg text-muted-foreground max-w-2xl mx-auto'>
              Choose the package that fits your needs. All packages include professional editing and
              delivery.
            </p>
          </div>

          <div className='grid gap-8 md:grid-cols-3 max-w-6xl mx-auto'>
            {/* Starter Package */}
            <Card className='border-2'>
              <CardHeader>
                <CardTitle className='text-2xl'>Starter</CardTitle>
                <CardDescription>Perfect for quick projects</CardDescription>
                <div className='mt-4'>
                  <span className='text-4xl font-bold'>$299</span>
                  <span className='text-muted-foreground'> /project</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className='space-y-3 mb-6'>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Up to 1 hour on-site</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>1-2 minute edited video</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>4K quality</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Basic color correction</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>72-hour delivery</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>1 revision included</span>
                  </li>
                </ul>
                <Button asChild variant='outline' className='w-full'>
                  <Link href='/services/video/request?package=starter'>Get Started</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Professional Package */}
            <Card className='border-2 border-brand-red-600/50 relative overflow-hidden'>
              <div className='absolute top-0 right-0 bg-brand-red-600 text-white text-xs px-3 py-1 rounded-bl-lg font-semibold'>
                MOST POPULAR
              </div>
              <CardHeader>
                <CardTitle className='text-2xl'>Professional</CardTitle>
                <CardDescription>Ideal for most projects</CardDescription>
                <div className='mt-4'>
                  <span className='text-4xl font-bold'>$599</span>
                  <span className='text-muted-foreground'> /project</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className='space-y-3 mb-6'>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Up to 3 hours on-site</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>3-5 minute edited video</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>4K quality + RAW files</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Professional color grading</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>48-hour delivery</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>3 revisions included</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Background music</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Social media formats</span>
                  </li>
                </ul>
                <Button asChild variant='UI' className='w-full'>
                  <Link href='/services/video/request?package=professional'>Get Started</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Premium Package */}
            <Card className='border-2'>
              <CardHeader>
                <CardTitle className='text-2xl'>Premium</CardTitle>
                <CardDescription>For comprehensive coverage</CardDescription>
                <div className='mt-4'>
                  <span className='text-4xl font-bold'>$1,299</span>
                  <span className='text-muted-foreground'> /project</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className='space-y-3 mb-6'>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Full-day coverage</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>5-10 minute edited video</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>4K quality + all RAW files</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Cinematic color grading</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>24-hour delivery</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Unlimited revisions</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Custom soundtrack</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Multi-format delivery</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Priority support</span>
                  </li>
                  <li className='flex items-start gap-2'>
                    <span className='text-green-600'>✓</span>
                    <span className='text-sm'>Dedicated project manager</span>
                  </li>
                </ul>
                <Button asChild variant='outline' className='w-full'>
                  <Link href='/services/video/request?package=premium'>Get Started</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className='text-center mt-8'>
            <p className='text-muted-foreground mb-4'>Need something custom?</p>
            <Button asChild variant='outline' size='lg'>
              <Link href='/contact'>Contact Us for Custom Quote</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className='py-16'>
        <div className='container mx-auto px-4'>
          <div className='text-center mb-12'>
            <h2 className='text-4xl font-bold mb-4'>Why Choose reveal UI?</h2>
          </div>

          <div className='grid gap-8 md:grid-cols-2 lg:grid-cols-4 max-w-6xl mx-auto'>
            <Card>
              <CardHeader className='text-center'>
                <div className='text-4xl mb-4'>🏆</div>
                <CardTitle>Proven Experience</CardTitle>
              </CardHeader>
              <CardContent className='text-center text-sm text-muted-foreground'>
                Years of filming combat sports and events. We know how to capture the action.
              </CardContent>
            </Card>

            <Card>
              <CardHeader className='text-center'>
                <div className='text-4xl mb-4'>[FAST]</div>
                <CardTitle>Fast Turnaround</CardTitle>
              </CardHeader>
              <CardContent className='text-center text-sm text-muted-foreground'>
                We deliver edited footage quickly without compromising quality.
              </CardContent>
            </Card>

            <Card>
              <CardHeader className='text-center'>
                <div className='text-4xl mb-4'>💎</div>
                <CardTitle>Professional Quality</CardTitle>
              </CardHeader>
              <CardContent className='text-center text-sm text-muted-foreground'>
                4K recording, professional editing, and color grading on every project.
              </CardContent>
            </Card>

            <Card>
              <CardHeader className='text-center'>
                <div className='text-4xl mb-4'>🔒</div>
                <CardTitle>Licensed & Insured</CardTitle>
              </CardHeader>
              <CardContent className='text-center text-sm text-muted-foreground'>
                FAA-certified pilots and full liability insurance for your peace of mind.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className='py-20 bg-gradient-to-b from-brand-red-600/10 to-background'>
        <div className='container mx-auto px-4'>
          <div className='max-w-3xl mx-auto text-center'>
            <h2 className='text-4xl font-bold mb-4'>Ready to Get Started?</h2>
            <p className='text-lg text-muted-foreground mb-8'>
              Request a free quote today and let's discuss your project. No obligation, just honest
              advice and competitive pricing.
            </p>
            <div className='flex gap-4 justify-center flex-wrap'>
              <Button asChild variant='UI' size='lg'>
                <Link href='/services/video/request'>Request Free Quote</Link>
              </Button>
              <Button asChild variant='outline' size='lg'>
                <Link href='/videos'>View Our Work</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export async function generateMetadata(): Promise<Metadata> {
  const meta = generateMeta({
    title: 'Professional Video Services - Drone & Ground Videography',
    description:
      'Professional aerial drone and ground-level videography for real estate, events, commercial projects, and more. Fast turnaround, competitive pricing, licensed and insured.',
    url: '/services/video',
    type: 'website',
  });

  return meta;
}
