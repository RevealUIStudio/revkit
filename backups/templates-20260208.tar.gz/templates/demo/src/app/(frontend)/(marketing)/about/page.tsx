import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'About - reveal UI',
  description:
    'Learn about reveal UI, a safe environment for organized combat sports and dispute resolution.',
};

export default function AboutPage() {
  return (
    <div className='pt-24 pb-24'>
      <div className='container mx-auto px-4'>
        {/* Hero Section */}
        <div className='text-center mb-16'>
          <h1 className='text-4xl font-bold mb-6'>About reveal UI</h1>
          <p className='text-xl text-muted-foreground max-w-3xl mx-auto'>
            A safe, controlled environment for settling disputes through organized combat sports. We
            provide a platform for fighters to showcase their skills and resolve conflicts in a
            structured manner.
          </p>
        </div>

        {/* Mission Section */}
        <section className='mb-16'>
          <div className='grid md:grid-cols-2 gap-12 items-center'>
            <div>
              <h2 className='text-3xl font-bold mb-6'>Our Mission</h2>
              <p className='text-lg text-muted-foreground mb-6'>
                reveal UI was founded with a simple mission: to provide a safe, controlled
                environment where disputes can be settled through organized combat sports. We
                believe in the power of structured competition to resolve conflicts and build
                respect.
              </p>
              <p className='text-lg text-muted-foreground mb-8'>
                Our facility is equipped with professional-grade equipment, trained medical staff,
                and strict safety protocols to ensure every match is conducted with the highest
                standards of safety and fairness.
              </p>
              <Button asChild variant='primary'>
                <Link href='/posts'>Read Our Stories</Link>
              </Button>
            </div>
            <div className='bg-elevation-100 rounded-lg p-8 border border-theme-border'>
              <h3 className='text-2xl font-bold mb-4'>Core Values</h3>
              <ul className='space-y-4'>
                <li className='flex items-start'>
                  <div className='w-2 h-2 bg-brand-red-600 rounded-full mt-2 mr-3 flex-shrink-0' />
                  <div>
                    <strong>Safety First:</strong> Every match is supervised with proper safety
                    measures
                  </div>
                </li>
                <li className='flex items-start'>
                  <div className='w-2 h-2 bg-brand-red-600 rounded-full mt-2 mr-3 flex-shrink-0' />
                  <div>
                    <strong>Fair Play:</strong> Clear rules and regulations ensure fair competition
                  </div>
                </li>
                <li className='flex items-start'>
                  <div className='w-2 h-2 bg-brand-red-600 rounded-full mt-2 mr-3 flex-shrink-0' />
                  <div>
                    <strong>Respect:</strong> Mutual respect between fighters and spectators
                  </div>
                </li>
                <li className='flex items-start'>
                  <div className='w-2 h-2 bg-brand-red-600 rounded-full mt-2 mr-3 flex-shrink-0' />
                  <div>
                    <strong>Community:</strong> Building a supportive community of fighters and fans
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className='mb-16'>
          <h2 className='text-3xl font-bold text-center mb-12'>What We Offer</h2>
          <div className='grid md:grid-cols-3 gap-8'>
            <Card>
              <CardHeader>
                <CardTitle>Professional Arena</CardTitle>
                <CardDescription>
                  State-of-the-art fighting arena with proper safety equipment and medical
                  facilities.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>• Professional-grade mats and equipment</li>
                  <li>• On-site medical staff</li>
                  <li>• Proper lighting and ventilation</li>
                  <li>• Spectator seating</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Organized Matches</CardTitle>
                <CardDescription>
                  Structured competitions with clear rules, weight classes, and fair judging.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>• Weight class divisions</li>
                  <li>• Professional referees</li>
                  <li>• Clear rules and regulations</li>
                  <li>• Fair judging system</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Community Events</CardTitle>
                <CardDescription>
                  Regular events, training sessions, and community gatherings for fighters and fans.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className='space-y-2 text-sm text-muted-foreground'>
                  <li>• Weekly fight nights</li>
                  <li>• Training sessions</li>
                  <li>• Community meetups</li>
                  <li>• Special events</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section className='bg-elevation-100 rounded-lg p-8 border border-theme-border'>
          <div className='text-center'>
            <h2 className='text-3xl font-bold mb-4'>Get in Touch</h2>
            <p className='text-theme-text opacity-80 mb-8'>
              Interested in joining the UI community? Contact us for more information.
            </p>
            <div className='grid md:grid-cols-3 gap-8 max-w-2xl mx-auto'>
              <div>
                <h3 className='font-semibold mb-2'>Email</h3>
                <p className='text-theme-text opacity-80'>
                  <a
                    href='mailto:info@reveal.com'
                    className='hover:text-brand-red-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-red-600 focus-visible:ring-offset-2 rounded-md'
                  >
                    info@reveal.com
                  </a>
                </p>
              </div>
              <div>
                <h3 className='font-semibold mb-2'>Phone</h3>
                <p className='text-theme-text opacity-80'>
                  <a
                    href='tel:+15551234567'
                    className='hover:text-brand-red-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-red-600 focus-visible:ring-offset-2 rounded-md'
                  >
                    (555) 123-4567
                  </a>
                </p>
              </div>
              <div>
                <h3 className='font-semibold mb-2'>Location</h3>
                <p className='text-theme-text opacity-80'>UI Arena</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
