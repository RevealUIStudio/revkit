import { generateMeta } from '@/config/system/utilities/generation.ts';
import { VideoRequestForm } from '@/presentation/components/media/VideoRequestForm';
import { Button } from '@/presentation/components/ui/primitives/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/presentation/components/ui/primitives/card';
import type { Metadata } from 'next';
import Link from 'next/link';

// Inherits revalidate: 3600 from (marketing)/layout.tsx

interface PageProps {
  searchParams: Promise<{
    package?: string;
  }>;
}

export default async function VideoRequestPage({ searchParams }: PageProps) {
  const params = await searchParams;

  return (
    <div className='min-h-screen bg-background'>
      {/* Hero Section */}
      <section className='py-12 bg-gradient-to-b from-brand-red-600/10 to-background'>
        <div className='container mx-auto px-4'>
          <div className='max-w-3xl mx-auto text-center'>
            <h1 className='text-4xl md:text-5xl font-bold mb-4'>Request a Video Quote</h1>
            <p className='text-lg text-muted-foreground'>
              Tell us about your project and we'll get back to you within 24 hours with a detailed
              quote.
            </p>
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className='py-8'>
        <div className='container mx-auto px-4'>
          <div className='grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto'>
            {/* Form */}
            <div className='lg:col-span-2'>
              <Card>
                <CardHeader>
                  <CardTitle>Project Details</CardTitle>
                  <CardDescription>
                    Fill out the form below and we'll provide a custom quote for your project.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <VideoRequestForm selectedPackage={params.package ?? ''} />
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className='lg:col-span-1'>
              {/* What to Expect */}
              <Card className='mb-6'>
                <CardHeader>
                  <CardTitle>What to Expect</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className='space-y-4 text-sm'>
                    <li className='flex items-start gap-3'>
                      <span className='text-2xl'>[1]</span>
                      <div>
                        <div className='font-semibold mb-1'>Submit Request</div>
                        <div className='text-muted-foreground'>
                          Fill out the form with your project details
                        </div>
                      </div>
                    </li>
                    <li className='flex items-start gap-3'>
                      <span className='text-2xl'>[2]</span>
                      <div>
                        <div className='font-semibold mb-1'>Get Quote (24hrs)</div>
                        <div className='text-muted-foreground'>
                          Receive a detailed quote via email
                        </div>
                      </div>
                    </li>
                    <li className='flex items-start gap-3'>
                      <span className='text-2xl'>[3]</span>
                      <div>
                        <div className='font-semibold mb-1'>Schedule Shoot</div>
                        <div className='text-muted-foreground'>
                          Choose your date and confirm booking
                        </div>
                      </div>
                    </li>
                    <li className='flex items-start gap-3'>
                      <span className='text-2xl'>[4]</span>
                      <div>
                        <div className='font-semibold mb-1'>Receive Footage</div>
                        <div className='text-muted-foreground'>
                          Get edited video delivered digitally
                        </div>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              {/* Pricing Reference */}
              <Card className='mb-6'>
                <CardHeader>
                  <CardTitle>Pricing Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='space-y-3 text-sm'>
                    <div className='flex justify-between items-center pb-2 border-b'>
                      <span className='font-semibold'>Starter</span>
                      <span className='text-brand-red-600'>$299</span>
                    </div>
                    <div className='flex justify-between items-center pb-2 border-b'>
                      <span className='font-semibold'>Professional</span>
                      <span className='text-brand-red-600'>$599</span>
                    </div>
                    <div className='flex justify-between items-center pb-2 border-b'>
                      <span className='font-semibold'>Premium</span>
                      <span className='text-brand-red-600'>$1,299</span>
                    </div>
                    <div className='flex justify-between items-center'>
                      <span className='font-semibold'>Custom</span>
                      <span className='text-muted-foreground'>Varies</span>
                    </div>
                  </div>
                  <div className='mt-4'>
                    <Button asChild variant='outline' className='w-full' size='sm'>
                      <Link href='/services/video'>View Full Pricing</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Need Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className='text-sm text-muted-foreground mb-4'>
                    Have questions? We're here to help!
                  </p>
                  <div className='space-y-2 text-sm'>
                    <div className='flex items-center gap-2'>
                      <span>[EMAIL]</span>
                      <a
                        href='mailto:video@reveal.com'
                        className='text-brand-red-600 hover:underline'
                      >
                        video@reveal.com
                      </a>
                    </div>
                    <div className='flex items-center gap-2'>
                      <span>📞</span>
                      <a href='tel:+15551234567' className='text-brand-red-600 hover:underline'>
                        (555) 123-4567
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export async function generateMetadata(): Promise<Metadata> {
  const meta = generateMeta({
    title: 'Request Video Quote - Professional Videography Services',
    description:
      'Request a free quote for professional drone and ground-level videography services. Fast response, competitive pricing.',
    url: '/services/video/request',
    type: 'website',
  });

  return meta;
}
