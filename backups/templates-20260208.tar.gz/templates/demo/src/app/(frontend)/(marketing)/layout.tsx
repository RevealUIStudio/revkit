import type { ReactNode } from 'react';

/**
 * Marketing Pages Layout
 *
 * Shared configuration for all marketing pages:
 * - About, Features, Pricing, Contact, Services
 *
 * These pages rarely change, so we use longer revalidation times
 * for optimal performance.
 */

// Static pages with 1-hour revalidation (marketing content changes infrequently)
export const revalidate = 3600;

export default function MarketingLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
