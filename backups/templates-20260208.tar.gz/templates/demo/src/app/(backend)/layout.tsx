import React from 'react';
import type { ServerFunctionClient } from "@revealui/content";
import { getRevealConfig } from "../../reveal.config";
import { importMap } from "./admin/importMap.js";

/* THIS FILE WAS GENERATED AUTOMATICALLY BY REVEALUI. */
/* DO NOT MODIFY IT BECAUSE IT COULD BE REWRITTEN AT ANY TIME. */

// Custom CSS is loaded via revealui.config.ts admin.css property
// DO NOT import CSS directly here - it breaks admin CSS extraction

type Args = {
	children: React.ReactNode;
};

const serverFunction: ServerFunctionClient = async function (args) {
	"use server";
	return {
		success: true,
		result: {
			config: await getRevealConfig(),
			importMap,
			args,
		},
	};
};

const Layout = async ({ children }: Args) => {
	const config = await getRevealConfig();

	return (
		<html>
			<body data-config={config?.revealui?.siteName ?? "RevealUI"}>
				{children}
			</body>
		</html>
	);
};

export default Layout;
