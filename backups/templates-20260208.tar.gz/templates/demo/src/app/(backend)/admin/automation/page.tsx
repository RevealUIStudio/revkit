/**
 * Automation Dashboard Page
 *
 * Admin page for monitoring automation logs and agent performance
 */

import AutomationDashboard from '@revealui/infrastructure/cms/admin/components/dashboards/AutomationDashboard';

export const metadata = {
  title: 'Automation Dashboard',
  description: 'Monitor automation logs, agent performance, and system health',
};

export default function AutomationDashboardPage() {
  return <AutomationDashboard />;
}
