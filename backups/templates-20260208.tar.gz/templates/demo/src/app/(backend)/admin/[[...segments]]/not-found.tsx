/* THIS FILE WAS GENERATED AUTOMATICALLY BY REVEALUI. */
/* DO NOT MODIFY IT BECAUSE IT COULD BE REWRITTEN AT ANY TIME. */

// Custom styling is handled via:
// 1. src/app/(backend)/admin/custom.css - For form styling
// 2. src/infrastructure/core/components/admin/BeforeLogin.tsx - For security notice

import { getRevealConfig } from "@/reveal.config";
import type { Metadata } from "next";

type Args = {
	params: Promise<{
		segments: string[];
	}>;
	searchParams: Promise<{
		[key: string]: string | string[];
	}>;
};

export const generateMetadata = async ({ params, searchParams }: Args): Promise<Metadata> => {
	const config = await getRevealConfig();
	const resolvedParams = await params;
	const resolvedSearch = await searchParams;
	return {
		title: config?.revealui?.siteName ?? "RevealUI Admin",
		openGraph: {
			title: config?.revealui?.siteName ?? "RevealUI Admin",
			url: resolvedParams?.segments?.join("/") ?? "",
		},
		other: { searchParams: JSON.stringify(resolvedSearch ?? {}) },
	};
};

const Page = async () => {
	return (
		<div className="flex min-h-screen items-center justify-center p-6">
			<div className="max-w-xl text-center">
				<p className="text-lg font-semibold">Admin page not found.</p>
				<p className="text-sm text-neutral-500">
					The requested admin route could not be located.
				</p>
			</div>
		</div>
	);
};

export default Page;

