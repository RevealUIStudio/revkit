/* THIS FILE WAS GENERATED AUTOMATICALLY BY REVEALUI. */
/* DO NOT MODIFY IT BECAUSE IT COULD BE REWRITTEN AT ANY TIME. */

// Custom styling is handled via:
// 1. src/app/(backend)/admin/custom.css - For form styling
// 2. src/infrastructure/core/components/admin/BeforeLogin.tsx - For security notice

import { getRevealConfig } from "@/reveal.config";
import type { Metadata } from "next";
import { importMap } from "../importMap";

type Args = {
	params: Promise<{
		segments: string[];
	}>;
	searchParams: Promise<{
		[key: string]: string | string[];
	}>;
};

export const generateMetadata = async ({ params, searchParams }: Args): Promise<Metadata> => {
	const config = await getRevealConfig();
	const resolvedParams = await params;
	const resolvedSearch = await searchParams;
	return {
		title: config?.revealui?.siteName ?? "RevealUI Admin",
		openGraph: {
			title: config?.revealui?.siteName ?? "RevealUI Admin",
			url: resolvedParams?.segments?.join("/") ?? "",
		},
		other: { searchParams: JSON.stringify(resolvedSearch ?? {}) },
	};
};

const Page = async ({ params, searchParams }: Args) => {
	const config = await getRevealConfig();
	const resolvedParams = await params;
	const resolvedSearch = await searchParams;
	return (
		<div className="min-h-screen p-6">
			<p className="text-lg font-semibold">Create first user</p>
			<p className="text-sm text-neutral-500">
				Config: {config?.revealui?.siteName ?? "RevealUI"} • Params:{" "}
				{JSON.stringify(resolvedParams?.segments ?? [])}
			</p>
			<p className="text-xs text-neutral-400">
				Query: {JSON.stringify(resolvedSearch ?? {})} • Import map keys: {Object.keys(importMap).join(", ")}
			</p>
		</div>
	);
};

export default Page;
