/**
 * RevealUI Content Engine Admin Layout
 *
 * Imports Tailwind CSS 4 theming for the admin panel
 * This layout wraps all admin routes and ensures styling is applied
 * 
 * NOTE: This file is in the auto-generated (backend) folder but is necessary
 * for Next.js App Router layout customization. RevealUI Content Engine typically only
 * generates files in subdirectories (e.g., [[...segments]], create-first-user),
 * so this root-level layout.tsx should be safe from regeneration.
 * 
 * However, monitor RevealUI Content Engine updates - if regeneration starts overwriting
 * this file, move CSS imports to admin-config.ts or use RevealUI Content Engine component
 * injection instead.
 */

import React from 'react';
import '@/app/(backend)/admin/revealStyles.css';
import { ThemeDetector } from './theme-detector';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <ThemeDetector />
      {children}
    </>
  );
}


