/**
 * MCP Comparison Dashboard
 *
 * Admin page showing Reveal MCP vs Standard MCP comparison
 */

'use client';

import { ComparisonChart, ComparisonTable } from '@revealui/mcp/analytics';
import type { ComparisonResult } from '@revealui/mcp/analytics';
import React, { useEffect, useState } from 'react';

export default function MCPComparisonPage() {
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchComparison();
  }, []);

  async function fetchComparison() {
    try {
      setLoading(true);
      const response = await fetch('/api/mcp/comparison?format=gtm');
      if (!response.ok) {
        throw new Error('Failed to fetch comparison');
      }
      const data = await response.json();
      setComparison(data.summary);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className='flex items-center justify-center min-h-screen'>
        <div className='text-center'>
          <div className='animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto'></div>
          <p className='mt-4 text-gray-600'>Loading comparison data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className='flex items-center justify-center min-h-screen'>
        <div className='text-center'>
          <p className='text-red-600'>Error: {error}</p>
          <button
            type='button'
            onClick={fetchComparison}
            className='mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600'
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!comparison) {
    return (
      <div className='flex items-center justify-center min-h-screen'>
        <p className='text-gray-600'>No comparison data available</p>
      </div>
    );
  }

  return (
    <div className='container mx-auto px-4 py-8'>
      <div className='mb-8'>
        <h1 className='text-3xl font-bold mb-2'>Reveal MCP vs Standard MCP</h1>
        <p className='text-gray-600'>
          Comprehensive comparison showing performance, cost, and business impact
        </p>
      </div>

      <div className='mb-8'>
        <ComparisonChart comparison={comparison} />
      </div>

      <div className='mb-8'>
        <h2 className='text-2xl font-bold mb-4'>Detailed Comparison</h2>
        <ComparisonTable comparison={comparison} />
      </div>

      <div className='bg-white dark:bg-gray-800 rounded-lg shadow p-6'>
        <h2 className='text-2xl font-bold mb-4'>Key Takeaways</h2>
        <ul className='space-y-2'>
          <li className='flex items-start'>
            <span className='text-green-500 mr-2'>✓</span>
            <span>
              <strong>{comparison.improvements.responseTimeImprovement.toFixed(1)}%</strong> faster
              response times
            </span>
          </li>
          <li className='flex items-start'>
            <span className='text-green-500 mr-2'>✓</span>
            <span>
              <strong>{comparison.improvements.costReduction.toFixed(1)}%</strong> cost reduction
            </span>
          </li>
          <li className='flex items-start'>
            <span className='text-green-500 mr-2'>✓</span>
            <span>
              <strong>{comparison.improvements.timeSavings.toFixed(1)} hours</strong> saved per
              month
            </span>
          </li>
          <li className='flex items-start'>
            <span className='text-green-500 mr-2'>✓</span>
            <span>
              <strong>${comparison.improvements.revenueImpact.toFixed(2)}</strong> monthly revenue
              impact
            </span>
          </li>
          <li className='flex items-start'>
            <span className='text-green-500 mr-2'>✓</span>
            <span>
              <strong>{comparison.improvements.roi.toFixed(0)}%</strong> ROI
            </span>
          </li>
        </ul>
      </div>
    </div>
  );
}
