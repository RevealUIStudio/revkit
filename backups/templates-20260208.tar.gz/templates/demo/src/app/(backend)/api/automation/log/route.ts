import { getRevealConfig } from '@/reveal.config';
import { logAutomationEvent } from '@revealui/mcp';
import { getRateLimiterService } from '@revealui/core/security';
import { NextResponse } from 'next/server';
import { getRevealUI } from '@revealui/content';

export async function POST(request: Request) {
  // Rate limiting: 100 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`automation:log:${ip}`, 100, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        success: false,
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '100',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  try {
    const revealuiInstance = await getRevealUI({ config: await getRevealConfig() });
    const { user } = await revealuiInstance.auth();

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    await logAutomationEvent({
      agent: body?.agent ?? 'unknown',
      action: body?.action ?? 'trigger',
      source: body?.source,
      revealui: body?.revealui,
      status: body?.status,
      errorMessage: body?.errorMessage,
      req: request,
      user,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 400 }
    );
  }
}
