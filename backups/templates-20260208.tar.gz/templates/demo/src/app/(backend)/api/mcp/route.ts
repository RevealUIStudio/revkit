import { getRateLimiterService } from '@revealui/core/security';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

// Minimal MCP-like endpoint for demo
// POST /api/mcp with { tool: string, params: object }
// GET /api/mcp returns available tools

export async function GET(request: NextRequest) {
  // Rate limiting: 100 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:get:${ip}`, 100, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '100',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }
  return NextResponse.json({
    server: 'revealui-mcp-demo',
    tools: [
      {
        name: 'echo',
        description: 'Echo parameters back to the caller',
        params: { type: 'object' },
      },
      {
        name: 'rfa-converge',
        description: 'Execute intelligence convergence using the Resonance Field Algorithm (RFA)',
        params: {
          type: 'object',
          properties: {
            intelligences: { type: 'array', description: 'Array of intelligence configurations' },
            objective: { type: 'string', description: 'Convergence objective' },
            maxIterations: { type: 'number', default: 20 }
          }
        }
      },
      {
        name: 'rfa-get-templates',
        description: 'Get available intelligence templates for RFA convergence',
        params: { type: 'object' }
      },
      {
        name: 'rfa-batch-converge',
        description: 'Execute batch convergence operations for multiple objectives',
        params: {
          type: 'object',
          properties: {
            intelligences: { type: 'array' },
            objectives: { type: 'array', items: { type: 'string' } }
          }
        }
      }
    ],
    integrations: {
      rfa: {
        endpoint: '/api/mcp/rfa',
        description: 'Enhanced Resonance Field Algorithm for physics-grounded intelligence convergence',
        physics: 'Based on vacuum fluctuation correlation functions and geometric confinement'
      }
    }
  });
}

export async function POST(req: NextRequest) {
  // Rate limiting: 50 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:post:${ip}`, 50, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        ok: false,
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '50',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  const body = (await req.json()) as { tool?: string; params?: unknown };
  switch (body.tool) {
    case 'echo':
      return NextResponse.json({ ok: true, result: body.params ?? null });
    default:
      return NextResponse.json({ ok: false, error: 'Unknown tool' }, { status: 400 });
  }
}
