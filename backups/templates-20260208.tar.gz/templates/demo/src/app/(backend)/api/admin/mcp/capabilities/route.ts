/**
 * Admin API for MCP Capability Management
 */

import { createLogger } from '@/config/infrastructure/integrations/logging';
import { NextRequest, NextResponse } from 'next/server';

const logger = createLogger('mcp-capabilities-api');

/**
 * GET /api/admin/mcp/capabilities
 * Get capability state
 */
export async function GET() {
  try {
    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    const state = mcpServer.getCapabilityState();
    return NextResponse.json(state);
  } catch (error) {
    logger.error('GET /api/admin/mcp/capabilities error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/mcp/capabilities/enable
 * Enable a capability
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { capability, action } = body;

    if (!capability) {
      return NextResponse.json(
        { error: 'Capability name is required' },
        { status: 400 }
      );
    }

    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    if (action === 'enable') {
      await mcpServer.enableCapability(capability);
      return NextResponse.json({
        success: true,
        message: `Capability "${capability}" enabled`,
      });
    } else if (action === 'disable') {
      await mcpServer.disableCapability(capability);
      return NextResponse.json({
        success: true,
        message: `Capability "${capability}" disabled`,
      });
    } else {
      return NextResponse.json(
        { error: 'Action must be "enable" or "disable"' },
        { status: 400 }
      );
    }
  } catch (error) {
    logger.error('POST /api/admin/mcp/capabilities error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

