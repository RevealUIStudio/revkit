import { getRateLimiterService } from '@revealui/core/security';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

type Lead = { email: string };

// In-memory simulated queue + status store (demo-only)
const jobStatus: Record<string, { total: number; processed: number }> = {};

async function processBatch(jobId: string, leads: Lead[]) {
  for (const lead of leads) {
    // Simulate async work per lead
    await new Promise(r => setTimeout(r, 150));
    jobStatus[jobId].processed += 1;
  }
}

export async function POST(req: NextRequest) {
  // Rate limiting: 20 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`queues:lead-enrichment:${ip}`, 20, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '20',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  const { leads } = (await req.json()) as { leads: Lead[] };
  if (!Array.isArray(leads) || leads.length === 0) {
    return NextResponse.json({ error: 'No leads provided' }, { status: 400 });
  }
  const jobId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  jobStatus[jobId] = { total: leads.length, processed: 0 };
  // Fire-and-forget background processing (demo). Replace with Vercel Queues consumer.
  processBatch(jobId, leads).catch(() => void 0);
  return NextResponse.json({ jobId, accepted: leads.length });
}

export async function GET(req: NextRequest) {
  // Rate limiting: 100 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(
    `queues:lead-enrichment:get:${ip}`,
    100,
    60000
  );

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '100',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  const jobId = req.nextUrl.searchParams.get('jobId') ?? '';
  if (!jobId || !jobStatus[jobId]) {
    return NextResponse.json({ error: 'Unknown jobId' }, { status: 404 });
  }
  return NextResponse.json({ jobId, ...jobStatus[jobId] });
}
