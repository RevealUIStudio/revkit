/**
 * Admin API for MCP Resource Management
 */

import { createLogger } from '@/config/infrastructure/integrations/logging';
import { NextRequest, NextResponse } from 'next/server';

const logger = createLogger('mcp-resources-api');

/**
 * GET /api/admin/mcp/resources
 * List all registered resources
 */
export async function GET() {
  try {
    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    const result = mcpServer.listResources();
    return NextResponse.json(result);
  } catch (error) {
    logger.error('GET /api/admin/mcp/resources error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/mcp/resources
 * Register a new resource
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.uri || !body.name || !body.mimeType || !body.source) {
      return NextResponse.json(
        { error: 'Invalid resource definition' },
        { status: 400 }
      );
    }

    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    mcpServer.registerResource(body);

    return NextResponse.json({
      success: true,
      message: `Resource "${body.uri}" registered`,
    });
  } catch (error) {
    logger.error('POST /api/admin/mcp/resources error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/mcp/resources
 * Unregister a resource
 */
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const uri = searchParams.get('uri');

    if (!uri) {
      return NextResponse.json(
        { error: 'Resource URI is required' },
        { status: 400 }
      );
    }

    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    mcpServer.unregisterResource(uri);

    return NextResponse.json({
      success: true,
      message: `Resource "${uri}" unregistered`,
    });
  } catch (error) {
    logger.error('DELETE /api/admin/mcp/resources error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

