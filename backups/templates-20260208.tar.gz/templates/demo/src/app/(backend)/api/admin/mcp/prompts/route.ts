/**
 * Admin API for MCP Prompt Management
 */

import { createLogger } from '@/config/infrastructure/integrations/logging';
import { NextRequest, NextResponse } from 'next/server';

const logger = createLogger('mcp-prompts-api');

/**
 * GET /api/admin/mcp/prompts
 * List all registered prompts
 */
export async function GET() {
  try {
    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    const result = mcpServer.listPrompts();
    return NextResponse.json(result);
  } catch (error) {
    logger.error('GET /api/admin/mcp/prompts error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/mcp/prompts
 * Register a new prompt
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.name || !body.description || !Array.isArray(body.arguments) || !Array.isArray(body.messages)) {
      return NextResponse.json(
        { error: 'Invalid prompt definition' },
        { status: 400 }
      );
    }

    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    mcpServer.registerPrompt(body);

    return NextResponse.json({
      success: true,
      message: `Prompt "${body.name}" registered`,
    });
  } catch (error) {
    logger.error('POST /api/admin/mcp/prompts error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/mcp/prompts
 * Unregister a prompt
 */
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const name = searchParams.get('name');

    if (!name) {
      return NextResponse.json(
        { error: 'Prompt name is required' },
        { status: 400 }
      );
    }

    const { getMCPServerFromRevealUI } = await import('@revealui/mcp/bridge/RevealUIMCPService');
    const mcpServer = await getMCPServerFromRevealUI();

    if (!mcpServer) {
      return NextResponse.json(
        { error: 'MCP server not available' },
        { status: 503 }
      );
    }

    mcpServer.unregisterPrompt(name);

    return NextResponse.json({
      success: true,
      message: `Prompt "${name}" unregistered`,
    });
  } catch (error) {
    logger.error('DELETE /api/admin/mcp/prompts error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}

