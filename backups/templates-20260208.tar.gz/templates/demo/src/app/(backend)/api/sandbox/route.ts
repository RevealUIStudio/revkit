import { getRateLimiterService } from '@revealui/core/security';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

// Demo endpoint to illustrate where Vercel Sandbox integration would live.
// For safety in this repo, we DO NOT execute arbitrary code. We echo inputs.

export async function POST(req: NextRequest) {
  // Rate limiting: 10 requests per minute per IP (strict for sandbox)
  const rateLimiter = getRateLimiterService();
  const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`sandbox:${ip}`, 10, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        ok: false,
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '10',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  const { code, input } = (await req.json()) as { code?: string; input?: unknown };
  // In production with Vercel Sandbox, you would:
  // 1) Create a sandbox with desired runtime
  // 2) Mount code or repo and execute safely
  // 3) Stream logs/output back
  return NextResponse.json({
    ok: true,
    message: 'Sandbox disabled in demo mode. Echoing inputs only.',
    code: code ?? null,
    input: input ?? null,
  });
}
