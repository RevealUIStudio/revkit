/**
 * MCP Comparison API
 *
 * Provides comparison data between Standard MCP and Reveal MCP
 */

import { type ComparisonConfig, ComparisonService } from '@revealui/mcp/analytics/server';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

// Singleton instance
let comparisonService: ComparisonService | null = null;

function getComparisonService(): ComparisonService {
  if (!comparisonService) {
    const config: ComparisonConfig = {
      standardMCPCostPerRequest: 0.001, // $0.001 per request
      revealMCPCostPerRequest: 0.0005, // $0.0005 per request (50% cheaper)
      developerHourlyRate: 100, // $100/hour
      revenuePerHourSaved: 200, // $200/hour (2x developer rate for revenue impact)
    };
    comparisonService = new ComparisonService(config);
  }
  return comparisonService;
}

/**
 * GET /api/mcp/comparison
 *
 * Get comparison report
 */
export async function GET(request: NextRequest) {
  // Rate limiting: 60 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:comparison:get:${ip}`, 60, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '60',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  try {
    const service = getComparisonService();
    const searchParams = request.nextUrl.searchParams;
    const format = searchParams.get('format') || 'summary';

    if (format === 'gtm') {
      // Full GTM report
      const report = service.exportGTMReport();
      return NextResponse.json(report);
    }
    if (format === 'historical') {
      // Historical data
      const days = Number.parseInt(searchParams.get('days') || '30', 10);
      const historical = service.getHistoricalComparison(days);
      return NextResponse.json({ historical });
    }
    // Summary comparison
    const comparison = service.generateComparison();
    return NextResponse.json(comparison);
  } catch (error) {
    console.error('Failed to generate comparison:', error);
    return NextResponse.json({ error: 'Failed to generate comparison' }, { status: 500 });
  }
}

/**
 * POST /api/mcp/comparison
 *
 * Record metrics
 */
export async function POST(request: NextRequest) {
  // Rate limiting: 30 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:comparison:post:${ip}`, 30, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '30',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  try {
    const service = getComparisonService();
    const body = await request.json();
    const { type, metrics } = body;

    if (type === 'standard') {
      service.recordStandardMCP(metrics);
      return NextResponse.json({ success: true, message: 'Standard MCP metrics recorded' });
    }
    if (type === 'reveal') {
      service.recordRevealMCP(metrics);
      return NextResponse.json({ success: true, message: 'Reveal MCP metrics recorded' });
    }
    return NextResponse.json(
      { error: 'Invalid type. Use "standard" or "reveal"' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Failed to record metrics:', error);
    return NextResponse.json({ error: 'Failed to record metrics' }, { status: 500 });
  }
}
