/**
 * RFA MCP Documentation Endpoint
 *
 * Provides comprehensive API documentation for the Resonance Field Algorithm MCP integration
 */

import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({
    title: 'Resonance Field Algorithm (RFA) MCP API Documentation',
    version: '1.0.0',
    description: 'Physics-grounded intelligence convergence through vacuum fluctuation correlation functions',
    physics: {
      foundation: 'Based on "Extending Einstein-Rosen\'s Geometric Vision" by Haramein et al.',
      validations: [
        'Hawking Temperature Validation',
        'Klein-Gordon Geometric Confinement',
        'Multi-Scale Screening Mechanisms',
        'Vacuum Correlation Resonance Signatures'
      ]
    },
    endpoints: {
      '/api/mcp/rfa': {
        get: {
          description: 'List available RFA tools and capabilities',
          response: {
            server: 'revealui-rfa-mcp',
            tools: ['Array of available tools with schemas'],
            capabilities: {
              streaming: true,
              batch: true,
              async: true,
              physicsValidation: true
            }
          }
        },
        post: {
          description: 'Execute RFA operations via JSON-RPC 2.0',
          request: {
            jsonrpc: '2.0',
            method: 'tools/call',
            params: {
              name: 'tool_name',
              arguments: { /* tool-specific arguments */ }
            },
            id: 'request_id'
          }
        }
      },
      '/api/mcp/rfa/stream': {
        get: {
          description: 'Server-Sent Events for real-time convergence monitoring',
          parameters: {
            sessionId: 'Unique convergence session identifier',
            intelligences: 'JSON-encoded intelligence configurations',
            objective: 'Convergence objective description',
            maxIterations: 'Maximum iterations (default: 20)'
          },
          events: [
            { type: 'connection', description: 'Stream established' },
            { type: 'phase_transition', description: 'Phase change in convergence' },
            { type: 'iteration_progress', description: 'Real-time iteration updates' },
            { type: 'convergence_complete', description: 'Final results' },
            { type: 'error', description: 'Error occurred' }
          ]
        }
      },
      '/api/mcp/rfa/webhook': {
        post: {
          description: 'Submit asynchronous convergence job',
          request: {
            intelligences: 'Array of intelligence configurations',
            objective: 'Convergence objective',
            maxIterations: 'Maximum iterations (default: 20)',
            webhookUrl: 'Optional callback URL for notifications',
            callbackData: 'Optional data to include in webhook'
          }
        },
        get: {
          description: 'Check status of async convergence job',
          parameters: {
            jobId: 'Job identifier from POST response'
          }
        }
      }
    },
    tools: {
      'rfa-converge': {
        description: 'Execute intelligence convergence with custom intelligences and objectives',
        parameters: {
          intelligences: {
            type: 'array',
            minItems: 2,
            items: {
              type: 'object',
              properties: {
                id: { type: 'string', description: 'Unique identifier' },
                type: { type: 'string', enum: ['human', 'ai', 'hybrid'] },
                name: { type: 'string', description: 'Display name' },
                trustVector: {
                  type: 'array',
                  items: { type: 'number', minimum: 0, maximum: 1 },
                  minItems: 4,
                  maxItems: 4,
                  description: '[connection, trust, curiosity, support]'
                },
                capabilities: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'List of capabilities'
                }
              }
            }
          },
          objective: { type: 'string', description: 'Convergence objective' },
          maxIterations: { type: 'number', minimum: 5, maximum: 50, default: 20 },
          stream: { type: 'boolean', default: false, description: 'Enable streaming updates' }
        },
        response: {
          convergence: {
            coherence: 'Field coherence measure (0-1)',
            convergenceScore: 'Trust relationship strength (0-1)',
            hawkingValidation: 'Thermodynamic consistency (0-1)',
            totalIterations: 'Iterations executed',
            finalPhase: 'Final screening phase reached'
          },
          collaborativeOutput: 'Generated collaborative insights',
          intelligenceEvolution: 'How intelligences evolved during convergence',
          physics: 'Physics validation results'
        }
      },
      'rfa-get-templates': {
        description: 'Retrieve available intelligence templates',
        parameters: {
          type: { type: 'string', enum: ['human', 'ai', 'hybrid', 'all'], default: 'all' }
        }
      },
      'rfa-get-objectives': {
        description: 'Retrieve available convergence objectives',
        parameters: {
          complexity: { type: 'string', enum: ['Low', 'Medium', 'High', 'all'], default: 'all' }
        }
      },
      'rfa-batch-converge': {
        description: 'Execute batch convergence across multiple objectives',
        parameters: {
          intelligences: 'Array of intelligence configurations',
          objectives: 'Array of objective descriptions',
          maxIterations: 'Maximum iterations per convergence'
        }
      },
      'rfa-validate-physics': {
        description: 'Validate convergence results against fundamental physics',
        parameters: {
          convergenceResult: 'Previous convergence result to validate',
          validationLevel: { type: 'string', enum: ['basic', 'comprehensive'], default: 'comprehensive' }
        }
      }
    },
    authentication: {
      method: 'Bearer token or API key',
      header: 'Authorization: Bearer <token>',
      environment: 'MCP_RFA_API_KEY or MCP_API_KEY'
    },
    examples: {
      basic_convergence: {
        jsonrpc: '2.0',
        method: 'tools/call',
        params: {
          name: 'rfa-converge',
          arguments: {
            intelligences: [
              {
                id: 'researcher',
                type: 'human',
                name: 'Research Scientist',
                trustVector: [0.9, 0.95, 0.9, 0.85],
                capabilities: ['hypothesis_generation', 'data_analysis', 'critical_thinking']
              },
              {
                id: 'analyzer',
                type: 'ai',
                name: 'Data Processor',
                trustVector: [0.8, 0.85, 0.7, 0.75],
                capabilities: ['statistical_modeling', 'pattern_recognition', 'predictive_analytics']
              }
            ],
            objective: 'Develop a comprehensive strategy for global climate change mitigation',
            maxIterations: 25
          }
        },
        id: 'example-1'
      },
      streaming_convergence: {
        url: '/api/mcp/rfa/stream?sessionId=session_123&intelligences=[{"id":"ai1","type":"ai","trustVector":[0.8,0.9,0.7,0.8],"capabilities":["analysis","synthesis"]}]&objective=Solve%20quantum%20gravity%20unification&maxIterations=30'
      },
      webhook_job: {
        method: 'POST',
        url: '/api/mcp/rfa/webhook',
        body: {
          intelligences: [
            {
              id: 'expert',
              type: 'hybrid',
              trustVector: [0.95, 0.98, 0.92, 0.96],
              capabilities: ['interdisciplinary_synthesis', 'innovation_acceleration']
            }
          ],
          objective: 'Design breakthrough renewable energy technologies',
          webhookUrl: 'https://your-app.com/webhook/rfa-callback'
        }
      }
    },
    physics: {
      foundation: 'Vacuum Fluctuation Correlation Functions',
      paper: 'Haramein et al. - Extending Einstein-Rosen\'s Geometric Vision',
      validations: {
        hawking_temperature: 'Thermodynamic consistency at event horizons',
        geometric_confinement: 'Klein-Gordon solutions for Yukawa potentials',
        screening_mechanisms: 'Multi-scale vacuum energy transformations',
        correlation_functions: 'Quantum vacuum interference patterns'
      },
      scales: ['Planck', 'Compton', 'Proton', 'Macroscopic'],
      phases: ['Bose', 'Bose-Fermi HD', 'Bose-Fermi LD', 'Fermi']
    },
    rate_limits: {
      'GET /api/mcp/rfa': '30 requests/minute',
      'POST /api/mcp/rfa': '20 requests/minute',
      'GET /api/mcp/rfa/stream': '5 connections/minute',
      'POST /api/mcp/rfa/webhook': '10 requests/minute'
    }
  });
}