import { requireUser } from '@/app/actions/automation';
import { executeAutomationTrigger, logAutomationEvent } from '@revealui/mcp';
import { getRateLimiterService } from '@revealui/core/security';

type SupportedAgent = 'faq' | 'launchkit';

export async function POST(request: Request) {
  // Rate limiting: 30 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`automation:run:${ip}`, 30, 60000);

  if (!rateLimitResult.allowed) {
    return Response.json(
      {
        error: 'Rate limit exceeded',
        success: false,
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '30',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  let currentUser: { id?: string | number | null; email?: string | null } | null = null;

  try {
    const auth = await requireUser(request);
    currentUser = auth.user ?? null;

    if (!currentUser) {
      return Response.json({ error: 'Authentication required', success: false }, { status: 401 });
    }

    const body = await request.json();
    const agent = body?.agent as SupportedAgent | undefined;

    if (!agent || !['faq', 'launchkit'].includes(agent)) {
      return Response.json(
        { error: 'Unsupported automation agent', success: false },
        { status: 400 }
      );
    }

    const revealui = typeof body?.revealui === 'object' && body?.revealui !== null ? body.revealui : {};
    const source = (body?.source as 'portal' | 'cli' | 'api' | 'other') ?? 'portal';

    const response = await executeAutomationTrigger({
      agent,
      revealui,
      request,
      source,
      user: currentUser,
    });

    return Response.json({ data: response.data, success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';

    await logAutomationEvent({
      action: 'automation-run',
      agent: 'AutomationExecutor',
      errorMessage: message,
      req: request,
      source: 'portal',
      status: 'error',
      user: currentUser,
    }).catch(() => {});

    return Response.json({ error: message, success: false }, { status: 400 });
  }
}
