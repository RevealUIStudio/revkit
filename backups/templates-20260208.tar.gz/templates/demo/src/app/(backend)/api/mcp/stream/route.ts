/**
 * MCP SSE Streaming Endpoint
 */

import { createLogger } from '@/config/infrastructure/integrations/logging';
import { NextRequest } from 'next/server';

const logger = createLogger('mcp-stream-api');

/**
 * GET /api/mcp/stream
 * SSE endpoint for streaming MCP responses
 */
export async function GET(request: NextRequest) {
  try {
    // Import SSE transport
    const { SSETransport } = await import('@revealui/mcp/transport/SSETransport');
    const transport = new SSETransport();

    // Create stream
    const stream = transport.createStream(
      () => {
        logger.info('SSE connection established');
      },
      () => {
        logger.info('SSE connection closed');
      }
    );

    // Return SSE response
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    logger.error('GET /api/mcp/stream error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return new Response(
      JSON.stringify({ error: 'Failed to create SSE stream' }),
      { status: 500 }
    );
  }
}

/**
 * POST /api/mcp/stream
 * Send message to SSE stream
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate message format
    if (!body.event && !body.data) {
      return new Response(
        JSON.stringify({ error: 'Invalid SSE message format' }),
        { status: 400 }
      );
    }

    logger.info('SSE message sent', { event: body.event });

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200 }
    );
  } catch (error) {
    logger.error('POST /api/mcp/stream error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return new Response(
      JSON.stringify({ error: 'Failed to send SSE message' }),
      { status: 500 }
    );
  }
}

