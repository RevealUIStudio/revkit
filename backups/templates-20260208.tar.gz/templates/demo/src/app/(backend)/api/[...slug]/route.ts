

/* THIS FILE WAS GENERATED AUTOMATICALLY BY REVEALUI. */
/* DO NOT MODIFY IT BECAUSE IT COULD BE REWRITTEN AT ANY TIME. */

import type { NextRequest } from "next/server";

import config from "@/reveal.config";

const REST_GET = async (request: NextRequest) =>
	Response.json({ ok: true, path: request.nextUrl.pathname });
const REST_POST = REST_GET;
const REST_DELETE = REST_GET;
const REST_PATCH = REST_GET;
const REST_PUT = REST_GET;
const REST_OPTIONS = REST_GET;

export const GET = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_GET(request, { params, config });

export const POST = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_POST(request, { params, config });

export const DELETE = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_DELETE(request, { params, config });

export const PATCH = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_PATCH(request, { params, config });

export const PUT = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_PUT(request, { params, config });

export const OPTIONS = (
	request: NextRequest,
	{ params }: { params: Promise<{ slug: string[] }> },
) => REST_OPTIONS(request, { params, config });