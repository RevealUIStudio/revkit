/**
 * RevealUI Content Engine MCP API Route
 *
 * Provides external access to RevealUI Content Engine collections via Model Context Protocol
 * Supports JSON-RPC 2.0 protocol for tool discovery and execution
 */

import { getEnvVarWithFallback } from '@/config/presentation/environment';
import {
  handleJSONRPCRequest,
  listTools,
} from '@revealui/infrastructure/cms/plugins/revealui/mcp/mcp-server';
import type { MCPToolCall } from '@revealui/infrastructure/cms/plugins/revealui/mcp/types';
import { createServiceLogger } from '@revealui/infrastructure';
import { getRateLimiterService } from '@revealui/core/security';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { getRevealUI } from '@revealui/content';

const logger = createServiceLogger('mcp-api-route');

/**
 * Authenticate request using API key
 */
function authenticateRequest(request: NextRequest): { authenticated: boolean; userId?: string } {
  const apiKey = getEnvVarWithFallback('MCP_API_KEY', '');

  if (!apiKey) {
    return { authenticated: false };
  }

  const authHeader = request.headers.get('authorization');
  if (!authHeader) {
    return { authenticated: false };
  }

  // Support both "Bearer <token>" and direct API key
  const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7) : authHeader;

  if (token !== apiKey) {
    return { authenticated: false };
  }

  // For now, external API key access doesn't have a specific user
  // In the future, we could map API keys to users
  return { authenticated: true };
}

/**
 * Log MCP operation to audit log
 */
async function logMCPOperation(
  operation: string,
  toolName: string,
  status: 'success' | 'error',
  errorMessage?: string,
  userId?: string
): Promise<void> {
  try {
    const revealui = await getRevealUI();

    await revealui.create({
      collection: 'mcp-automation-logs',
      data: {
        agent: 'RevealUI Content Engine MCP Plugin',
        action: `${operation}: ${toolName}`,
        userId: userId || undefined,
        status: status === 'success' ? 'success' : 'error',
        errorMessage,
        source: 'api',
        revealui: {
          tool: toolName,
          operation,
        },
      },
    });
  } catch (error) {
    // Don't fail the request if audit logging fails
    logger.warn('Failed to log MCP operation', {
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

/**
 * GET /api/mcp/revealui
 * List available tools
 */
export async function GET(request: NextRequest) {
  // Rate limiting: 60 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:revealui:get:${ip}`, 60, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        jsonrpc: '2.0',
        error: {
          code: -32000,
          message: 'Rate limit exceeded',
          data: {
            retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
          },
        },
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '60',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  try {
    // Check authentication
    const auth = authenticateRequest(request);
    if (!auth.authenticated) {
      return NextResponse.json(
        { error: 'Unauthorized', message: 'Invalid or missing API key' },
        { status: 401 }
      );
    }

    // Get tools
    const tools = listTools();

    return NextResponse.json({
      jsonrpc: '2.0',
      result: {
        tools: tools.map(tool => ({
          name: tool.name,
          description: tool.description,
          inputSchema: tool.inputSchema,
        })),
      },
    });
  } catch (error) {
    logger.error('GET /api/mcp/revealui error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      {
        jsonrpc: '2.0',
        error: {
          code: -32603,
          message: 'Internal error',
        },
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/mcp/revealui
 * Execute JSON-RPC 2.0 requests
 */
export async function POST(request: NextRequest) {
  // Rate limiting: 40 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`mcp:revealui:post:${ip}`, 40, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        jsonrpc: '2.0',
        error: {
          code: -32000,
          message: 'Rate limit exceeded',
          data: {
            retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
          },
        },
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '40',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }

  try {
    // Check authentication
    const auth = authenticateRequest(request);
    if (!auth.authenticated) {
      return NextResponse.json(
        {
          jsonrpc: '2.0',
          error: {
            code: -32000,
            message: 'Unauthorized',
          },
        },
        { status: 401 }
      );
    }

    // Parse request body
    const body = await request.json();

    // Validate JSON-RPC 2.0 format
    if (body.jsonrpc !== '2.0' || !body.method) {
      return NextResponse.json(
        {
          jsonrpc: '2.0',
          id: body.id,
          error: {
            code: -32600,
            message: 'Invalid Request',
          },
        },
        { status: 400 }
      );
    }

    // Handle request
    const response = await handleJSONRPCRequest(body, auth.userId);

    // Log operation
    const toolName =
      body.method === 'tools/call'
        ? (body.params as MCPToolCall | undefined)?.name || 'unknown'
        : body.method;

    await logMCPOperation(
      body.method,
      toolName,
      response.error ? 'error' : 'success',
      response.error?.message,
      auth.userId
    );

    return NextResponse.json(response);
  } catch (error) {
    logger.error('POST /api/mcp/revealui error', {
      error: error instanceof Error ? error.message : String(error),
    });

    return NextResponse.json(
      {
        jsonrpc: '2.0',
        error: {
          code: -32603,
          message: error instanceof Error ? error.message : 'Internal error',
        },
      },
      { status: 500 }
    );
  }
}
