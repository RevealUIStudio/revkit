import { getRateLimiterService } from '@revealui/core/security';
import { NextResponse } from 'next/server';

/**
 * AI Chat API Route
 *
 * Note: This endpoint is kept for backward compatibility.
 * New implementations should use the server action: chatWithAgent from '@/app/actions'
 *
 * @deprecated Use server actions instead: import { chatWithAgent } from '@/app/actions'
 */
export async function POST(request: Request) {
  // Rate limiting: 20 requests per minute per IP
  const rateLimiter = getRateLimiterService();
  const ip =
    request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  const rateLimitResult = rateLimiter.checkSlidingWindow(`chat:${ip}`, 20, 60000);

  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      {
        success: false,
        error: 'Rate limit exceeded',
        retryAfter: Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000),
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimitResult.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Limit': '20',
          'X-RateLimit-Remaining': String(rateLimitResult.remaining),
          'X-RateLimit-Reset': String(rateLimitResult.resetTime),
        },
      }
    );
  }
  try {
    const body = await request.json();
    const { prompt, conversationId } = body;

    if (!prompt) {
      return NextResponse.json(
        {
          success: false,
          error: 'Prompt is required',
        },
        { status: 400 }
      );
    }

    // Import server action dynamically to avoid circular dependencies
    const { chatWithAgent } = await import('@/app/actions');

    const result = await chatWithAgent({
      conversationId: conversationId || `api-${Date.now()}`,
      message: prompt,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error,
          details: result.details,
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error',
      },
      { status: 500 }
    );
  }
}
