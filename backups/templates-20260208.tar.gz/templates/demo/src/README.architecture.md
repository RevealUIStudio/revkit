# Architecture (RevealUI)

- Layers
  - domain: pure business logic only
  - features: application orchestration and server actions
  - infrastructure: integrations, services, data-access, jobs, middleware, events, cms adapters
  - presentation: UI components (shared primitives and feature-specific UI)
  - app: routing (Next.js app router)
- Imports
  - presentation → features → domain; features consume infrastructure via interfaces; no inverse imports.
  - Avoid new barrel files; only approved public entry points are allowed.
- Styling helpers
  - infrastructure uses `@/infrastructure/config/styles`
  - domain/features/presentation use `@/lib/styles/classnames`
- Routing
  - Use the app router; keep RevealUI routes under `src/app/(frontend)/(backend)` as appropriate.
  - Mark RevealUI routes with `export const dynamic = "force-dynamic"` when required.
- Adapters and directories
  - Do not add new `adapters` directories outside the shared `src/lib/adapters/{client,server}` convention.
  - Place external SDK bindings under `src/infrastructure/integrations/*`.

