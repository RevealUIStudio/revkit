/**
 * Configuration Utilities Tests
 * Tests for utility functions in config/utilities
 */

import { generateSlug, generateUUID } from '@/config/system/utilities/generation';
import {
  ValidationUtils,
  isEmptyArray,
  isNotEmptyArray,
  validateArrayLength,
} from '@/config/system/validators/domain';
import { describe, expect, it } from 'vitest';

describe('Configuration Utilities', () => {
  describe('Array Validation', () => {
    describe('isEmptyArray', () => {
      it('should return true for null', () => {
        expect(isEmptyArray(null)).toBe(true);
      });

      it('should return true for undefined', () => {
        expect(isEmptyArray(undefined)).toBe(true);
      });

      it('should return true for empty array', () => {
        expect(isEmptyArray([])).toBe(true);
      });

      it('should return false for non-empty array', () => {
        expect(isEmptyArray([1, 2, 3])).toBe(false);
      });
    });

    describe('isNotEmptyArray', () => {
      it('should return false for null', () => {
        expect(isNotEmptyArray(null)).toBe(false);
      });

      it('should return true for non-empty array', () => {
        expect(isNotEmptyArray([1])).toBe(true);
      });
    });

    describe('validateArrayLength', () => {
      it('should return true for arrays within limit', () => {
        expect(validateArrayLength([1, 2], 5)).toBe(true);
      });

      it('should return false for arrays exceeding limit', () => {
        expect(validateArrayLength([1, 2, 3], 2)).toBe(false);
      });

      it('should return true for null/undefined', () => {
        expect(validateArrayLength(null, 5)).toBe(true);
        expect(validateArrayLength(undefined, 5)).toBe(true);
      });
    });
  });

  describe('ValidationUtils', () => {
    describe('validateRequired', () => {
      it('should throw for null', () => {
        expect(() => ValidationUtils.validateRequired(null, 'field')).toThrow();
      });

      it('should throw for empty string', () => {
        expect(() => ValidationUtils.validateRequired('', 'field')).toThrow();
      });

      it('should not throw for valid value', () => {
        expect(() => ValidationUtils.validateRequired('value', 'field')).not.toThrow();
      });
    });

    describe('validateEmail', () => {
      it('should accept valid email', () => {
        expect(() => ValidationUtils.validateEmail('user@example.com')).not.toThrow();
      });

      it('should reject invalid email', () => {
        expect(() => ValidationUtils.validateEmail('invalid')).toThrow();
        expect(() => ValidationUtils.validateEmail('@example.com')).toThrow();
        expect(() => ValidationUtils.validateEmail('user@')).toThrow();
      });
    });

    describe('validateSlug', () => {
      it('should accept valid slug', () => {
        expect(() => ValidationUtils.validateSlug('valid-slug-123')).not.toThrow();
      });

      it('should reject invalid characters', () => {
        expect(() => ValidationUtils.validateSlug('Invalid_Slug')).toThrow();
        expect(() => ValidationUtils.validateSlug('invalid slug')).toThrow();
      });

      it('should reject slugs starting/ending with hyphen', () => {
        expect(() => ValidationUtils.validateSlug('-invalid')).toThrow();
        expect(() => ValidationUtils.validateSlug('invalid-')).toThrow();
      });
    });

    describe('validateUsername', () => {
      it('should accept valid username', () => {
        expect(() => ValidationUtils.validateUsername('valid_user-123')).not.toThrow();
      });

      it('should reject invalid characters', () => {
        expect(() => ValidationUtils.validateUsername('invalid user')).toThrow();
      });
    });

    describe('validateRange', () => {
      it('should accept values within range', () => {
        expect(() => ValidationUtils.validateRange(5, 1, 10, 'field')).not.toThrow();
      });

      it('should reject values outside range', () => {
        expect(() => ValidationUtils.validateRange(0, 1, 10, 'field')).toThrow();
        expect(() => ValidationUtils.validateRange(11, 1, 10, 'field')).toThrow();
      });
    });
  });

  describe('Generation Utilities', () => {
    describe('generateUUID', () => {
      it('should generate valid UUID', () => {
        const uuid = generateUUID();
        expect(uuid).toBeDefined();
        expect(typeof uuid).toBe('string');
        expect(uuid.length).toBeGreaterThan(0);
      });

      it('should generate unique UUIDs', () => {
        const uuid1 = generateUUID();
        const uuid2 = generateUUID();
        expect(uuid1).not.toBe(uuid2);
      });
    });

    describe('generateSlug', () => {
      it('should generate slug from text', () => {
        const slug = generateSlug('Hello World Test');
        expect(slug).toBe('hello-world-test');
      });

      it('should handle special characters', () => {
        const slug = generateSlug('Test & Special! Characters?');
        expect(slug).not.toContain('&');
        expect(slug).not.toContain('!');
        expect(slug).not.toContain('?');
      });

      it('should handle multiple spaces', () => {
        const slug = generateSlug('Multiple   Spaces');
        expect(slug).toBe('multiple-spaces');
      });
    });
  });
});
