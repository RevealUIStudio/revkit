// @eslint-allow-underscore-prefixes

declare const global: any;

import React from 'react';
import { expect, vi } from 'vitest';

// Import global test setup from testing package
import '@revealui/dev/testing/setup';

// Make React available globally for JSX
global.React = React;

// Mock logger globally with proper DevLogger structure
vi.mock('@/config/infrastructure/integrations/logging/logger', () => ({
  devLogger: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    forService: vi.fn().mockReturnValue({
      debug: vi.fn(),
      info: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
    }),
    startOperation: vi.fn().mockReturnValue(vi.fn()),
    logError: vi.fn(),
  },
  createServiceLogger: vi.fn().mockReturnValue({
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  }),
}));

// Mock BaseService to avoid import issues
vi.mock('@/domain/services/BaseService', () => ({
  BaseService: {
    createContext: vi.fn().mockReturnValue({
      serviceName: 'TestService',
      options: {
        enableLogging: true,
        enableMetrics: true,
        enableHealthChecks: true,
      },
      metrics: {
        totalOperations: 0,
        successfulOperations: 0,
        failedOperations: 0,
        averageResponseTime: 0,
      },
      initialized: false,
      healthy: false,
      startTime: new Date(),
    }),
    executeOperation: vi.fn().mockImplementation(async (_context, _logger, _operation, fn) => {
      return await fn();
    }),
    handleServiceResult: vi
      .fn()
      .mockImplementation((result: unknown, operationName: Readonly<string>, _logger: unknown) => {
        const typedResult = result as {
          success: boolean;
          data?: unknown;
          error?: string;
        };
        if (typedResult.success === true && typedResult.data !== undefined) {
          return typedResult.data;
        }
        throw new Error(typedResult.error ?? `Operation ${operationName} failed`);
      }),
    handleEntityResult: vi
      .fn()
      .mockImplementation((result: unknown, operationName: Readonly<string>, _logger: unknown) => {
        const typedResult = result as {
          success: boolean;
          data?: unknown;
          error?: string;
        };
        if (typedResult.success === true && typedResult.data !== undefined) {
          return typedResult.data;
        }
        throw new Error(typedResult.error ?? `Operation ${operationName} failed`);
      }),
  },
}));

// Project-specific test setup (global mocks are handled by @revealui/dev/testing)

// Mock process.env using vi.stubEnv for project-specific variables
vi.stubEnv('APP_ENV', 'test');
vi.stubEnv('NEXT_PUBLIC_APP_URL', 'http://localhost:3000');
vi.stubEnv('DATABASE_URL', 'postgresql://test:test@localhost:5432/test');
vi.stubEnv('REVEALUI_SECRET', 'test-secret');
vi.stubEnv('BLOB_READ_WRITE_TOKEN', 'test-token');

// Custom DOM matchers are provided by @revealui/dev/testing
