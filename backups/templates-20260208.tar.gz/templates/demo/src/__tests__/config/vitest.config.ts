import { defineConfig } from 'vitest/config';
import { resolve } from 'path';
import { fileURLToPath } from 'url';

const dirname = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  test: {
    setupFiles: ['./src/__tests__/config/setup/vitest.setup.ts'],
    exclude: [
      '**/node_modules/**',
      '**/dist/**',
      '**/.next/**',
      '**/e2e/**', // E2E tests run via Playwright, not Vitest
      '**/playwright/**', // Playwright tests
    ],
  },
  resolve: {
    alias: {
      '@': resolve(dirname, '../../../src'),
    },
  },
});
