/**
 * Chat Server Actions Tests
 *
 * Note: The current implementation is a basic chat that doesn't use MCP.
 * Tests are updated to reflect the actual implementation.
 */

import { beforeEach, describe, expect, it, vi } from 'vitest';

// Mock RevealUI at the file level to avoid loading the real postgres driver via `revealui`
vi.mock('@revealui/content', () => {
  const mockRevealUIInstance = {
    logger: {
      info: vi.fn(),
      error: vi.fn(),
      warn: vi.fn(),
      debug: vi.fn(),
    },
    sendEmail: vi.fn(),
    create: vi.fn(),
    findByID: vi.fn(),
    find: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
  };

  return {
    getRevealUI: vi.fn().mockResolvedValue(mockRevealUIInstance),
    buildConfig: vi.fn().mockReturnValue({}),
  };
});

// Mock reveal config to avoid executing the real RevealUI + jose setup
vi.mock('@/reveal.config', () => ({
  getRevealConfig: vi.fn().mockResolvedValue({}),
}));

// Chat action under test
import { chatWithAgent } from '@/app/actions/chat';

describe('Chat Server Actions', () => {
  beforeEach(() => {
    vi.clearAllMocks();

    // Set required environment variables
    process.env.REVEAL_SECRET = 'test-secret-that-is-long-enough-32-chars';
    process.env.MCP_ENCRYPTION_KEY = 'a'.repeat(64);
  });

  describe('chatWithAgent', () => {
    it('should successfully process chat message and return basic response', async () => {
      const result = await chatWithAgent({
        conversationId: 'conv-123',
        message: 'Hello',
      });

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.conversationId).toBe('conv-123');
        expect(result.data.response).toContain('I received your message');
        expect(result.data.response).toContain('Hello');
        expect(result.data.response).toContain('basic chat implementation');
      }
    });

    it('should validate input and reject empty messages', async () => {
      const result = await chatWithAgent({
        conversationId: 'conv-123',
        message: '', // Empty message - should fail validation
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // Validation errors may be wrapped, so check for any indication of failure
        expect(result.error).toBeTruthy();
        expect(typeof result.error).toBe('string');
      }
    });

    it('should validate conversationId is required', async () => {
      const result = await chatWithAgent({
        conversationId: '', // Empty conversation ID - should fail validation
        message: 'Hello',
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // Validation errors may be wrapped, so check for any indication of failure
        expect(result.error).toBeTruthy();
        expect(typeof result.error).toBe('string');
      }
    });

    it('should return response with the original message included', async () => {
      const testMessage = 'How are you today?';
      const result = await chatWithAgent({
        conversationId: 'conv-456',
        message: testMessage,
      });

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.response).toContain(testMessage);
      }
    });
  });
});
