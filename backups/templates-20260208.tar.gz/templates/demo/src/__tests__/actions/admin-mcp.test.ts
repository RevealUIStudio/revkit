/**
 * Admin MCP Server Actions Tests
 *
 * Note: These actions are currently disabled in the implementation.
 * Tests are updated to reflect the disabled state.
 */

import {
  executeMCPTask,
  getMCPAgentsStatus,
  getMCPAuditLog,
  getPendingApprovals,
  handleApproval,
} from '@/app/actions/admin/mcp';
import { beforeEach, describe, expect, it, vi } from 'vitest';

describe('Admin MCP Server Actions', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.REVEALUI_SECRET = 'test-secret-that-is-long-enough-32-chars';
    process.env.MCP_ENCRYPTION_KEY = 'a'.repeat(64);
  });

  describe('getMCPAgentsStatus', () => {
    it('should return disabled message (actions are currently disabled)', async () => {
      const result = await getMCPAgentsStatus();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('MCP admin actions are disabled');
      }
    });
  });

  describe('executeMCPTask', () => {
    it('should return disabled message (actions are currently disabled)', async () => {
      const result = await executeMCPTask({
        type: 'agents.test',
        revealui: { test: 'data' },
        priority: 'medium',
      } as any);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('MCP admin actions are disabled');
      }
    });
  });

  describe('getMCPAuditLog', () => {
    it('should return disabled message (actions are currently disabled)', async () => {
      const result = await getMCPAuditLog({
        limit: 20,
      } as any);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('MCP admin actions are disabled');
      }
    });
  });

  describe('getPendingApprovals', () => {
    it('should return disabled message (actions are currently disabled)', async () => {
      const result = await getPendingApprovals();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('MCP admin actions are disabled');
      }
    });
  });

  describe('handleApproval', () => {
    it('should return disabled message (actions are currently disabled)', async () => {
      const result = await handleApproval({
        requestId: 'req-123',
        action: 'approve',
      } as any);

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('MCP admin actions are disabled');
      }
    });
  });
});
