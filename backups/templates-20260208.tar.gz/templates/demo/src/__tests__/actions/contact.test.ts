/**
 * Contact Form Server Actions Tests
 */

import { beforeEach, describe, expect, it, vi } from 'vitest';

// Mock RevealUI at the file level to avoid loading the real postgres driver via `revealui`
vi.mock('@revealui/content', () => {
  const mockRevealUIInstance = {
    logger: {
      info: vi.fn(),
      error: vi.fn(),
      warn: vi.fn(),
      debug: vi.fn(),
    },
    sendEmail: vi.fn(),
    create: vi.fn(),
    findByID: vi.fn(),
    find: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
  };

  return {
    getRevealUI: vi.fn().mockResolvedValue(mockRevealUIInstance),
    buildConfig: vi.fn().mockReturnValue({}),
  };
});

// Mock reveal config to avoid executing the real RevealUI + jose setup
vi.mock('@/reveal.config', () => ({
  getRevealConfig: vi.fn().mockResolvedValue({}),
}));

// Contact action under test
import { submitContactForm } from '@/app/actions/contact';

describe('Contact Form Server Actions', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.SUPPORT_EMAIL = 'support@test.com';
  });

  describe('submitContactForm', () => {
    it('should successfully submit valid contact form', async () => {
      const result = await submitContactForm({
        name: 'John Doe',
        email: 'john@example.com',
        subject: 'Test inquiry',
        message: 'This is a test message with sufficient length',
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.message).toContain('sent successfully');
      }
    });

    it('should validate email format', async () => {
      const result = await submitContactForm({
        name: 'John Doe',
        email: 'invalid-email', // Invalid email
        subject: 'Test',
        message: 'Test message',
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // Validation errors may be wrapped, so check for any indication of failure
        expect(result.error).toBeTruthy();
        expect(typeof result.error).toBe('string');
      }
    });

    it('should require message to be non-empty', async () => {
      const result = await submitContactForm({
        name: 'John Doe',
        email: 'john@example.com',
        subject: 'Test',
        message: '', // Empty message - should fail validation
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // Validation errors may be wrapped, so check for any indication of failure
        expect(result.error).toBeTruthy();
        expect(typeof result.error).toBe('string');
      }
    });

    it('should require all required fields', async () => {
      const result = await submitContactForm({
        name: '',
        email: 'john@example.com',
        subject: 'Test',
        message: 'Test message',
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // Validation errors may be wrapped, so check for any indication of failure
        expect(result.error).toBeTruthy();
        expect(typeof result.error).toBe('string');
      }
    });

    it('should handle email sending failures', async () => {
      const { getRevealUI } = await import('revealui');
      const mockSendEmail = vi.fn(() => Promise.reject(new Error('Email service unavailable')));
      (getRevealUI as any).mockResolvedValueOnce({
        logger: {
          info: vi.fn(),
          error: vi.fn(),
          warn: vi.fn(),
          debug: vi.fn(),
        },
        sendEmail: mockSendEmail,
      });

      const result = await submitContactForm({
        name: 'John Doe',
        email: 'john@example.com',
        subject: 'Test',
        message: 'This is a test message',
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(false);
      if (!result.success) {
        // The error message from the actual error will be returned
        expect(result.error).toContain('Email service unavailable');
      }
    });

    it('should default priority to medium', async () => {
      const result = await submitContactForm({
        name: 'John Doe',
        email: 'john@example.com',
        subject: 'Test',
        message: 'This is a test message',
        priority: 'medium',
        category: 'general',
      });

      expect(result.success).toBe(true);
    });

    it('should accept all priority levels', async () => {
      const priorities: Array<'low' | 'medium' | 'high' | 'critical'> = [
        'low',
        'medium',
        'high',
        'critical',
      ];

      for (const priority of priorities) {
        const result = await submitContactForm({
          name: 'John Doe',
          email: 'john@example.com',
          subject: 'Test',
          message: 'This is a test message',
          priority,
          category: 'general',
        });

        expect(result.success).toBe(true);
      }
    });

    it('should accept all category types', async () => {
      const categories: Array<'general' | 'support' | 'sales' | 'technical' | 'billing'> = [
        'general',
        'support',
        'sales',
        'technical',
        'billing',
      ];

      for (const category of categories) {
        const result = await submitContactForm({
          name: 'John Doe',
          email: 'john@example.com',
          subject: 'Test',
          message: 'This is a test message',
          priority: 'medium',
          category,
        });

        expect(result.success).toBe(true);
      }
    });
  });
});
