/**
 * RevealUI Content Engine Jobs Integration Tests
 * Integration tests for RevealUI Content Engine job system
 */

import { processScheduledBackups } from '@revealui/infrastructure/jobs/backup';
import { processPaymentRetries } from '@revealui/infrastructure/jobs/payment-retry';
import { BackupService } from '@revealui/infrastructure/services/backup/BackupService';
import { getPaymentRetryService } from '@revealui/infrastructure/services/billing/PaymentRetryService';
import {
  createMockRevealUI Content Engine,
  createMockRevealFindResult,
} from '@revealui/dev/testing/utilities/mocks/revealui-mock';
import { getRevealUI } from '@revealui/content';
import { beforeEach, describe, expect, it, vi } from 'vitest';

// Mock dependencies
vi.mock('@revealui/content');
vi.mock('@revealui/infrastructure/services/backup/BackupService');
vi.mock('@revealui/infrastructure/services/billing/PaymentRetryService');

describe('RevealUI Content Engine Jobs Integration', () => {
  let mockRevealUI: any;

  beforeEach(() => {
    vi.clearAllMocks();

    mockRevealUI = createMockRevealUI Content Engine();
    vi.mocked(getRevealUI).mockResolvedValue(mockRevealUI as any);
  });

  describe('Backup Job', () => {
    it('should execute scheduled backups job', async () => {
      const mockBackupService = {
        getInstance: vi.fn().mockReturnValue({
          initialize: vi.fn().mockResolvedValue(undefined),
          processScheduledBackups: vi.fn().mockResolvedValue(undefined),
        }),
      };

      vi.mocked(BackupService.getInstance).mockImplementation(mockBackupService.getInstance as any);

      await processScheduledBackups();

      expect(BackupService.getInstance).toHaveBeenCalled();
      expect(mockBackupService.getInstance().processScheduledBackups).toHaveBeenCalled();
    });

    it('should handle backup job failures', async () => {
      const mockBackupService = {
        getInstance: vi.fn().mockReturnValue({
          initialize: vi.fn().mockResolvedValue(undefined),
          processScheduledBackups: vi.fn().mockRejectedValue(new Error('Backup failed')),
        }),
      };

      vi.mocked(BackupService.getInstance).mockImplementation(mockBackupService.getInstance as any);

      await expect(processScheduledBackups()).rejects.toThrow('Backup failed');
    });
  });

  describe('Payment Retry Job', () => {
    it('should execute payment retry job', async () => {
      const mockService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        processScheduledRetries: vi.fn().mockResolvedValue(undefined),
      };

      vi.mocked(getPaymentRetryService).mockReturnValue(mockService as any);

      await processPaymentRetries();

      expect(getPaymentRetryService).toHaveBeenCalled();
      expect(mockService.processScheduledRetries).toHaveBeenCalled();
    });

    it('should handle payment retry job failures', async () => {
      const mockService = {
        initialize: vi.fn().mockResolvedValue(undefined),
        processScheduledRetries: vi.fn().mockRejectedValue(new Error('Retry failed')),
      };

      vi.mocked(getPaymentRetryService).mockReturnValue(mockService as any);

      await expect(processPaymentRetries()).rejects.toThrow('Retry failed');
    });
  });

  describe('Job Registration', () => {
    it('should register jobs with RevealUI Content Engine', async () => {
      // Jobs should be registered in jobs-config.ts
      // This test verifies the integration
      expect(getRevealUI).toBeDefined();
    });
  });
});
