/**
 * Stripe Integration Tests
 * Integration tests for payment retry functionality
 */

import { PaymentRetryService } from '@revealui/infrastructure/services/billing/PaymentRetryService';
import { getStripeClient } from '@revealui/infrastructure/compat/external';
import {
  createMockStripeClient,
  createMockStripeInvoice,
  createMockStripeSubscription,
} from '@revealui/dev/testing/utilities/mocks/stripe-mock';
import { beforeEach, describe, expect, it, vi } from 'vitest';

// Mock Stripe client
vi.mock('@revealui/infrastructure/compat/external', () => ({
  getStripeClient: vi.fn(),
}));

describe('Stripe Payment Retry Integration', () => {
  let mockStripe: any;

  beforeEach(() => {
    vi.clearAllMocks();
    mockStripe = createMockStripeClient();
    vi.mocked(getStripeClient).mockReturnValue(mockStripe as any);
  });

  describe('Payment Failure Handling', () => {
    it('should handle payment failure and schedule retry', async () => {
      const invoiceId = 'in_test_123';
      const paymentIntentId = 'pi_test_123';
      const error = 'Card declined';

      const invoice = createMockStripeInvoice({
        id: invoiceId,
        subscription: 'sub_test_123',
      });

      if (mockStripe.invoices?.retrieve) {
        mockStripe.invoices.retrieve.mockResolvedValue(invoice);
      }

      const service = new PaymentRetryService();
      await service.initialize();

      const result = await service.handlePaymentFailure(invoiceId, paymentIntentId, error);

      expect(result).toBeDefined();
      expect(mockStripe.invoices?.retrieve).toHaveBeenCalledWith(invoiceId);
    });

    it('should cancel subscription on max retries', async () => {
      const invoiceId = 'in_test_123';
      const paymentIntentId = 'pi_test_123';
      const error = 'Card declined';

      const invoice = createMockStripeInvoice({
        id: invoiceId,
        subscription: 'sub_test_123',
      });
      const subscription = createMockStripeSubscription({ id: 'sub_test_123' });

      if (mockStripe.invoices?.retrieve) {
        mockStripe.invoices.retrieve.mockResolvedValue(invoice);
      }
      if (mockStripe.subscriptions?.update) {
        mockStripe.subscriptions.update.mockResolvedValue(subscription);
      }

      const service = new PaymentRetryService();
      await service.initialize();

      // Simulate max retries by creating multiple retries
      for (let i = 0; i < 3; i++) {
        await service.handlePaymentFailure(invoiceId, paymentIntentId, error);
      }

      // On 4th attempt, should cancel subscription
      const result = await service.handlePaymentFailure(invoiceId, paymentIntentId, error);

      expect(mockStripe.subscriptions?.update).toHaveBeenCalledWith('sub_test_123', {
        cancel_at_period_end: true,
      });
    });
  });

  describe('Webhook Processing', () => {
    it('should process payment_intent.payment_failed webhook', async () => {
      const webhookReveal = {
        type: 'payment_intent.payment_failed',
        data: {
          object: {
            id: 'pi_test_123',
            invoice: 'in_test_123',
          },
        },
      };

      const invoice = createMockStripeInvoice({ id: 'in_test_123' });
      if (mockStripe.invoices?.retrieve) {
        mockStripe.invoices.retrieve.mockResolvedValue(invoice);
      }

      const service = new PaymentRetryService();
      await service.initialize();

      // Process webhook (simulated)
      const result = await service.handlePaymentFailure(
        webhookReveal.data.object.invoice,
        webhookReveal.data.object.id,
        'Payment failed'
      );

      expect(result).toBeDefined();
    });
  });

  describe('Idempotency Handling', () => {
    it('should handle duplicate payment failures idempotently', async () => {
      const invoiceId = 'in_test_123';
      const paymentIntentId = 'pi_test_123';
      const error = 'Card declined';

      const invoice = createMockStripeInvoice({ id: invoiceId });
      if (mockStripe.invoices?.retrieve) {
        mockStripe.invoices.retrieve.mockResolvedValue(invoice);
      }

      const service = new PaymentRetryService();
      await service.initialize();

      // Call multiple times with same parameters
      const result1 = await service.handlePaymentFailure(invoiceId, paymentIntentId, error);
      const result2 = await service.handlePaymentFailure(invoiceId, paymentIntentId, error);

      // Should handle gracefully (may create multiple retries or deduplicate)
      expect(result1).toBeDefined();
      expect(result2).toBeDefined();
    });
  });
});
