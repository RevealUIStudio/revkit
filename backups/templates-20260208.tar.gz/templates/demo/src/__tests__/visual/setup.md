# Visual Regression Testing Setup

This guide explains how to set up and use visual regression testing for UI
components.

## Overview

Visual regression testing captures screenshots of components and compares them
against baseline images to detect unintended visual changes.

## Tools

- **Playwright**: E2E testing framework with built-in screenshot capabilities
- **Storybook** (optional): Component playground for isolation testing

## Setup

### 1. Install Dependencies

Dependencies are already installed:

- `@playwright/test` - E2E testing framework
- `playwright` - Browser automation

### 2. Configure Playwright

Update `src/__tests__/config/playwright.config.ts`:

```typescript
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: '../visual',

  use: {
    baseURL: 'http://localhost:3000',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: {
        browserName: 'chromium',
        viewport: { width: 1280, height: 720 },
      },
    },
    {
      name: 'firefox',
      use: {
        browserName: 'firefox',
        viewport: { width: 1280, height: 720 },
      },
    },
    {
      name: 'webkit',
      use: {
        browserName: 'webkit',
        viewport: { width: 1280, height: 720 },
      },
    },
  ],

  webServer: {
    command: 'pnpm dev',
    port: 3000,
    reuseExistingServer: !process.env.CI,
  },
});
```

## Writing Visual Tests

### Example: Button Component

Create `src/__tests__/visual/button.spec.ts`:

```typescript
import { test, expect } from '@playwright/test';

test.describe('Button Component', () => {
  test('renders primary variant correctly', async ({ page }) => {
    await page.goto('/components/button');

    const button = page.locator('[data-testid="button-primary"]');
    await expect(button).toHaveScreenshot('button-primary.png');
  });

  test('renders hover state correctly', async ({ page }) => {
    await page.goto('/components/button');

    const button = page.locator('[data-testid="button-primary"]');
    await button.hover();
    await expect(button).toHaveScreenshot('button-primary-hover.png');
  });

  test('renders disabled state correctly', async ({ page }) => {
    await page.goto('/components/button');

    const button = page.locator('[data-testid="button-disabled"]');
    await expect(button).toHaveScreenshot('button-disabled.png');
  });
});
```

### Example: Card Component

Create `src/__tests__/visual/card.spec.ts`:

```typescript
import { test, expect } from '@playwright/test';

test.describe('Card Component', () => {
  test('default variant matches snapshot', async ({ page }) => {
    await page.goto('/components/card');

    const card = page.locator('[data-testid="card-default"]');
    await expect(card).toHaveScreenshot('card-default.png');
  });

  test('elevated variant matches snapshot', async ({ page }) => {
    await page.goto('/components/card');

    const card = page.locator('[data-testid="card-elevated"]');
    await expect(card).toHaveScreenshot('card-elevated.png');
  });

  test('hoverable state matches snapshot', async ({ page }) => {
    await page.goto('/components/card');

    const card = page.locator('[data-testid="card-hoverable"]');
    await card.hover();
    await expect(card).toHaveScreenshot('card-hoverable-hover.png');
  });
});
```

## Running Tests

### Update Baseline Screenshots

First time or when intentional changes are made:

```bash
pnpm playwright test --update-snapshots
```

### Run Visual Tests

```bash
pnpm playwright test src/__tests__/visual
```

### Run in UI Mode

```bash
pnpm playwright test --ui
```

### Run Specific Test

```bash
pnpm playwright test button.spec.ts
```

## Best Practices

### 1. Use Test IDs

Add `data-testid` attributes to components:

```tsx
<button
  data-testid='button-primary'
  className={buttonVariants({ variant: 'primary' })}
>
  Click me
</button>
```

### 2. Test Multiple States

Capture different states:

- Default
- Hover
- Focus
- Active
- Disabled
- Loading
- Error

### 3. Test Responsive Designs

```typescript
test('button responsive on mobile', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto('/components/button');

  const button = page.locator('[data-testid="button-primary"]');
  await expect(button).toHaveScreenshot('button-primary-mobile.png');
});
```

### 4. Test Dark/Light Themes

```typescript
test('button in dark mode', async ({ page }) => {
  await page.goto('/components/button');
  await page.evaluate(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
  });

  const button = page.locator('[data-testid="button-primary"]');
  await expect(button).toHaveScreenshot('button-primary-dark.png');
});
```

### 5. Test Animations

Wait for animations to complete:

```typescript
test('loading button animation', async ({ page }) => {
  await page.goto('/components/button');

  const button = page.locator('[data-testid="button-loading"]');

  // Wait for animation to complete
  await page.waitForTimeout(500);

  await expect(button).toHaveScreenshot('button-loading.png');
});
```

## Handling Failures

When visual tests fail:

1. **Review the diff** - Check what changed
2. **Investigate** - Determine if change is intentional
3. **Update baseline** - If change is correct:
   ```bash
   pnpm playwright test --update-snapshots
   ```

## CI/CD Integration

### GitHub Actions

Add to `.github/workflows/test.yml`:

```yaml
name: Visual Regression Tests

on: [push, pull_request]

jobs:
  visual-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'

      - name: Install dependencies
        run: pnpm install

      - name: Install Playwright browsers
        run: pnpm playwright install --with-deps

      - name: Run visual tests
        run: pnpm playwright test src/__tests__/visual

      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: playwright-report
          path: playwright-report/
```

## Component Test Page

Create test pages for components at `/components/*`:

```tsx
// src/app/(frontend)/components/button/page.tsx
import { buttonVariants } from '@/presentation/core/styles';

export default function ButtonTestPage() {
  return (
    <div className='p-8 space-y-4'>
      <h1>Button Component Tests</h1>

      <section>
        <h2>Primary</h2>
        <button
          data-testid='button-primary'
          className={buttonVariants({ variant: 'primary' })}
        >
          Primary Button
        </button>
      </section>

      <section>
        <h2>Disabled</h2>
        <button
          data-testid='button-disabled'
          className={buttonVariants({ variant: 'primary' })}
          disabled
        >
          Disabled Button
        </button>
      </section>

      {/* Add more variants */}
    </div>
  );
}
```

## Resources

- [Playwright Visual Comparisons](https://playwright.dev/docs/test-snapshots)
- [Best Practices for Visual Testing](https://playwright.dev/docs/best-practices)
- [Storybook Visual Testing](https://storybook.js.org/docs/react/writing-tests/visual-testing)

---

**Note**: Visual regression testing is most effective when:

- Components are isolated
- Tests are deterministic (no random values)
- Screenshots are taken after animations complete
- Baseline images are kept up to date
