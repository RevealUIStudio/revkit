import { MetricType, pluginTelemetry } from '@revealui/infrastructure/plugins/core';
import { beforeEach, describe, expect, it } from 'vitest';

describe('PluginTelemetryManager', () => {
  beforeEach(() => {
    // Clear telemetry between tests
    pluginTelemetry.clear();
  });

  describe('Metric Recording', () => {
    it('should record counter metric', () => {
      pluginTelemetry.recordMetric('test-plugin', {
        name: 'test.counter',
        type: MetricType.COUNTER,
        value: 1,
      });

      const metrics = pluginTelemetry.getPluginMetrics('test-plugin');
      expect(metrics.length).toBe(1);
      expect(metrics[0].name).toBe('test.counter');
      expect(metrics[0].type).toBe(MetricType.COUNTER);
      expect(metrics[0].value).toBe(1);
    });

    it('should record gauge metric', () => {
      pluginTelemetry.recordMetric('test-plugin', {
        name: 'test.gauge',
        type: MetricType.GAUGE,
        value: 50,
        unit: '%',
      });

      const metrics = pluginTelemetry.getPluginMetrics('test-plugin');
      expect(metrics[0].type).toBe(MetricType.GAUGE);
      expect(metrics[0].unit).toBe('%');
    });

    it('should record histogram metric', () => {
      pluginTelemetry.recordMetric('test-plugin', {
        name: 'test.histogram',
        type: MetricType.HISTOGRAM,
        value: 250,
        labels: { operation: 'read' },
      });

      const metrics = pluginTelemetry.getPluginMetrics('test-plugin');
      expect(metrics[0].type).toBe(MetricType.HISTOGRAM);
      expect(metrics[0].labels?.operation).toBe('read');
    });

    it('should add timestamp automatically', () => {
      pluginTelemetry.recordMetric('test-plugin', {
        name: 'test.metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      const metrics = pluginTelemetry.getPluginMetrics('test-plugin');
      expect(metrics[0].timestamp).toBeGreaterThan(0);
    });

    it('should limit metrics per plugin', () => {
      // Record more than max (1000)
      for (let i = 0; i < 1100; i++) {
        pluginTelemetry.recordMetric('limit-test', {
          name: `metric.${i}`,
          type: MetricType.COUNTER,
          value: i,
        });
      }

      const metrics = pluginTelemetry.getPluginMetrics('limit-test');
      expect(metrics.length).toBeLessThanOrEqual(1000);
    });
  });

  describe('Distributed Tracing', () => {
    it('should start a span', () => {
      const span = pluginTelemetry.startSpan('test-plugin', 'test.operation');

      expect(span).toBeDefined();
      expect(span.spanId).toBeDefined();
      expect(span.traceId).toBeDefined();
      expect(span.name).toBe('test.operation');
      expect(span.status).toBe('ok');
    });

    it('should end a span', () => {
      const span = pluginTelemetry.startSpan('test-plugin', 'test.operation');

      pluginTelemetry.endSpan(span.spanId, 'ok');

      const trace = pluginTelemetry.getTrace(span.traceId);
      const endedSpan = trace.find(s => s.spanId === span.spanId);

      expect(endedSpan?.endTime).toBeDefined();
      expect(endedSpan?.duration).toBeDefined();
      expect(endedSpan?.status).toBe('ok');
    });

    it('should support nested spans', () => {
      const parentSpan = pluginTelemetry.startSpan('test-plugin', 'parent.operation');
      const childSpan = pluginTelemetry.startSpan(
        'test-plugin',
        'child.operation',
        parentSpan.traceId,
        parentSpan.spanId
      );

      expect(childSpan.traceId).toBe(parentSpan.traceId);
      expect(childSpan.parentSpanId).toBe(parentSpan.spanId);
    });

    it('should add events to span', () => {
      const span = pluginTelemetry.startSpan('test-plugin', 'test.operation');

      pluginTelemetry.addSpanEvent(span.spanId, 'processing.started', {
        itemCount: 10,
      });

      const trace = pluginTelemetry.getTrace(span.traceId);
      const spanWithEvents = trace.find(s => s.spanId === span.spanId);

      expect(spanWithEvents?.events).toBeDefined();
      expect(spanWithEvents?.events?.length).toBe(1);
      expect(spanWithEvents?.events?.[0].name).toBe('processing.started');
    });

    it('should set span attributes', () => {
      const span = pluginTelemetry.startSpan('test-plugin', 'test.operation');

      pluginTelemetry.setSpanAttributes(span.spanId, {
        userId: '123',
        operation: 'read',
      });

      const trace = pluginTelemetry.getTrace(span.traceId);
      const spanWithAttrs = trace.find(s => s.spanId === span.spanId);

      expect(spanWithAttrs?.attributes?.userId).toBe('123');
      expect(spanWithAttrs?.attributes?.operation).toBe('read');
    });
  });

  describe('Specialized Metrics', () => {
    it('should record initialization metrics', () => {
      pluginTelemetry.recordInitialization('init-test', 150, true);

      const metrics = pluginTelemetry.getPluginMetrics('init-test');
      expect(metrics.some(m => m.name === 'plugin.initialization.duration')).toBe(true);
      expect(metrics.some(m => m.name === 'plugin.initialization.count')).toBe(true);
    });

    it('should record failed initialization', () => {
      const error = new Error('Init failed');
      pluginTelemetry.recordInitialization('fail-test', 100, false, error);

      const metrics = pluginTelemetry.getPluginMetrics('fail-test');
      const initMetric = metrics.find(m => m.name === 'plugin.initialization.count');

      expect(initMetric?.labels?.status).toBe('error');
    });

    it('should record hook execution metrics', () => {
      pluginTelemetry.recordHookExecution('hook-test', 'beforeRead', 25, true);

      const metrics = pluginTelemetry.getPluginMetrics('hook-test');
      expect(metrics.some(m => m.name === 'plugin.hook.execution.duration')).toBe(true);
    });

    it('should record memory usage', () => {
      pluginTelemetry.recordMemoryUsage('memory-test', 45.5);

      const metrics = pluginTelemetry.getPluginMetrics('memory-test');
      const memMetric = metrics.find(m => m.name === 'plugin.memory.usage');

      expect(memMetric).toBeDefined();
      expect(memMetric?.value).toBe(45.5);
      expect(memMetric?.unit).toBe('MB');
    });

    it('should record CPU usage', () => {
      pluginTelemetry.recordCPUUsage('cpu-test', 35.2);

      const metrics = pluginTelemetry.getPluginMetrics('cpu-test');
      const cpuMetric = metrics.find(m => m.name === 'plugin.cpu.usage');

      expect(cpuMetric).toBeDefined();
      expect(cpuMetric?.value).toBe(35.2);
      expect(cpuMetric?.unit).toBe('%');
    });
  });

  describe('Statistics', () => {
    it('should return telemetry statistics', () => {
      pluginTelemetry.recordMetric('stats-plugin-1', {
        name: 'test.metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      pluginTelemetry.recordMetric('stats-plugin-2', {
        name: 'test.metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      const stats = pluginTelemetry.getStats();

      expect(stats.totalMetrics).toBe(2);
      expect(stats.metricsByPlugin['stats-plugin-1']).toBe(1);
      expect(stats.metricsByPlugin['stats-plugin-2']).toBe(1);
    });

    it('should track span statistics', () => {
      pluginTelemetry.startSpan('span-stats-1', 'operation');
      const span2 = pluginTelemetry.startSpan('span-stats-2', 'operation');
      pluginTelemetry.endSpan(span2.spanId, 'error');

      const stats = pluginTelemetry.getStats();

      expect(stats.totalSpans).toBe(2);
      expect(stats.spansByStatus.ok).toBe(1);
      expect(stats.spansByStatus.error).toBe(1);
    });
  });

  describe('Export Formats', () => {
    it('should export metrics in OpenTelemetry format', () => {
      pluginTelemetry.recordMetric('export-test', {
        name: 'test.metric',
        type: MetricType.COUNTER,
        value: 5,
        labels: { env: 'test' },
      });

      const exported = pluginTelemetry.exportMetrics('export-test');

      expect(exported).toBeDefined();
      expect(typeof exported).toBe('string');
      expect(JSON.parse(exported)).toBeInstanceOf(Array);
    });

    it('should export traces in OpenTelemetry format', () => {
      const span = pluginTelemetry.startSpan('trace-test', 'operation');
      pluginTelemetry.endSpan(span.spanId, 'ok');

      const exported = pluginTelemetry.exportTraces(span.traceId);

      expect(exported).toBeDefined();
      expect(typeof exported).toBe('string');
      expect(JSON.parse(exported)).toBeInstanceOf(Array);
    });
  });

  describe('Correlation IDs', () => {
    it('should generate unique correlation IDs', () => {
      const id1 = pluginTelemetry.generateCorrelationId();
      const id2 = pluginTelemetry.generateCorrelationId();

      expect(id1).toBeDefined();
      expect(id2).toBeDefined();
      expect(id1).not.toBe(id2);
    });
  });

  describe('Data Management', () => {
    it('should clear plugin-specific telemetry', () => {
      pluginTelemetry.recordMetric('clear-test-1', {
        name: 'metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      pluginTelemetry.recordMetric('clear-test-2', {
        name: 'metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      pluginTelemetry.clear('clear-test-1');

      expect(pluginTelemetry.getPluginMetrics('clear-test-1').length).toBe(0);
      expect(pluginTelemetry.getPluginMetrics('clear-test-2').length).toBe(1);
    });

    it('should clear all telemetry', () => {
      pluginTelemetry.recordMetric('clear-all-1', {
        name: 'metric',
        type: MetricType.COUNTER,
        value: 1,
      });

      pluginTelemetry.clear();

      const stats = pluginTelemetry.getStats();
      expect(stats.totalMetrics).toBe(0);
      expect(stats.totalSpans).toBe(0);
      expect(stats.totalTraces).toBe(0);
    });
  });

  describe('Get All Metrics', () => {
    it('should return all metrics as map', () => {
      pluginTelemetry.recordMetric('plugin-1', {
        name: 'metric1',
        type: MetricType.COUNTER,
        value: 1,
      });

      pluginTelemetry.recordMetric('plugin-2', {
        name: 'metric2',
        type: MetricType.COUNTER,
        value: 2,
      });

      const allMetrics = pluginTelemetry.getAllMetrics();

      expect(allMetrics.size).toBe(2);
      expect(allMetrics.has('plugin-1')).toBe(true);
      expect(allMetrics.has('plugin-2')).toBe(true);
    });
  });
});
