import { PluginPermission, pluginRegistry, pluginVerifier } from '@revealui/infrastructure/plugins/config';
import { beforeEach, describe, expect, it } from 'vitest';

describe('PluginVerifier', () => {
  beforeEach(() => {
    // Ensure test plugins are registered
    pluginRegistry.registerPlugin({
      name: 'test-verifier-plugin',
      version: '1.0.0',
      checksum: 'test-checksum-123',
      author: 'test',
      permissions: [PluginPermission.READ_COLLECTIONS],
      verified: true,
    });
  });

  describe('Plugin Verification', () => {
    it('should verify plugin in allowlist', async () => {
      const result = await pluginVerifier.verifyPlugin('test-verifier-plugin', '1.0.0');

      expect(result).toBeDefined();
      expect(result.valid).toBe(true);
      expect(result.errors.length).toBe(0);
    });

    it('should reject plugin not in allowlist', async () => {
      const result = await pluginVerifier.verifyPlugin('unknown-plugin', '1.0.0');

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors[0]).toContain('not in the allowlist');
    });

    it('should detect deprecated plugins', async () => {
      pluginRegistry.registerPlugin({
        name: 'deprecated-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        deprecated: true,
        deprecationMessage: 'Use v2 instead',
      });

      const result = await pluginVerifier.verifyPlugin('deprecated-plugin', '1.0.0');

      expect(result.warnings.length).toBeGreaterThan(0);
      expect(result.warnings.some(w => w.includes('deprecated'))).toBe(true);
    });
  });

  describe('Permission Validation', () => {
    it('should accept safe permission combinations', () => {
      pluginRegistry.registerPlugin({
        name: 'safe-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS, PluginPermission.EXECUTE_HOOKS],
        verified: true,
      });

      // Permission validation happens during verification
      const result = pluginVerifier.validatePermissions([
        PluginPermission.READ_COLLECTIONS,
        PluginPermission.EXECUTE_HOOKS,
      ]);

      expect(result).toBe(true);
    });

    it('should warn about dangerous permission combinations', () => {
      const dangerous = [PluginPermission.ADMIN_ACCESS, PluginPermission.FILESYSTEM_WRITE];

      const result = pluginVerifier.validatePermissions(dangerous);

      expect(result).toBe(false);
    });

    it('should detect network + environment access as dangerous', () => {
      const dangerous = [PluginPermission.NETWORK_ACCESS, PluginPermission.ENVIRONMENT_ACCESS];

      const result = pluginVerifier.validatePermissions(dangerous);

      expect(result).toBe(false);
    });
  });

  describe('Code Sanitization', () => {
    it('should detect dangerous eval patterns', () => {
      const code = `
        function myPlugin() {
          eval('malicious code');
        }
      `;

      const result = pluginVerifier.sanitizePluginCode(code);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('eval()');
    });

    it('should detect Function constructor', () => {
      const code = `new Function('return process.env')()`;

      const result = pluginVerifier.sanitizePluginCode(code);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('Function constructor');
    });

    it('should detect child_process usage', () => {
      const code = `const { exec } = require('child_process');`;

      const result = pluginVerifier.sanitizePluginCode(code);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('child_process');
    });

    it('should detect process.exit', () => {
      const code = 'process.exit(1);';

      const result = pluginVerifier.sanitizePluginCode(code);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('process.exit');
    });

    it('should allow safe code', () => {
      const code = `
        export const myPlugin = () => {
          return { configured: true };
        };
      `;

      const result = pluginVerifier.sanitizePluginCode(code);

      expect(result.safe).toBe(true);
      expect(result.removed.length).toBe(0);
    });
  });

  describe('Structure Validation', () => {
    it('should validate correct plugin structure', () => {
      const plugin = {
        name: 'valid-plugin',
        version: '1.0.0',
        description: 'A valid plugin',
        author: 'test',
        hooks: {
          beforeRead: async () => {},
        },
      };

      const result = pluginVerifier.validatePluginStructure(plugin);

      expect(result).toBe(true);
    });

    it('should reject invalid plugin structure', () => {
      const plugin = {
        name: 'invalid-plugin',
        version: 'not-semver',
        // Missing required fields
      };

      const result = pluginVerifier.validatePluginStructure(plugin);

      expect(result).toBe(false);
    });
  });

  describe('Signature Generation', () => {
    it('should generate consistent signatures', () => {
      const code = 'test plugin code';
      const sig1 = pluginVerifier.generateSignature(code);
      const sig2 = pluginVerifier.generateSignature(code);

      expect(sig1).toBe(sig2);
      expect(sig1.length).toBeGreaterThan(0);
    });

    it('should generate different signatures for different code', () => {
      const code1 = 'plugin code 1';
      const code2 = 'plugin code 2';

      const sig1 = pluginVerifier.generateSignature(code1);
      const sig2 = pluginVerifier.generateSignature(code2);

      expect(sig1).not.toBe(sig2);
    });
  });

  describe('hasPermission', () => {
    it('should check if plugin has specific permission', () => {
      const hasRead = pluginVerifier.hasPermission(
        'test-verifier-plugin',
        '1.0.0',
        PluginPermission.READ_COLLECTIONS
      );

      expect(hasRead).toBe(true);

      const hasWrite = pluginVerifier.hasPermission(
        'test-verifier-plugin',
        '1.0.0',
        PluginPermission.WRITE_COLLECTIONS
      );

      expect(hasWrite).toBe(false);
    });
  });

  describe('Verification Report', () => {
    it('should generate comprehensive verification report', async () => {
      const report = await pluginVerifier.generateVerificationReport(
        'test-verifier-plugin',
        '1.0.0'
      );

      expect(report).toBeDefined();
      expect(report).toContain('Plugin Verification Report');
      expect(report).toContain('test-verifier-plugin@1.0.0');
      expect(report).toContain('Author: test');
    });
  });
});
