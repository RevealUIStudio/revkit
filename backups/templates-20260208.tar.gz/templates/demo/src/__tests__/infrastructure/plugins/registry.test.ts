import { PluginPermission, PluginRegistry } from '@revealui/infrastructure/plugins/config';
import { beforeEach, describe, expect, it } from 'vitest';

describe('PluginRegistry', () => {
  let registry: PluginRegistry;

  beforeEach(() => {
    // Get fresh instance for each test
    registry = PluginRegistry.getInstance();
    registry.clearChecksumCache();
  });

  describe('Plugin Registration', () => {
    it('should register a plugin successfully', () => {
      registry.registerPlugin({
        name: 'test-plugin',
        version: '1.0.0',
        checksum: 'abc123',
        author: 'test-author',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
        description: 'Test plugin',
      });

      expect(registry.isPluginAllowed('test-plugin', '1.0.0')).toBe(true);
    });

    it('should retrieve registered plugin', () => {
      registry.registerPlugin({
        name: 'test-plugin',
        version: '1.0.0',
        checksum: 'abc123',
        author: 'test-author',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
      });

      const plugin = registry.getPlugin('test-plugin', '1.0.0');
      expect(plugin).toBeDefined();
      expect(plugin?.name).toBe('test-plugin');
      expect(plugin?.version).toBe('1.0.0');
    });

    it('should allow wildcard version matching', () => {
      registry.registerPlugin({
        name: 'wildcard-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      expect(registry.isPluginAllowed('wildcard-plugin', '*')).toBe(true);
      expect(registry.isPluginAllowed('wildcard-plugin')).toBe(true);
    });

    it('should reject unregistered plugins', () => {
      expect(registry.isPluginAllowed('unknown-plugin', '1.0.0')).toBe(false);
    });
  });

  describe('Plugin Unregistration', () => {
    it('should unregister a specific version', () => {
      registry.registerPlugin({
        name: 'test-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      expect(registry.isPluginAllowed('test-plugin', '1.0.0')).toBe(true);

      const removed = registry.unregisterPlugin('test-plugin', '1.0.0');
      expect(removed).toBe(true);
      expect(registry.isPluginAllowed('test-plugin', '1.0.0')).toBe(false);
    });

    it('should unregister all versions with wildcard', () => {
      registry.registerPlugin({
        name: 'multi-version',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      registry.registerPlugin({
        name: 'multi-version',
        version: '2.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      const removed = registry.unregisterPlugin('multi-version', '*');
      expect(removed).toBe(true);
      expect(registry.isPluginAllowed('multi-version', '1.0.0')).toBe(false);
      expect(registry.isPluginAllowed('multi-version', '2.0.0')).toBe(false);
    });
  });

  describe('Default Plugins', () => {
    it('should have core infrastructure plugins registered', () => {
      expect(registry.isPluginAllowed('circuit-breaker')).toBe(true);
      expect(registry.isPluginAllowed('metrics')).toBe(true);
      expect(registry.isPluginAllowed('lru-cache')).toBe(true);
      expect(registry.isPluginAllowed('security')).toBe(true);
    });

    it('should have RevealUI Content Engine plugins registered', () => {
      expect(registry.isPluginAllowed('audit-log')).toBe(true);
      expect(registry.isPluginAllowed('rate-limit')).toBe(true);
      expect(registry.isPluginAllowed('domain-events')).toBe(true);
      expect(registry.isPluginAllowed('performance-monitor')).toBe(true);
    });

    it('should have external plugins registered', () => {
      expect(registry.isPluginAllowed('@revealui/plugin-stripe')).toBe(true);
      expect(registry.isPluginAllowed('@revealui/plugin-seo')).toBe(true);
    });
  });

  describe('Statistics', () => {
    it('should return accurate statistics', () => {
      const stats = registry.getStats();

      expect(stats.total).toBeGreaterThan(0);
      expect(stats.verified).toBeGreaterThan(0);
      expect(stats.byAuthor).toBeDefined();
      expect(stats.byAuthor.reveal).toBeGreaterThan(0);
      expect(stats.byAuthor.revealui).toBeGreaterThan(0);
    });

    it('should track deprecated plugins', () => {
      registry.registerPlugin({
        name: 'old-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        deprecated: true,
        deprecationMessage: 'Use new-plugin instead',
      });

      const stats = registry.getStats();
      expect(stats.deprecated).toBeGreaterThan(0);
    });
  });

  describe('Permissions', () => {
    it('should validate permissions correctly', () => {
      const plugin = registry.getPlugin('audit-log');
      expect(plugin).toBeDefined();
      expect(plugin?.permissions).toContain(PluginPermission.READ_COLLECTIONS);
      expect(plugin?.permissions).toContain(PluginPermission.WRITE_COLLECTIONS);
    });

    it('should enforce minimum permissions', () => {
      registry.registerPlugin({
        name: 'minimal-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
      });

      const plugin = registry.getPlugin('minimal-plugin', '1.0.0');
      expect(plugin?.permissions.length).toBe(1);
      expect(plugin?.permissions).toContain(PluginPermission.READ_COLLECTIONS);
    });
  });

  describe('Checksum Cache', () => {
    it('should clear checksum cache', () => {
      // This is a simple test - in reality, you'd mock fs operations
      expect(() => registry.clearChecksumCache()).not.toThrow();
    });
  });

  describe('Edge Cases', () => {
    it('should handle missing plugin gracefully', () => {
      const plugin = registry.getPlugin('non-existent', '1.0.0');
      expect(plugin).toBeNull();
    });

    it('should handle wildcard on non-existent plugin', () => {
      const plugin = registry.getPlugin('non-existent', '*');
      expect(plugin).toBeNull();
    });

    it('should return all registered plugins', () => {
      const allPlugins = registry.getAllPlugins();
      expect(allPlugins.length).toBeGreaterThan(0);
      expect(Array.isArray(allPlugins)).toBe(true);
    });
  });
});
