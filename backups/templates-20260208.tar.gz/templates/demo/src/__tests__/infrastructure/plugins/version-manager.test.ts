import {
  ComparisonResult,
  pluginRegistry,
  pluginVersionManager,
} from '@revealui/infrastructure/plugins/config';
import { describe, expect, it } from 'vitest';

describe('PluginVersionManager', () => {
  describe('Semver Validation', () => {
    it('should validate correct semver format', () => {
      expect(pluginVersionManager.validateSemver('1.0.0')).toBe(true);
      expect(pluginVersionManager.validateSemver('2.10.5')).toBe(true);
      expect(pluginVersionManager.validateSemver('0.0.1')).toBe(true);
      expect(pluginVersionManager.validateSemver('1.0.0-alpha')).toBe(true);
      expect(pluginVersionManager.validateSemver('1.0.0-beta.1')).toBe(true);
      expect(pluginVersionManager.validateSemver('1.0.0+build.123')).toBe(true);
    });

    it('should reject invalid semver format', () => {
      expect(pluginVersionManager.validateSemver('1')).toBe(false);
      expect(pluginVersionManager.validateSemver('1.0')).toBe(false);
      expect(pluginVersionManager.validateSemver('v1.0.0')).toBe(false);
      expect(pluginVersionManager.validateSemver('1.0.0.0')).toBe(false);
      expect(pluginVersionManager.validateSemver('not-a-version')).toBe(false);
    });

    it('should handle version prefixes', () => {
      expect(pluginVersionManager.validateSemver('^1.0.0')).toBe(true);
      expect(pluginVersionManager.validateSemver('~1.0.0')).toBe(true);
      expect(pluginVersionManager.validateSemver('>=1.0.0')).toBe(true);
    });
  });

  describe('Version Comparison', () => {
    it('should compare major versions correctly', () => {
      expect(pluginVersionManager.compareSemver('2.0.0', '1.0.0')).toBe(
        ComparisonResult.GREATER_THAN
      );
      expect(pluginVersionManager.compareSemver('1.0.0', '2.0.0')).toBe(ComparisonResult.LESS_THAN);
      expect(pluginVersionManager.compareSemver('1.0.0', '1.0.0')).toBe(ComparisonResult.EQUAL);
    });

    it('should compare minor versions correctly', () => {
      expect(pluginVersionManager.compareSemver('1.5.0', '1.3.0')).toBe(
        ComparisonResult.GREATER_THAN
      );
      expect(pluginVersionManager.compareSemver('1.3.0', '1.5.0')).toBe(ComparisonResult.LESS_THAN);
    });

    it('should compare patch versions correctly', () => {
      expect(pluginVersionManager.compareSemver('1.0.5', '1.0.3')).toBe(
        ComparisonResult.GREATER_THAN
      );
      expect(pluginVersionManager.compareSemver('1.0.3', '1.0.5')).toBe(ComparisonResult.LESS_THAN);
    });

    it('should handle pre-release versions', () => {
      expect(pluginVersionManager.compareSemver('1.0.0', '1.0.0-alpha')).toBe(
        ComparisonResult.GREATER_THAN
      );
      expect(pluginVersionManager.compareSemver('1.0.0-beta', '1.0.0-alpha')).toBe(
        ComparisonResult.GREATER_THAN
      );
    });
  });

  describe('Compatibility Checking', () => {
    it('should check basic compatibility', () => {
      pluginRegistry.registerPlugin({
        name: 'compat-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        minSystemVersion: '1.0.0',
        maxSystemVersion: '2.0.0',
      });

      // Within range
      expect(pluginVersionManager.checkCompatibility('compat-test', '1.0.0', '1.5.0')).toBe(true);

      // Below minimum
      expect(pluginVersionManager.checkCompatibility('compat-test', '1.0.0', '0.5.0')).toBe(false);

      // Above maximum
      expect(pluginVersionManager.checkCompatibility('compat-test', '1.0.0', '2.5.0')).toBe(false);
    });

    it('should generate compatibility report', () => {
      pluginRegistry.registerPlugin({
        name: 'report-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        minSystemVersion: '1.5.0',
      });

      const report = pluginVersionManager.getCompatibilityReport('report-test', '1.0.0', '1.0.0');

      expect(report).toBeDefined();
      expect(report.pluginName).toBe('report-test');
      expect(report.compatible).toBe(false);
      expect(report.reason).toContain('below minimum');
    });
  });

  describe('Version Finding', () => {
    it('should find compatible version', () => {
      pluginRegistry.registerPlugin({
        name: 'multi-version',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        minSystemVersion: '0.5.0',
      });

      pluginRegistry.registerPlugin({
        name: 'multi-version',
        version: '2.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
        minSystemVersion: '1.5.0',
      });

      const version = pluginVersionManager.findCompatibleVersion('multi-version', '1.0.0');
      expect(version).toBe('1.0.0');
    });

    it('should get latest version', () => {
      pluginRegistry.registerPlugin({
        name: 'latest-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      pluginRegistry.registerPlugin({
        name: 'latest-test',
        version: '2.5.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      pluginRegistry.registerPlugin({
        name: 'latest-test',
        version: '2.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      const latest = pluginVersionManager.getLatestVersion('latest-test');
      expect(latest).toBe('2.5.0');
    });

    it('should detect outdated versions', () => {
      pluginRegistry.registerPlugin({
        name: 'outdated-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      pluginRegistry.registerPlugin({
        name: 'outdated-test',
        version: '2.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      const isOutdated = pluginVersionManager.isVersionOutdated('outdated-test', '1.0.0');
      expect(isOutdated).toBe(true);
    });
  });

  describe('Version Incrementing', () => {
    it('should increment major version', () => {
      const newVersion = pluginVersionManager.incrementVersion('1.5.3', 'major');
      expect(newVersion).toBe('2.0.0');
    });

    it('should increment minor version', () => {
      const newVersion = pluginVersionManager.incrementVersion('1.5.3', 'minor');
      expect(newVersion).toBe('1.6.0');
    });

    it('should increment patch version', () => {
      const newVersion = pluginVersionManager.incrementVersion('1.5.3', 'patch');
      expect(newVersion).toBe('1.5.4');
    });
  });

  describe('Version Range Satisfaction', () => {
    it('should check exact version match', () => {
      const satisfies = pluginVersionManager.satisfiesRange('1.0.0', { exact: '1.0.0' });
      expect(satisfies).toBe(true);
    });

    it('should check minimum version', () => {
      const satisfies = pluginVersionManager.satisfiesRange('1.5.0', { min: '1.0.0' });
      expect(satisfies).toBe(true);

      const fails = pluginVersionManager.satisfiesRange('0.9.0', { min: '1.0.0' });
      expect(fails).toBe(false);
    });

    it('should check maximum version', () => {
      const satisfies = pluginVersionManager.satisfiesRange('1.5.0', { max: '2.0.0' });
      expect(satisfies).toBe(true);

      const fails = pluginVersionManager.satisfiesRange('2.5.0', { max: '2.0.0' });
      expect(fails).toBe(false);
    });

    it('should check version range', () => {
      const satisfies = pluginVersionManager.satisfiesRange('1.5.0', {
        min: '1.0.0',
        max: '2.0.0',
      });
      expect(satisfies).toBe(true);
    });
  });

  describe('Statistics', () => {
    it('should return version statistics', () => {
      const stats = pluginVersionManager.getStats();

      expect(stats).toBeDefined();
      expect(stats.totalPlugins).toBeGreaterThan(0);
      expect(stats.byMajorVersion).toBeDefined();
      expect(stats.compatibleCount).toBeGreaterThanOrEqual(0);
    });
  });

  describe('Plugin Upgrade', () => {
    it('should upgrade to compatible version', async () => {
      pluginRegistry.registerPlugin({
        name: 'upgrade-test',
        version: '2.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      await expect(
        pluginVersionManager.upgradePlugin('upgrade-test', '2.0.0')
      ).resolves.not.toThrow();
    });

    it('should reject upgrade to non-existent version', async () => {
      await expect(pluginVersionManager.upgradePlugin('unknown', '99.0.0')).rejects.toThrow();
    });
  });
});
