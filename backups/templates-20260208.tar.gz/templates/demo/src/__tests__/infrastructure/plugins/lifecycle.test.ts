import { PluginState, pluginLifecycleManager } from '@revealui/infrastructure/plugins/config';
import type { Config, Plugin } from '@revealui/content';
import { describe, expect, it } from 'vitest';

describe('PluginLifecycleManager', () => {
  const mockPlugin: Plugin = (config: Config) => ({
    ...config,
    collections: [...(config.collections || [])],
  });

  const mockConfig: Config = {
    collections: [],
    db: {} as Config['db'],
    secret: 'test-secret',
  };

  describe('Plugin Installation', () => {
    it('should install plugin successfully', async () => {
      await pluginLifecycleManager.installPlugin('test-install', '1.0.0', mockPlugin, mockConfig);

      const state = pluginLifecycleManager.getPluginState('test-install');
      expect(state).toBe(PluginState.INSTALLED);
    });

    it('should create checkpoints during installation', async () => {
      await pluginLifecycleManager.installPlugin(
        'checkpoint-test',
        '1.0.0',
        mockPlugin,
        mockConfig
      );

      const checkpoints = pluginLifecycleManager.getCheckpoints('checkpoint-test');
      expect(checkpoints.length).toBeGreaterThan(0);
    });

    it('should record installation events', async () => {
      await pluginLifecycleManager.installPlugin('event-test', '1.0.0', mockPlugin, mockConfig);

      const events = pluginLifecycleManager.getEvents('event-test');
      expect(events.length).toBeGreaterThan(0);
      expect(events.some(e => e.type === 'install')).toBe(true);
    });

    it('should handle installation failure', async () => {
      const failingPlugin: Plugin = () => {
        throw new Error('Installation failed');
      };

      await expect(
        pluginLifecycleManager.installPlugin('fail-test', '1.0.0', failingPlugin, mockConfig)
      ).rejects.toThrow('Installation failed');

      const state = pluginLifecycleManager.getPluginState('fail-test');
      expect(state).toBe(PluginState.FAILED);
    });
  });

  describe('Plugin Rollback', () => {
    it('should rollback plugin on failure', async () => {
      // Install successfully first
      await pluginLifecycleManager.installPlugin('rollback-test', '1.0.0', mockPlugin, mockConfig);

      // Now rollback
      await pluginLifecycleManager.rollbackPlugin('rollback-test');

      const state = pluginLifecycleManager.getPluginState('rollback-test');
      expect(state).toBe(PluginState.ROLLED_BACK);
    });

    it('should restore checkpoint on rollback', async () => {
      await pluginLifecycleManager.installPlugin('restore-test', '1.0.0', mockPlugin, mockConfig);

      const checkpointsBefore = pluginLifecycleManager.getCheckpoints('restore-test');
      const checkpointCount = checkpointsBefore.length;

      await pluginLifecycleManager.rollbackPlugin('restore-test');

      // Checkpoint count should be the same or more (rollback may add checkpoint)
      const checkpointsAfter = pluginLifecycleManager.getCheckpoints('restore-test');
      expect(checkpointsAfter.length).toBeGreaterThanOrEqual(checkpointCount);
    });

    it('should fail gracefully when rolling back unknown plugin', async () => {
      await expect(pluginLifecycleManager.rollbackPlugin('unknown-plugin')).rejects.toThrow();
    });
  });

  describe('Plugin Enable/Disable', () => {
    it('should enable plugin', async () => {
      await pluginLifecycleManager.installPlugin('enable-test', '1.0.0', mockPlugin, mockConfig);

      await pluginLifecycleManager.enablePlugin('enable-test');

      const state = pluginLifecycleManager.getPluginState('enable-test');
      expect(state).toBe(PluginState.ENABLED);
    });

    it('should disable plugin', async () => {
      await pluginLifecycleManager.installPlugin('disable-test', '1.0.0', mockPlugin, mockConfig);

      await pluginLifecycleManager.disablePlugin('disable-test');

      const state = pluginLifecycleManager.getPluginState('disable-test');
      expect(state).toBe(PluginState.DISABLED);
    });

    it('should record enable/disable events', async () => {
      await pluginLifecycleManager.installPlugin('event-tracking', '1.0.0', mockPlugin, mockConfig);

      await pluginLifecycleManager.enablePlugin('event-tracking');
      await pluginLifecycleManager.disablePlugin('event-tracking');

      const events = pluginLifecycleManager.getEvents('event-tracking');
      expect(events.some(e => e.type === 'enable')).toBe(true);
      expect(events.some(e => e.type === 'disable')).toBe(true);
    });
  });

  describe('Checkpoint Management', () => {
    it('should save checkpoint', async () => {
      await pluginLifecycleManager.installPlugin(
        'checkpoint-save',
        '1.0.0',
        mockPlugin,
        mockConfig
      );

      const installation = pluginLifecycleManager.getInstallation('checkpoint-save');
      if (installation) {
        const checkpoint = pluginLifecycleManager.saveCheckpoint(
          'checkpoint-save',
          '1.0.0',
          PluginState.ENABLED,
          mockConfig
        );

        expect(checkpoint).toBeDefined();
        expect(checkpoint.pluginName).toBe('checkpoint-save');
        expect(checkpoint.state).toBe(PluginState.ENABLED);
      }
    });

    it('should limit checkpoint history', async () => {
      await pluginLifecycleManager.installPlugin('limit-test', '1.0.0', mockPlugin, mockConfig);

      // Save many checkpoints
      for (let i = 0; i < 15; i++) {
        pluginLifecycleManager.saveCheckpoint(
          'limit-test',
          '1.0.0',
          PluginState.ENABLED,
          mockConfig
        );
      }

      const checkpoints = pluginLifecycleManager.getCheckpoints('limit-test');
      expect(checkpoints.length).toBeLessThanOrEqual(10); // Max 10 checkpoints
    });
  });

  describe('Statistics', () => {
    it('should return lifecycle statistics', () => {
      const stats = pluginLifecycleManager.getStats();

      expect(stats).toBeDefined();
      expect(stats.totalInstallations).toBeGreaterThanOrEqual(0);
      expect(stats.byState).toBeDefined();
      expect(stats.totalCheckpoints).toBeGreaterThanOrEqual(0);
      expect(stats.totalEvents).toBeGreaterThanOrEqual(0);
    });

    it('should track installations by state', async () => {
      await pluginLifecycleManager.installPlugin('stats-test', '1.0.0', mockPlugin, mockConfig);

      const stats = pluginLifecycleManager.getStats();
      expect(stats.byState[PluginState.INSTALLED]).toBeGreaterThan(0);
    });
  });

  describe('History Management', () => {
    it('should clear installation history', async () => {
      await pluginLifecycleManager.installPlugin('history-test', '1.0.0', mockPlugin, mockConfig);

      const cleared = pluginLifecycleManager.clearHistory('history-test');
      expect(cleared).toBe(true);

      const checkpoints = pluginLifecycleManager.getCheckpoints('history-test');
      const events = pluginLifecycleManager.getEvents('history-test');

      expect(checkpoints.length).toBe(0);
      expect(events.length).toBe(0);
    });

    it('should remove installation completely', async () => {
      await pluginLifecycleManager.installPlugin('remove-test', '1.0.0', mockPlugin, mockConfig);

      const removed = pluginLifecycleManager.removeInstallation('remove-test');
      expect(removed).toBe(true);

      const state = pluginLifecycleManager.getPluginState('remove-test');
      expect(state).toBeNull();
    });
  });
});
