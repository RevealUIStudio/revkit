import { pluginRateLimiter } from '@revealui/infrastructure/plugins/config';
import { beforeEach, describe, expect, it } from 'vitest';

describe('PluginRateLimiter', () => {
  beforeEach(() => {
    // Reset limits before each test
    pluginRateLimiter.resetLimits();
  });

  describe('Rate Limit Checking', () => {
    it('should allow operations within limit', () => {
      const allowed = pluginRateLimiter.checkOperationLimit('test-plugin', 'initialization');
      expect(allowed).toBe(true);
    });

    it('should track operations', () => {
      pluginRateLimiter.trackOperation('test-plugin', 'initialization');

      const stats = pluginRateLimiter.getStats('test-plugin');
      expect(stats.totalOperations).toBeGreaterThan(0);
    });

    it('should enforce rate limits', () => {
      const config = pluginRateLimiter.getConfig();
      const maxInits = config.maxInitializationsPerMinute;

      // Exceed the limit
      for (let i = 0; i < maxInits + 5; i++) {
        pluginRateLimiter.trackOperation('limit-test', 'initialization');
      }

      // Next check should fail
      const allowed = pluginRateLimiter.checkOperationLimit('limit-test', 'initialization');
      expect(allowed).toBe(false);
    });

    it('should reset window after expiration', async () => {
      // This test would need to wait for the window to expire
      // or mock time - simplified version:
      pluginRateLimiter.trackOperation('window-test', 'initialization');
      pluginRateLimiter.resetLimits('window-test');

      const allowed = pluginRateLimiter.checkOperationLimit('window-test', 'initialization');
      expect(allowed).toBe(true);
    });
  });

  describe('Initialization Rate Limiting', () => {
    it('should check initialization rate limit', () => {
      const allowed = pluginRateLimiter.checkInitialization('init-test');
      expect(allowed).toBe(true);
    });

    it('should track initializations', () => {
      pluginRateLimiter.trackInitialization('init-track');

      const stats = pluginRateLimiter.getStats('init-track');
      expect(stats.totalOperations).toBe(1);
    });

    it('should enforce initialization limits', () => {
      const config = pluginRateLimiter.getConfig();

      for (let i = 0; i < config.maxInitializationsPerMinute + 1; i++) {
        pluginRateLimiter.trackInitialization('excessive-init');
      }

      const allowed = pluginRateLimiter.checkInitialization('excessive-init');
      expect(allowed).toBe(false);
    });
  });

  describe('Hook Execution Rate Limiting', () => {
    it('should check hook execution rate limit', () => {
      const allowed = pluginRateLimiter.checkHookExecution('hook-test', 'beforeRead');
      expect(allowed).toBe(true);
    });

    it('should track hook executions', () => {
      pluginRateLimiter.trackHookExecution('hook-track', 'beforeRead');

      const stats = pluginRateLimiter.getStats('hook-track');
      expect(stats.operationsByType['hook:beforeRead']).toBe(1);
    });
  });

  describe('Resource Access Rate Limiting', () => {
    it('should check resource access rate limit', () => {
      const allowed = pluginRateLimiter.checkResourceAccess('resource-test', 'database');
      expect(allowed).toBe(true);
    });

    it('should track resource access', () => {
      pluginRateLimiter.trackResourceAccess('resource-track', 'database');

      const stats = pluginRateLimiter.getStats('resource-track');
      expect(stats.operationsByType['resource:database']).toBe(1);
    });
  });

  describe('Violation Tracking', () => {
    it('should record violations', () => {
      const config = pluginRateLimiter.getConfig();

      // Exceed limit to trigger violation
      for (let i = 0; i < config.maxInitializationsPerMinute + 2; i++) {
        pluginRateLimiter.trackInitialization('violation-test');
      }

      // Check should fail and record violation
      pluginRateLimiter.checkInitialization('violation-test');

      const violations = pluginRateLimiter.getViolations('violation-test');
      expect(violations.length).toBeGreaterThan(0);
    });

    it('should clear violations', () => {
      // Create a violation
      const config = pluginRateLimiter.getConfig();
      for (let i = 0; i < config.maxInitializationsPerMinute + 1; i++) {
        pluginRateLimiter.trackInitialization('clear-violation');
      }
      pluginRateLimiter.checkInitialization('clear-violation');

      expect(pluginRateLimiter.getViolations('clear-violation').length).toBeGreaterThan(0);

      // Clear violations
      pluginRateLimiter.clearViolations('clear-violation');

      expect(pluginRateLimiter.getViolations('clear-violation').length).toBe(0);
    });

    it('should detect when plugin should be disabled', () => {
      const config = pluginRateLimiter.getConfig();

      // Create violations exceeding threshold
      for (let i = 0; i < config.violationThreshold + 1; i++) {
        for (let j = 0; j < config.maxInitializationsPerMinute + 1; j++) {
          pluginRateLimiter.trackInitialization('disable-candidate');
        }
        pluginRateLimiter.checkInitialization('disable-candidate');
      }

      const shouldDisable = pluginRateLimiter.shouldDisablePlugin('disable-candidate');
      expect(shouldDisable).toBe(true);
    });
  });

  describe('Statistics', () => {
    it('should return global statistics', () => {
      pluginRateLimiter.trackInitialization('stats-plugin-1');
      pluginRateLimiter.trackHookExecution('stats-plugin-2', 'beforeRead');

      const stats = pluginRateLimiter.getStats();

      expect(stats.totalOperations).toBeGreaterThan(0);
      expect(stats.operationsByType).toBeDefined();
    });

    it('should return plugin-specific statistics', () => {
      pluginRateLimiter.trackInitialization('specific-stats');

      const stats = pluginRateLimiter.getStats('specific-stats');

      expect(stats.totalOperations).toBe(1);
    });

    it('should track top offenders', () => {
      const config = pluginRateLimiter.getConfig();

      // Create violations
      for (let i = 0; i < config.maxInitializationsPerMinute + 2; i++) {
        pluginRateLimiter.trackInitialization('offender-1');
      }
      pluginRateLimiter.checkInitialization('offender-1');

      const stats = pluginRateLimiter.getStats();
      expect(stats.topOffenders.length).toBeGreaterThan(0);
    });
  });

  describe('Configuration', () => {
    it('should update configuration', () => {
      const newConfig = {
        maxInitializationsPerMinute: 10,
        maxHookExecutionsPerMinute: 2000,
      };

      pluginRateLimiter.updateConfig(newConfig);

      const config = pluginRateLimiter.getConfig();
      expect(config.maxInitializationsPerMinute).toBe(10);
      expect(config.maxHookExecutionsPerMinute).toBe(2000);
    });

    it('should get current configuration', () => {
      const config = pluginRateLimiter.getConfig();

      expect(config).toBeDefined();
      expect(config.maxInitializationsPerMinute).toBeGreaterThan(0);
      expect(config.maxHookExecutionsPerMinute).toBeGreaterThan(0);
      expect(config.violationThreshold).toBeGreaterThan(0);
    });
  });

  describe('Limit Reset', () => {
    it('should reset limits for specific plugin', () => {
      pluginRateLimiter.trackInitialization('reset-test');
      pluginRateLimiter.resetLimits('reset-test');

      const stats = pluginRateLimiter.getStats('reset-test');
      expect(stats.totalOperations).toBe(0);
    });

    it('should reset all limits', () => {
      pluginRateLimiter.trackInitialization('reset-all-1');
      pluginRateLimiter.trackInitialization('reset-all-2');

      pluginRateLimiter.resetLimits();

      const stats = pluginRateLimiter.getStats();
      expect(stats.totalOperations).toBe(0);
    });
  });

  describe('All Violations', () => {
    it('should get all violations across plugins', () => {
      const config = pluginRateLimiter.getConfig();

      // Create violations for multiple plugins
      for (let i = 0; i < config.maxInitializationsPerMinute + 1; i++) {
        pluginRateLimiter.trackInitialization('violation-1');
        pluginRateLimiter.trackInitialization('violation-2');
      }

      pluginRateLimiter.checkInitialization('violation-1');
      pluginRateLimiter.checkInitialization('violation-2');

      const allViolations = pluginRateLimiter.getAllViolations();
      expect(allViolations.size).toBeGreaterThan(0);
    });
  });
});
