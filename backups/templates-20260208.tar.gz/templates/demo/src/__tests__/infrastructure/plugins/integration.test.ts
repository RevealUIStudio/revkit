/**
 * Integration Tests for Plugin System
 * Tests the complete plugin loading, verification, and execution flow
 */
import {
  PluginPermission,
  PluginState,
  pluginLifecycleManager,
  pluginRateLimiter,
  pluginRegistry,
  pluginVerifier,
} from '@revealui/infrastructure/plugins/config';
import type { Config, Plugin } from '@revealui/content';
import { beforeEach, describe, expect, it } from 'vitest';

describe('Plugin System Integration', () => {
  const mockConfig: Config = {
    collections: [],
    db: {} as Config['db'],
    secret: 'test-secret',
  };

  beforeEach(() => {
    // Reset rate limiter
    pluginRateLimiter.resetLimits();
  });

  describe('Complete Plugin Loading Flow', () => {
    it('should complete full plugin lifecycle: register → verify → install → enable', async () => {
      // Step 1: Register plugin in allowlist
      pluginRegistry.registerPlugin({
        name: 'integration-test-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS, PluginPermission.EXECUTE_HOOKS],
        verified: true,
        description: 'Test plugin for integration',
      });

      // Step 2: Verify plugin
      const verification = await pluginVerifier.verifyPlugin('integration-test-plugin', '1.0.0');
      expect(verification.valid).toBe(true);

      // Step 3: Create plugin function
      const testPlugin: Plugin = (config: Config) => ({
        ...config,
        collections: [...(config.collections || [])],
      });

      // Step 4: Install plugin
      await pluginLifecycleManager.installPlugin(
        'integration-test-plugin',
        '1.0.0',
        testPlugin,
        mockConfig
      );

      expect(pluginLifecycleManager.getPluginState('integration-test-plugin')).toBe(
        PluginState.INSTALLED
      );

      // Step 5: Enable plugin
      await pluginLifecycleManager.enablePlugin('integration-test-plugin');

      expect(pluginLifecycleManager.getPluginState('integration-test-plugin')).toBe(
        PluginState.ENABLED
      );

      // Verify events were recorded
      const events = pluginLifecycleManager.getEvents('integration-test-plugin');
      expect(events.length).toBeGreaterThan(0);
    });

    it('should handle plugin failure with automatic rollback', async () => {
      // Register failing plugin
      pluginRegistry.registerPlugin({
        name: 'failing-integration-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
      });

      // Create failing plugin
      const failingPlugin: Plugin = () => {
        throw new Error('Simulated plugin failure');
      };

      // Attempt installation - should fail and rollback
      await expect(
        pluginLifecycleManager.installPlugin(
          'failing-integration-test',
          '1.0.0',
          failingPlugin,
          mockConfig
        )
      ).rejects.toThrow();

      // Check state is FAILED
      expect(pluginLifecycleManager.getPluginState('failing-integration-test')).toBe(
        PluginState.FAILED
      );

      // Attempt rollback
      await expect(
        pluginLifecycleManager.rollbackPlugin('failing-integration-test')
      ).resolves.not.toThrow();
    });

    it('should enforce rate limits during plugin operations', async () => {
      const config = pluginRateLimiter.getConfig();

      // Register plugin
      pluginRegistry.registerPlugin({
        name: 'rate-limit-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
      });

      // Exceed initialization rate limit
      for (let i = 0; i < config.maxInitializationsPerMinute + 1; i++) {
        pluginRateLimiter.trackInitialization('rate-limit-test');
      }

      // Next check should fail
      const allowed = pluginRateLimiter.checkInitialization('rate-limit-test');
      expect(allowed).toBe(false);

      // Violations should be recorded
      const violations = pluginRateLimiter.getViolations('rate-limit-test');
      expect(violations.length).toBeGreaterThan(0);
    });
  });

  describe('Security Enforcement', () => {
    it('should block unauthorized plugins', async () => {
      // Try to verify plugin not in allowlist
      const result = await pluginVerifier.verifyPlugin('unauthorized-plugin', '1.0.0');

      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.includes('not in the allowlist'))).toBe(true);
    });

    it('should validate dangerous permission combinations', async () => {
      pluginRegistry.registerPlugin({
        name: 'dangerous-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.ADMIN_ACCESS, PluginPermission.FILESYSTEM_WRITE],
        verified: true,
      });

      const result = await pluginVerifier.verifyPlugin('dangerous-plugin', '1.0.0');

      expect(result.warnings.some(w => w.includes('broad permissions'))).toBe(true);
    });

    it('should detect dangerous code patterns', () => {
      const dangerousCode = `
        function malicious() {
          eval('process.exit(1)');
        }
      `;

      const result = pluginVerifier.sanitizePluginCode(dangerousCode);

      expect(result.safe).toBe(false);
      expect(result.removed.length).toBeGreaterThan(0);
    });
  });

  describe('Multi-Plugin Scenarios', () => {
    it('should handle multiple plugins with dependencies', async () => {
      // Register base plugin
      pluginRegistry.registerPlugin({
        name: 'base-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
      });

      // Register dependent plugin
      pluginRegistry.registerPlugin({
        name: 'dependent-plugin',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [PluginPermission.READ_COLLECTIONS],
        verified: true,
        dependencies: ['base-plugin'],
      });

      // Both should verify successfully
      const baseVerification = await pluginVerifier.verifyPlugin('base-plugin', '1.0.0');
      const depVerification = await pluginVerifier.verifyPlugin('dependent-plugin', '1.0.0');

      expect(baseVerification.valid).toBe(true);
      expect(depVerification.valid).toBe(true);
    });

    it('should handle concurrent plugin operations', async () => {
      // Register multiple plugins
      const plugins = ['concurrent-1', 'concurrent-2', 'concurrent-3'];

      plugins.forEach(name => {
        pluginRegistry.registerPlugin({
          name,
          version: '1.0.0',
          checksum: '',
          author: 'test',
          permissions: [PluginPermission.READ_COLLECTIONS],
          verified: true,
        });
      });

      // Verify all plugins concurrently
      const verifications = await Promise.all(
        plugins.map(name => pluginVerifier.verifyPlugin(name, '1.0.0'))
      );

      verifications.forEach(v => {
        expect(v.valid).toBe(true);
      });
    });
  });

  describe('Error Scenarios', () => {
    it('should handle missing plugin gracefully', async () => {
      const result = await pluginVerifier.verifyPlugin('non-existent-plugin', '1.0.0');

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should handle invalid version gracefully', async () => {
      pluginRegistry.registerPlugin({
        name: 'version-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      const result = await pluginVerifier.verifyPlugin('version-test', '99.0.0');

      expect(result.valid).toBe(false);
    });
  });

  describe('Telemetry Integration', () => {
    it('should track plugin operations with telemetry', async () => {
      // This is tested through the lifecycle manager
      // which automatically records telemetry
      const testPlugin: Plugin = (config: Config) => config;

      pluginRegistry.registerPlugin({
        name: 'telemetry-integration',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      await pluginLifecycleManager.installPlugin(
        'telemetry-integration',
        '1.0.0',
        testPlugin,
        mockConfig
      );

      // Telemetry should have been recorded
      const state = pluginLifecycleManager.getPluginState('telemetry-integration');
      expect(state).toBe(PluginState.INSTALLED);
    });
  });

  describe('Cleanup and Resource Management', () => {
    it('should clean up plugin resources on removal', async () => {
      const testPlugin: Plugin = (config: Config) => config;

      pluginRegistry.registerPlugin({
        name: 'cleanup-test',
        version: '1.0.0',
        checksum: '',
        author: 'test',
        permissions: [],
        verified: true,
      });

      await pluginLifecycleManager.installPlugin('cleanup-test', '1.0.0', testPlugin, mockConfig);

      // Remove installation
      const removed = pluginLifecycleManager.removeInstallation('cleanup-test');
      expect(removed).toBe(true);

      // Should no longer exist
      const state = pluginLifecycleManager.getPluginState('cleanup-test');
      expect(state).toBeNull();
    });
  });
});
