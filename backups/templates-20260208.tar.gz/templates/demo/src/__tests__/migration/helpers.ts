/**
 * Migration Testing Helpers
 *
 * Test utilities for migration feature flags, before/after comparisons, and validation.
 */

import type { ComparisonResult, MigrationValidationResult } from '@revealui/core/shared-types';
import type { FeatureFlagRecord } from '@/contracts';
import { defaultFeatureFlags } from '@/features/flags/config/feature-flags';
import {
  resetMigrationTracking,
  startMigrationMetrics,
  trackMigrationStatus,
} from '@revealui/infrastructure/feature-flags/rollout-tracker';

// ======
// FEATURE FLAG TOGGLING IN TESTS
// ======

/**
 * Create a test feature flag record with specific flags enabled/disabled
 */
export function createTestFlags(
  overrides: Partial<Record<string, Partial<FeatureFlagRecord[string]>>>
): FeatureFlagRecord {
  const flags: FeatureFlagRecord = { ...defaultFeatureFlags };

  for (const [flagName, flagConfig] of Object.entries(overrides)) {
    if (flags[flagName]) {
      flags[flagName] = {
        ...flags[flagName],
        ...flagConfig,
      };
    } else {
      flags[flagName] = {
        name: flagName,
        enabled: false,
        ...flagConfig,
      } as FeatureFlagRecord[string];
    }
  }

  return flags;
}

/**
 * Enable a migration flag for testing
 */
export function enableMigrationFlag(
  flags: FeatureFlagRecord,
  flagName: string,
  rolloutPercentage: number = 100
): FeatureFlagRecord {
  return createTestFlags({
    [flagName]: {
      enabled: true,
      rolloutPercentage,
    },
  });
}

/**
 * Disable a migration flag for testing
 */
export function disableMigrationFlag(
  flags: FeatureFlagRecord,
  flagName: string
): FeatureFlagRecord {
  return createTestFlags({
    [flagName]: {
      enabled: false,
      rolloutPercentage: 0,
    },
  });
}

/**
 * Set rollout percentage for a migration flag
 */
export function setRolloutPercentage(
  flags: FeatureFlagRecord,
  flagName: string,
  percentage: number
): FeatureFlagRecord {
  return createTestFlags({
    [flagName]: {
      enabled: percentage > 0,
      rolloutPercentage: percentage,
    },
  });
}

/**
 * Create flags with all migration flags enabled
 */
export function createAllMigrationFlagsEnabled(): FeatureFlagRecord {
  return createTestFlags({
    unifiedAuth: { enabled: true, rolloutPercentage: 100 },
    unifiedValidation: { enabled: true, rolloutPercentage: 100 },
    unifiedLogger: { enabled: true, rolloutPercentage: 100 },
    unifiedResultTypes: { enabled: true, rolloutPercentage: 100 },
  });
}

/**
 * Create flags with all migration flags disabled
 */
export function createAllMigrationFlagsDisabled(): FeatureFlagRecord {
  return createTestFlags({
    unifiedAuth: { enabled: false, rolloutPercentage: 0 },
    unifiedValidation: { enabled: false, rolloutPercentage: 0 },
    unifiedLogger: { enabled: false, rolloutPercentage: 0 },
    unifiedResultTypes: { enabled: false, rolloutPercentage: 0 },
  });
}

// ======
// BEFORE/AFTER COMPARISON UTILITIES
// ======

/**
 * Compare two values and return differences
 */
export function compareValues<T>(before: T, after: T): ComparisonResult<T> {
  const differences: string[] = [];
  let isEqual = true;

  if (typeof before !== typeof after) {
    differences.push(`Type mismatch: ${typeof before} vs ${typeof after}`);
    isEqual = false;
  } else if (typeof before === 'object' && before !== null && after !== null) {
    // Deep comparison for objects
    // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
    const beforeKeys = Object.keys(
      before as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
        string,
        unknown
      >
    );
    // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
    const afterKeys = Object.keys(
      after as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
        string,
        unknown
      >
    );

    const allKeys = new Set([...beforeKeys, ...afterKeys]);

    for (const key of allKeys) {
      // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
      const beforeValue = (
        before as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
          string,
          unknown
        >
      )[key];
      // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
      const afterValue = (
        after as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
          string,
          unknown
        >
      )[key];

      // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
      if (
        !(
          key in
          (before as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
            string,
            unknown
          >)
        )
      ) {
        differences.push(`Key '${key}' added in after`);
        isEqual = false;
        // Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed
      } else if (
        !(
          key in
          (after as /* Using Record<string, unknown> because object structure varies by migration data and cannot be strictly typed */ Record<
            string,
            unknown
          >)
        )
      ) {
        differences.push(`Key '${key}' removed in after`);
        isEqual = false;
      } else if (JSON.stringify(beforeValue) !== JSON.stringify(afterValue)) {
        differences.push(
          `Key '${key}' changed: ${JSON.stringify(beforeValue)} -> ${JSON.stringify(afterValue)}`
        );
        isEqual = false;
      }
    }
  } else if (before !== after) {
    differences.push(`Value changed: ${String(before)} -> ${String(after)}`);
    isEqual = false;
  }

  return {
    before,
    after,
    differences,
    isEqual,
  };
}

/**
 * Compare function results before and after migration
 */
export async function compareFunctionResults<T>(
  beforeFn: () => Promise<T> | T,
  afterFn: () => Promise<T> | T
): Promise<ComparisonResult<T>> {
  const before = await beforeFn();
  const after = await afterFn();
  return compareValues(before, after);
}

/**
 * Compare API responses before and after migration
 */
export async function compareApiResponses(
  beforeFn: () => Promise<Response>,
  afterFn: () => Promise<Response>
): Promise<ComparisonResult<unknown>> {
  const beforeResponse = await beforeFn();
  const afterResponse = await afterFn();

  const beforeData = await beforeResponse.json();
  const afterData = await afterResponse.json();

  return compareValues(beforeData, afterData);
}

// ======
// MIGRATION VALIDATION HELPERS
// ======

/**
 * Validate that migration flag is properly configured
 */
export function validateMigrationFlag(
  flags: FeatureFlagRecord,
  flagName: string
): MigrationValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  const flag = flags[flagName];
  if (!flag) {
    errors.push(`Flag '${flagName}' not found in feature flags`);
    return { isValid: false, errors, warnings };
  }

  if (flag.enabled && flag.rolloutPercentage !== undefined) {
    if (flag.rolloutPercentage < 0 || flag.rolloutPercentage > 100) {
      errors.push(`Flag '${flagName}' has invalid rolloutPercentage: ${flag.rolloutPercentage}`);
    }
  }

  if (flag.enabled && (!flag.rolloutPercentage || flag.rolloutPercentage === 0)) {
    warnings.push(`Flag '${flagName}' is enabled but rolloutPercentage is 0`);
  }

  if (!flag.enabled && flag.rolloutPercentage && flag.rolloutPercentage > 0) {
    warnings.push(
      `Flag '${flagName}' is disabled but rolloutPercentage is ${flag.rolloutPercentage}`
    );
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Validate all migration flags
 */
export function validateAllMigrationFlags(
  flags: FeatureFlagRecord
): Record<string, MigrationValidationResult> {
  const results: Record<string, MigrationValidationResult> = {};

  const migrationFlagNames = [
    'unifiedAuth',
    'unifiedValidation',
    'unifiedLogger',
    'unifiedResultTypes',
  ];

  for (const flagName of migrationFlagNames) {
    results[flagName] = validateMigrationFlag(flags, flagName);
  }

  return results;
}

/**
 * Setup test environment for migration testing
 */
export function setupMigrationTest(): void {
  // Reset migration tracking
  resetMigrationTracking();

  // Initialize migration statuses
  trackMigrationStatus('unifiedAuth', 0, 0);
  trackMigrationStatus('unifiedValidation', 0, 0);
  trackMigrationStatus('unifiedLogger', 0, 0);
  trackMigrationStatus('unifiedResultTypes', 0, 0);

  // Start metrics tracking
  startMigrationMetrics('unifiedAuth');
  startMigrationMetrics('unifiedValidation');
  startMigrationMetrics('unifiedLogger');
  startMigrationMetrics('unifiedResultTypes');
}

/**
 * Cleanup test environment
 */
export function cleanupMigrationTest(): void {
  resetMigrationTracking();
}

/**
 * Assert that migration produces same results as before
 */
export async function assertMigrationEquivalence<T>(
  beforeFn: () => Promise<T> | T,
  afterFn: () => Promise<T> | T,
  message?: string
): Promise<void> {
  const comparison = await compareFunctionResults(beforeFn, afterFn);

  if (!comparison.isEqual) {
    throw new Error(
      message || `Migration produced different results:\n${comparison.differences.join('\n')}`
    );
  }
}

/**
 * Assert that migration produces different results (for testing migration itself)
 */
export async function assertMigrationDifference<T>(
  beforeFn: () => Promise<T> | T,
  afterFn: () => Promise<T> | T,
  message?: string
): Promise<void> {
  const comparison = await compareFunctionResults(beforeFn, afterFn);

  if (comparison.isEqual) {
    throw new Error(message || 'Migration did not produce different results (expected difference)');
  }
}
