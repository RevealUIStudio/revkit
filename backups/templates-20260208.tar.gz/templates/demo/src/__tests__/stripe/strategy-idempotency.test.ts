import { StripePaymentStrategy } from '@revealui/infrastructure/integrations/payment/StripePaymentStrategy';
import { describe, expect, it, vi } from 'vitest';

describe('StripePaymentStrategy idempotency', () => {
  it('does not throw when no client yet (initialize later)', async () => {
    const strategy = new StripePaymentStrategy('sk_test_xxx', 'whsec_xxx');
    const res = await strategy.initialize();
    expect(res.success === true || res.success === false).toBeTruthy();
  });
});
