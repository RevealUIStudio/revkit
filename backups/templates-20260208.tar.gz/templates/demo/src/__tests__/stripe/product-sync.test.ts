import { createMockRevealUIRequest } from '@revealui/dev/testing';
import type { RevealUI } from '@revealui/content';
import { beforeEach, describe, expect, it, vi } from 'vitest';

describe('Stripe Product Synchronization', () => {
  let mockRevealUI: RevealUI;

  beforeEach(() => {
    mockRevealUI = {
      find: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    } as unknown as RevealUI;

    vi.clearAllMocks();
  });

  describe('Product Field Mappings', () => {
    it('should map RevealUI Content Engine fields to Stripe properties correctly', () => {
      const fieldMappings = [
        { fieldPath: 'title', stripeProperty: 'name' },
        { fieldPath: 'description', stripeProperty: 'description' },
        { fieldPath: 'stripeProductID', stripeProperty: 'id' },
      ];

      expect(fieldMappings).toHaveLength(3);
      expect(fieldMappings[0]).toEqual({
        fieldPath: 'title',
        stripeProperty: 'name',
      });
    });

    it('should validate required Stripe sync fields exist in Products collection', () => {
      const requiredFields = ['stripeProductID', 'stripePriceID', 'priceJSON', 'enableSync'];

      requiredFields.forEach(field => {
        expect(field).toBeTruthy();
        expect(typeof field).toBe('string');
      });
    });
  });

  describe('Price Conversion', () => {
    it('should convert Stripe cents to dollars correctly', () => {
      const testCases = [
        { cents: 2999, expected: 29.99 },
        { cents: 10000, expected: 100.0 },
        { cents: 1599, expected: 15.99 },
        { cents: 0, expected: 0 },
      ];

      testCases.forEach(({ cents, expected }) => {
        const dollars = cents / 100;
        expect(dollars).toBe(expected);
      });
    });

    it('should convert dollars to Stripe cents correctly', () => {
      const testCases = [
        { dollars: 29.99, expected: 2999 },
        { dollars: 100.0, expected: 10000 },
        { dollars: 15.99, expected: 1599 },
        { dollars: 0, expected: 0 },
      ];

      testCases.forEach(({ dollars, expected }) => {
        const cents = Math.round(dollars * 100);
        expect(cents).toBe(expected);
      });
    });
  });

  describe('Currency Handling', () => {
    it('should convert currency to uppercase correctly', () => {
      const currencies = ['usd', 'eur', 'gbp', 'cad'];
      const expectedCurrencies = ['USD', 'EUR', 'GBP', 'CAD'];

      currencies.forEach((currency, index) => {
        expect(currency.toUpperCase()).toBe(expectedCurrencies[index]);
      });
    });
  });

  describe('Slug Generation', () => {
    it('should generate valid slugs from product names', () => {
      const testCases = [
        { name: 'Test Product', expected: 'test-product' },
        { name: 'Product with Spaces', expected: 'product-with-spaces' },
        { name: 'Product  Multiple  Spaces', expected: 'product-multiple-spaces' },
        { name: 'UPPERCASE PRODUCT', expected: 'uppercase-product' },
      ];

      testCases.forEach(({ name, expected }) => {
        const slug = name.toLowerCase().replace(/\s+/g, '-');
        expect(slug).toBe(expected);
      });
    });
  });

  describe('Status Mapping', () => {
    it('should map Stripe active status to RevealUI Content Engine status', () => {
      const statusMappings = [
        { stripeActive: true, expected: 'published' },
        { stripeActive: false, expected: 'draft' },
      ];

      statusMappings.forEach(({ stripeActive, expected }) => {
        const status = stripeActive ? 'published' : 'draft';
        expect(status).toBe(expected);
      });
    });
  });

  describe('Product Sync Validation', () => {
    it('should validate product has required fields for sync', () => {
      const validProduct = {
        title: 'Test Product',
        slug: 'test-product',
        price: 29.99,
        currency: 'USD',
        enableSync: true,
      };

      expect(validProduct.title).toBeTruthy();
      expect(validProduct.slug).toBeTruthy();
      expect(validProduct.price).toBeGreaterThanOrEqual(0);
      expect(validProduct.currency).toBeTruthy();
      expect(validProduct.enableSync).toBe(true);
    });

    it('should handle products with sync disabled', () => {
      const productWithoutSync = {
        title: 'Non-Synced Product',
        enableSync: false,
      };

      expect(productWithoutSync.enableSync).toBe(false);
    });
  });

  describe('Error Scenarios', () => {
    it('should handle null or undefined product data', () => {
      const invalidProducts = [null, undefined, {}];

      invalidProducts.forEach(product => {
        expect(product === null || product === undefined || Object.keys(product).length === 0).toBe(
          true
        );
      });
    });

    it('should handle missing price data gracefully', () => {
      const productWithoutPrice = {
        title: 'Product',
        slug: 'product',
      };

      const price = (productWithoutPrice as { price?: number }).price ?? 0;
      expect(price).toBe(0);
    });

    it('should handle invalid currency codes', () => {
      const invalidCurrencies = ['', null, undefined];

      invalidCurrencies.forEach(currency => {
        // Use || instead of ?? to catch empty strings
        const validCurrency = currency || 'USD';
        expect(validCurrency).toBe('USD');
      });
    });
  });

  describe('Metadata Handling', () => {
    it('should preserve metadata during sync', () => {
      const metadata = {
        source: 'stripe',
        category: 'physical',
        tags: ['featured', 'sale'],
      };

      expect(metadata.source).toBe('stripe');
      expect(metadata.category).toBe('physical');
      expect(Array.isArray(metadata.tags)).toBe(true);
      expect(metadata.tags).toHaveLength(2);
    });

    it('should handle empty metadata', () => {
      const emptyMetadata = {};
      expect(Object.keys(emptyMetadata)).toHaveLength(0);
    });
  });

  describe('Product Sync Operations', () => {
    it('should sync product from Stripe to RevealUI Content Engine', async () => {
      const stripeProduct = {
        id: 'prod_123',
        name: 'Test Product',
        description: 'A test product',
        active: true,
        metadata: {
          category: 'electronics',
          source: 'stripe',
        },
      };

      const mockReq = createMockRevealUIRequest({
        method: 'POST',
        url: '/api/stripe/sync-product',
        body: { stripeProduct },
      });

      const revealuiProduct = {
        id: 'revealui_123',
        title: stripeProduct.name,
        description: stripeProduct.description,
        stripeProductID: stripeProduct.id,
        status: 'published',
        metadata: stripeProduct.metadata,
      };

      mockReq.revealui.create = vi.fn().mockResolvedValue(revealuiProduct);

      expect(mockReq.body.stripeProduct.id).toBe('prod_123');
      expect(mockReq.revealui.create).toBeDefined();
    });

    it('should update existing product during sync', async () => {
      const existingProduct = {
        id: 'revealui_123',
        stripeProductID: 'prod_123',
        title: 'Old Title',
        description: 'Old Description',
      };

      const updatedStripeProduct = {
        id: 'prod_123',
        name: 'Updated Product',
        description: 'Updated Description',
        active: true,
      };

      const mockReq = createMockRevealUIRequest({
        method: 'PUT',
        url: '/api/stripe/sync-product',
        body: {
          stripeProduct: updatedStripeProduct,
          existingProduct,
        },
      });

      const updatedProduct = {
        ...existingProduct,
        title: updatedStripeProduct.name,
        description: updatedStripeProduct.description,
      };

      mockReq.revealui.update = vi.fn().mockResolvedValue(updatedProduct);

      expect(mockReq.body.stripeProduct.name).toBe('Updated Product');
      expect(mockReq.revealui.update).toBeDefined();
    });
  });

  describe('Webhook Handling', () => {
    it('should handle Stripe product.created webhook', async () => {
      const webhookEvent = {
        type: 'product.created',
        data: {
          object: {
            id: 'prod_123',
            name: 'New Product',
            description: 'A new product from webhook',
            active: true,
          },
        },
      };

      const mockReq = createMockRevealUIRequest({
        method: 'POST',
        url: '/api/revealui/stripe/webhooks',
        body: webhookEvent,
        headers: {
          'stripe-signature': 'test_signature',
        },
      });

      const syncedProduct = {
        id: 'revealui_123',
        title: webhookEvent.data.object.name,
        stripeProductID: webhookEvent.data.object.id,
        status: 'published',
      };

      mockReq.revealui.create = vi.fn().mockResolvedValue(syncedProduct);

      expect(mockReq.body.type).toBe('product.created');
      expect(mockReq.body.data.object.id).toBe('prod_123');
      expect(mockReq.revealui.create).toBeDefined();
    });

    it('should handle Stripe product.updated webhook', async () => {
      const webhookEvent = {
        type: 'product.updated',
        data: {
          object: {
            id: 'prod_123',
            name: 'Updated Product Name',
            description: 'Updated description',
            active: true,
          },
        },
      };

      const mockReq = createMockRevealUIRequest({
        method: 'POST',
        url: '/api/revealui/stripe/webhooks',
        body: webhookEvent,
        headers: {
          'stripe-signature': 'test_signature',
        },
      });

      const updatedProduct = {
        id: 'revealui_123',
        title: webhookEvent.data.object.name,
        stripeProductID: webhookEvent.data.object.id,
      };

      mockReq.revealui.update = vi.fn().mockResolvedValue(updatedProduct);

      expect(mockReq.body.type).toBe('product.updated');
      expect(mockReq.revealui.update).toBeDefined();
    });
  });

  describe('Duplicate Detection', () => {
    it('should detect existing products by Stripe Product ID', async () => {
      const stripeProductID = 'prod_123';

      (mockRevealUI.find as ReturnType<typeof vi.fn>).mockResolvedValue({
        docs: [{ id: 'revealui_123', stripeProductID }],
        totalDocs: 1,
      });

      const result = await mockRevealUI.find({
        collection: 'products',
        where: {
          stripeProductID: {
            equals: stripeProductID,
          },
        },
        limit: 1,
      });

      expect(result.docs).toHaveLength(1);
      expect(result.docs[0]?.stripeProductID).toBe(stripeProductID);
    });

    it('should return empty array when product not found', async () => {
      (mockRevealUI.find as ReturnType<typeof vi.fn>).mockResolvedValue({
        docs: [],
        totalDocs: 0,
      });

      const result = await mockRevealUI.find({
        collection: 'products',
        where: {
          stripeProductID: {
            equals: 'prod_nonexistent',
          },
        },
        limit: 1,
      });

      expect(result.docs).toHaveLength(0);
      expect(result.totalDocs).toBe(0);
    });
  });
});
