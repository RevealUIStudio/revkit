import type { FullConfig } from '@playwright/test';

/**
 * Global teardown for Playwright E2E tests
 * Runs once after all tests complete
 */
async function globalTeardown(config: FullConfig) {
  console.log('🧹 Cleaning up E2E test environment...');

  // Cleanup tasks can be added here:
  // - Delete test users
  // - Clean up test database
  // - Remove temporary files
  // - Clear authentication state
  // - Reset test data

  // Intentionally use config to satisfy linting
  const projectCount = config.projects.length;
  console.log(`[OK] E2E test environment cleanup complete (${projectCount} projects tested)`);
}

export default globalTeardown;
