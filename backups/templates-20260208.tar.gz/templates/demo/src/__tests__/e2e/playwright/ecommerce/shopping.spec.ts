/**
 * E2E Test: Shopping & Checkout Journey
 * Tests complete shopping workflow from product browse to checkout
 */

import { expect, test } from '@playwright/test';

test.describe('Shopping & Checkout Journey', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to shop page
    await page.goto('/shop');
  });

  test('should browse products and view details', async ({ page }) => {
    // Wait for products to load
    await page.waitForSelector('[data-testid="product-card"]', { timeout: 5000 });

    // Check if products are displayed
    const productCards = await page.$$('[data-testid="product-card"]');
    expect(productCards.length).toBeGreaterThan(0);

    // Click on first product
    if (productCards.length > 0) {
      await productCards[0].click();

      // Wait for product detail page
      await page.waitForSelector('[data-testid="product-title"]', { timeout: 5000 });

      // Verify product details are displayed
      const productTitle = await page.textContent('[data-testid="product-title"]');
      expect(productTitle).toBeTruthy();
    }
  });

  test('should add product to cart', async ({ page }) => {
    // Wait for shop page to load
    await page.waitForLoadState('networkidle');

    // Look for "Add to Cart" button
    const addToCartButton = page.locator('button:has-text("Add to Cart")').first();

    if (await addToCartButton.isVisible({ timeout: 5000 })) {
      // Click add to cart
      await addToCartButton.click();

      // Wait for cart to update (look for cart icon or notification)
      await page.waitForTimeout(1000);

      // Verify cart icon shows item count
      const cartIcon = page.locator('[data-testid="cart-icon"]');
      if (await cartIcon.isVisible()) {
        const cartCount = await cartIcon.textContent();
        expect(cartCount).toBeTruthy();
      }
    }
  });

  test('should view cart page', async ({ page }) => {
    // Navigate to cart
    await page.goto('/cart');

    // Wait for cart page to load
    await page.waitForLoadState('networkidle');

    // Verify cart page elements
    const cartTitle = page.locator('h1:has-text("Cart")');
    expect(await cartTitle.isVisible({ timeout: 5000 })).toBeTruthy();
  });

  test('should update cart item quantity', async ({ page }) => {
    // Go to cart page
    await page.goto('/cart');
    await page.waitForLoadState('networkidle');

    // Look for quantity input or increment/decrement buttons
    const quantityInput = page.locator('input[type="number"]').first();
    const incrementButton = page
      .locator(
        'button:has-text("+"), button[aria-label*="increment"], button[aria-label*="increase"]'
      )
      .first();
    const decrementButton = page
      .locator(
        'button:has-text("-"), button[aria-label*="decrement"], button[aria-label*="decrease"]'
      )
      .first();

    if (await quantityInput.isVisible({ timeout: 5000 })) {
      // Get initial value
      const initialValue = await quantityInput.inputValue();
      const initialNum = Number.parseInt(initialValue || '1', 10);

      // Try increment button first
      if (await incrementButton.isVisible({ timeout: 2000 }).catch(() => false)) {
        await incrementButton.click();
        await page.waitForTimeout(500);

        // Verify quantity increased
        const newValue = await quantityInput.inputValue();
        const newNum = Number.parseInt(newValue || '1', 10);
        expect(newNum).toBeGreaterThan(initialNum);
      } else {
        // Fallback: update via input
        await quantityInput.fill('3');
        await quantityInput.press('Enter');
        await page.waitForTimeout(1000);
      }
    } else if (await incrementButton.isVisible({ timeout: 5000 }).catch(() => false)) {
      // If no input but has buttons, test button increment
      await incrementButton.click();
      await page.waitForTimeout(1000);
    }
  });

  test('should proceed to checkout', async ({ page }) => {
    // Go to cart page
    await page.goto('/cart');
    await page.waitForLoadState('networkidle');

    // Look for checkout button (multiple possible texts)
    const checkoutButton = page
      .locator(
        'button:has-text("Checkout"), button:has-text("Proceed to Checkout"), a:has-text("Checkout")'
      )
      .first();

    if (await checkoutButton.isVisible({ timeout: 5000 })) {
      await checkoutButton.click();

      // Wait for navigation to checkout page
      await page.waitForURL('**/checkout**', { timeout: 5000 });

      // Verify checkout page loaded
      expect(page.url()).toContain('/checkout');

      // Verify checkout page content
      const checkoutTitle = page.locator('h1:has-text("Checkout"), h2:has-text("Checkout")');
      await expect(checkoutTitle.isVisible({ timeout: 5000 }).catch(() => false)).toBeTruthy();
    }
  });

  test('should display order summary at checkout', async ({ page }) => {
    // Navigate directly to checkout
    await page.goto('/checkout');
    await page.waitForLoadState('networkidle');

    // Check for order summary section
    const orderSummary = page.locator('[data-testid="order-summary"]');

    if (await orderSummary.isVisible({ timeout: 5000 })) {
      // Verify subtotal, tax, shipping, total are displayed
      expect(orderSummary).toBeTruthy();
    }
  });

  test('should handle empty cart', async ({ page }) => {
    // Go to cart page
    await page.goto('/cart');
    await page.waitForLoadState('networkidle');

    // Check for empty cart message
    const emptyMessage = page.locator('text=/empty|no items/i');
    const checkoutButton = page.locator('button:has-text("Checkout")');

    // Either cart is empty or has items
    const isEmpty = await emptyMessage.isVisible({ timeout: 2000 }).catch(() => false);

    if (isEmpty) {
      // Checkout button should be disabled or hidden
      const isCheckoutVisible = await checkoutButton.isVisible().catch(() => false);
      expect(isCheckoutVisible).toBe(false);
    }
  });
});
