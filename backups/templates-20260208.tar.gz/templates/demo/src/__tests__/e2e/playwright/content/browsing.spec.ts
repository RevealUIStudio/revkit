/**
 * E2E Test: Content Browsing & Video Access
 * Tests content discovery and paywall workflows
 */

import { expect, test } from '@playwright/test';

test.describe('Content Browsing & Video Access', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should browse and view blog posts', async ({ page }) => {
    // Navigate to posts/blog page
    const postsLink = page.locator('a:has-text("Posts"), a:has-text("Blog")').first();

    if (await postsLink.isVisible({ timeout: 5000 })) {
      await postsLink.click();
      await page.waitForLoadState('networkidle');

      // Check for post listings
      const postCards = page.locator('[data-testid="post-card"], article');
      const hasCards = await postCards.count();

      if (hasCards > 0) {
        // Click first post
        await postCards.first().click();
        await page.waitForTimeout(1000);

        // Verify post page loaded
        const postTitle = page.locator('h1');
        expect(await postTitle.isVisible({ timeout: 5000 })).toBeTruthy();
      }
    }
  });

  test('should search for content', async ({ page }) => {
    // Look for search input
    const searchInput = page.locator('input[type="search"], input[placeholder*="Search"]').first();

    if (await searchInput.isVisible({ timeout: 5000 })) {
      // Enter search query
      await searchInput.fill('test');
      await searchInput.press('Enter');

      // Wait for results
      await page.waitForTimeout(1000);

      // Verify search results or search page loaded
      const resultsIndicator = page.locator('text=/results|found|search/i');
      const hasResults = await resultsIndicator.isVisible({ timeout: 2000 }).catch(() => false);

      expect(hasResults || page.url().includes('search')).toBeTruthy();
    }
  });

  test('should filter posts by category', async ({ page }) => {
    // Go to posts page
    await page.goto('/posts');
    await page.waitForLoadState('networkidle');

    // Look for category filters
    const categoryLink = page
      .locator('a[href*="/category/"], [data-testid="category-filter"]')
      .first();

    if (await categoryLink.isVisible({ timeout: 5000 })) {
      await categoryLink.click();
      await page.waitForTimeout(1000);

      // Verify filtered results
      const posts = page.locator('[data-testid="post-card"], article');
      const postCount = await posts.count();

      expect(postCount).toBeGreaterThanOrEqual(0);
    }
  });

  test('should view video content', async ({ page }) => {
    // Navigate to videos page
    await page.goto('/videos');
    await page.waitForLoadState('networkidle');

    // Look for video cards
    const videoCards = page.locator('[data-testid="video-card"], [class*="video"]').first();

    if (await videoCards.isVisible({ timeout: 5000 })) {
      await videoCards.click();
      await page.waitForTimeout(1000);

      // Verify video page loaded
      const videoPlayer = page.locator('video, [data-testid="video-player"]');
      const hasVideo = await videoPlayer.isVisible({ timeout: 5000 }).catch(() => false);

      expect(hasVideo || page.url().includes('video')).toBeTruthy();
    }
  });

  test('should encounter paywall for premium video', async ({ page }) => {
    // Go to videos
    await page.goto('/videos');
    await page.waitForLoadState('networkidle');

    // Look for premium indicator
    const premiumBadge = page.locator('text=/premium|paid|locked/i').first();

    if (await premiumBadge.isVisible({ timeout: 5000 })) {
      // Click on premium content
      const premiumCard = premiumBadge.locator('..').first();
      await premiumCard.click();
      await page.waitForTimeout(1000);

      // Should see paywall or login prompt
      const paywallIndicator = page.locator('text=/upgrade|subscribe|purchase|login/i');
      const hasPaywall = await paywallIndicator.isVisible({ timeout: 3000 }).catch(() => false);

      expect(hasPaywall).toBeTruthy();
    }
  });

  test('should redirect to login from paywall', async ({ page }) => {
    // Try to access premium content while logged out
    await page.goto('/videos');
    await page.waitForLoadState('networkidle');

    // Click premium content
    const premiumContent = page.locator('[data-testid="premium-video"]').first();

    if (await premiumContent.isVisible({ timeout: 2000 })) {
      await premiumContent.click();
      await page.waitForTimeout(1000);

      // Should redirect to login or show login prompt
      const loginIndicator = page.locator(
        'input[type="email"], input[type="password"], text=/login|sign in/i'
      );
      const hasLogin = await loginIndicator.isVisible({ timeout: 5000 }).catch(() => false);

      expect(hasLogin || page.url().includes('login')).toBeTruthy();
    }
  });

  test('should view free video without paywall', async ({ page }) => {
    await page.goto('/videos');
    await page.waitForLoadState('networkidle');

    // Look for free video
    const freeVideo = page
      .locator('[data-testid="free-video"], :not(:has([text*="premium"]))')
      .first();

    if (await freeVideo.isVisible({ timeout: 2000 })) {
      await freeVideo.click();
      await page.waitForTimeout(1000);

      // Should be able to watch without paywall
      const videoPlayer = page.locator('video');
      const hasPlayer = await videoPlayer.isVisible({ timeout: 5000 }).catch(() => false);

      expect(hasPlayer).toBeTruthy();
    }
  });

  test('should navigate between posts', async ({ page }) => {
    await page.goto('/posts');
    await page.waitForLoadState('networkidle');

    // Click first post
    const firstPost = page.locator('[data-testid="post-card"], article').first();

    if (await firstPost.isVisible({ timeout: 5000 })) {
      await firstPost.click();
      await page.waitForTimeout(1000);

      // Look for next/previous post navigation
      const navLink = page
        .locator('a:has-text("Next"), a:has-text("Previous"), [data-testid="next-post"]')
        .first();

      if (await navLink.isVisible({ timeout: 3000 })) {
        await navLink.click();
        await page.waitForTimeout(1000);

        // Verify navigation worked
        const postTitle = page.locator('h1');
        expect(await postTitle.isVisible({ timeout: 5000 })).toBeTruthy();
      }
    }
  });

  test('should view media gallery', async ({ page }) => {
    await page.goto('/media');
    await page.waitForLoadState('networkidle');

    // Look for media items
    const mediaItems = page.locator('img, [data-testid="media-item"]');
    const itemCount = await mediaItems.count();

    if (itemCount > 0) {
      // Click first item
      await mediaItems.first().click();
      await page.waitForTimeout(500);

      // Should show larger view or detail page
      expect(page.url()).toBeDefined();
    }
  });
});
