/**
 * E2E Test: Account Management
 * Tests user account workflows
 */

import { expect, test } from '@playwright/test';

test.describe('Account Management', () => {
  test('should display account page for logged in user', async ({ page }) => {
    // Navigate to account page
    await page.goto('/account');
    await page.waitForLoadState('networkidle');

    // Page should either show login form or account info
    const loginForm = page.locator('form:has(input[type="email"])');
    const accountInfo = page.locator('[data-testid="account-info"]');

    const hasLoginForm = await loginForm.isVisible({ timeout: 2000 }).catch(() => false);
    const hasAccountInfo = await accountInfo.isVisible({ timeout: 2000 }).catch(() => false);

    // One of them should be visible
    expect(hasLoginForm || hasAccountInfo).toBe(true);
  });

  test('should navigate to orders page', async ({ page }) => {
    // Go to account orders
    await page.goto('/account/orders');
    await page.waitForLoadState('networkidle');

    // Check for orders page elements
    const ordersTitle = page.locator('h1:has-text("Orders")');
    const isVisible = await ordersTitle.isVisible({ timeout: 5000 }).catch(() => false);

    expect(isVisible).toBeTruthy();
  });

  test('should display order history', async ({ page }) => {
    await page.goto('/account/orders');
    await page.waitForLoadState('networkidle');

    // Look for order list or empty state
    const orderList = page.locator('[data-testid="order-list"]');
    const emptyState = page.locator('text=/no orders|empty/i');

    const hasOrders = await orderList.isVisible({ timeout: 2000 }).catch(() => false);
    const isEmpty = await emptyState.isVisible({ timeout: 2000 }).catch(() => false);

    // Should show either orders or empty state
    expect(hasOrders || isEmpty).toBe(true);
  });

  test('should view order details', async ({ page }) => {
    await page.goto('/account/orders');
    await page.waitForLoadState('networkidle');

    // Look for first order link
    const firstOrder = page.locator('[data-testid="order-item"]').first();

    if (await firstOrder.isVisible({ timeout: 5000 })) {
      await firstOrder.click();

      // Wait for order details page
      await page.waitForTimeout(1000);

      // Check for order details
      const orderNumber = page.locator('[data-testid="order-number"]');
      const hasOrderNumber = await orderNumber.isVisible({ timeout: 5000 }).catch(() => false);

      expect(hasOrderNumber).toBeTruthy();
    }
  });

  test('should access profile settings', async ({ page }) => {
    await page.goto('/account');
    await page.waitForLoadState('networkidle');

    // Look for profile/settings link
    const settingsLink = page.locator('a:has-text("Settings"), a:has-text("Profile")').first();

    if (await settingsLink.isVisible({ timeout: 5000 })) {
      await settingsLink.click();

      // Wait for navigation
      await page.waitForTimeout(1000);

      // Verify settings page loaded
      const settingsForm = page.locator('form');
      const hasForm = await settingsForm.isVisible({ timeout: 5000 }).catch(() => false);

      expect(hasForm).toBeTruthy();
    }
  });
});
