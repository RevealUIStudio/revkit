import { expect, test } from '@playwright/test';

/**
 * Example E2E test for the home page
 * Demonstrates basic Playwright testing patterns
 */
test.describe('Home Page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should load the home page successfully', async ({ page }) => {
    // Verify the page loaded
    await expect(page).toHaveURL('/');

    // Check for basic page structure
    const title = await page.title();
    expect(title).toBeTruthy();
  });

  test('should have proper meta tags', async ({ page }) => {
    // Verify viewport meta tag
    const viewport = page.locator('meta[name="viewport"]');
    await expect(viewport).toHaveAttribute('content', /width=device-width/);
  });

  test('should be responsive', async ({ page }) => {
    // Test mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    await page.waitForLoadState('networkidle');

    // Verify page is still functional
    await expect(page).toHaveURL('/');

    // Test tablet viewport
    await page.setViewportSize({ width: 768, height: 1024 });
    await page.waitForLoadState('networkidle');

    // Verify page is still functional
    await expect(page).toHaveURL('/');

    // Test desktop viewport
    await page.setViewportSize({ width: 1920, height: 1080 });
    await page.waitForLoadState('networkidle');

    // Verify page is still functional
    await expect(page).toHaveURL('/');
  });

  test('should have no console errors', async ({ page }) => {
    const consoleErrors: string[] = [];

    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Allow some time for any async errors
    await page.waitForTimeout(1000);

    // Filter out known/expected errors if any
    const unexpectedErrors = consoleErrors.filter(error => {
      // Add filters for expected errors here
      return !error.includes('known-expected-error');
    });

    expect(unexpectedErrors).toHaveLength(0);
  });

  test('should handle navigation', async ({ page }) => {
    // This is a placeholder - update with actual navigation elements
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Example: Click a navigation link if available
    // const aboutLink = page.locator('a[href="/about"]');
    // if (await aboutLink.isVisible()) {
    //   await aboutLink.click();
    //   await expect(page).toHaveURL('/about');
    // }
  });
});
