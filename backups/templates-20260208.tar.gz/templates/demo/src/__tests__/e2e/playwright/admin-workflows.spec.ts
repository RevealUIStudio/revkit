import { expect, test } from '@playwright/test';

/**
 * Comprehensive E2E tests for admin workflows
 * Tests the RevealUI Content Engine admin panel functionality including:
 * - Authentication and authorization
 * - Content management operations
 * - User management
 * - Media management
 * - Settings and configuration
 */

test.describe('Admin Workflows', () => {
  test.describe('Authentication & Authorization', () => {
    test('should login successfully as admin', async ({ page }) => {
      await page.goto('/admin');

      // Fill login form
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');

      // Should redirect to admin dashboard
      await expect(page).toHaveURL(/\/admin$/);
      await expect(page.locator('[data-testid="admin-dashboard"]')).toBeVisible();
    });

    test('should show error for invalid credentials', async ({ page }) => {
      await page.goto('/admin');

      // Fill login form with invalid credentials
      await page.fill('[data-testid="email"]', 'invalid@example.com');
      await page.fill('[data-testid="password"]', 'wrongpassword');
      await page.click('[data-testid="login-button"]');

      // Should show error message
      await expect(page.locator('[data-testid="login-error"]')).toBeVisible();
      await expect(page.locator('[data-testid="login-error"]')).toContainText(
        /invalid credentials/i
      );
    });

    test('should logout successfully', async ({ page }) => {
      // Login first
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');

      // Click logout
      await page.click('[data-testid="user-menu"]');
      await page.click('[data-testid="logout-button"]');

      // Should redirect to login page
      await expect(page).toHaveURL(/\/admin$/);
      await expect(page.locator('[data-testid="login-form"]')).toBeVisible();
    });
  });

  test.describe('Content Management', () => {
    test.beforeEach(async ({ page }) => {
      // Login as admin before each test
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');
    });

    test('should create a new post', async ({ page }) => {
      // Navigate to posts collection
      await page.click('[data-testid="nav-posts"]');
      await page.click('[data-testid="create-post-button"]');

      // Fill post form
      await page.fill('[data-testid="post-title"]', 'Test Post Title');
      await page.fill('[data-testid="post-slug"]', 'test-post-slug');
      await page.selectOption('[data-testid="post-status"]', 'published');

      // Add content using Lexical editor (if available)
      const editor = page.locator('[data-testid="lexical-editor"]');
      if (await editor.isVisible()) {
        await editor.click();
        await page.keyboard.type('This is test content for the post.');
      }

      // Save the post
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Should redirect to post edit page
      await expect(page).toHaveURL(/\/admin\/collections\/posts\/\d+/);
    });

    test('should edit an existing post', async ({ page }) => {
      // Navigate to posts and click on first post
      await page.click('[data-testid="nav-posts"]');
      await page.click('[data-testid="post-item"]:first-child');

      // Update the post title
      const titleField = page.locator('[data-testid="post-title"]');
      await titleField.fill('Updated Post Title');

      // Save changes
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Title should be updated
      await expect(titleField).toHaveValue('Updated Post Title');
    });

    test('should delete a post', async ({ page }) => {
      // Navigate to posts
      await page.click('[data-testid="nav-posts"]');

      // Click on first post to open it
      await page.click('[data-testid="post-item"]:first-child');

      // Click delete button
      await page.click('[data-testid="delete-button"]');

      // Confirm deletion in modal
      await page.click('[data-testid="confirm-delete"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Should redirect back to posts list
      await expect(page).toHaveURL(/\/admin\/collections\/posts$/);
    });

    test('should handle post validation errors', async ({ page }) => {
      // Navigate to posts and create new post
      await page.click('[data-testid="nav-posts"]');
      await page.click('[data-testid="create-post-button"]');

      // Try to save without required fields
      await page.click('[data-testid="save-button"]');

      // Should show validation errors
      await expect(page.locator('[data-testid="validation-errors"]')).toBeVisible();
      await expect(page.locator('[data-testid="title-error"]')).toBeVisible();
    });
  });

  test.describe('Media Management', () => {
    test.beforeEach(async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');
    });

    test('should upload media file', async ({ page }) => {
      // Navigate to media collection
      await page.click('[data-testid="nav-media"]');

      // Click upload button
      await page.click('[data-testid="upload-button"]');

      // Upload test file
      await page.setInputFiles('[data-testid="file-input"]', {
        name: 'test-image.jpg',
        mimeType: 'image/jpeg',
        buffer: Buffer.from('fake-image-content'),
      });

      // Should show upload progress
      await expect(page.locator('[data-testid="upload-progress"]')).toBeVisible();

      // Should show success message after upload
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Should show uploaded file in media list
      await expect(page.locator('[data-testid="media-item"]')).toBeVisible();
    });

    test('should edit media metadata', async ({ page }) => {
      // Navigate to media collection
      await page.click('[data-testid="nav-media"]');

      // Click on first media item
      await page.click('[data-testid="media-item"]:first-child');

      // Update alt text
      await page.fill('[data-testid="alt-text"]', 'Updated alt text');

      // Save changes
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();
    });

    test('should delete media file', async ({ page }) => {
      // Navigate to media collection
      await page.click('[data-testid="nav-media"]');

      // Click on first media item
      await page.click('[data-testid="media-item"]:first-child');

      // Click delete button
      await page.click('[data-testid="delete-button"]');

      // Confirm deletion
      await page.click('[data-testid="confirm-delete"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();
    });
  });

  test.describe('User Management', () => {
    test.beforeEach(async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');
    });

    test('should create a new user', async ({ page }) => {
      // Navigate to users collection
      await page.click('[data-testid="nav-users"]');
      await page.click('[data-testid="create-user-button"]');

      // Fill user form
      await page.fill('[data-testid="user-email"]', 'newuser@example.com');
      await page.fill('[data-testid="user-password"]', 'password123');
      await page.selectOption('[data-testid="user-role"]', 'editor');

      // Save the user
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Should redirect to user edit page
      await expect(page).toHaveURL(/\/admin\/collections\/users\/\d+/);
    });

    test('should update user role', async ({ page }) => {
      // Navigate to users collection
      await page.click('[data-testid="nav-users"]');

      // Click on first user (not admin)
      await page.click('[data-testid="user-item"]:first-child');

      // Update role to admin
      await page.selectOption('[data-testid="user-role"]', 'admin');

      // Save changes
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Role should be updated
      await expect(page.locator('[data-testid="user-role"]')).toHaveValue('admin');
    });

    test('should deactivate user account', async ({ page }) => {
      // Navigate to users collection
      await page.click('[data-testid="nav-users"]');

      // Click on first active user
      await page.click('[data-testid="user-item"]:first-child');

      // Click deactivate button
      await page.click('[data-testid="deactivate-button"]');

      // Confirm deactivation
      await page.click('[data-testid="confirm-deactivate"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // User should be marked as inactive
      await expect(page.locator('[data-testid="user-status"]')).toContainText('inactive');
    });
  });

  test.describe('Settings & Configuration', () => {
    test.beforeEach(async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');
    });

    test('should access admin settings', async ({ page }) => {
      // Navigate to settings
      await page.click('[data-testid="settings-menu"]');

      // Should be able to access settings pages
      await expect(page.locator('[data-testid="settings-content"]')).toBeVisible();
    });

    test('should update site configuration', async ({ page }) => {
      // Navigate to site settings
      await page.click('[data-testid="settings-menu"]');
      await page.click('[data-testid="site-settings"]');

      // Update site name
      await page.fill('[data-testid="site-name"]', 'Updated Site Name');

      // Save changes
      await page.click('[data-testid="save-button"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();

      // Site name should be updated
      await expect(page.locator('[data-testid="site-name"]')).toHaveValue('Updated Site Name');
    });

    test('should manage navigation menus', async ({ page }) => {
      // Navigate to navigation settings
      await page.click('[data-testid="settings-menu"]');
      await page.click('[data-testid="navigation-settings"]');

      // Should see navigation editor
      await expect(page.locator('[data-testid="navigation-editor"]')).toBeVisible();

      // Add a new menu item
      await page.click('[data-testid="add-menu-item"]');
      await page.fill('[data-testid="menu-label"]', 'New Page');
      await page.fill('[data-testid="menu-url"]', '/new-page');

      // Save navigation
      await page.click('[data-testid="save-navigation"]');

      // Should show success message
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();
    });
  });

  test.describe('Role-Based Access Control', () => {
    test('should restrict access for non-admin users', async ({ page }) => {
      // Login as editor (non-admin user)
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'editor@example.com');
      await page.fill('[data-testid="password"]', 'editor123');
      await page.click('[data-testid="login-button"]');

      // Should login successfully but with limited access
      await expect(page).toHaveURL(/\/admin$/);

      // Should not see admin-only sections
      await expect(page.locator('[data-testid="user-management"]')).not.toBeVisible();
      await expect(page.locator('[data-testid="system-settings"]')).not.toBeVisible();

      // Should see content management sections
      await expect(page.locator('[data-testid="posts-management"]')).toBeVisible();
      await expect(page.locator('[data-testid="media-management"]')).toBeVisible();
    });

    test('should allow admin full access', async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');

      // Should see all admin sections
      await expect(page.locator('[data-testid="user-management"]')).toBeVisible();
      await expect(page.locator('[data-testid="system-settings"]')).toBeVisible();
      await expect(page.locator('[data-testid="posts-management"]')).toBeVisible();
      await expect(page.locator('[data-testid="media-management"]')).toBeVisible();
    });
  });

  test.describe('Error Handling & Edge Cases', () => {
    test.beforeEach(async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');
    });

    test('should handle network errors gracefully', async ({ page }) => {
      // Navigate to posts
      await page.click('[data-testid="nav-posts"]');

      // Simulate network error by intercepting requests
      await page.route('**/api/posts', route => {
        route.abort('failed');
      });

      // Try to load posts
      await page.reload();

      // Should show error message
      await expect(page.locator('[data-testid="error-message"]')).toBeVisible();

      // Should provide retry option
      await expect(page.locator('[data-testid="retry-button"]')).toBeVisible();
    });

    test('should handle large data sets with pagination', async ({ page }) => {
      // Navigate to posts
      await page.click('[data-testid="nav-posts"]');

      // Should show pagination controls for large datasets
      await expect(page.locator('[data-testid="pagination"]')).toBeVisible();

      // Should be able to navigate between pages
      await page.click('[data-testid="next-page"]');
      await expect(page.locator('[data-testid="page-2"]')).toBeVisible();

      await page.click('[data-testid="prev-page"]');
      await expect(page.locator('[data-testid="page-1"]')).toBeVisible();
    });

    test('should handle concurrent editing conflicts', async ({ page }) => {
      // Navigate to a post
      await page.click('[data-testid="nav-posts"]');
      await page.click('[data-testid="post-item"]:first-child');

      // Simulate another user editing the same post
      await page.evaluate(() => {
        // This would normally be done by another browser instance
        window.localStorage.setItem('conflict-detected', 'true');
      });

      // Try to save changes
      await page.fill('[data-testid="post-title"]', 'Conflicted Title');
      await page.click('[data-testid="save-button"]');

      // Should detect conflict and show resolution options
      await expect(page.locator('[data-testid="conflict-resolution"]')).toBeVisible();
    });
  });

  test.describe('Performance & Responsiveness', () => {
    test('should handle rapid navigation', async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');

      // Rapidly navigate between sections
      const sections = ['posts', 'media', 'users', 'settings'];

      for (const section of sections) {
        await page.click(`[data-testid="nav-${section}"]`);
        await page.waitForLoadState('networkidle');
        await expect(page.locator(`[data-testid="${section}-content"]`)).toBeVisible();
      }

      // All navigations should complete successfully
      await expect(page.locator('[data-testid="admin-dashboard"]')).toBeVisible();
    });

    test('should handle large forms efficiently', async ({ page }) => {
      // Login as admin
      await page.goto('/admin');
      await page.fill('[data-testid="email"]', 'admin@example.com');
      await page.fill('[data-testid="password"]', 'admin123');
      await page.click('[data-testid="login-button"]');

      // Navigate to a complex form (like site settings)
      await page.click('[data-testid="settings-menu"]');
      await page.click('[data-testid="site-settings"]');

      // Should load complex form without performance issues
      await expect(page.locator('[data-testid="complex-form"]')).toBeVisible();

      // Form interactions should be responsive
      await page.fill('[data-testid="large-text-field"]', 'A'.repeat(1000));
      await expect(page.locator('[data-testid="large-text-field"]')).toHaveValue('A'.repeat(1000));
    });
  });
});
