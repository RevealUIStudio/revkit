import type { FullConfig } from '@playwright/test';

/**
 * Global setup for Playwright E2E tests
 * Runs once before all tests
 */
async function globalSetup(config: FullConfig) {
  const baseURL = config.projects[0]?.use?.baseURL ?? 'http://localhost:3000';

  console.log('[CONFIG] Setting up E2E test environment...');
  console.log(`📍 Base URL: ${baseURL}`);

  // Wait for the server to be ready
  const maxAttempts = 30;
  let attempts = 0;
  let serverReady = false;

  while (attempts < maxAttempts && !serverReady) {
    try {
      const response = await fetch(baseURL);
      if (response.ok || response.status === 404) {
        serverReady = true;
        console.log(`[OK] Server is ready at ${baseURL}`);
      }
    } catch (error) {
      attempts++;
      if (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }

  if (!serverReady) {
    console.error(`[ERROR] Server not ready after ${maxAttempts} attempts`);
    throw new Error(`Server at ${baseURL} is not responding`);
  }

  // Additional setup tasks can be added here:
  // - Create test users
  // - Seed test database
  // - Initialize test data
  // - Set up authentication state

  console.log('[OK] E2E test environment setup complete');
}

export default globalSetup;
