import type {EnvironmentVariables,ExtendedRevealUI} from '@/contracts';
import {resendAdapter} from '@revealui/email-resend';
import {createServiceLogger} from '@revealui/infrastructure';
import {dirname as pathDirname,resolve as pathResolve} from 'path';
import type {Field} from '@revealui/content';
import {buildConfig} from '@revealui/content';
import revealImage from '@revealui/asset-pipeline/assets/image';
import {fileURLToPath} from 'url';
import {getBooleanEnvVar,getEnvVarWithFallback} from './config/presentation/environment';
import {validateEnvironmentVariables} from './config/presentation/environment-validation';
import {
  UPLOAD_DEFAULTS
} from './config/system/constants/defaults';
import { ERROR_MESSAGES } from './config/system/constants/error-messages';
import { COLLECTIONS } from './config/system/constants/collections';
import {configureAnalyzerLogging,isAnalyzerBuild} from './config/system/utilities/build-flags';
// Import modularized configuration
import {
  APIKeys,
  AuditLogs,
  Brands,
  BusinessFeatures,
  Businesses,
  Carts,
  Categories,
  Contracts,
  Coupons,
  CreditBalances,
  CreditTransactions,
  EnterpriseOnboardings,
  Folders,
  GDPRDeletions,
  GDPRExports,
  HelpArticles,
  IPWhitelists,
  IndustryTemplates,
  Invoices,
  MCPAutomationLogs,
  Media,
  Menus,
  Orders,
  Pages,
  PaymentRetries,
  Paywalls,
  PerformanceMetrics,
  Posts,
  Prefixes,
  Products,
  SLAViolations,
  Sessions,
  Subscriptions,
  SupportMessages,
  SupportTickets,
  Tags,
  TenantBranding,
  Tenants,
  TrainingSessions,
  UsageRecords,
  Users,
  Versions,
  VideoPurchases,
  VideoRequests,
  Videos,
  WebhookEvents,
} from './infrastructure/cms/collections';
import {FormsFallback} from './infrastructure/cms/collections/Forms/fallback';
import {RevealMigrationsFallback} from './infrastructure/cms/collections/RevealUIMigrations/fallback';
import {RedirectsFallback} from './infrastructure/cms/collections/Redirects/fallback';
import {getDatabaseAdapter} from './infrastructure/cms/config/adapters/database';
import {getAdminConfig} from './infrastructure/cms/config/admin/admin-config';
import {endpoints} from './infrastructure/cms/config/endpoints';
import {getJobsConfig} from './infrastructure/cms/config/jobs/jobs-config';
import {getPlugins} from './infrastructure/cms/config/plugins/plugin-config';
import {getCorsConfig} from './infrastructure/cms/config/security/cors';
import {getCsrfConfig} from './infrastructure/cms/config/security/csrf';
import {getRevealUISecret} from './infrastructure/cms/config/security/secret';
import {SiteSettings} from './infrastructure/cms/globals/SiteSettings';
import {defaultLexical} from './infrastructure/cms/plugins/utilities/rich-text';
import {footerConfig} from './presentation/components/branding/Footer/config';
import {headerConfig} from './presentation/components/branding/Header/config';

configureAnalyzerLogging();
const logger = createServiceLogger('reveal-config');

// Plugins

// Modern TypeScript: combine type and value imports from RevealUI in one line

// Utility
const filename = fileURLToPath(import.meta.url);
const dirname = pathDirname(filename);

// Environment validation is now handled by the shared utility

/**
 * Gets the RevealUI configuration optimized for Vercel hosting
 * @returns A Promise that resolves to the RevealUI configuration
 */
/**
 * Validates required environment variables
 */
function validateRequiredEnvironmentVariables(): void {
  const requiredEnvVars: (keyof EnvironmentVariables)[] = [
    'REVEAL_SECRET',
    'POSTGRES_URL',
    'BLOB_READ_WRITE_TOKEN',
  ];
  const envValidation = validateEnvironmentVariables(requiredEnvVars);

  if (!envValidation.valid) {
    logger.error('Missing required environment variables', {
      missingVars: envValidation.missingVars,
    });
    throw new Error(
      `Missing required environment variables: ${envValidation.missingVars.join(', ')}`
    );
  }
}

/**
 * Tests database connection (non-blocking)
 */
async function testDatabaseConnection(revealui: ExtendedRevealUI): Promise<void> {
  try {
    logger.info('Testing database connection');

    // Simple connection test - let the adapter handle retries
    await revealui.count({
      collection: COLLECTIONS.USERS,
      depth: 0,
    });

    logger.success('Database connection successful');
  } catch (error) {
    logger.warn('Database connection test failed - adapter will retry', {
      error: error instanceof Error ? error.message : 'Unknown error',
    });
    // Don't throw - let the application continue and the adapter will retry
  }
}

/**
 * Initializes services (non-blocking)
 * Note: Cache and rate limiting services are now auto-initialized
 */
function initializeServices(): void {
  // Services (EnhancedCacheService, RateLimiterService) are already available
  // and work independently
  
  logger.success('Services ready');
}

/**
 * Initializes plugin system (non-blocking)
 */
function initializePluginSystem(revealui: ExtendedRevealUI): void {
  Promise.resolve().then(() => {
    try {
      logger.success('Plugin system initialized', {
        collections: revealui.config.collections?.map((c: { slug: string }) => c.slug) ?? [],
        plugins: revealui.config.plugins?.length ?? 0,
        environment: getBooleanEnvVar('APP_ENV', false) ? 'development' : 'production',
      });
    } catch (error) {
      logger.warn('Plugin system initialization encountered issues', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  });
}

const disableExternalPlugins = isAnalyzerBuild();

const coreCollections = [
  Brands,
  BusinessFeatures,
  Businesses,
  IndustryTemplates,
  Users,
  Media,
  Videos, // Mux-hosted fight videos
  VideoPurchases, // Individual video purchases
  VideoRequests, // Video service request leads
  HelpArticles, // Help center articles
  Pages,
  Posts,
  Prefixes,
  Tags,
  Sessions,
  Categories,
  Folders,
  Menus,
  Paywalls,
  Products,
  Carts, // Shopping cart management
  Orders, // Order tracking and fulfillment
  Coupons, // Discount codes and promotions,
  WebhookEvents, // Webhook event processing queue
  Tenants,
  Versions,
  PerformanceMetrics,
  // Billing Collections
  Subscriptions,
  CreditBalances,
  CreditTransactions,
  UsageRecords,
  Invoices,
  PaymentRetries,
  // Enterprise Collections
  APIKeys,
  SupportTickets,
  SupportMessages,
  SLAViolations,
  AuditLogs,
  Contracts,
  IPWhitelists,
  EnterpriseOnboardings,
  TrainingSessions,
  TenantBranding,
  GDPRExports,
  GDPRDeletions,
  // Automation Collections
  MCPAutomationLogs,
];

export function getRevealConfig() {
  const collections = [...coreCollections];

  if (disableExternalPlugins) {
    collections.push(FormsFallback, RedirectsFallback, RevealMigrationsFallback);
  }

  // Minimal interface for RevealUI field structure
  interface RevealUIField {
    name?: string;
    type?: string;
    fields?: RevealUIField[];
    tabs?: Array<{ fields?: RevealUIField[] }>;
  }

  // Validate collections for duplicate fields before building config
  // Recursive function to check for duplicate fields at any nesting level
  const checkFieldsRecursive = (fields: RevealUIField[], collectionSlug: string, path = 'root', seenAtLevel = new Map<string, number>()) => {
    if (!Array.isArray(fields)) return;
    
    for (let i = 0; i < fields.length; i++) {
      const field = fields[i];
      if (field?.name) {
        if (seenAtLevel.has(field.name)) {
          const firstIndex = seenAtLevel.get(field.name);
          if (firstIndex !== undefined) {
            logger.error(`❌ DUPLICATE FIELD DETECTED in collection '${collectionSlug}'`, {
              collection: collectionSlug,
              fieldName: field.name,
              firstIndex,
              secondIndex: i,
              level: path,
              firstField: JSON.stringify(fields[firstIndex], null, 2),
              secondField: JSON.stringify(field, null, 2),
            });
            console.error(`\n❌ DUPLICATE FIELD DETECTED:`);
            console.error(`   Collection: '${collectionSlug}'`);
            console.error(`   Field name: '${field.name}'`);
            console.error(`   Level: ${path}`);
            const firstField = fields[firstIndex];
            console.error(`   First occurrence: index ${firstIndex} (type: ${firstField && 'type' in firstField ? firstField.type : 'unknown'})`);
            console.error(`   Second occurrence: index ${i} (type: ${'type' in field ? field.type : 'unknown'})\n`);
          }
        } else {
          seenAtLevel.set(field.name, i);
        }
        
        // Recursively check nested fields (arrays, groups, tabs)
        if (field.fields && Array.isArray(field.fields)) {
          checkFieldsRecursive(field.fields, collectionSlug, `${path}.${field.name}.fields`, new Map());
        }
        if (field.tabs && Array.isArray(field.tabs)) {
          field.tabs.forEach((tab, tabIndex: number) => {
            if (tab.fields && Array.isArray(tab.fields)) {
              checkFieldsRecursive(tab.fields, collectionSlug, `${path}.${field.name}.tabs[${tabIndex}]`, new Map());
            }
          });
        }
      }
    }
  };

  try {
    for (const collection of collections) {
      if (collection?.fields && Array.isArray(collection.fields)) {
        checkFieldsRecursive(collection.fields, collection.slug || 'unknown', collection.slug || 'root');
        
        // Also check specifically for duplicate 'name' fields at root level
        const nameFields: Array<{ index: number; field: RevealUIField }> = [];
        collection.fields.forEach((field: RevealUIField, index: number) => {
          if (field?.name === 'name') {
            nameFields.push({ index, field });
          }
        });
        if (nameFields.length > 1) {
          logger.error(`❌ DUPLICATE 'name' FIELD DETECTED in collection '${collection.slug}'`, {
            collection: collection.slug,
            count: nameFields.length,
            fields: nameFields.map(({ index, field }) => ({ index, type: field.type })),
          });
          console.error(`\n❌ DUPLICATE 'name' FIELD in collection '${collection.slug}':`);
          nameFields.forEach(({ index, field }) => {
            const fieldType = 'type' in field ? field.type : 'unknown';
            const fieldLabel = 'label' in field ? field.label : ('admin' in field && typeof field.admin === 'object' && field.admin !== null && 'label' in field.admin ? field.admin.label : 'none');
            console.error(`   - Index ${index}: type=${fieldType}, label=${fieldLabel}`);
          });
        }
      }
    }
  } catch (error) {
    logger.warn('Collection validation error (non-fatal):', {
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }


  // Wrap buildConfig to catch duplicate field errors with more context
  try {
    const jobsConfig = getJobsConfig();
    return buildConfig({
    serverURL: getEnvVarWithFallback(
      'REVEALUI_PUBLIC_SERVER_URL',
      getEnvVarWithFallback('REVEAL_PUBLIC_SERVER_URL', 'http://localhost:3000'),
    ),
    admin: getAdminConfig(),

    // Set the default rich text editor to Lexical
    editor: defaultLexical,

    // Vercel Postgres adapter - automatically uses POSTGRES_URL
    db: getDatabaseAdapter(),

    // Resend email adapter - lightweight and perfect for Vercel
    email: resendAdapter({
      apiKey: getEnvVarWithFallback('RESEND_API_KEY', ''),
      defaultFromAddress: getEnvVarWithFallback('REVEAL_EMAIL_FROM', 'noreply@example.com'),
      defaultFromName: getEnvVarWithFallback('REVEAL_EMAIL_FROM_NAME', 'RevealUI'),
    }),

    plugins: getPlugins(),

    collections,

    globals: [headerConfig, footerConfig, SiteSettings],

    // Top-level custom endpoints
    // Note: Endpoint handlers extracted to src/infrastructure/endpoints/ for better maintainability
    endpoints,

    // CORS configuration for Vercel
    cors: getCorsConfig(),

    // CSRF configuration for Vercel
    csrf: getCsrfConfig(),

    // SECURITY: No fallback - fail fast if REVEAL_SECRET is missing
    secret: getRevealUISecret(),
    sharp: revealImage,

    typescript: {
      outputFile: pathResolve(dirname, 'infrastructure/cms/db/reveal-types.ts'),
    },

    // Jobs configuration for Vercel Cron
    // @ts-expect-error - Jobs config handler return type doesn't match RevealUI's strict type, but works at runtime
    jobs: jobsConfig,

    upload: {
      limits: {
        fileSize: UPLOAD_DEFAULTS.MAX_FILE_SIZE,
        // Client-side uploads bypass Vercel's 4.5MB serverless function limit
        // Videos go directly from browser → Vercel Blob Storage
      },
    },

    // Disable GraphQL as per project requirements
    graphQL: {
      disable: true,
    },

    debug: getBooleanEnvVar('APP_ENV', false),

    logger: {
      options: {
        level: getBooleanEnvVar('APP_ENV', false) ? 'debug' : 'info',
      },
    },

    onInit: async (revealui: ExtendedRevealUI) => {
      try {
        // 1. Validate environment variables (critical)
        validateRequiredEnvironmentVariables();

        // 2. Test database connection (non-blocking)
        await testDatabaseConnection(revealui);

        // 3. Initialize services (non-blocking)
        initializeServices();

        // 4. Initialize plugin system (non-blocking)
        initializePluginSystem(revealui);

        // 5. Register event handlers (non-blocking)
        try {
          const { registerEventHandlers } = await import(
            './infrastructure/events/registerEventHandlers'
          );
          registerEventHandlers();
          logger.success('Event handlers registered');
        } catch (error) {
          logger.error('Failed to register event handlers - application will continue', {
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        }

        logger.success('RevealUI initialization complete');
      } catch (error) {
        // Enhanced error logging for duplicate field errors
        const errorMessage = error instanceof Error ? error.message : ERROR_MESSAGES.UNKNOWN_ERROR;
        const errorStack = error instanceof Error ? error.stack : undefined;
        
        if (errorMessage.includes('DuplicateFieldName') || errorMessage.includes('duplicate')) {
          logger.error('Duplicate field error detected during RevealUI initialization', {
            error: errorMessage,
            stack: errorStack,
            errorType: error?.constructor?.name,
            // Try to extract collection name from error if possible
            collections: revealui?.collections ? Object.keys(revealui.collections) : [],
          });
          
          // Log each collection's field structure for debugging
          if (revealui?.collections) {
            for (const [slug, collection] of Object.entries(revealui.collections)) {
              if (collection?.config?.fields) {
                const fieldNames = collection.config.fields
                  .filter((f): f is Field & { name: string } => 'name' in f && typeof f.name === 'string')
                  .map((f) => f.name);
                const duplicates = fieldNames.filter((name, index) => fieldNames.indexOf(name) !== index);
                if (duplicates.length > 0) {
                  logger.error(`Collection '${slug}' has duplicate field names:`, {
                    duplicates,
                    allFields: fieldNames,
                  });
                }
              }
            }
          }
        }
        
        logger.error('Critical error during RevealUI initialization', {
          error: errorMessage,
          stack: errorStack,
        });
        throw error; // Re-throw critical errors only
      }
    },
  });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : ERROR_MESSAGES.UNKNOWN_ERROR;
    const errorStack = error instanceof Error ? error.stack : undefined;
    
    if (errorMessage.includes('DuplicateFieldName') || errorMessage.includes('duplicate') || errorMessage.includes('name')) {
      logger.error('❌ DuplicateFieldName error during buildConfig:', {
        error: errorMessage,
        stack: errorStack,
        errorObject: error,
        collectionsCount: collections.length,
        collectionSlugs: collections.map(c => c.slug).filter(Boolean),
      });
      
      console.error('\n❌ CRITICAL: DuplicateFieldName error detected during RevealUI config build');
      console.error(`   Error: ${errorMessage}`);
      
      // Check each collection for duplicate 'name' fields
      console.error('\n   Checking collections for duplicate "name" fields...');
      for (const collection of collections) {
        if (collection?.fields && Array.isArray(collection.fields)) {
          const nameFields: Array<{ index: number; field: RevealUIField }> = [];
          collection.fields.forEach((field: RevealUIField, index: number) => {
            if (field?.name === 'name') {
              nameFields.push({ index, field });
            }
          });
          if (nameFields.length > 1) {
            console.error(`\n   ⚠️  FOUND: Collection '${collection.slug}' has ${nameFields.length} fields named 'name' at root level:`);
            nameFields.forEach(({ index, field }) => {
              console.error(`      - Index ${index}: type=${field.type || 'unknown'}`);
            });
          }
        }
      }
      
      // Try to extract collection name from error or stack
      if (errorStack) {
        const collectionMatch = errorStack.match(/collections[/\\]([^/\\]+)/i);
        if (collectionMatch) {
          console.error(`   ⚠️  Likely collection: ${collectionMatch[1]}`);
        }
        
        // Also check for collection slug in stack
        const slugMatch = errorStack.match(/slug['"]?\s*[:=]\s*['"]([^'"]+)['"]/i);
        if (slugMatch) {
          console.error(`   ⚠️  Collection slug found: ${slugMatch[1]}`);
        }
      }
      
      // Check if error has additional properties that might indicate the collection
      if (error && typeof error === 'object') {
        const errorKeys = Object.keys(error);
        console.error(`   Error properties: ${errorKeys.join(', ')}`);
        if ('data' in error) {
          console.error(`   Error data:`, error.data);
        }
        // RevealUI errors sometimes have a 'collection' property
        if ('collection' in error && typeof (error as { collection?: unknown }).collection === 'string') {
          console.error(`   ⚠️  Error collection: ${(error as { collection: string }).collection}`);
        }
      }
      
      console.error('\n   💡 TIP: Check the validation output above for which collection has duplicates.');
      console.error('   This error prevents RevealUI from initializing properly.\n');
    }
    throw error;
  }
}

export default getRevealConfig();
