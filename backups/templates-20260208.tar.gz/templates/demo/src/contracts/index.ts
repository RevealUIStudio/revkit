// ====================================================================
// CONTRACTS - Unified Entry Point
// ====================================================================
// Single source of truth for all contracts: Shape + Behavior + Quality
// Unified domain contract snapshots provide complete domain contracts
//
// 📖 Documentation:
//   - README.md - System overview
//   - MIGRATION_GUIDE.md - How to migrate
//   - MIGRATION_EXAMPLES.md - Real examples
//   - ACTION_PLAN.md - Migration strategy
//
// 🛠️ Tools:
//   - pnpm migrate:contracts - Migrate files
//   - pnpm migrate:contracts:analyze - Check status
//   - pnpm migrate:contracts:monitor - Check ESLint warnings

// ====================================================================
// UNIFIED DOMAIN CONTRACTS (Primary Access Point)
// ====================================================================
// Contract snapshots: Shape + Behavior + Quality in one cohesive unit

export * from './core';
export * from './registry';
export * from './domains';

// ====================================================================
// UNIFIED DOMAIN CONTRACT EXPORTS
// ====================================================================
// Type-safe access to common contract components

export { Contracts, ContractUtils, type ContractName, type GetContract } from './registry';

export {
  UserContract,
  type User,
  type CreateUser,
  type UpdateUser,
  type UserService,
  UserValidation,
} from './domains/user.contract';

export {
  ProductContract,
  type Product,
  type CreateProduct,
  type UpdateProduct,
  type ProductService,
  ProductValidation,
} from './domains/product.contract';

export {
  FightContract,
  type Fight,
  type CreateFight,
  type UpdateFight,
  type FightService,
  FightValidation,
} from './domains/fight.contract';

export {
  CartContract,
  type Cart,
  type CreateCartItem,
  type UpdateCartItem,
  type CartService,
  CartValidation,
} from './domains/cart.contract';

// Additional Cart DTOs (not in contract snapshot but commonly used)
export type {
  RemoveCartItemDTO,
  ApplyCouponDTO,
  RemoveCouponDTO,
  CartCheckoutDTO,
  CartFiltersDTO,
  CartTotalsDTO,
} from './types/domain/dto/cart';

// Additional Order DTOs (not in contract snapshot but commonly used)
export type {
  CreateOrderDTO,
  UpdateOrderDTO,
  OrderFiltersDTO,
  OrderRefundDTO,
  OrderStatusUpdateDTO,
} from './types/domain/dto/order';

export {
  OrderContract,
  type Order,
  type CreateOrder,
  type UpdateOrder,
  type OrderService,
  OrderValidation,
} from './domains/order.contract';

export {
  CategoryContract,
  type Category,
  type CreateCategory,
  type UpdateCategory,
  type CategoryService,
  CategoryValidation,
} from './domains/category.contract';

// Additional Category utility types (commonly used)
export type {
  CategoryFilters,
  CategoryTree,
  CreateCategoryData,
  UpdateCategoryData,
} from './types/domain/entities/category';

// Infrastructure service interfaces (for infrastructure services)
export type { ICategoryService } from './interfaces/infrastructure/services/ICategoryService';

export {
  PostContract,
  type Post,
  type CreatePost,
  type UpdatePost,
  type PostService,
  PostValidation,
} from './domains/post.contract';

// Additional Post utility types (commonly used)
export type { PostFilters } from './types/domain/entities/post';

// Domain entity types (legacy names for compatibility)
export type { DomainTag, TagFromRevealUI } from './types/domain/entities/tag';
export type { DomainMenu, MenuFromRevealUI } from './types/domain/entities/menu';
export type {
  DomainUser,
  UserRole,
  UserPermission,
  UserStatus,
  UserFromRevealUI,
} from './types/domain/entities/user';
export type { DomainCart, CartFromRevealUI } from './types/domain/entities/cart';
export type { DomainCategory, CategoryFromRevealUI } from './types/domain/entities/category';
export type { DomainMedia, MediaFromRevealUI } from './types/domain/entities/media';
export type { DomainOrder, OrderFromRevealUI } from './types/domain/entities/order';
export type { DomainPost, PostFromRevealUI } from './types/domain/entities/post';
export type { DomainProduct, ProductFromRevealUI } from './types/domain/entities/product';

// Address types
export type { BillingAddress, ShippingAddress, Address } from './types/domain/address';

// Post domain service types (commonly used)
export type {
  PostData,
  PostPublicationAnalysis,
  PostPublicationContext,
  PostContentValidation,
  PostSlugValidation,
  PostMetricsSummary,
  PostSchedulingValidation,
} from './interfaces/domain/services/IPostDomainService';

export {
  MediaContract,
  type Media,
  type MediaService,
  MediaValidation,
} from './domains/media.contract';

export {
  MenuContract,
  type Menu,
  type CreateMenu,
  type UpdateMenu,
  type MenuService,
  MenuValidation,
} from './domains/menu.contract';

export {
  TagContract,
  type Tag,
  type CreateTag,
  type UpdateTag,
  type TagService,
  TagValidation,
} from './domains/tag.contract';

// ====================================================================
// SHARED UTILITY TYPES
// ====================================================================
// Common types used across multiple domains

export type { PaginatedResult, PaginationParams } from './types/shared/pagination';
export type {
  EnvironmentVariables,
  AuthConfig,
  EmailConfig,
} from './types/shared/environment';
export { EnvironmentSchema } from './types/shared/environment';
export type {
  ServiceResult,
  ServicePaginatedResult,
  ServiceValidationResult,
  ValidationError,
  ValidationResult,
} from './types/domain/service-results';

// Service result helper functions (exactOptionalPropertyTypes compliant)
export {
  createServiceResultSuccess,
  createServiceResultFailure,
  createServiceValidationSuccess,
  createServiceValidationFailure,
  createServiceValidation,
  includeIf,
  includeIfDefined,
} from './types/domain/service-result-helpers';

// Result type adapters (for layer boundary conversions)
export {
  serviceResultToApiResponse,
  serviceValidationResultToApiResponse,
  apiResponseToServiceResult,
  serviceResultToSimple,
  serviceValidationResultToServiceResult,
  serviceResultToServiceValidationResult,
} from './types/domain/result-adapters';

// ====================================================================
// INFRASTRUCTURE TYPES
// ====================================================================
// RevealUI utility types and infrastructure interfaces

// RevealUI utility types
export type {
  RevealUIWhere,
  RevealUICreateInput,
  RevealUIUpdateInput,
  RevealUIUpsertInput,
  RevealUISelect,
  RevealUISort,
  RevealUIQueryOptions,
  RevealUISearchOptions,
} from './types/infrastructure/reveal-utils';

// RevealUI entity types (RevealUIEntity exported here to avoid duplicate)
export type { RevealUIEntity, ExtendedRevealUI } from './types/infrastructure/extended-reveal';
export type { RequestWithSocket } from './types/infrastructure/reveal';

// Cache types
export type {
  CacheEntry,
  CacheOptions,
  CacheMetrics,
  CacheStats,
} from './types/infrastructure/cache';

// Infrastructure logger types
export type { DomainLogger } from './types/infrastructure/logger';

// Infrastructure service types
export type {
  InfrastructureEventData,
  ServiceConfig,
  ServiceMetadata,
  HealthStatus,
  CacheType,
} from './types/infrastructure/service';

// Error detail types
export type {
  ErrorDetails,
  BaseErrorDetails,
  ValidationErrorDetails,
  EntityErrorDetails,
  ConcurrencyErrorDetails,
  AuthorizationErrorDetails,
  InfrastructureErrorDetails,
  ExternalServiceErrorDetails,
  BusinessRuleErrorDetails,
  ErrorContext,
} from './types/domain/errors/error-details';

// ====================================================================
// REPOSITORY INTERFACES
// ====================================================================
// Infrastructure repository interfaces

export type {
  IRevealUIRepository,
  IBaseRepository,
  IEntityRepository,
} from './interfaces/infrastructure/repositories/IBaseRepository';

export type {
  ICartRepository,
  ICategoryRepository,
  IDomainMediaRepository,
  IDomainMenuRepository,
  IFighterRepository,
  IFightRepository,
  IMediaRepository,
  IOrderRepository,
  IPostRepository,
  IProductRepository,
  ITagRepository,
  IUserRepository,
} from './interfaces/infrastructure/repositories';

// ====================================================================
// PRESENTATION SERVICE INTERFACES
// ====================================================================
// Presentation layer service interfaces

export type {
  IPrefixService,
  PrefixServiceContext,
  CreatePrefixData,
  UpdatePrefixData,
} from './interfaces/presentation/services/IPrefixService';

export type {
  IProductService,
  ProductFilters,
} from './interfaces/domain/services/IProductService';

export type {
  GetUsersOptions,
  UserStatistics,
  UsersResult,
  UserApplicationServiceContext,
} from './types/presentation/services/user-application';

export type {
  IMetaService,
  MetaServiceContext,
  MetaData,
  MetaGenerationOptions,
  GeneratedMetaTags,
  MetaValidationResult,
  StructuredDataOptions,
} from './interfaces/presentation/services/IMetaService';

export type {
  IURLService,
  URLServiceContext,
  ValidationOptions as URLValidationOptions,
} from './interfaces/presentation/services/IURLService';

export type {
  SlugValidationData,
  SlugValidationOptions,
} from './interfaces/services';

export type {
  IViewTrackingRepository,
  ViewTrackingData,
  UniqueViewCheck,
} from './interfaces/repositories/IViewTrackingRepository';

// ====================================================================
// PRESENTATION SERVICE TYPES
// ====================================================================
// Types for presentation layer services

export type { CartUser } from './types/presentation/services/cart';
export type { OrderUser, CreateOrderData } from './types/presentation/services/order';
export type {
  FeatureFlagRecord,
  FeatureFlagsProvider,
  FeatureFlag,
} from './types/presentation/features/flags';
export type { MenuItem, MenuItemType } from './types/presentation/blocks';
export type { PaywallData } from './types/domain/entities/paywall';

// ====================================================================
// UI COMPONENT INTERFACES
// ====================================================================
// Presentation component interfaces

export type {
  SearchBarProps,
  SearchResultsProps,
  CacheExampleProps,
} from './interfaces/presentation/components/ui';
export type { AppProvidersProps } from './interfaces/presentation/provider';
export type { HomeHeroProps } from './types/presentation/ui/components';

// ====================================================================
// VALIDATION UTILITIES
// ====================================================================
// Validation helper functions

export { validateOrThrow } from './validation/utilities';

// Validation result types
export type { GenericValidationResult, FormValidationState } from './validation/results';
// Note: ValidationResult is already exported from service-results above, no need to re-export

// ====================================================================
// REVEALUI HELPER FUNCTIONS
// ====================================================================
// Utility functions for working with RevealUI data

export {
  revealRichTextToString as revealuiRichTextToString,
  extractRevealRelationId as extractRevealUIRelationId,
  revealTimestampToDate as revealuiTimestampToDate,
  revealNumberCoerce as revealuiNumberCoerce,
  revealStringCoerce as revealuiStringCoerce,
  revealBooleanCoerce as revealuiBooleanCoerce,
} from './types/shared/helpers';

// Validation schema types
export type {
  CreateUserData,
  UpdateUserData,
} from './validation/schemas/user';

// ====================================================================
// PLUGIN TYPES
// ====================================================================
// Plugin configuration types

export type {
  MuxPluginConfig,
  MuxVideoPluginOptions,
  MuxCollectionConfig,
} from './interfaces/infrastructure/plugins/mux-video';

// Domain plugin types
export type {
  DomainEventData,
  DomainEventsPluginOptions,
  BeforeSyncPluginOptions,
  SyncEvent,
  MultiTenantPluginOptions,
  ExtendedRevealUIRequest,
  PerformanceMetricData,
  ResponseTimeData,
  PerformanceMonitorPluginOptions,
  AuditLogEntry,
  AuditLogPluginOptions,
  CacheEvent,
  CacheAnalytics,
  RevealUICachePluginOptions,
  PluginConfig,
  PluginLifecycleEvent,
  PluginManagerOptions,
  PluginPerformanceMetrics,
  CachePlugin,
} from './types/domain';

// ====================================================================
// ACCESS CONTROL TYPES
// ====================================================================
// Access control interfaces and types

export type {
  IPermissionChecker,
  PermissionCheckData,
  RoleCheckData,
  ModuleAccessData,
  ActionPermissionData,
  RolePermission,
} from './interfaces/access-control';

export type {
  PermissionCheckData as AccessControlPermissionCheckData,
  RoleCheckData as AccessControlRoleCheckData,
  ModuleAccessData as AccessControlModuleAccessData,
  ActionPermissionData as AccessControlActionPermissionData,
} from './types/access-control';

// ====================================================================
// TESTING TYPES
// ====================================================================
// Testing utility types (from core/testing.ts)

export * from './core/testing';

// Testing interfaces
export type {
  HealthCheckResult,
  HealthReport,
  AnalysisResult,
  TestFixOptions,
  TestResult,
  TestFixReport,
  AnalyzeOptions,
  CleanOptions,
  CleanResult,
  UpdateResult,
  DependencyInfo,
  DependencyReport,
  AuditResult,
} from './interfaces/testing';

// ====================================================================
// UI/ADMIN INTERFACE TYPES
// ====================================================================
// UI component and admin interface types

export type {
  AdminThemeContextType,
  AdminThemeProviderProps,
  AdminThemeConfig,
  BeforeLoginProps,
  BeforeDashboardProps,
} from './interfaces/infrastructure/components/ui';

export type { FormSubmissionResult } from './interfaces/presentation/components/ui';

export type {
  RevealUIRedirectsProps,
  RedirectRule,
} from './interfaces/presentation/components/ui';

export type {
  AccessibilityOptions,
  AccessibilityReturn,
  AccessibleComponentProps,
  FocusableElement,
} from './interfaces/presentation/components/accessibility';

export type {
  LabelProps,
  ProgressProps,
  PaginationProps,
  PageRangeProps,
  FlexContainerProps,
  PostCardProps,
  PostProps,
  PageProps as UIPageProps,
  AuthorListProps,
  Category as UICategory, // Renamed to avoid conflict with domain Category type
  CategoryListProps,
  TagListProps,
  SearchProps,
  SearchState,
} from './types/presentation/ui/components';

export type { ButtonGroupProps } from './types/presentation/ui/button';

export type {
  Block,
  SlugComponentProps,
  PrefixBlockProps,
  PrefixBlockClientProps,
  MediaBlockPropsExtended,
  MediaBlockProps,
  MediaDisplayOptions,
  ViewMode,
  LinkAppearances,
  LinkType,
  LinkGroupType,
  Slug as PresentationSlug,
  CMSLinkType,
  PostCard,
} from './types/presentation/blocks';

export type { InitThemeProps } from './interfaces/presentation/components/props';

export type {
  LoadingSpinnerProps,
  PostFormProps,
  UserFormProps,
  UserFormState,
} from './interfaces/presentation/components/ui';

export type {
  IndustryTemplateTesterProps,
  IndustryTemplateDisplayProps,
  IndustryTemplateProviderProps,
  IndustryTemplateContextValue,
} from './interfaces/domain/models/industry-template';

export type {
  VideoPlayerProps,
  SimpleCaptionProps,
  RevealUIMediaGalleryProps,
  MediaWithCaptionProps,
  MediaGridProps,
  MediaDisplayProps,
  AudioPlayerProps,
} from './types/presentation/media';

export type {
  TextFieldProps,
  NumberFieldProps,
  FormBlockProps,
} from './types/presentation/form';

export type {
  HeroProps,
  PostHeroProps,
  PageHeroProps,
  MediumImpactHeroProps,
  LowImpactHeroProps,
} from './interfaces/presentation/components/hero';

export type {
  HeaderProps,
  IconProps,
  LivePreviewListenerProps,
} from './interfaces/presentation/components/common';

export type {
  InputProps,
  SelectProps,
  TextareaProps,
} from './interfaces/presentation/components/ui';

export type {
  UseDataFetchingOptions,
  UseDataFetchingResult,
  UseStateManagementOptions,
  UseStateManagementReturn,
} from './interfaces/presentation/hooks';

export type {
  UseCacheOptions,
  UseCacheState,
} from './interfaces/infrastructure/cache';

export type {
  IndustryTemplate,
  UseIndustryTemplateOptions,
  UseIndustryTemplateReturn,
} from './interfaces/domain/models/industry-template';

export type {
  Theme,
  ThemeContextType,
  ThemeProviderProps,
} from './interfaces/presentation/components/theme';

export type {
  PreviewContextType,
  PreviewData,
  PreviewProviderProps,
} from './interfaces/presentation/preview';

export type {
  AuthContextType,
  AuthProviderProps,
} from './types/presentation/ui/auth';

export type { Action } from './types/presentation/state/patterns';
