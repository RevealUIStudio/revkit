# Contract Migration Examples

**Date**: 2024-12-19 **Status**: Active Examples

This document shows real-world examples of files that have been migrated from
legacy contract imports to unified imports.

---

## Example 1: ProductService.ts

### Before

```typescript
import type { DomainProduct } from '@/contracts/types/domain/entities/product';
import type { ServiceResult } from '@/contracts/types/domain/service-results';

export type CreateProductData = Partial<DomainProduct>;
export type UpdateProductData = Partial<DomainProduct>;

function domainToRevealUIInput(data: Partial<DomainProduct>): Partial<RevealUIProduct> {
  // ...
}

async listProducts(): Promise<ServiceResult<PaginatedResult<DomainProduct>>> {
  // ...
}

async createProduct(_data: CreateProductData): Promise<ServiceResult<DomainProduct>> {
  // ...
}
```

### After

```typescript
import { type Product } from '@/contracts';
import type { ServiceResult } from '@/contracts/types/domain/service-results';

export type CreateProductData = Partial<Product>;
export type UpdateProductData = Partial<Product>;

function domainToRevealUIInput(data: Partial<Product>): Partial<RevealUIProduct> {
  // ...
}

async listProducts(): Promise<ServiceResult<PaginatedResult<Product>>> {
  // ...
}

async createProduct(_data: CreateProductData): Promise<ServiceResult<Product>> {
  // ...
}
```

**Changes**:
- ✅ `DomainProduct` → `Product`
- ✅ Single import from `@/contracts`
- ✅ All type references updated

---

## Example 2: UserApplicationService.ts

### Before

```typescript
import type { DomainUser } from '@/contracts/types/domain/entities/user';
import type { ServiceResult } from '@/contracts/types/domain/service-results';

type CreateUserInput = DomainUser & { password?: string };

private mapUser(doc: RevealUIUser): DomainUser {
  return userToDomain(doc);
}

async listUsers(): Promise<ServiceResult<{ docs: DomainUser[]; ... }>> {
  // ...
}

async getUser(id: string): Promise<ServiceResult<DomainUser>> {
  // ...
}

async createUser(data: CreateUserInput): Promise<ServiceResult<DomainUser>> {
  // ...
}
```

### After

```typescript
import { type User } from '@/contracts';
import type { ServiceResult } from '@/contracts/types/domain/service-results';

type CreateUserInput = User & { password?: string };

private mapUser(doc: RevealUIUser): User {
  return userToDomain(doc);
}

async listUsers(): Promise<ServiceResult<{ docs: User[]; ... }>> {
  // ...
}

async getUser(id: string): Promise<ServiceResult<User>> {
  // ...
}

async createUser(data: CreateUserInput): Promise<ServiceResult<User>> {
  // ...
}
```

**Changes**:
- ✅ `DomainUser` → `User`
- ✅ Single import from `@/contracts`
- ✅ All type references updated (7 occurrences)

---

## Example 3: CartApplicationService.ts

### Before

```typescript
import type {
  CreateCartItemDTO,
  UpdateCartItemDTO,
} from '@/contracts/types/domain/dto/cart';
import {
  createCartItemSchema,
  cartFiltersSchema,
  cartCheckoutSchema,
} from '@/contracts/validation/schemas/cart';

async addItem(
  data: CreateCartItemDTO,
  user: CartUser | null
): Promise<ServiceResult<Cart>> {
  const validatedData = validateOrThrow(createCartItemSchema, data);
  // ...
}

async getCarts(filters: CartFiltersDTO): Promise<ServiceResult<Cart[]>> {
  const validatedFilters = validateOrThrow(cartFiltersSchema, filters);
  // ...
}

async checkout(data: CartCheckoutDTO): Promise<ServiceResult<Order>> {
  const validatedData = validateOrThrow(cartCheckoutSchema, data);
  // ...
}
```

### After

```typescript
import {
  type CreateCartItem,
  type UpdateCartItem,
  CartValidation,
} from '@/contracts';

async addItem(
  data: CreateCartItem,
  user: CartUser | null
): Promise<ServiceResult<Cart>> {
  const validatedData = validateOrThrow(CartValidation.create, data);
  // ...
}

async getCarts(filters: CartFiltersDTO): Promise<ServiceResult<Cart[]>> {
  const validatedFilters = validateOrThrow(CartValidation.filters, filters);
  // ...
}

async checkout(data: CartCheckoutDTO): Promise<ServiceResult<Order>> {
  const validatedData = validateOrThrow(CartValidation.checkout, data);
  // ...
}
```

**Changes**:
- ✅ `CreateCartItemDTO` → `CreateCartItem`
- ✅ `createCartItemSchema` → `CartValidation.create`
- ✅ `cartFiltersSchema` → `CartValidation.filters`
- ✅ `cartCheckoutSchema` → `CartValidation.checkout`
- ✅ Single import from `@/contracts`

**Note**: Some DTOs like `CartCheckoutDTO`, `ApplyCouponDTO` remain in legacy
imports as they're not part of the core contract exports yet. These can be
migrated later.

---

## Migration Patterns Used

### Pattern 1: Entity Types
```typescript
// Before
import type { DomainUser } from '@/contracts/types/domain/entities/user';

// After
import { type User } from '@/contracts';
```

### Pattern 2: DTO Types
```typescript
// Before
import type { CreateUserDTO } from '@/contracts/types/domain/dto/user';

// After
import { type CreateUser } from '@/contracts';
```

### Pattern 3: Validation Schemas
```typescript
// Before
import { createUserSchema } from '@/contracts/validation/schemas/user';
const validated = createUserSchema.parse(data);

// After
import { UserValidation } from '@/contracts';
const validated = UserValidation.create.parse(data);
```

### Pattern 4: Multiple Types from Same Domain
```typescript
// Before
import type { DomainUser } from '@/contracts/types/domain/entities/user';
import type { CreateUserDTO } from '@/contracts/types/domain/dto/user';
import { createUserSchema } from '@/contracts/validation/schemas/user';

// After
import {
  type User,
  type CreateUser,
  UserValidation,
} from '@/contracts';
```

---

## Files Migrated

1. ✅ `src/domain/services/ProductService.ts`
   - Migrated: `DomainProduct` → `Product`
   - Impact: 6 type references updated

2. ✅ `src/presentation/services/UserApplicationService.ts`
   - Migrated: `DomainUser` → `User`
   - Impact: 7 type references updated

3. ✅ `src/features/commerce/services/CartApplicationService.ts`
   - Migrated: DTOs and validation schemas
   - Impact: 3 validation schema usages updated

---

## Benefits Observed

1. **Cleaner Imports**: Single import instead of multiple
2. **Better Discoverability**: All related types in one place
3. **Type Safety**: No change in type safety, maintained
4. **Consistency**: All files now follow same pattern
5. **ESLint Compliance**: No more warnings from `reveal/prefer-unified-contracts`

---

## Next Steps

- Continue migrating remaining files
- Use `pnpm migrate:contracts` for bulk migration
- Review and test migrated files
- Update documentation as needed

---

**Last Updated**: 2024-12-19
































