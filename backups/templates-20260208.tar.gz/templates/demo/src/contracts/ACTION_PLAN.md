# Contract Migration Action Plan

**Created**: 2024-12-19 **Status**: Ready for Execution

This document provides a clear action plan for systematically migrating the
codebase to unified contract imports.

---

## Current State

### Baseline Metrics (2024-12-19)

- **Total Files**: 1,508
- **Files Needing Migration**: 40
- **Already Migrated**: 3
- **Mixed (Partial)**: 1
- **Adoption Rate**: 6.8%

### Priority Areas

1. **Domain Services** (8 files) - Highest priority
2. **Transform Packages** (21 files) - Medium priority
3. **Application Services** (3 files) - Medium priority
4. **Repositories** (1 file) - Low priority
5. **Config Files** (4 files) - Low priority

---

## Migration Strategy

### Phase 1: Domain Services (Week 1-2)

**Target**: Migrate all domain services

**Files**:
1. `src/domain/services/UserDomainService.ts`
2. `src/domain/services/PostDomainService.ts` ⚠️ (2 imports)
3. `src/domain/services/MediaDomainService.ts`
4. `src/domain/services/ContentDomainService.ts`
5. `src/domain/services/MenuDomainService.ts`
6. `src/domain/services/TagDomainService.ts`
7. `src/domain/services/RoleBasedUIService.ts`
8. `src/domain/services/PostService.ts`

**Commands**:
```bash
# Analyze domain services
pnpm migrate:contracts:analyze | grep "domain/services"

# Migrate one at a time
pnpm migrate:contracts src/domain/services/UserDomainService.ts --dry-run
pnpm migrate:contracts src/domain/services/UserDomainService.ts

# Verify
pnpm lint:types
pnpm test
```

**Goal**: 8 files migrated, ~20% adoption rate

---

### Phase 2: Application Services (Week 3)

**Target**: Migrate application services

**Files**:
1. `src/presentation/services/UserServiceCoordinator.ts`
2. `src/presentation/services/UserManagementService.ts`
3. `src/presentation/services/ContentManagementService.ts`
4. `src/features/commerce/services/CartApplicationService.ts` (complete partial migration)

**Goal**: 4 files migrated, ~25% adoption rate

---

### Phase 3: Repositories & Infrastructure (Week 4)

**Target**: Migrate repositories and infrastructure services

**Files**:
- `src/infrastructure/data-access/repositories/*.ts` (1 file)
- `src/infrastructure/services/business/*.ts` (1 file)
- Config files (4 files)

**Goal**: 6 files migrated, ~30% adoption rate

---

### Phase 4: Transform Packages (Month 2)

**Target**: Migrate transform package files

**Files**: 21 files in `packages/transform/`

**Note**: These may need special handling due to package structure.

**Goal**: 21 files migrated, ~60% adoption rate

---

## Weekly Workflow

### Monday: Status Check

```bash
# Get current status
pnpm migrate:contracts:analyze > status-$(date +%Y-%m-%d).txt

# Check ESLint warnings
pnpm migrate:contracts:monitor > warnings-$(date +%Y-%m-%d).txt

# Review progress
cat status-*.txt
```

### Tuesday-Thursday: Migration

```bash
# Pick a file from priority list
# Dry run first
pnpm migrate:contracts <file> --dry-run

# Review changes
# If good, apply
pnpm migrate:contracts <file>

# Verify
pnpm lint:types
pnpm test

# Commit
git add <file>
git commit -m "migrate: use unified contracts in <file>"
```

### Friday: Review & Plan

```bash
# Get updated status
pnpm migrate:contracts:analyze

# Update MIGRATION_STATUS.md with progress
# Plan next week's targets
```

---

## Migration Checklist

For each file:

- [ ] Run analysis: `pnpm migrate:contracts:analyze`
- [ ] Check ESLint: `pnpm migrate:contracts:monitor`
- [ ] Dry run: `pnpm migrate:contracts <file> --dry-run`
- [ ] Review changes
- [ ] Apply: `pnpm migrate:contracts <file>`
- [ ] Type check: `pnpm lint:types`
- [ ] Lint: `pnpm lint`
- [ ] Test: `pnpm test` (if applicable)
- [ ] Update MIGRATION_STATUS.md
- [ ] Commit with message: `migrate: use unified contracts in <file>`

---

## Success Metrics

### Week 1-2: Domain Services
- **Target**: 8 files migrated
- **Adoption**: ~20%
- **ESLint Warnings**: -8

### Week 3: Application Services
- **Target**: 4 files migrated
- **Adoption**: ~25%
- **ESLint Warnings**: -4

### Week 4: Infrastructure
- **Target**: 6 files migrated
- **Adoption**: ~30%
- **ESLint Warnings**: -6

### Month 2: Transform Packages
- **Target**: 21 files migrated
- **Adoption**: ~60%
- **ESLint Warnings**: -21

### Month 3: Completion
- **Target**: All files migrated
- **Adoption**: 80%+
- **ESLint Warnings**: 0

---

## Troubleshooting

### Issue: Migration tool doesn't work on a file

**Solution**: Migrate manually using patterns from MIGRATION_GUIDE.md

### Issue: Type errors after migration

**Solution**:
1. Check type mapping in MIGRATION_GUIDE.md
2. Verify contract exports
3. May need to keep some legacy imports temporarily

### Issue: ESLint still shows warnings

**Solution**:
1. Clear cache: `rm -rf .eslintcache`
2. Verify file was actually migrated
3. Check for mixed imports

---

## Resources

- [Migration Guide](./MIGRATION_GUIDE.md) - Complete patterns
- [Migration Examples](./MIGRATION_EXAMPLES.md) - Real examples
- [Quick Start](../docs/development/contracts/QUICK_START.md) - 5-minute guide
- [Migration Status](../docs/development/contracts/MIGRATION_STATUS.md) - Track progress

---

## Team Coordination

### Assignments

- **Developer 1**: Domain services (Week 1-2)
- **Developer 2**: Application services (Week 3)
- **Developer 3**: Infrastructure (Week 4)
- **All**: Transform packages (Month 2)

### Communication

- Update MIGRATION_STATUS.md daily
- Share blockers in team chat
- Celebrate milestones! 🎉

---

## Quick Commands Reference

```bash
# Analysis
pnpm migrate:contracts:analyze
pnpm migrate:contracts:report
pnpm migrate:contracts:json

# Monitoring
pnpm migrate:contracts:monitor
pnpm migrate:contracts:monitor:report

# Migration
pnpm migrate:contracts --dry-run
pnpm migrate:contracts <file>
pnpm migrate:contracts
```

---

**Ready to start?** Begin with Week 1: Domain Services!

**Last Updated**: 2024-12-19
































