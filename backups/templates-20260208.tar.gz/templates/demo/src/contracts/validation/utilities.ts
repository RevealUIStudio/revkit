// ====================================================================
// VALIDATION UTILITIES
// ====================================================================
// Re-export commonly used validation utilities from @revealui/core/validation package

export {
  validateDTO,
  validateOrThrow,
  validateDTOWithResult,
  validatePartialDTO,
  validateArray,
  validateAsync,
  validateMultiple,
  validateAndTransform,
  validateWithCustomMessages,
  createValidationMiddleware,
  type ValidationError,
  type DTOValidationResult,
} from '@revealui/core/validation';
