# Validation Layer Documentation

The validation layer provides a comprehensive, type-safe validation system for
the RevealUI application. All validation schemas are centralized in
`src/contracts/validation/schemas/` with standardized patterns.

## Architecture

```
src/contracts/validation/
├── schemas/           # All validation schemas (single source of truth)
│   ├── user.ts        # User validation
│   ├── product.ts     # Product validation
│   ├── fight.ts       # Fight validation
│   ├── cart.ts        # Cart validation
│   ├── order.ts       # Order validation
│   ├── post.ts        # Post validation
│   ├── category.ts    # Category validation
│   ├── media.ts       # Media validation
│   └── index.ts       # Barrel export
├── base.ts           # Base validation schemas
├── errors.ts         # Validation error types
├── results.ts        # Validation result types
├── utilities.ts      # Validation utility functions
├── middleware.ts     # Pre-configured validation middleware
├── architecture.ts   # Architecture validation types
├── index.ts          # Main entry point
└── README.md         # This file
```

## Quick Start

### 1. Basic Validation

```typescript
import {
  createUserSchema,
  userValidationSchemas,
} from '@/contracts/validation';
import { validateDTO } from '@/contracts/validation';

// Using validation utility
const result = validateDTO(createUserSchema, userData);
if (result.success) {
  console.log('Valid:', result.data);
} else {
  console.log('Errors:', result.errors);
}

// Using validation suite
const suite = userValidationSchemas.createUser;
const validation = suite.validate(userData);
if (validation.success) {
  console.log('Valid:', validation.data);
}
```

### 2. Middleware Integration

#### Server Actions

```typescript
import { createAuthenticatedServerAction } from '@revealui/infrastructure/middleware/serverActions/createServerAction';
import { userValidationMiddleware } from '@/contracts/validation';

export const createUser = createAuthenticatedServerAction(
  [userValidationMiddleware.create],
  async (input, ctx) => {
    // input is validated and typed as CreateUserData
    const service = new UserApplicationService(revealui);
    return service.createUser(input);
  }
);
```

#### API Routes

```typescript
import { createAuthenticatedAPIRoute } from '@revealui/infrastructure/middleware/api/createAPIRoute';
import { productValidationMiddleware } from '@/contracts/validation';

export const POST = createAuthenticatedAPIRoute(
  [productValidationMiddleware.create],
  async (req, ctx) => {
    // req.body is validated and typed
    const body = await req.json();
    // body is typed as CreateProductData
  }
);
```

## Validation Schemas

### Standard Pattern

All domain schemas follow this pattern:

```typescript
// Define schema
export const createUserSchema = z.object({
  /* ... */
});

// Create validation suite
export const userValidationSchemas = createValidationSuites({
  createUser: createUserSchema,
  updateUser: updateUserSchema,
  userFilters: userFiltersSchema,
  userProfile: userProfileSchema,
});

// Export types
export type CreateUserData = z.infer<typeof createUserSchema>;
```

### Available Schemas

- **User**: `createUserSchema`, `updateUserSchema`, `userFiltersSchema`,
  `userProfileSchema`
- **Product**: `createProductSchema`, `updateProductSchema`,
  `productFiltersSchema`, `productVariantSchema`
- **Fight**: `createFightSchema`, `updateFightSchema`, `fightFiltersSchema`,
  `fightResultSchema`
- **Cart**: `createCartItemSchema`, `updateCartItemSchema`, `applyCouponSchema`,
  `cartCheckoutSchema`
- **Order**: `createOrderSchema`, `updateOrderSchema`, `orderFiltersSchema`
- **Post**: `createPostSchema`, `updatePostSchema`, `postFiltersSchema`
- **Category**: `createCategorySchema`, `updateCategorySchema`,
  `categoryFiltersSchema`
- **Media**: `uploadMediaSchema`, `updateMediaSchema`, `mediaFiltersSchema`

## Middleware

Pre-configured middleware is available for all schemas:

```typescript
import {
  userValidationMiddleware,
  productValidationMiddleware,
  fightValidationMiddleware,
  // ... etc
} from '@/contracts/validation';

// Usage
userValidationMiddleware.create; // validateCreateUser
userValidationMiddleware.update; // validateUpdateUser
userValidationMiddleware.filters; // validateUserFilters
```

## Utilities

### Available Functions

```typescript
import {
  validateDTO,
  validateOrThrow,
  validateDTOWithResult,
  validatePartialDTO,
  validateArray,
  validateAsync,
  validateMultiple,
  validateAndTransform,
  validateWithCustomMessages,
} from '@/contracts/validation';
```

### Examples

```typescript
// Safe validation with result
const result = validateDTO(createUserSchema, userData);

// Throw on validation failure
const validated = validateOrThrow(createUserSchema, userData);

// Service result pattern
const serviceResult = validateDTOWithResult(createUserSchema, userData);
if (!serviceResult.success) {
  return failure('VALIDATION_ERROR', serviceResult.error);
}

// Partial validation for updates
const partialResult = validatePartialDTO(updateUserSchema, partialData);

// Array validation
const arrayResult = validateArray(createProductSchema, productsArray);

// Async validation
const asyncResult = await validateAsync(createUserSchema, userData);
```

## Error Handling

### Error Types

```typescript
import type {
  ValidationError,
  ValidationErrorCode,
} from '@/contracts/validation';

interface ValidationError {
  field: string;
  message: string;
  code?: ValidationErrorCode;
  value?: unknown;
  path?: string[];
}
```

### Error Codes

All available error codes are exported as `ValidationErrorCodes`:

```typescript
import { ValidationErrorCodes } from '@/contracts/validation';

ValidationErrorCodes.INVALID_EMAIL;
ValidationErrorCodes.REQUIRED;
ValidationErrorCodes.INVALID_LENGTH;
// ... etc
```

## Form Integration

### React Hook Form

```typescript
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { createUserSchema, type CreateUserData } from '@/contracts/validation';

export function UserForm() {
  const form = useForm<CreateUserData>({
    resolver: zodResolver(createUserSchema),
  });

  // ...
}
```

### Form Validation State

```typescript
import type { FormValidationState } from '@/contracts/validation';

type UserFormState = FormValidationState<CreateUserData>;

function handleValidation(state: UserFormState) {
  if (state.status === 'valid') {
    console.log('Valid data:', state.data);
  } else if (state.status === 'invalid') {
    console.log('Errors:', state.errors);
  }
}
```

## Best Practices

### 1. Import from Entry Point

```typescript
// ✅ Good
import {
  createUserSchema,
  userValidationMiddleware,
} from '@/contracts/validation';

// ❌ Bad
import { createUserSchema } from '@/contracts/validation/schemas/user';
```

### 2. Use Middleware for Routes/Actions

```typescript
// ✅ Good
export const POST = createAuthenticatedAPIRoute(
  [userValidationMiddleware.create],
  async (req, ctx) => {
    /* ... */
  }
);

// ❌ Bad - manual validation
export const POST = async (req, ctx) => {
  const result = validateDTO(createUserSchema, await req.json());
  // manual error handling...
};
```

### 3. Derive Types from Schemas

```typescript
// ✅ Good - single source of truth
export const createUserSchema = z.object({
  /* ... */
});
export type CreateUserData = z.infer<typeof createUserSchema>;

// ❌ Bad - duplicate type definitions
export interface CreateUserData {
  /* ... */
}
export const createUserSchema = z.object({
  /* ... */
});
```

### 4. Use Validation Suites

```typescript
// ✅ Good
export const userValidationSchemas = createValidationSuites({
  createUser: createUserSchema,
  updateUser: updateUserSchema,
  // ...
});

// ❌ Bad - separate validate functions
export const validateCreateUser = (data: unknown) => {
  /* ... */
};
export const validateUpdateUser = (data: unknown) => {
  /* ... */
};
```

## Adding New Schemas

1. Create schema in `schemas/[domain].ts`
2. Export validation suite using `createValidationSuites`
3. Export types using `z.infer`
4. Add to `schemas/index.ts`
5. Add middleware to `middleware.ts`
6. Done! Available via `@/contracts/validation`

Example:

```typescript
// schemas/video.ts
import { z } from 'zod';
import { createValidationSuites } from '@revealui/core/validation';

export const createVideoSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().optional(),
  url: z.string().url(),
});

export const videoValidationSchemas = createValidationSuites({
  createVideo: createVideoSchema,
});

export type CreateVideoData = z.infer<typeof createVideoSchema>;
```

## Migration Notes

If you're migrating from the old structure:

- ❌ `import { createUserSchema } from '@/contracts/validation/user'`
- ✅ `import { createUserSchema } from '@/contracts/validation'`

All schemas are now exported from the main entry point. No breaking changes to
the validation logic itself.
