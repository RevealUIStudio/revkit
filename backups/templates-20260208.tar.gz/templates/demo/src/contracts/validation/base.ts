// ====================================================================
// BASE VALIDATION SCHEMAS
// ====================================================================
// Re-export base schemas from @revealui/core/validation package
// Import these utilities directly from @revealui/core/validation in your code

export {
  baseValidationSchema,
  paginationSchema,
  searchSchema,
  dateRangeSchema,
  statusSchema,
  roleSchema,
  type BaseValidationData,
  type PaginationData,
  type SearchData,
  type DateRangeData,
  type StatusData,
  type RoleData,
} from '@revealui/core/validation';

// NOTE: createValidationSuite and createValidationSuites should be imported
// directly from '@revealui/core/validation' to avoid circular dependencies
