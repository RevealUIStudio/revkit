// ====================================================================
// TAG VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for tag validation

import { z } from 'zod';

/**
 * Create tag validation schema
 */
export const createTagSchema = z.object({
  name: z.string().min(1, 'Tag name is required').max(50, 'Tag name too long'),
  slug: z
    .string()
    .min(1, 'Tag slug is required')
    .max(100, 'Tag slug too long')
    .regex(/^[a-z0-9-]+$/, 'Tag slug may only contain lowercase letters, numbers, and hyphens'),
  description: z.string().max(500, 'Description too long').optional(),
});

/**
 * Update tag validation schema
 */
export const updateTagSchema = z.object({
  name: z.string().min(1, 'Tag name is required').max(50, 'Tag name too long').optional(),
  slug: z
    .string()
    .min(1, 'Tag slug is required')
    .max(100, 'Tag slug too long')
    .regex(/^[a-z0-9-]+$/, 'Tag slug may only contain lowercase letters, numbers, and hyphens')
    .optional(),
  description: z.string().max(500, 'Description too long').optional(),
});

/**
 * Tag filters validation schema
 */
export const tagFiltersSchema = z.object({
  searchTerm: z.string().max(100, 'Search term too long').optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
  sortBy: z.enum(['name', 'slug', 'createdAt', 'updatedAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});
