// ====================================================================
// PRODUCT VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for product validation

import { createValidationSuites } from '@revealui/core/validation';
import { z } from 'zod';

// ======
// PRODUCT SCHEMAS
// ======

/**
 * Product type schema
 */
export const productTypeSchema = z.enum([
  'physical',
  'digital',
  'subscription',
  'service',
  'ticket',
  'merchandise',
]);

/**
 * Product status schema
 */
export const productStatusSchema = z.enum([
  'draft',
  'published',
  'archived',
  'out_of_stock',
  'discontinued',
]);

/**
 * Create product validation schema
 */
export const createProductSchema = z.object({
  title: z
    .string()
    .min(1, 'Title is required')
    .max(200, 'Title must be no more than 200 characters'),
  description: z
    .string()
    .min(1, 'Description is required')
    .max(2000, 'Description must be no more than 2000 characters'),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .max(200, 'Slug must be no more than 200 characters')
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  type: productTypeSchema,
  category: z
    .string()
    .min(1, 'Category is required')
    .max(100, 'Category must be no more than 100 characters'),
  price: z.object({
    amount: z.number().positive('Price must be positive'),
    originalAmount: z.number().positive('Original price must be positive').optional(),
    currency: z.string().length(3, 'Currency must be 3 characters'),
    saleEndsAt: z.string().datetime().optional(),
  }),
  inventory: z.object({
    stock: z.number().int().min(0, 'Stock must be non-negative'),
    lowStockThreshold: z.number().int().min(0, 'Low stock threshold must be non-negative'),
    isUnlimited: z.boolean(),
    sku: z.string().max(50, 'SKU must be no more than 50 characters').optional(),
    barcode: z.string().max(50, 'Barcode must be no more than 50 characters').optional(),
  }),
  media: z.object({
    images: z.array(z.string().url('Invalid image URL')),
    thumbnail: z.string().url('Invalid thumbnail URL'),
    videos: z.array(z.string().url('Invalid video URL')).optional(),
  }),
  metadata: z.record(z.string(), z.unknown()).optional(),
  featured: z.boolean(),
  status: productStatusSchema,
});

/**
 * Update product validation schema
 */
export const updateProductSchema = createProductSchema.partial();

/**
 * Product filters validation schema
 */
export const productFiltersSchema = z.object({
  type: z.array(productTypeSchema).optional(),
  category: z.array(z.string()).optional(),
  status: z.array(productStatusSchema).optional(),
  priceRange: z
    .object({
      min: z.number().positive('Minimum price must be positive'),
      max: z.number().positive('Maximum price must be positive'),
    })
    .optional(),
  featured: z.boolean().optional(),
  inStock: z.boolean().optional(),
  onSale: z.boolean().optional(),
  brand: z.array(z.string()).optional(),
  tags: z.array(z.string()).optional(),
});

/**
 * Product variant validation schema
 */
export const productVariantSchema = z.object({
  name: z
    .string()
    .min(1, 'Variant name is required')
    .max(100, 'Variant name must be no more than 100 characters'),
  sku: z.string().min(1, 'SKU is required').max(50, 'SKU must be no more than 50 characters'),
  price: z.object({
    amount: z.number().positive('Price must be positive'),
    currency: z.string().length(3, 'Currency must be 3 characters'),
  }),
  inventory: z.object({
    stock: z.number().int().min(0, 'Stock must be non-negative'),
    isUnlimited: z.boolean(),
  }),
  attributes: z.record(z.string(), z.string()).optional(),
});

// ======
// VALIDATION SUITES
// ======

/**
 * Product validation schemas and utilities
 */
export const productValidationSchemas = createValidationSuites({
  createProduct: createProductSchema,
  updateProduct: updateProductSchema,
  productFilters: productFiltersSchema,
  productVariant: productVariantSchema,
});

// ======
// TYPE EXPORTS
// ======

export type CreateProductData = z.infer<typeof createProductSchema>;
export type UpdateProductData = z.infer<typeof updateProductSchema>;
export type ProductFiltersData = z.infer<typeof productFiltersSchema>;
export type ProductVariantData = z.infer<typeof productVariantSchema>;
export type ProductTypeData = z.infer<typeof productTypeSchema>;
export type ProductStatusData = z.infer<typeof productStatusSchema>;
