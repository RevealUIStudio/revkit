// ====================================================================
// CART VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for cart validation

import { z } from 'zod';

/**
 * Create cart item validation schema
 */
export const createCartItemSchema = z.object({
  productId: z.string().min(1, 'Product ID is required'),
  variantId: z.string().optional(),
  quantity: z
    .number()
    .int()
    .min(1, 'Quantity must be at least 1')
    .max(999, 'Quantity cannot exceed 999'),
});

/**
 * Update cart item validation schema
 */
export const updateCartItemSchema = z.object({
  itemId: z.string().min(1, 'Item ID is required'),
  quantity: z
    .number()
    .int()
    .min(1, 'Quantity must be at least 1')
    .max(999, 'Quantity cannot exceed 999'),
});

/**
 * Remove cart item validation schema
 */
export const removeCartItemSchema = z.object({
  itemId: z.string().min(1, 'Item ID is required'),
});

/**
 * Apply coupon validation schema
 */
export const applyCouponSchema = z.object({
  cartId: z.string().min(1, 'Cart ID is required'),
  couponCode: z.string().min(1, 'Coupon code is required').max(50, 'Coupon code too long'),
});

/**
 * Remove coupon validation schema
 */
export const removeCouponSchema = z.object({
  cartId: z.string().min(1, 'Cart ID is required'),
  couponCode: z.string().min(1, 'Coupon code is required').max(50, 'Coupon code too long'),
});

/**
 * Cart filters validation schema
 */
export const cartFiltersSchema = z.object({
  userId: z.string().optional(),
  sessionId: z.string().optional(),
  status: z.enum(['active', 'abandoned', 'converted']).optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
});

/**
 * Cart checkout validation schema
 */
export const cartCheckoutSchema = z.object({
  cartId: z.string().min(1, 'Cart ID is required'),
  shippingAddress: z.object({
    street1: z.string().min(1, 'Street address is required'),
    street2: z.string().optional(),
    city: z.string().min(1, 'City is required'),
    state: z.string().min(1, 'State is required'),
    postalCode: z.string().min(1, 'Postal code is required'),
    country: z.string().min(1, 'Country is required'),
  }),
  billingAddress: z
    .object({
      street1: z.string().min(1, 'Street address is required'),
      street2: z.string().optional(),
      city: z.string().min(1, 'City is required'),
      state: z.string().min(1, 'State is required'),
      postalCode: z.string().min(1, 'Postal code is required'),
      country: z.string().min(1, 'Country is required'),
    })
    .optional(),
  paymentMethod: z.object({
    type: z.enum(['card', 'paypal', 'stripe']),
    token: z.string().min(1, 'Payment token is required'),
  }),
  customerEmail: z.string().email().optional(),
  customerName: z.string().optional(),
  notes: z.string().optional(),
});
