// ====================================================================
// MEDIA VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for media validation

import { z } from 'zod';

/**
 * Upload media validation schema
 */
export const uploadMediaSchema = z.object({
  file: z.any(),
  alt: z.string().max(200, 'Alt text too long').optional(),
  caption: z.string().max(500, 'Caption too long').optional(),
  folder: z.string().max(100, 'Folder name too long').optional(),
  tags: z.array(z.string()).optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Update media validation schema
 */
export const updateMediaSchema = z.object({
  alt: z.string().max(200, 'Alt text too long').optional(),
  caption: z.string().max(500, 'Caption too long').optional(),
  tags: z.array(z.string()).optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Media filters validation schema
 */
export const mediaFiltersSchema = z.object({
  filename: z.string().optional(),
  alt: z.string().optional(),
  mimeType: z.string().optional(),
  folder: z.string().optional(),
  tags: z.array(z.string()).optional(),
  sizeMin: z.number().int().min(0).optional(),
  sizeMax: z.number().int().min(0).optional(),
  widthMin: z.number().int().min(0).optional(),
  widthMax: z.number().int().min(0).optional(),
  heightMin: z.number().int().min(0).optional(),
  heightMax: z.number().int().min(0).optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
  sortBy: z.enum(['filename', 'size', 'createdAt', 'updatedAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

/**
 * Media search validation schema
 */
export const mediaSearchSchema = z.object({
  query: z.string().min(1, 'Search query is required'),
  filters: mediaFiltersSchema.optional(),
  includeVariants: z.boolean().optional(),
});

/**
 * Media resize validation schema
 */
export const mediaResizeSchema = z.object({
  mediaId: z.string().min(1, 'Media ID is required'),
  width: z.number().int().min(1).optional(),
  height: z.number().int().min(1).optional(),
  quality: z.number().min(0).max(100).optional(),
  format: z.enum(['jpeg', 'png', 'webp', 'avif']).optional(),
  maintainAspectRatio: z.boolean().optional(),
});

/**
 * Media crop validation schema
 */
export const mediaCropSchema = z.object({
  mediaId: z.string().min(1, 'Media ID is required'),
  x: z.number().int().min(0),
  y: z.number().int().min(0),
  width: z.number().int().min(1),
  height: z.number().int().min(1),
});

/**
 * Media folder validation schema
 */
export const mediaFolderSchema = z.object({
  name: z.string().min(1, 'Folder name is required').max(100, 'Folder name too long'),
  parentId: z.string().optional(),
  description: z.string().max(500, 'Description too long').optional(),
});
