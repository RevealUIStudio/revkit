// ====================================================================
// ORDER VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for order validation

import { z } from 'zod';

/**
 * Create order validation schema
 */
export const createOrderSchema = z.object({
  cartId: z.string().min(1, 'Cart ID is required'),
  customerEmail: z.string().email('Valid email is required'),
  customerName: z.string().optional(),
  shippingAddress: z.object({
    street1: z.string().min(1, 'Street address is required'),
    street2: z.string().optional(),
    city: z.string().min(1, 'City is required'),
    state: z.string().min(1, 'State is required'),
    postalCode: z.string().min(1, 'Postal code is required'),
    country: z.string().min(1, 'Country is required'),
  }),
  billingAddress: z
    .object({
      street1: z.string().min(1, 'Street address is required'),
      street2: z.string().optional(),
      city: z.string().min(1, 'City is required'),
      state: z.string().min(1, 'State is required'),
      postalCode: z.string().min(1, 'Postal code is required'),
      country: z.string().min(1, 'Country is required'),
    })
    .optional(),
  paymentMethod: z.object({
    type: z.enum(['card', 'paypal', 'stripe']),
    token: z.string().min(1, 'Payment token is required'),
  }),
  notes: z.string().optional(),
});

/**
 * Update order validation schema
 */
export const updateOrderSchema = z.object({
  status: z
    .enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])
    .optional(),
  trackingNumber: z.string().optional(),
  notes: z.string().optional(),
  shippingAddress: z
    .object({
      street1: z.string().min(1, 'Street address is required'),
      street2: z.string().optional(),
      city: z.string().min(1, 'City is required'),
      state: z.string().min(1, 'State is required'),
      postalCode: z.string().min(1, 'Postal code is required'),
      country: z.string().min(1, 'Country is required'),
    })
    .optional(),
});

/**
 * Order filters validation schema
 */
export const orderFiltersSchema = z.object({
  status: z
    .enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])
    .optional(),
  customerEmail: z.string().email().optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
  totalMin: z.number().min(0).optional(),
  totalMax: z.number().min(0).optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
  sortBy: z.enum(['createdAt', 'total', 'status']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

/**
 * Order status update validation schema
 */
export const orderStatusUpdateSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  status: z.enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded']),
  notes: z.string().optional(),
  trackingNumber: z.string().optional(),
});

/**
 * Order refund validation schema
 */
export const orderRefundSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  amount: z.number().min(0).optional(),
  reason: z.string().min(1, 'Refund reason is required'),
  notes: z.string().optional(),
});
