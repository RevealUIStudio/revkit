// ====================================================================
// CATEGORY VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for category validation

import { z } from 'zod';

/**
 * Create category validation schema
 */
export const createCategorySchema = z.object({
  name: z.string().min(1, 'Category name is required').max(100, 'Category name too long'),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .max(100, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug must contain only lowercase letters, numbers, and hyphens'),
  description: z.string().optional(),
  parentId: z.string().optional(),
  sortOrder: z.number().int().min(0).optional(),
  status: z.enum(['draft', 'published', 'archived']),
  image: z.string().optional(),
  seoTitle: z.string().max(60, 'SEO title too long').optional(),
  seoDescription: z.string().max(160, 'SEO description too long').optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Update category validation schema
 */
export const updateCategorySchema = z.object({
  name: z
    .string()
    .min(1, 'Category name is required')
    .max(100, 'Category name too long')
    .optional(),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .max(100, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug must contain only lowercase letters, numbers, and hyphens')
    .optional(),
  description: z.string().optional(),
  parentId: z.string().optional(),
  sortOrder: z.number().int().min(0).optional(),
  status: z.enum(['draft', 'published', 'archived']).optional(),
  image: z.string().optional(),
  seoTitle: z.string().max(60, 'SEO title too long').optional(),
  seoDescription: z.string().max(160, 'SEO description too long').optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Category filters validation schema
 */
export const categoryFiltersSchema = z.object({
  name: z.string().optional(),
  slug: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).optional(),
  parentId: z.string().optional(),
  hasChildren: z.boolean().optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
  sortBy: z.enum(['name', 'sortOrder', 'createdAt', 'updatedAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

/**
 * Category reorder validation schema
 */
export const categoryReorderSchema = z.object({
  categoryId: z.string().min(1, 'Category ID is required'),
  newSortOrder: z.number().int().min(0, 'Sort order must be non-negative'),
  parentId: z.string().optional(),
});
