// ====================================================================
// FIGHT VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for fight validation

import { createValidationSuites } from '@revealui/core/validation';
import { z } from 'zod';

// ======
// FIGHT SCHEMAS
// ======

/**
 * Weight class schema
 */
export const weightClassSchema = z.enum([
  'strawweight',
  'flyweight',
  'bantamweight',
  'featherweight',
  'lightweight',
  'welterweight',
  'middleweight',
  'light_heavyweight',
  'heavyweight',
  'open_weight',
]);

/**
 * Fight status schema
 */
export const fightStatusSchema = z.enum([
  'scheduled',
  'in_progress',
  'completed',
  'cancelled',
  'postponed',
  'no_contest',
]);

/**
 * Fight result method schema
 */
export const fightResultMethodSchema = z.enum([
  'knockout',
  'submission',
  'decision',
  'technical_decision',
  'split_decision',
  'majority_decision',
  'unanimous_decision',
  'disqualification',
  'no_contest',
]);

/**
 * Create fight validation schema
 */
export const createFightSchema = z.object({
  title: z
    .string()
    .min(1, 'Title is required')
    .max(200, 'Title must be no more than 200 characters'),
  description: z
    .string()
    .min(1, 'Description is required')
    .max(1000, 'Description must be no more than 1000 characters'),
  scheduledDate: z.string().datetime('Invalid scheduled date format'),
  weightClass: weightClassSchema,
  fighterIds: z
    .array(z.string().uuid('Invalid fighter ID format'))
    .min(2, 'Must have exactly 2 fighters')
    .max(2, 'Must have exactly 2 fighters'),
  eventId: z.string().uuid('Invalid event ID format').optional(),
  venue: z
    .string()
    .min(1, 'Venue is required')
    .max(200, 'Venue must be no more than 200 characters'),
  location: z
    .string()
    .min(1, 'Location is required')
    .max(200, 'Location must be no more than 200 characters'),
  ticketPrice: z.number().positive('Ticket price must be positive').optional(),
  streamPrice: z.number().positive('Stream price must be positive').optional(),
  payPerView: z.boolean(),
  status: fightStatusSchema,
});

/**
 * Update fight validation schema
 */
export const updateFightSchema = createFightSchema.partial();

/**
 * Fight filters validation schema
 */
export const fightFiltersSchema = z.object({
  status: z.array(fightStatusSchema).optional(),
  weightClass: z.array(weightClassSchema).optional(),
  dateRange: z
    .object({
      start: z.string().datetime('Invalid start date format'),
      end: z.string().datetime('Invalid end date format'),
    })
    .optional(),
  location: z.string().optional(),
  fighterIds: z.array(z.string().uuid('Invalid fighter ID format')).optional(),
  eventId: z.string().uuid('Invalid event ID format').optional(),
  featured: z.boolean().optional(),
  payPerView: z.boolean().optional(),
});

/**
 * Fight result validation schema
 */
export const fightResultSchema = z.object({
  winnerId: z.string().uuid('Invalid winner ID format'),
  loserId: z.string().uuid('Invalid loser ID format'),
  method: fightResultMethodSchema,
  round: z
    .number()
    .int()
    .min(1, 'Round must be at least 1')
    .max(25, 'Round must be no more than 25')
    .optional(),
  time: z
    .string()
    .regex(/^\d{1,2}:\d{2}$/, 'Time must be in MM:SS format')
    .optional(),
  judges: z.array(z.string().uuid('Invalid judge ID format')).optional(),
  scores: z
    .array(
      z.object({
        judgeId: z.string().uuid('Invalid judge ID format'),
        winnerScore: z.number().int().min(0, 'Winner score must be non-negative'),
        loserScore: z.number().int().min(0, 'Loser score must be non-negative'),
      })
    )
    .optional(),
  notes: z.string().max(500, 'Notes must be no more than 500 characters').optional(),
});

// ======
// VALIDATION SUITES
// ======

/**
 * Fight validation schemas and utilities
 */
export const fightValidationSchemas = createValidationSuites({
  createFight: createFightSchema,
  updateFight: updateFightSchema,
  fightFilters: fightFiltersSchema,
  fightResult: fightResultSchema,
});

// ======
// TYPE EXPORTS
// ======

export type CreateFightData = z.infer<typeof createFightSchema>;
export type UpdateFightData = z.infer<typeof updateFightSchema>;
export type FightFiltersData = z.infer<typeof fightFiltersSchema>;
export type FightResultData = z.infer<typeof fightResultSchema>;
export type WeightClassData = z.infer<typeof weightClassSchema>;
export type FightStatusData = z.infer<typeof fightStatusSchema>;
export type FightResultMethodData = z.infer<typeof fightResultMethodSchema>;
