// ====================================================================
// USER VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for user validation

import {
  createValidationSuites,
  dateRangeSchema,
  roleSchema,
  statusSchema,
} from '@revealui/core/validation';
import { z } from 'zod';

// ======
// USER SCHEMAS
// ======

/**
 * Create user validation schema
 */
export const createUserSchema = z.object({
  email: z.string().email('Please enter a valid email address').max(255, 'Email too long'),
  username: z
    .string()
    .min(3, 'Username must be at least 3 characters')
    .max(50, 'Username must be no more than 50 characters')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores'),
  name: z.string().min(1, 'Name is required').max(100, 'Name must be no more than 100 characters'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
      'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'
    ),
  role: roleSchema.default('user'),
  status: statusSchema.default('published'),
  bio: z.string().max(500, 'Bio must be no more than 500 characters').optional(),
  avatar: z.string().url('Please enter a valid URL').optional(),
  preferences: z
    .object({
      emailNotifications: z.boolean().default(true),
      pushNotifications: z.boolean().default(true),
      privacyLevel: z.enum(['public', 'friends', 'private']).default('public'),
      theme: z.enum(['light', 'dark', 'auto']).default('auto'),
      language: z.string().default('en'),
      timezone: z.string().default('UTC'),
      currency: z.string().default('USD'),
    })
    .optional(),
});

/**
 * Update user validation schema
 */
export const updateUserSchema = z.object({
  name: z
    .string()
    .min(1, 'Name is required')
    .max(100, 'Name must be no more than 100 characters')
    .optional(),
  username: z
    .string()
    .min(3, 'Username must be at least 3 characters')
    .max(50, 'Username must be no more than 50 characters')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores')
    .optional(),
  email: z.string().email('Please enter a valid email address').optional(),
  role: roleSchema.optional(),
  status: statusSchema.optional(),
  bio: z.string().max(500, 'Bio must be no more than 500 characters').optional(),
  avatar: z.string().url('Please enter a valid URL').optional(),
  preferences: z
    .object({
      emailNotifications: z.boolean().optional(),
      pushNotifications: z.boolean().optional(),
      privacyLevel: z.enum(['public', 'friends', 'private']).optional(),
      theme: z.enum(['light', 'dark', 'auto']).optional(),
      language: z.string().optional(),
      timezone: z.string().optional(),
      currency: z.string().optional(),
    })
    .optional(),
});

/**
 * User filters validation schema
 */
export const userFiltersSchema = z.object({
  page: z.number().int().min(1, 'Page must be at least 1').optional().default(1),
  limit: z
    .number()
    .int()
    .min(1, 'Limit must be at least 1')
    .max(100, 'Limit must be no more than 100')
    .optional()
    .default(20),
  sort: z.string().optional().default('createdAt'),
  search: z.string().max(100, 'Search term must be no more than 100 characters').optional(),
  role: z.array(roleSchema).optional(),
  status: z.array(statusSchema).optional(),
  verified: z.boolean().optional(),
  dateRange: dateRangeSchema.optional(),
  hasAvatar: z.boolean().optional(),
  hasBio: z.boolean().optional(),
});

/**
 * User profile validation schema
 */
export const userProfileSchema = z.object({
  bio: z.string().max(500, 'Bio must be no more than 500 characters').optional(),
  avatar: z.string().url('Please enter a valid URL').optional(),
  socialLinks: z
    .object({
      twitter: z.string().url().optional(),
      facebook: z.string().url().optional(),
      instagram: z.string().url().optional(),
      linkedin: z.string().url().optional(),
      website: z.string().url().optional(),
    })
    .optional(),
  preferences: z
    .object({
      emailNotifications: z.boolean().optional(),
      pushNotifications: z.boolean().optional(),
      privacyLevel: z.enum(['public', 'friends', 'private']).optional(),
      theme: z.enum(['light', 'dark', 'auto']).optional(),
      language: z.string().optional(),
      timezone: z.string().optional(),
      currency: z.string().optional(),
    })
    .optional(),
});

// ======
// VALIDATION SUITES
// ======

/**
 * User validation schemas and utilities
 */
export const userValidationSchemas = createValidationSuites({
  createUser: createUserSchema,
  updateUser: updateUserSchema,
  userFilters: userFiltersSchema,
  userProfile: userProfileSchema,
});

// ======
// TYPE EXPORTS
// ======

export type CreateUserData = z.infer<typeof createUserSchema>;
export type UpdateUserData = z.infer<typeof updateUserSchema>;
export type UserFiltersData = z.infer<typeof userFiltersSchema>;
export type UserProfileData = z.infer<typeof userProfileSchema>;
