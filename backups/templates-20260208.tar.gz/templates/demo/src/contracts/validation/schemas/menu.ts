// ====================================================================
// MENU VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for menu validation

import { z } from 'zod';

/**
 * Menu item data schema
 */
const menuItemDataSchema: z.ZodType<{ label: string; href: string; children?: unknown[] }> =
  z.object({
    label: z.string().min(1, 'Label is required').max(100, 'Label too long'),
    href: z.string().min(1, 'Href is required').max(500, 'Href too long'),
    children: z.lazy(() => z.array(menuItemDataSchema)).optional(),
  });

/**
 * Create menu validation schema
 */
export const createMenuSchema = z.object({
  name: z.string().min(1, 'Menu name is required').max(100, 'Menu name too long'),
  location: z.enum(['header', 'footer', 'sidebar'], {
    errorMap: () => ({ message: 'Location must be header, footer, or sidebar' }),
  }),
  isActive: z.boolean().optional().default(true),
  sortOrder: z.number().int().min(0).optional().default(0),
  items: z.array(menuItemDataSchema).min(0, 'Menu items array is required'),
  status: z.enum(['active', 'inactive']).optional().default('active'),
});

/**
 * Update menu validation schema
 */
export const updateMenuSchema = z.object({
  name: z.string().min(1, 'Menu name is required').max(100, 'Menu name too long').optional(),
  location: z.enum(['header', 'footer', 'sidebar']).optional(),
  isActive: z.boolean().optional(),
  sortOrder: z.number().int().min(0).optional(),
  items: z.array(menuItemDataSchema).optional(),
  status: z.enum(['active', 'inactive']).optional(),
});

/**
 * Menu filters validation schema
 */
export const menuFiltersSchema = z.object({
  location: z.enum(['header', 'footer', 'sidebar']).optional(),
  status: z.enum(['active', 'inactive']).optional(),
  isActive: z.boolean().optional(),
  searchTerm: z.string().max(100, 'Search term too long').optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
});
