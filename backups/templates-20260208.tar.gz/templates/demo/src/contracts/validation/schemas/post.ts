// ====================================================================
// POST VALIDATION SCHEMAS
// ====================================================================
// Zod schemas for post validation

import { z } from 'zod';

/**
 * Create post validation schema
 */
export const createPostSchema = z.object({
  title: z.string().min(1, 'Post title is required').max(200, 'Title too long'),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .max(100, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug must contain only lowercase letters, numbers, and hyphens'),
  content: z.string().optional(),
  excerpt: z.string().max(500, 'Excerpt too long').optional(),
  status: z.enum(['draft', 'published', 'archived']),
  publishedAt: z.string().datetime().optional(),
  authorId: z.string().min(1, 'Author ID is required'),
  categoryId: z.string().optional(),
  tags: z.array(z.string()).optional(),
  featuredImage: z.string().optional(),
  seoTitle: z.string().max(60, 'SEO title too long').optional(),
  seoDescription: z.string().max(160, 'SEO description too long').optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Update post validation schema
 */
export const updatePostSchema = z.object({
  title: z.string().min(1, 'Post title is required').max(200, 'Title too long').optional(),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .max(100, 'Slug too long')
    .regex(/^[a-z0-9-]+$/, 'Slug must contain only lowercase letters, numbers, and hyphens')
    .optional(),
  content: z.string().optional(),
  excerpt: z.string().max(500, 'Excerpt too long').optional(),
  status: z.enum(['draft', 'published', 'archived']).optional(),
  publishedAt: z.string().datetime().optional(),
  authorId: z.string().min(1, 'Author ID is required').optional(),
  categoryId: z.string().optional(),
  tags: z.array(z.string()).optional(),
  featuredImage: z.string().optional(),
  seoTitle: z.string().max(60, 'SEO title too long').optional(),
  seoDescription: z.string().max(160, 'SEO description too long').optional(),
  metaFields: z.record(z.string(), z.unknown()).optional(),
});

/**
 * Post filters validation schema
 */
export const postFiltersSchema = z.object({
  title: z.string().optional(),
  slug: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).optional(),
  authorId: z.string().optional(),
  categoryId: z.string().optional(),
  tags: z.array(z.string()).optional(),
  publishedAfter: z.string().datetime().optional(),
  publishedBefore: z.string().datetime().optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(100).optional(),
  page: z.number().int().min(1).optional(),
  sortBy: z.enum(['title', 'publishedAt', 'createdAt', 'updatedAt']).optional(),
  sortOrder: z.enum(['asc', 'desc']).optional(),
});

/**
 * Post search validation schema
 */
export const postSearchSchema = z.object({
  query: z.string().min(1, 'Search query is required'),
  filters: postFiltersSchema.optional(),
  includeContent: z.boolean().optional(),
  includeExcerpt: z.boolean().optional(),
});
