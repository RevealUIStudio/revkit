// ====================================================================
// VALIDATION MIDDLEWARE
// ====================================================================
// Pre-configured validation middleware for common schemas

import { validateInput } from '@revealui/core/middleware/validation';
import {
  createFightSchema,
  createProductSchema,
  createUserSchema,
  fightFiltersSchema,
  fightResultSchema,
  productFiltersSchema,
  productVariantSchema,
  updateFightSchema,
  updateProductSchema,
  updateUserSchema,
  userFiltersSchema,
  userProfileSchema,
} from './schemas';
import { createCartItemSchema, updateCartItemSchema } from './schemas/cart';
import {
  categoryFiltersSchema,
  createCategorySchema,
  updateCategorySchema,
} from './schemas/category';
import { createOrderSchema, orderFiltersSchema, updateOrderSchema } from './schemas/order';
import { createPostSchema, postFiltersSchema, updatePostSchema } from './schemas/post';

// ======
// USER MIDDLEWARE
// ======

export const validateCreateUser = validateInput(createUserSchema);
export const validateUpdateUser = validateInput(updateUserSchema);
export const validateUserFilters = validateInput(userFiltersSchema);
export const validateUserProfile = validateInput(userProfileSchema);

// ======
// PRODUCT MIDDLEWARE
// ======

export const validateCreateProduct = validateInput(createProductSchema);
export const validateUpdateProduct = validateInput(updateProductSchema);
export const validateProductFilters = validateInput(productFiltersSchema);
export const validateProductVariant = validateInput(productVariantSchema);

// ======
// FIGHT MIDDLEWARE
// ======

export const validateCreateFight = validateInput(createFightSchema);
export const validateUpdateFight = validateInput(updateFightSchema);
export const validateFightFilters = validateInput(fightFiltersSchema);
export const validateFightResult = validateInput(fightResultSchema);

// ======
// CATEGORY MIDDLEWARE
// ======

export const validateCreateCategory = validateInput(createCategorySchema);
export const validateUpdateCategory = validateInput(updateCategorySchema);
export const validateCategoryFilters = validateInput(categoryFiltersSchema);

// ======
// POST MIDDLEWARE
// ======

export const validateCreatePost = validateInput(createPostSchema);
export const validateUpdatePost = validateInput(updatePostSchema);
export const validatePostFilters = validateInput(postFiltersSchema);

// ======
// CART MIDDLEWARE
// ======

export const validateCreateCartItem = validateInput(createCartItemSchema);
export const validateUpdateCartItem = validateInput(updateCartItemSchema);

// ======
// ORDER MIDDLEWARE
// ======

export const validateCreateOrder = validateInput(createOrderSchema);
export const validateUpdateOrder = validateInput(updateOrderSchema);
export const validateOrderFilters = validateInput(orderFiltersSchema);

// ======
// GROUPED MIDDLEWARE OBJECTS
// ======

/**
 * User validation middleware
 */
export const userValidationMiddleware = {
  create: validateCreateUser,
  update: validateUpdateUser,
  filters: validateUserFilters,
  profile: validateUserProfile,
};

/**
 * Product validation middleware
 */
export const productValidationMiddleware = {
  create: validateCreateProduct,
  update: validateUpdateProduct,
  filters: validateProductFilters,
  variant: validateProductVariant,
};

/**
 * Fight validation middleware
 */
export const fightValidationMiddleware = {
  create: validateCreateFight,
  update: validateUpdateFight,
  filters: validateFightFilters,
  result: validateFightResult,
};

/**
 * Category validation middleware
 */
export const categoryValidationMiddleware = {
  create: validateCreateCategory,
  update: validateUpdateCategory,
  filters: validateCategoryFilters,
};

/**
 * Post validation middleware
 */
export const postValidationMiddleware = {
  create: validateCreatePost,
  update: validateUpdatePost,
  filters: validatePostFilters,
};

/**
 * Cart validation middleware
 */
export const cartValidationMiddleware = {
  createItem: validateCreateCartItem,
  updateItem: validateUpdateCartItem,
};

/**
 * Order validation middleware
 */
export const orderValidationMiddleware = {
  create: validateCreateOrder,
  update: validateUpdateOrder,
  filters: validateOrderFilters,
};
