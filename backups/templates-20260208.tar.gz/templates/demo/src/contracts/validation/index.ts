// ====================================================================
// VALIDATION INDEX - Single Entry Point
// ====================================================================
// Export all validation schemas, inferred DTOs, and validation utilities
// NOTE: Domain entities live in types/, not here. This exports runtime validators.

// ====================================================================
// VALIDATION RESULTS & ERRORS
// ====================================================================
export * from './errors';
export * from './results';
export * from './architecture';
export type { ValidationError, ValidationErrorCode, ValidationErrorCodes } from './errors';
export type { GenericValidationResult, FormValidationState } from './results';
export type { ArchitectureValidationResult, BuildValidationResult } from './architecture';

// ====================================================================
// BASE VALIDATION
// ====================================================================
export * from './base';
export type {
  BaseValidationData,
  DateRangeData,
  PaginationData,
  RoleData,
  SearchData,
  StatusData,
} from './base';

// ====================================================================
// VALIDATION SCHEMAS (All domain schemas)
// ====================================================================
export * from './schemas';

// ====================================================================
// VALIDATION UTILITIES
// ====================================================================
export * from './utilities';
export type { ValidationError as DTOValidationError, DTOValidationResult } from './utilities';

// ====================================================================
// VALIDATION MIDDLEWARE
// ====================================================================
export * from './middleware';

// ====================================================================
// VALIDATION PERFORMANCE
// ====================================================================
export * from './performance';
