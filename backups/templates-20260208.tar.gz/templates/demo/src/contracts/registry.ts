// ====================================================================
// CONTRACT REGISTRY
// ====================================================================
// Centralized registry of all domain contract snapshots

import { createContractRegistry } from './core/registry';
import { CartContract } from './domains/cart.contract';
import { CategoryContract } from './domains/category.contract';
import { FightContract } from './domains/fight.contract';
import { MediaContract } from './domains/media.contract';
import { MenuContract } from './domains/menu.contract';
import { OrderContract } from './domains/order.contract';
import { PostContract } from './domains/post.contract';
import { ProductContract } from './domains/product.contract';
import { TagContract } from './domains/tag.contract';
import { UserContract } from './domains/user.contract';

/**
 * Contract registry mapping
 * Internal type for the contracts object
 */
type ContractsMap = {
  user: typeof UserContract;
  product: typeof ProductContract;
  fight: typeof FightContract;
  cart: typeof CartContract;
  order: typeof OrderContract;
  category: typeof CategoryContract;
  post: typeof PostContract;
  media: typeof MediaContract;
  menu: typeof MenuContract;
  tag: typeof TagContract;
};

/**
 * Unified Contract Registry
 *
 * Provides type-safe access to all domain contracts.
 * Each contract is a snapshot capturing Shape, Behavior, and Quality.
 *
 * Uses the proper BaseContractRegistry implementation for runtime benefits:
 * - Contract validation
 * - Type-safe access
 * - Utility methods
 */
const contractsMap: ContractsMap = {
  user: UserContract,
  product: ProductContract,
  fight: FightContract,
  cart: CartContract,
  order: OrderContract,
  category: CategoryContract,
  post: PostContract,
  media: MediaContract,
  menu: MenuContract,
  tag: TagContract,
};

// Create the registry
const registry = createContractRegistry(contractsMap);

// Export Contracts as both the registry AND with direct property access
// This allows both Contracts.get('user') and Contracts.user to work
export const Contracts = Object.assign(registry, contractsMap) as typeof registry & ContractsMap;

/**
 * Contract names type
 */
export type ContractName = keyof ContractsMap;

/**
 * Get contract by name
 */
export type GetContract<T extends ContractName> = ContractsMap[T];

/**
 * Contract registry utilities
 * Provides convenient access to registry methods
 */
export const ContractUtils = {
  /**
   * Get all contract names
   */
  getNames(): ContractName[] {
    return Contracts.getNames() as ContractName[];
  },

  /**
   * Get contract by name
   */
  get<T extends ContractName>(name: T): ContractsMap[T] {
    return Contracts.get(name);
  },

  /**
   * Get total number of contracts
   */
  count(): number {
    return Contracts.size();
  },

  /**
   * Check if contract exists
   */
  has(name: string): name is ContractName {
    return Contracts.has(name);
  },

  /**
   * Get all contracts
   */
  getAll(): ContractsMap {
    return Contracts.getAll();
  },

  /**
   * Validate a contract
   */
  validate<T extends ContractName>(name: T) {
    return Contracts.validateContract(name);
  },

  /**
   * Validate all contracts
   */
  validateAll() {
    return Contracts.validateAll();
  },

  /**
   * Check contract health
   */
  checkHealth<T extends ContractName>(name: T) {
    return Contracts.checkHealth(name);
  },

  /**
   * Check health of all contracts
   */
  checkAllHealth() {
    return Contracts.checkAllHealth();
  },

  /**
   * Get contract dependencies
   */
  getDependencies<T extends ContractName>(name: T): string[] {
    return Contracts.getDependencies(name);
  },

  /**
   * Get contracts that depend on a given contract
   */
  getDependents<T extends ContractName>(name: T): ContractName[] {
    return Contracts.getDependents(name) as ContractName[];
  },

  /**
   * Detect circular dependencies
   */
  detectCircularDependencies(): string[][] {
    return Contracts.detectCircularDependencies();
  },
};
