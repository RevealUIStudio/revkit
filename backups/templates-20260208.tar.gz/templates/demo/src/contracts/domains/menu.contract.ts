// ====================================================================
// MENU DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Menu domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IMenuDomainService } from '../interfaces/domain/services/IMenuDomainService';
import type { CreateMenuDTO, UpdateMenuDTO } from '../types/domain/dto/menu';
import type { DomainMenu } from '../types/domain/entities/menu';
import { createMenuSchema, menuFiltersSchema, updateMenuSchema } from '../validation/schemas/menu';

/**
 * Menu Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainMenu entity and DTOs
 * - Behavior: IMenuDomainService interface
 * - Quality: Zod validation schemas
 */
export const MenuContract = createContractSnapshot({
  domain: 'menu',
  version: '1.0.0',

  shape: {
    entity: {} as DomainMenu,
    dto: {
      create: {} as CreateMenuDTO,
      update: {} as UpdateMenuDTO,
    },
  },

  behavior: {
    service: {} as IMenuDomainService,
  },

  validation: {
    create: createMenuSchema,
    update: updateMenuSchema,
    filters: menuFiltersSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: [],
    description: 'Menu management domain contract including navigation and structure',
    tags: ['navigation', 'ui', 'menu'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Menu = typeof MenuContract.shape.entity;
export type CreateMenu = typeof MenuContract.shape.dto.create;
export type UpdateMenu = typeof MenuContract.shape.dto.update;
export type MenuService = typeof MenuContract.behavior.service;

export const { validation: MenuValidation } = MenuContract;
