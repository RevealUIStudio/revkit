// ====================================================================
// ORDER DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Order domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IOrderService } from '../interfaces/domain/services/IOrderService';
import type { CreateOrderDTO, UpdateOrderDTO } from '../types/domain/dto/order';
import type { DomainOrder } from '../types/domain/entities/order';
import {
  createOrderSchema,
  orderFiltersSchema,
  updateOrderSchema,
} from '../validation/schemas/order';

/**
 * Order Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainOrder entity and DTOs
 * - Behavior: IOrderService interface
 * - Quality: Zod validation schemas
 */
export const OrderContract = createContractSnapshot({
  domain: 'order',
  version: '1.0.0',

  shape: {
    entity: {} as DomainOrder,
    dto: {
      create: {} as CreateOrderDTO,
      update: {} as UpdateOrderDTO,
    },
  },

  behavior: {
    service: {} as IOrderService,
  },

  validation: {
    create: createOrderSchema,
    update: updateOrderSchema,
    filters: orderFiltersSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['cart', 'product'],
    description: 'Order management domain contract including fulfillment and payment processing',
    tags: ['ecommerce', 'order-management'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Order = typeof OrderContract.shape.entity;
export type CreateOrder = typeof OrderContract.shape.dto.create;
export type UpdateOrder = typeof OrderContract.shape.dto.update;
export type OrderService = typeof OrderContract.behavior.service;

export const { validation: OrderValidation } = OrderContract;
