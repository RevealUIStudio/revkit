// ====================================================================
// USER DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for User domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IUserDomainService } from '../interfaces/domain/services/IUserDomainService';
import type { CreateUserDTO, UpdateUserDTO } from '../types/domain/dto/user';
import type { DomainUser } from '../types/domain/entities/user';
import {
  createUserSchema,
  updateUserSchema,
  userFiltersSchema,
  userProfileSchema,
} from '../validation/schemas/user';

/**
 * User Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainUser entity and DTOs
 * - Behavior: IUserDomainService interface
 * - Quality: Zod validation schemas
 */
export const UserContract = createContractSnapshot({
  domain: 'user',
  version: '1.0.0',

  shape: {
    entity: {} as DomainUser,
    dto: {
      create: {} as CreateUserDTO,
      update: {} as UpdateUserDTO,
    },
  },

  behavior: {
    service: {} as IUserDomainService,
  },

  validation: {
    create: createUserSchema,
    update: updateUserSchema,
    filters: userFiltersSchema,
    profile: userProfileSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['auth', 'role'],
    description: 'User management domain contract including authentication and profile management',
    tags: ['auth', 'user-management', 'profile'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================
// Type-safe access to contract components

export type User = typeof UserContract.shape.entity;
export type CreateUser = typeof UserContract.shape.dto.create;
export type UpdateUser = typeof UserContract.shape.dto.update;
export type UserService = typeof UserContract.behavior.service;

export const { validation: UserValidation } = UserContract;
