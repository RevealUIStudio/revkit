// ====================================================================
// MEDIA DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Media domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IMediaDomainService } from '../interfaces/domain/services/IMediaDomainService';
import type { DomainMedia } from '../types/domain/entities/media';
import {
  mediaCropSchema,
  mediaFiltersSchema,
  mediaResizeSchema,
  updateMediaSchema,
  uploadMediaSchema,
} from '../validation/schemas/media';

/**
 * Media Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainMedia entity
 * - Behavior: IMediaDomainService interface
 * - Quality: Zod validation schemas
 */
export const MediaContract = createContractSnapshot({
  domain: 'media',
  version: '1.0.0',

  shape: {
    entity: {} as DomainMedia,
    dto: {
      // Media uploads use File objects, not traditional DTOs
      upload: {} as { file: File; alt?: string; caption?: string; folder?: string },
      update: {} as { alt?: string; caption?: string; tags?: string[] },
    },
  },

  behavior: {
    service: {} as IMediaDomainService,
  },

  validation: {
    upload: uploadMediaSchema,
    update: updateMediaSchema,
    filters: mediaFiltersSchema,
    resize: mediaResizeSchema,
    crop: mediaCropSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: [],
    description: 'Media management domain contract including file uploads and processing',
    tags: ['media', 'file-management', 'assets'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Media = typeof MediaContract.shape.entity;
export type MediaService = typeof MediaContract.behavior.service;

export const { validation: MediaValidation } = MediaContract;
