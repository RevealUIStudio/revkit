// ====================================================================
// CART DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Cart domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { ICartService } from '../interfaces/domain/services/ICartService';
import type { CreateCartItemDTO, UpdateCartItemDTO } from '../types/domain/dto/cart';
import type { DomainCart } from '../types/domain/entities/cart';
import {
  cartCheckoutSchema,
  cartFiltersSchema,
  createCartItemSchema,
  updateCartItemSchema,
} from '../validation/schemas/cart';

/**
 * Cart Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainCart entity and DTOs
 * - Behavior: ICartService interface
 * - Quality: Zod validation schemas
 */
export const CartContract = createContractSnapshot({
  domain: 'cart',
  version: '1.0.0',

  shape: {
    entity: {} as DomainCart,
    dto: {
      create: {} as CreateCartItemDTO,
      update: {} as UpdateCartItemDTO,
    },
  },

  behavior: {
    service: {} as ICartService,
  },

  validation: {
    create: createCartItemSchema,
    update: updateCartItemSchema,
    filters: cartFiltersSchema,
    checkout: cartCheckoutSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['product'],
    description: 'Shopping cart domain contract including item management and checkout',
    tags: ['ecommerce', 'shopping-cart'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Cart = typeof CartContract.shape.entity;
export type CreateCartItem = typeof CartContract.shape.dto.create;
export type UpdateCartItem = typeof CartContract.shape.dto.update;
export type CartService = typeof CartContract.behavior.service;

export const { validation: CartValidation } = CartContract;
