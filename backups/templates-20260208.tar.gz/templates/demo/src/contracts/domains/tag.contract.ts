// ====================================================================
// TAG DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Tag domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { ITagDomainService } from '../interfaces/domain/services/ITagDomainService';
import type { CreateTagDTO, UpdateTagDTO } from '../types/domain/dto/tag';
import type { DomainTag } from '../types/domain/entities/tag';
import { createTagSchema, tagFiltersSchema, updateTagSchema } from '../validation/schemas/tag';

/**
 * Tag Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainTag entity and DTOs
 * - Behavior: ITagDomainService interface
 * - Quality: Zod validation schemas
 */
export const TagContract = createContractSnapshot({
  domain: 'tag',
  version: '1.0.0',

  shape: {
    entity: {} as DomainTag,
    dto: {
      create: {} as CreateTagDTO,
      update: {} as UpdateTagDTO,
    },
  },

  behavior: {
    service: {} as ITagDomainService,
  },

  validation: {
    create: createTagSchema,
    update: updateTagSchema,
    filters: tagFiltersSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: [],
    description: 'Tag management domain contract including taxonomy and content organization',
    tags: ['taxonomy', 'content', 'tagging'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Tag = typeof TagContract.shape.entity;
export type CreateTag = typeof TagContract.shape.dto.create;
export type UpdateTag = typeof TagContract.shape.dto.update;
export type TagService = typeof TagContract.behavior.service;

export const { validation: TagValidation } = TagContract;
