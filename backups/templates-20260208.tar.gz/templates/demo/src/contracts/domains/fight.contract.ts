// ====================================================================
// FIGHT DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Fight domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IFightService } from '../interfaces/domain/services/IFightService';
import type { CreateFightDTO, UpdateFightDTO } from '../types/domain/dto/fight';
import type { Fight as FightEntity } from '../types/domain/entities/fight';
import {
  createFightSchema,
  fightFiltersSchema,
  fightResultSchema,
  updateFightSchema,
} from '../validation/schemas/fight';

/**
 * Fight Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: Fight entity and DTOs
 * - Behavior: IFightService interface
 * - Quality: Zod validation schemas
 */
export const FightContract = createContractSnapshot({
  domain: 'fight',
  version: '1.0.0',

  shape: {
    entity: {} as FightEntity,
    dto: {
      create: {} as CreateFightDTO,
      update: {} as UpdateFightDTO,
    },
  },

  behavior: {
    service: {} as IFightService,
  },

  validation: {
    create: createFightSchema,
    update: updateFightSchema,
    filters: fightFiltersSchema,
    result: fightResultSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['user', 'media', 'category'],
    description: 'Fight management domain contract including scheduling, results, and analytics',
    tags: ['mma', 'combat-sports', 'scheduling'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================
// Type-safe access to contract components

export type Fight = typeof FightContract.shape.entity;
export type CreateFight = typeof FightContract.shape.dto.create;
export type UpdateFight = typeof FightContract.shape.dto.update;
export type FightService = typeof FightContract.behavior.service;

export const { validation: FightValidation } = FightContract;
