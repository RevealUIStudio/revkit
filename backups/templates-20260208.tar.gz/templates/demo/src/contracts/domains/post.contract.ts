// ====================================================================
// POST DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Post domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IPostDomainService } from '../interfaces/domain/services/IPostDomainService';
import type { CreatePostDTO, UpdatePostDTO } from '../types/domain/dto/post';
import type { DomainPost } from '../types/domain/entities/post';
import { createPostSchema, postFiltersSchema, updatePostSchema } from '../validation/schemas/post';

/**
 * Post Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainPost entity and DTOs
 * - Behavior: IPostDomainService interface
 * - Quality: Zod validation schemas
 */
export const PostContract = createContractSnapshot({
  domain: 'post',
  version: '1.0.0',

  shape: {
    entity: {} as DomainPost,
    dto: {
      create: {} as CreatePostDTO,
      update: {} as UpdatePostDTO,
    },
  },

  behavior: {
    service: {} as IPostDomainService,
  },

  validation: {
    create: createPostSchema,
    update: updatePostSchema,
    filters: postFiltersSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['user', 'category', 'media'],
    description: 'Post management domain contract including publishing and content workflow',
    tags: ['content', 'cms', 'publishing'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

export type Post = typeof PostContract.shape.entity;
export type CreatePost = typeof PostContract.shape.dto.create;
export type UpdatePost = typeof PostContract.shape.dto.update;
export type PostService = typeof PostContract.behavior.service;

export const { validation: PostValidation } = PostContract;
