# Contract Guidelines

## Overview

This document provides clear guidelines on what types and interfaces belong in
the `contracts/` folder versus implementation files.

## Core Principle

**Contracts** = Architectural boundaries and shared contracts  
**Implementation Types** = Component-specific, local, or implementation details

## Decision Tree

```
Is this type exported?
├─ No → Keep in implementation file (private/local type)
└─ Yes → Continue
    │
    Does it match an allow pattern?
    ├─ Yes → Keep in implementation file (component props, variants, etc.)
    └─ No → Continue
        │
        Does it match an enforce pattern?
        ├─ Yes → Move to contracts/
        └─ No → Continue
            │
            Is it in an allowed file location?
            ├─ Yes → Keep in file (component/style files)
            └─ No → Consider moving to contracts/
```

## Pattern Reference

### Enforce Patterns (MUST be in contracts/)

These patterns represent architectural boundaries and MUST be defined in
`contracts/`:

| Pattern       | Examples                                        | Why                                                |
| ------------- | ----------------------------------------------- | -------------------------------------------------- |
| `*Service`    | `UserService`, `CartService`, `IProductService` | Service contracts define behavioral boundaries     |
| `*Repository` | `UserRepository`, `ICartRepository`             | Repository contracts define data access boundaries |
| `*DTO`        | `CreateUserDTO`, `UpdateProductDTO`             | DTOs represent cross-layer data transfer           |
| `Domain*`     | `DomainUser`, `DomainCart`                      | Domain entities are core business objects          |
| `*Event`      | `CartCreatedEvent`, `UserRegisteredEvent`       | Events represent domain occurrences                |
| `*Result`     | `ServiceResult`, `ValidationResult`             | Result types wrap operation outcomes               |
| `*Response`   | `ApiResponse`, `HttpResponse`                   | Response types represent API boundaries            |

### Allow Patterns (Can stay in implementation files)

These patterns represent implementation details and can stay where they're used:

| Pattern     | Examples                                         | Why                                                       |
| ----------- | ------------------------------------------------ | --------------------------------------------------------- |
| `*Props`    | `ButtonProps`, `InputProps`, `ClientButtonProps` | Component props are inherently coupled to their component |
| `*Variants` | `buttonVariants`, `inputVariants`                | Style variants are implementation details                 |
| `*Config`   | `ComponentConfig`, `ThemeConfig`                 | Configuration types are local concerns                    |
| `Internal*` | `InternalHelper`, `InternalState`                | Explicitly marked as implementation detail                |
| `_*`        | `_internalType`, `_localHelper`                  | Underscore prefix indicates private scope                 |

### Allowed File Locations

These file patterns are always allowed regardless of type naming:

- `src/presentation/ui/**/*.tsx` - Component files
- `src/presentation/components/**/*.tsx` - Component files
- `src/presentation/styles/**/*.ts` - Style files
- `*.test.tsx?` - Test files
- `*.spec.tsx?` - Spec files

## Common Scenarios

### Scenario 1: Component Props

**Question**: Where should `ButtonProps` live?

**Answer**: In the component file (`src/presentation/ui/base/button.tsx`)

**Reasoning**: Props are implementation details specific to a component. The
`*Props` pattern is allowed.

```typescript
// ✅ GOOD: In component file
// src/presentation/ui/base/button.tsx
export interface ButtonProps {
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
}

// ❌ AVOID: In contracts
// src/contracts/types/presentation/ui/button.ts
export interface ButtonProps { ... }
```

### Scenario 2: Reusable Component Library Props

**Question**: If we create a design system library with shared components, where
should props go?

**Answer**: Still in component files, unless they're truly cross-system
boundaries

**Reasoning**: Even design system components are tied to their implementation.
Keep props co-located.

### Scenario 3: Service Interface

**Question**: Where should `IUserService` live?

**Answer**: In `src/contracts/interfaces/domain/services/IUserService.ts`

**Reasoning**: Matches `*Service` enforce pattern, defines behavioral contract.

```typescript
// ✅ GOOD: In contracts
// src/contracts/interfaces/domain/services/IUserService.ts
export interface IUserService {
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
}

// ❌ BAD: In implementation
// src/domain/services/UserService.ts
export interface IUserService { ... }
```

### Scenario 4: Domain Entity

**Question**: Where should `DomainUser` live?

**Answer**: In `src/contracts/types/domain/entities/user.ts`

**Reasoning**: Matches `Domain*` enforce pattern, represents core business
object.

```typescript
// ✅ GOOD: In contracts
// src/contracts/types/domain/entities/user.ts
export interface DomainUser {
  id: string;
  email: string;
  name: string;
}

// ❌ BAD: In implementation
// src/domain/models/User.ts
export interface DomainUser { ... }
```

### Scenario 5: Hook Return Type

**Question**: Where should `UseUserAuthReturn` live?

**Answer**: In `src/contracts/types/presentation/ui/hooks.ts`

**Reasoning**: Hook return types represent data shapes (types), not behavioral
contracts (interfaces).

```typescript
// ✅ GOOD: In contracts/types
// src/contracts/types/presentation/ui/hooks.ts
export interface UseUserAuthReturn {
  user: User | null;
  login: (credentials: LoginCredentials) => Promise<boolean>;
}

// ❌ AVOID: In contracts/interfaces
// src/contracts/interfaces/infrastructure/components/hooks.ts
export interface UseUserAuthReturn { ... }
```

### Scenario 6: CVA Variants

**Question**: Where should `buttonVariants` live?

**Answer**: In `src/presentation/styles/variants.ts`

**Reasoning**: Matches `*Variants` allow pattern, style files are always
allowed.

```typescript
// ✅ GOOD: In style file
// src/presentation/styles/variants.ts
export const buttonVariants = cva(...);

// ❌ AVOID: In contracts
// src/contracts/types/presentation/ui/button.ts
export const buttonVariants = cva(...);
```

### Scenario 7: Local Helper Type

**Question**: Where should an internal helper type like `_internalCacheEntry`
live?

**Answer**: In the implementation file where it's used

**Reasoning**: Underscore prefix indicates private scope, non-exported types are
always allowed.

```typescript
// ✅ GOOD: Internal to file
// src/infrastructure/cache/CacheManager.ts
type _internalCacheEntry = {
  key: string;
  value: unknown;
};

// ❌ AVOID: In contracts
// src/contracts/types/infrastructure/cache.ts
export type _internalCacheEntry = { ... };
```

## Migration Guide

### Moving Types to Contracts

1. **Identify** the type matches an enforce pattern
2. **Choose** the right contracts location:
   - Service interfaces → `contracts/interfaces/{layer}/services/`
   - Domain entities → `contracts/types/domain/entities/`
   - DTOs → `contracts/validation/`
   - Hook return types → `contracts/types/presentation/ui/`
3. **Move** the type definition
4. **Update** imports across the codebase
5. **Re-export** from old location if needed for backward compatibility

### Keeping Types in Implementation

1. **Verify** it matches an allow pattern OR is in an allowed file location
2. **Ensure** it's truly implementation-specific
3. **Document** why it stays local (if non-obvious)

## Contracts Folder Structure

```
contracts/
├── types/           # Static type definitions (data shapes)
│   ├── domain/      # Domain entities, enums, value objects
│   ├── presentation/ # UI types, hook return types
│   ├── infrastructure/ # Infrastructure types
│   └── shared/      # Cross-cutting types
│
├── interfaces/      # Service contracts (behavioral)
│   ├── domain/      # Domain service interfaces
│   ├── infrastructure/ # Repository interfaces, external services
│   └── presentation/   # Application service interfaces
│
└── validation/      # Runtime validation (Zod schemas + DTOs)
    ├── domain/      # Entity validation schemas
    └── shared/      # Common validation utilities
```

## Type Categories

### types/ - Static Type Definitions

- **Purpose**: Define data shapes
- **Examples**: Domain entities, enums, value objects, UI types
- **Pattern**: "What shape is the data?"

### interfaces/ - Service Contracts

- **Purpose**: Define behavioral contracts
- **Examples**: Service interfaces, repository interfaces
- **Pattern**: "What can the service do?"

### validation/ - Runtime Validation

- **Purpose**: Validate data at runtime
- **Examples**: Zod schemas, DTOs, validation results
- **Pattern**: "Is the data valid?"

## Anti-Patterns

### ❌ Don't: Put Everything in Contracts

```typescript
// ❌ BAD: Component props in contracts
// src/contracts/types/presentation/ui/button.ts
export interface ButtonProps { ... }

// ✅ GOOD: Component props stay with component
// src/presentation/ui/base/button.tsx
export interface ButtonProps { ... }
```

### ❌ Don't: Create Contracts for Implementation Details

```typescript
// ❌ BAD: Internal helper in contracts
// src/contracts/types/infrastructure/helpers.ts
export type InternalCacheEntry = { ... };

// ✅ GOOD: Internal helper stays internal
// src/infrastructure/cache/CacheManager.ts
type InternalCacheEntry = { ... };
```

### ❌ Don't: Mix Contracts and Implementation

```typescript
// ❌ BAD: Service implementation defines its interface
// src/domain/services/UserService.ts
export interface IUserService { ... }
export class UserService implements IUserService { ... }

// ✅ GOOD: Interface in contracts, implementation elsewhere
// src/contracts/interfaces/domain/services/IUserService.ts
export interface IUserService { ... }

// src/domain/services/UserService.ts
export class UserService implements IUserService { ... }
```

## Questions?

**Q: Why separate validation from types?**  
A: Runtime validation (Zod) serves a different purpose than compile-time types.
Keeping them separate makes the codebase more maintainable.

**Q: Can I use domain entities in validation schemas?**  
A: No. Validation schemas should be independent. Domain entities may have
additional computed properties or methods.

**Q: Where do enums go?**  
A: In `types/` - they're static definitions.

**Q: What about shared validation utilities?**  
A: In `validation/base.ts` and exported via `validation/index.ts`.

**Q: Can interfaces reference validation types?**  
A: Yes! Interfaces reference both validation (inputs) and types (outputs).

**Q: I have a type that doesn't match any pattern. Where does it go?**  
A: If it's architectural (shared across modules, defines boundaries), put it in
contracts. If it's implementation-specific, keep it local.

## Quick Reference

| Type Category        | Location                                            | Pattern           |
| -------------------- | --------------------------------------------------- | ----------------- |
| Domain Entity        | `contracts/types/domain/entities/`                  | `Domain*`         |
| Service Interface    | `contracts/interfaces/{layer}/services/`            | `*Service`        |
| Repository Interface | `contracts/interfaces/infrastructure/repositories/` | `*Repository`     |
| DTO                  | `contracts/validation/`                             | `*DTO`            |
| Hook Return Type     | `contracts/types/presentation/ui/hooks.ts`          | `Use*Return`      |
| Component Props      | In component file                                   | `*Props`          |
| Style Variants       | In style file                                       | `*Variants`       |
| Local Helper         | In implementation file                              | `Internal*`, `_*` |
