// =======
// STATE MANAGEMENT PATTERNS
// =======

/**
 * Action type for state management reducer pattern
 */
export type Action<T> =
  | { type: 'SET'; revealui: T }
  | { type: 'RESET' }
  | { type: 'UPDATE'; revealui: Partial<T> }
  | { type: 'CLEAR' };

/**
 * Loading State Pattern - Re-exported from @revealui/dev/transform for consistency
 * @deprecated Use LoadingState from @revealui/dev/transform or @/features/transform/services directly
 */
export type { LoadingState } from '@revealui/dev/transform';

/**
 * Async Result Pattern with better error handling
 */
export type AsyncResult<T, E = Error> =
  | { status: 'pending' }
  | { status: 'fulfilled'; data: T }
  | { status: 'rejected'; error: E; retry?: () => void };

import type { ApiMetadata } from './api-metadata';

/**
 * API Response Pattern with improved error handling
 */
export type ApiResponse<T> =
  | { status: 'success'; data: T; meta?: ApiMetadata }
  | { status: 'error'; error: string; code?: number; details?: unknown };

/**
 * Enhanced state machine pattern with events
 */
export type StateMachine<T, E> =
  | { state: 'idle' }
  | { state: 'loading' }
  | { state: 'success'; data: T }
  | { state: 'error'; error: E; retry?: () => void };

/**
 * Event-driven state machine with improved event types
 */
export type StateEvent<T, E> =
  | { type: 'START' }
  | { type: 'SUCCESS'; data: T }
  | { type: 'ERROR'; error: E }
  | { type: 'RESET' }
  | { type: 'RETRY' };

/**
 * Enhanced discriminated union for pagination
 */
export type PaginationState<T> =
  | { status: 'idle' }
  | { status: 'loading'; page: number }
  | { status: 'success'; data: T[]; page: number; hasMore: boolean }
  | { status: 'error'; error: Error; page: number; retry?: () => void };

/**
 * Enhanced discriminated union for network requests
 */
export type NetworkState<T> =
  | { status: 'idle' }
  | { status: 'loading'; requestId: string }
  | { status: 'success'; data: T; requestId: string }
  | { status: 'error'; error: Error; requestId: string; retry?: () => void };
