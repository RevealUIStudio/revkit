// ====================================================================
// FORM COMPONENT TYPES
// ====================================================================
// Types for form-related presentation components

import type { FormFieldBlock } from '@revealui/content-plugins/forms';

/**
 * Text field component props
 */
export interface TextFieldProps {
  name: string;
  label?: string;
  required?: boolean;
  width?: string;
}

/**
 * Number field component props
 */
export interface NumberFieldProps {
  name: string;
  label?: string;
  required?: boolean;
  width?: string;
}

/**
 * Form block component props
 */
export interface FormBlockProps {
  blockName?: string;
  blockType?: string;
  enableIntro?: boolean;
  form: {
    id: string;
    fields: FormFieldBlock[];
    [key: string]: unknown;
  };
  introContent?: unknown;
}
