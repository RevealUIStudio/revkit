/**
 * Feature Flag Types
 *
 * Type definitions for feature flags system.
 */

/**
 * Feature flag configuration
 */
export interface FeatureFlag {
  name: string;
  description?: string;
  enabled: boolean;
  rolloutPercentage?: number; // 0-100
  targetUsers?: string[];
  targetGroups?: string[];
  startDate?: Date;
  endDate?: Date;
  dependencies?: string[];
}

/**
 * Record of feature flags keyed by flag name
 */
export type FeatureFlagRecord = Record<string, FeatureFlag>;

/**
 * Provider function that returns feature flags
 */
export type FeatureFlagsProvider = () => FeatureFlagRecord;
