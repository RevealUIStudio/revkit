// ====================================================================
// POST APPLICATION PRESENTATION TYPES
// ====================================================================

// Lexical editor content type
export type LexicalContent = {
  root: {
    children: unknown[];
    direction: string | null;
    format: string;
    indent: number;
    type: string;
    version: number;
  };
};

export interface Post {
  id: string;
  title: string;
  slug: string;
  content: LexicalContent;
  excerpt?: string;
  authorId: string;
  status: 'draft' | 'published' | 'archived';
  publishedAt?: string;
  featuredImage?: string;
  categories?: string[];
  tags?: string[];
  meta?: {
    title?: string;
    description?: string;
    image?: string;
  };
  viewCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePostData {
  title: string;
  slug: string;
  content: LexicalContent;
  excerpt?: string;
  authorId: string;
  status?: 'draft' | 'published';
  featuredImage?: string;
  categories?: string[];
  tags?: string[];
}

export interface UpdatePostData {
  title?: string;
  slug?: string;
  content?: LexicalContent;
  excerpt?: string;
  status?: 'draft' | 'published' | 'archived';
  featuredImage?: string;
  categories?: string[];
  tags?: string[];
  meta?: {
    title?: string;
    description?: string;
    image?: string;
  };
}

export interface GetPostsOptions {
  limit?: number;
  page?: number;
  status?: 'draft' | 'published' | 'archived';
  authorId?: string;
  categoryIds?: string[];
  tagIds?: string[];
  search?: string;
  sort?: string;
}

export interface PostsResult {
  posts: Post[];
  totalCount: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface PostStatistics {
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  archivedPosts: number;
  postsByCategory: Record<string, number>;
  recentPosts: Post[];
}
