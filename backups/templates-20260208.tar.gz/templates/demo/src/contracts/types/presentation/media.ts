// ====================================================================
// MEDIA COMPONENT TYPES
// ====================================================================
// Types for media-related presentation components

import type { Media as RevealUIMedia } from '@revealui/infrastructure/cms/db/reveal-types';
import type { ReactNode } from 'react';

/**
 * Video player component props
 */
export interface VideoPlayerProps {
  src: string;
  title?: string;
  className?: string;
}

/**
 * Simple caption component props
 */
export interface SimpleCaptionProps {
  caption?: string;
  className?: string;
}

/**
 * RevealUI media gallery component props
 */
export interface RevealUIMediaGalleryProps {
  items: Array<{
    id: string;
    url?: string;
    alt?: string;
    filename?: string;
    mimeType?: string;
  }>;
  className?: string;
}

/**
 * Media with caption component props
 */
export interface MediaWithCaptionProps {
  media: RevealUIMedia | string;
  caption?: string;
  className?: string;
}

/**
 * Media grid component props
 */
export interface MediaGridProps {
  items: RevealUIMedia[];
  className?: string;
  columns?: number;
}

/**
 * Media display component props
 */
export interface MediaDisplayProps {
  src: string;
  alt?: string;
  width?: number;
  height?: number;
  priority?: boolean;
  className?: string;
}

/**
 * Audio player component props
 */
export interface AudioPlayerProps {
  src: string;
  title?: string;
  className?: string;
}
