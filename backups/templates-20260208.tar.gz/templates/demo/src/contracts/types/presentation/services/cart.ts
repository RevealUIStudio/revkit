// =======
// PRESENTATION SERVICE TYPES - CART
// =======
// Types specific to cart presentation services

/**
 * User interface for cart operations
 */
export interface CartUser {
  id: string;
  role?: string;
}
