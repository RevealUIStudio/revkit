/**
 * Theme Type Definitions
 *
 * Type-safe design system configuration
 */

/**
 * Basic theme type for light/dark/auto modes
 */
export type Theme = 'light' | 'dark' | 'auto';

export interface ColorToken {
  oklch: string; // OKLCH color space values
  hex: string; // Hex fallback
  name: string; // Human-readable name
}

export interface FontToken {
  family: string;
  weight: {
    [key: string]: string;
  };
}

export interface DesignTokens {
  // Brand identity
  brand: {
    name: string;
    tagline: string;
    logo?: string;
    icon?: string;
  };

  // Color system
  colors: {
    primary: ColorToken;
    secondary: ColorToken;
    accent: ColorToken;
    success: ColorToken;
    warning: ColorToken;
    error: ColorToken;
    info: ColorToken;
    neutral: {
      light: {
        bg: string;
        text: string;
        border: string;
      };
      dark: {
        bg: string;
        text: string;
        border: string;
      };
    };
  };

  // Typography
  typography: {
    fonts: {
      heading: FontToken;
      body: FontToken;
      display: FontToken;
      mono: FontToken;
    };
    sizes: {
      [key: string]: string;
    };
    lineHeight: {
      tight: string;
      normal: string;
      relaxed: string;
    };
    letterSpacing: {
      tight: string;
      normal: string;
      wide: string;
      wider: string;
      widest: string;
    };
  };

  // Spacing scale
  spacing: {
    base: string;
    scale: {
      [key: number]: string;
    };
  };

  // Border radius
  radius: {
    [key: string]: string;
  };

  // Shadows
  shadows: {
    [key: string]: string;
  };

  // Transitions
  transitions: {
    duration: {
      fast: string;
      base: string;
      slow: string;
      slower: string;
    };
    timing: {
      ease: string;
      easeIn: string;
      easeOut: string;
      easeInOut: string;
    };
  };

  // Breakpoints
  breakpoints: {
    [key: string]: string;
  };

  // Z-index scale
  zIndex: {
    [key: string]: number;
  };
}

/**
 * Theme configuration for both frontend and admin
 */
export interface ThemeConfig {
  tokens: DesignTokens;
  mode: 'light' | 'dark' | 'auto';
  customCSS?: string;
}
