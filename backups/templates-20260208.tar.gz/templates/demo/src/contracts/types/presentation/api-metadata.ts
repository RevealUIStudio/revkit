// ====================================================================
// API RESPONSE METADATA TYPES
// ====================================================================
// Typed metadata structures for API responses
// Replaces Record<string, unknown> with specific interfaces

/**
 * Base API response metadata
 */
export interface BaseApiMetadata {
  /** Request ID for tracking */
  requestId?: string;
  /** Response timestamp */
  timestamp?: Date;
  /** Processing duration in milliseconds */
  duration?: number;
  /** API version */
  version?: string;
}

/**
 * Pagination metadata
 */
export interface PaginationApiMetadata extends BaseApiMetadata {
  /** Current page number (1-indexed) */
  page: number;
  /** Number of items per page */
  limit: number;
  /** Total number of items */
  total: number;
  /** Total number of pages */
  totalPages: number;
  /** Whether there is a next page */
  hasNext: boolean;
  /** Whether there is a previous page */
  hasPrev: boolean;
}

/**
 * Cache metadata
 */
export interface CacheApiMetadata extends BaseApiMetadata {
  /** Cache status */
  cacheStatus: 'hit' | 'miss' | 'bypass' | 'stale';
  /** Cache key used */
  cacheKey?: string;
  /** Cache TTL in seconds */
  cacheTtl?: number;
  /** Cache age in seconds */
  cacheAge?: number;
}

/**
 * Rate limiting metadata
 */
export interface RateLimitApiMetadata extends BaseApiMetadata {
  /** Remaining requests in current window */
  rateLimitRemaining?: number;
  /** Total requests allowed in window */
  rateLimitLimit?: number;
  /** Time when rate limit window resets */
  rateLimitReset?: Date;
}

/**
 * Performance metadata
 */
export interface PerformanceApiMetadata extends BaseApiMetadata {
  /** Database query time in milliseconds */
  dbQueryTime?: number;
  /** External API call time in milliseconds */
  externalApiTime?: number;
  /** Cache lookup time in milliseconds */
  cacheTime?: number;
  /** Total processing time breakdown */
  breakdown?: {
    [component: string]: number;
  };
}

/**
 * Union type for all API metadata types
 */
export type ApiMetadata =
  | BaseApiMetadata
  | PaginationApiMetadata
  | CacheApiMetadata
  | RateLimitApiMetadata
  | PerformanceApiMetadata;

/**
 * Type guard to check if metadata is PaginationApiMetadata
 */
export function isPaginationApiMetadata(metadata: ApiMetadata): metadata is PaginationApiMetadata {
  return 'page' in metadata && 'limit' in metadata && 'total' in metadata;
}

/**
 * Type guard to check if metadata is CacheApiMetadata
 */
export function isCacheApiMetadata(metadata: ApiMetadata): metadata is CacheApiMetadata {
  return 'cacheStatus' in metadata;
}

/**
 * Type guard to check if metadata is RateLimitApiMetadata
 */
export function isRateLimitApiMetadata(metadata: ApiMetadata): metadata is RateLimitApiMetadata {
  return 'rateLimitRemaining' in metadata || 'rateLimitLimit' in metadata;
}

/**
 * Type guard to check if metadata is PerformanceApiMetadata
 */
export function isPerformanceApiMetadata(
  metadata: ApiMetadata
): metadata is PerformanceApiMetadata {
  return 'dbQueryTime' in metadata || 'externalApiTime' in metadata || 'breakdown' in metadata;
}
