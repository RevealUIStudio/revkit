// =======
// AUTH STATE TYPES
// =======

/**
 * Enhanced discriminated union for authentication
 */
export type AuthState =
  | { status: 'unauthenticated' }
  | { status: 'authenticating' }
  | {
      status: 'authenticated';
      user: { id: string; email: string; name: string };
    }
  | { status: 'error'; error: Error; retry?: () => void };
