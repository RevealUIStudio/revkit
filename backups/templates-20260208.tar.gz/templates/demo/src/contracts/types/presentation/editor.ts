/**
 * Lexical Editor State
 * Type definition for Lexical rich text editor state
 */
export interface LexicalEditorState {
  root: {
    type: string;
    children: LexicalNode[];
    direction: 'ltr' | 'rtl' | null;
    format: 'left' | 'start' | 'center' | 'right' | 'end' | 'justify' | '';
    indent: number;
    version: number;
  };
  [key: string]: unknown;
}

/**
 * Lexical Node
 * Individual node within the editor state
 */
export interface LexicalNode {
  type: string;
  version: number;
  [key: string]: unknown;
}

/**
 * Serialized Editor State
 * Alternative name for LexicalEditorState
 */
export type SerializedEditorState = LexicalEditorState;

/**
 * Rich Text Content
 * Union type for different rich text formats
 */
export type RichTextContent = LexicalEditorState | string;

/**
 * Editor Node Types
 * Common node types used in the editor
 */
export type EditorNodeType =
  | 'paragraph'
  | 'heading'
  | 'list'
  | 'listitem'
  | 'quote'
  | 'code'
  | 'link'
  | 'text';
