import type { DomainLogger, IUserRepository } from '@/contracts';

// ====================================================================
// USER APPLICATION PRESENTATION TYPES
// ====================================================================

export interface GetUsersOptions {
  limit?: number;
  page?: number;
  role?: string;
  status?: string;
  search?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface UserApplicationServiceContext {
  userRepository: IUserRepository;
  logger: DomainLogger;
  currentUserId?: string;
  role?: string;
  permissions?: string[];
}

export interface UsersResult {
  users: Array<{
    id: string;
    name?: string;
    email: string;
    role: string;
    status?: string;
    createdAt: string;
    updatedAt: string;
  }>;
  totalCount: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface UserStatistics {
  totalUsers: number;
  activeUsers: number;
  inactiveUsers: number;
  verifiedUsers: number;
  usersByRole: Record<string, number>;
  recentUsers: Array<{
    id: string;
    name?: string;
    email: string;
    createdAt: string;
  }>;
}
