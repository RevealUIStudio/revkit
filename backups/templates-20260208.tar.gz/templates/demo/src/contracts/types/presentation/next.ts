// ====================================================================
// NEXT.JS TYPES
// ====================================================================
// Type definitions for Next.js pages and API routes

/**
 * Page props with params and searchParams
 */
export interface PageProps<
  TParams extends Record<string, string | string[]> = Record<string, string | string[]>,
  TSearchParams extends Record<string, string | string[] | undefined> = Record<
    string,
    string | string[] | undefined
  >,
> {
  params: Promise<TParams>;
  searchParams: Promise<TSearchParams>;
}

/**
 * Slug page arguments
 */
export interface SlugPageArgs {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

/**
 * Dynamic route page arguments
 */
export interface DynamicPageArgs {
  params: Promise<Record<string, string>>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

/**
 * Page number arguments
 */
export interface PageNumberArgs {
  params: Promise<{ pageNumber: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}
