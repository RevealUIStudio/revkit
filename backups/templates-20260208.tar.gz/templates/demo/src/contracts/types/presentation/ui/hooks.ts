// =======
// UI HOOK TYPES
// =======
// Consolidated UI hook interfaces and return types
// Hook-related types for React components

import type { AuthSession, LoginCredentials } from './auth';

type User = {
  id: string;
  email?: string;
  role?: string;
  [key: string]: unknown;
};

/**
 * User activity event interface
 */
export interface UserActivityEvent {
  id: string;
  userId: string;
  type: string;
  description: string;
  // Using Record<string, unknown> because user activity event metadata structure varies by event type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because user activity event metadata structure varies by event type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  timestamp: string;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * User profile interface for hooks
 */
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  bio?: string;
  avatar?: string;
  socialLinks?: Record<string, string>;
  // Using Record<string, unknown> because user preferences structure varies by user type and cannot be strictly typed
  preferences?: /* Using Record<string, unknown> because user preferences structure varies by user type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

/**
 * User authentication state interface
 */
export interface UserAuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
}

/**
 * User authentication actions interface
 */
export interface UserAuthActions {
  login: (email: string, password: string) => Promise<void>;
  register: (userData: {
    email: string;
    password: string;
    name: string;
    role?: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (profile: Partial<UserProfile>) => Promise<void>;
}

/**
 * User permissions state interface
 */
export interface UserPermissionsState {
  permissions: string[];
  roles: string[];
  isLoading: boolean;
  error: string | null;
}

/**
 * User profile state interface
 */
export interface UserProfileState {
  profile: UserProfile | null;
  isLoading: boolean;
  error: string | null;
}

/**
 * User activity state interface
 */
export interface UserActivityState {
  activities: unknown[];
  isLoading: boolean;
  error: string | null;
  isTracking: boolean;
}

/**
 * UseUserAuth hook options interface
 */
export interface UseUserAuthOptions {
  autoCheck?: boolean;
  checkInterval?: number;
  onLogin?: (session: AuthSession) => void;
  onLogout?: () => void;
  onError?: (error: string) => void;
}

/**
 * UseUserAuth hook return interface
 */
export interface UseUserAuthReturn {
  // Authentication state
  user: User | null;
  session: AuthSession | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Authentication actions
  login: (credentials: LoginCredentials) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: unknown) => Promise<boolean>;
  refreshSession: () => Promise<void>;

  // Session management
  checkAuth: () => Promise<void>;
  clearError: () => void;

  // State indicators
  isLoggingIn: boolean;
  isLoggingOut: boolean;
  isRegistering: boolean;
  lastAuthCheck: Date | null;
}

/**
 * UseUserActivity hook options interface
 */
export interface UseUserActivityOptions {
  user: User | null;
  autoTrack?: boolean;
  trackPageViews?: boolean;
  trackClicks?: boolean;
  trackScroll?: boolean;
  trackFormInteractions?: boolean;
  debounceMs?: number;
  maxEvents?: number;
  onEvent?: (event: UserActivityEvent) => void;
}

/**
 * UseUserActivity hook return interface
 */
export interface UseUserActivityReturn {
  // Activity state
  events: UserActivityEvent[];
  isLoading: boolean;
  error: string | null;

  // Activity actions
  trackEvent: (
    type: UserActivityEvent['type'],
    description: string,
    // Using Record<string, unknown> because user activity event metadata structure varies by event type and cannot be strictly typed
    metadata?: /* Using Record<string, unknown> because user activity event metadata structure varies by event type and cannot be strictly typed */ Record<
      string,
      unknown
    >
  ) => void;
  trackPageView: (page: string) => void;
  trackClick: (element: string, context?: string) => void;
  trackFormInteraction: (formName: string, action: 'focus' | 'blur' | 'submit' | 'error') => void;

  // Activity management
  clearEvents: () => void;
  exportEvents: () => UserActivityEvent[];

  // Analytics
  totalEvents: number;
  eventsByType: Record<string, number>;
  recentActivity: UserActivityEvent[];

  // State indicators
  isTracking: boolean;
  lastActivity: Date | null;
}
