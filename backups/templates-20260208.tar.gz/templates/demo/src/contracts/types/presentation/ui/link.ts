export type LinkAppearances = 'default' | 'outline';

export const LINK_APPEARANCE_VALUES = ['default', 'outline'] as const;
