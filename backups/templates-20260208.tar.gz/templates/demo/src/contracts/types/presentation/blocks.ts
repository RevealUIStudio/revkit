// Block Component Types
// This file contains types for block components used in the CMS

import type {
  Media as RevealUIMedia,
  Post as RevealUIPost,
} from '@revealui/infrastructure/cms/db/revealui-types';
import type { LexicalEditorState } from './editor';

export type ViewMode = 'grid' | 'list' | 'filesystem';

// Lexical Editor State type for RevealUI CMS
export type DefaultTypedEditorState = LexicalEditorState;

export type Block = {
  id?: string | null;
  blockType?: string;
  [key: string]: unknown;
};

export type Props = {
  className?: string;
  [key: string]: unknown;
};

export type SlugComponentProps = {
  value: string;
  onChange: (value: string) => void;
  className?: string;
};

export type PrefixBlockProps = {
  prefix?: number | { id: number; name: string };
  // Using Record<string, unknown> because block description structure varies by block type and cannot be strictly typed
  description?: /* Using Record<string, unknown> because block description structure varies by block type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  displayOptions?: {
    showGallery?: boolean;
    defaultView?: ViewMode;
  };
};

export type PrefixBlockClientProps = {
  media: Media[];
  className?: string;
  displayOptions?: {
    showGallery?: boolean;
    defaultView?: ViewMode;
  };
};

export type RelatedPostsProps = {
  className?: string;
  docs?: Post[];
  introContent?: LexicalEditorState;
};

export type MenuItemType = 'link' | 'page' | 'post' | 'category' | 'custom';

export type MenuItem = {
  type: MenuItemType;
  label: string;
  link?: string;
  page?: string;
  post?: string;
  category?: string;
  customUrl?: string;
  newTab?: boolean;
  order?: number;
};

export type MediaBlockProps = {
  media: Media[];
  className?: string;
  enableGutter?: boolean;
  disableInnerContainer?: boolean;
};

export type CodeBlockProps = {
  code: string;
  language?: string;
  blockType: 'code';
  className?: string;
};

// Code block specific types
export type CodeLanguage =
  | 'typescript'
  | 'javascript'
  | 'css'
  | 'html'
  | 'json'
  | 'markdown'
  | 'python'
  | 'ruby'
  | 'php'
  | 'java'
  | 'csharp'
  | 'go'
  | 'rust'
  | 'sql'
  | 'shell'
  | 'yaml'
  | 'plaintext';

export type CodeProps = {
  code: string;
  language?: string | undefined;
};

export type CodeBlockPropsExtended = CodeBlockProps & {
  className?: string;
};

export type BannerBlockProps = {
  title: string;
  content?: string;
  backgroundImage?: string;
  className?: string;
};

// Removed duplicate MediaBlockProps - keeping the first definition

export type MediaDisplayOptions = {
  defaultView?: ViewMode;
  showCaption?: boolean;
};

export type MediaGalleryProps = {
  media: Media[];
  caption?: LexicalEditorState;
  displayOptions?: {
    showGallery?: boolean;
    defaultView?: ViewMode;
  };
  className?: string;
  defaultView?: ViewMode;
};

export type MediaBlockPropsExtended = MediaBlockProps & {
  breakout?: boolean;
  captionClassName?: string;
  className?: string;
  enableGutter?: boolean;
  imgClassName?: string;
  staticImage?: {
    src: string;
    width: number;
    height: number;
    blurDataURL?: string;
  };
  disableInnerContainer?: boolean;
  displayOptions?: {
    showGallery?: boolean;
    defaultView?: ViewMode;
  };
};

export type DeletePostOperationInput = {
  id: string;
};

export type UserRole = 'admin' | 'editor' | 'user';

export type LinkAppearances = 'default' | 'outline';

export type LinkType = (options?: {
  appearances?: LinkAppearances[] | false;
  disableLabel?: boolean;
  // Using Record<string, unknown> because link overrides structure varies by link type and cannot be strictly typed
  overrides?: /* Using Record<string, unknown> because link overrides structure varies by link type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}) => {
  name: string;
  type: string;
  required?: boolean;
  [key: string]: unknown;
};

export type LinkGroupType = (options?: {
  appearances?: LinkAppearances[] | false;
  // Using Record<string, unknown> because link group overrides structure varies by link group type and cannot be strictly typed
  overrides?: /* Using Record<string, unknown> because link group overrides structure varies by link group type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}) => {
  name: string;
  type: string;
  fields: unknown[];
  [key: string]: unknown;
};

// Removed duplicate SlugComponentProps - keeping the first definition

export type Overrides = {
  // Using Record<string, unknown> because slug overrides structure varies by field type and cannot be strictly typed
  slugOverrides?: /* Using Record<string, unknown> because slug overrides structure varies by field type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  // Using Record<string, unknown> because checkbox overrides structure varies by field type and cannot be strictly typed
  checkboxOverrides?: /* Using Record<string, unknown> because checkbox overrides structure varies by field type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
};

export type Slug = (
  fieldToUse?: string,
  overrides?: Overrides
) => [
  { name: string; type: string; [key: string]: unknown },
  { name: string; type: string; [key: string]: unknown },
];

export type CMSLinkType = {
  appearance?: 'inline' | 'default' | 'outline' | 'ghost' | 'destructive';
  children?: React.ReactNode;
  className?: string;
  label?: string | null;
  newTab?: boolean | null;
  reference?: {
    relationTo: 'pages' | 'posts';
    value: Post | string | number;
  } | null;
  size?: 'default' | 'sm' | 'lg' | 'icon' | null;
  type?: 'custom' | 'reference' | null;
  url?: string | null;
};

// Removed duplicate MediaBlockProps - keeping the first definition

// Archive Block Types
export type PostCard = {
  id: string;
  title: string;
  description?: DefaultTypedEditorState;
  image?: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
  };
  href: string;
};

// Removed duplicate BannerBlockProps - keeping the first definition
