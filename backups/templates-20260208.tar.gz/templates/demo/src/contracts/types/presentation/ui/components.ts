// =======
// UI COMPONENT TYPES
// =======
// Consolidated UI component interfaces from various sources

import type * as React from 'react';

/**
 * Hero component type variants
 */
export type HeroType = 'none' | 'lowImpact' | 'mediumImpact' | 'highImpact' | null | undefined;

/**
 * Common HTML attributes for accessibility
 */
export interface AccessibilityProps {
  'aria-label'?: string;
  'aria-describedby'?: string;
  'aria-labelledby'?: string;
  'aria-hidden'?: boolean;
  'aria-expanded'?: boolean;
  'aria-pressed'?: boolean;
  'aria-selected'?: boolean;
  'aria-checked'?: boolean;
  'aria-required'?: boolean;
  'aria-invalid'?: boolean;
  'aria-disabled'?: boolean;
  role?: string;
  tabIndex?: number;
}

/**
 * Input component props
 */
export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  variant?: 'default' | 'outlined' | 'filled';
  size?: 'sm' | 'md' | 'lg';
}

/**
 * Search bar component props
 */
export interface SearchBarProps extends AccessibilityProps {
  className?: string;
  placeholder?: string;
  autoFocus?: boolean;
  showClearButton?: boolean;
}

/**
 * Search component props
 */
export interface SearchProps extends AccessibilityProps {
  className?: string;
  initialQuery?: string;
  initialResults?: unknown[];
}

/**
 * Search state interface
 */
export interface SearchState {
  results: unknown[];
  query: string;
  isLoading: boolean;
  error?: string;
}

/**
 * Post card component props
 */
export interface PostCardProps extends AccessibilityProps {
  post: unknown;
  className?: string;
  showExcerpt?: boolean;
  showTags?: boolean;
  showCategories?: boolean;
}

/**
 * Post component props
 */
export interface PostProps extends AccessibilityProps {
  post?: unknown;
  title?: string;
  // Using Record<string, unknown> because post description structure varies by post type and cannot be strictly typed
  description?: /* Using Record<string, unknown> because post description structure varies by post type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  // Using Record<string, unknown> because post content structure varies by post type and cannot be strictly typed
  content?: /* Using Record<string, unknown> because post content structure varies by post type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  image?: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
  };
  date?: string;
  author?: string;
  className?: string;
}

/**
 * Page component props
 */
export interface PageProps extends AccessibilityProps {
  page?: unknown;
  title?: string;
  description?: unknown;
  children?: React.ReactNode;
  className?: string;
}

/**
 * Author interface for components
 */
export interface Author {
  id: string;
  name: string;
  email?: string;
  avatar?: string;
  // Using Record<string, unknown> because author bio structure varies by author type and cannot be strictly typed
  bio?: /* Using Record<string, unknown> because author bio structure varies by author type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  image?: {
    src: string;
    alt: string;
    width?: number;
    height?: number;
  };
  href: string;
}

/**
 * Author list component props
 */
export interface AuthorListProps extends AccessibilityProps {
  authors: Author[];
  className?: string;
}

/**
 * Category interface for components
 */
export interface Category {
  id: string;
  title: string;
  slug: string;
  description?: string;
  name?: string;
  href?: string;
}

/**
 * Category list component props
 */
export interface CategoryListProps extends AccessibilityProps {
  categories: Category[];
  className?: string;
  industry?: string;
}

/**
 * Tag interface for components
 */
export interface Tag {
  id: string;
  title: string;
  slug: string;
  label?: string;
  href?: string;
}

/**
 * Tag list component props
 */
export interface TagListProps extends AccessibilityProps {
  tags: Tag[];
  className?: string;
}

/**
 * Pagination component props
 */
export interface PaginationProps extends AccessibilityProps {
  page?: number;
  currentPage?: number;
  totalPages: number;
  baseUrl?: string;
  className?: string;
}

/**
 * Page range component props
 */
export interface PageRangeProps {
  currentPage: number;
  totalPages: number;
  maxVisible?: number;
}

/**
 * Flex container component props
 */
export interface FlexContainerProps extends AccessibilityProps {
  children: React.ReactNode;
  className?: string;
  direction?: 'row' | 'column';
  justify?: 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';
  align?: 'start' | 'center' | 'end' | 'stretch';
  wrap?: boolean;
  gap?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12;
  as?: 'div' | 'section' | 'article' | 'main' | 'aside' | 'header' | 'footer';
}

/**
 * User profile component props
 */
export interface UserProfileProps extends AccessibilityProps {
  user: unknown;
  className?: string;
  editable?: boolean;
  onUpdate?: (userData: unknown) => Promise<void>;
}

/**
 * User form component props
 */
export interface UserFormProps extends AccessibilityProps {
  mode: 'create' | 'update';
  initialData?: {
    id?: string;
    email?: string;
    name?: string;
    role?: string;
    phone?: string;
    dateOfBirth?: string;
  };
  className?: string;
}

/**
 * User form state interface
 */
export interface UserFormState {
  success: boolean;
  message: string;
  errors?: string[];
  user?: unknown;
}

/**
 * Product card component props
 */
export interface ProductCardProps extends AccessibilityProps {
  product: unknown;
  className?: string;
  priority?: boolean;
  cartId?: string;
  userId?: string;
}

/**
 * Product grid component props
 */
export interface ProductGridProps extends AccessibilityProps {
  products: unknown[];
  className?: string;
  cartId?: string;
  userId?: string;
}

/**
 * Product filters component props
 */
export interface ProductFiltersProps extends AccessibilityProps {
  categories: unknown[];
  searchAction: (formData: FormData) => void;
  clearAction: () => void;
  className?: string;
  currentFilters?: Record<string, string>;
}

/**
 * Order summary component props
 */
export interface OrderSummaryProps extends AccessibilityProps {
  order: unknown;
  className?: string;
  showActions?: boolean;
  onCancel?: (orderId: string) => void;
  onRefund?: (orderId: string) => void;
}

/**
 * Label component props
 */
export interface LabelProps {
  children?: React.ReactNode;
  className?: string;
  required?: boolean;
}

/**
 * Progress component props
 */
export interface ProgressProps {
  value: number;
  max?: number;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'success' | 'warning' | 'error';
  showValue?: boolean;
  className?: string;
}
