// =======
// PRESENTATION SERVICE TYPES - ORDER
// =======
// Types specific to order presentation services

/**
 * User interface for order operations
 */
export interface OrderUser {
  id: string;
  email: string;
}

/**
 * Create order data
 */
export interface CreateOrderData {
  shipping?: {
    address?: {
      line1?: string;
      line2?: string;
      city?: string;
      state?: string;
      zip?: string;
      country?: string;
    };
  };
  billing?: {
    address?: {
      line1?: string;
      line2?: string;
      city?: string;
      state?: string;
      zip?: string;
      country?: string;
    };
  };
}
