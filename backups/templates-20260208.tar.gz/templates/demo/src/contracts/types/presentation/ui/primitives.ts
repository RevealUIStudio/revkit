// =======
// UI PRIMITIVES
// =======
// Foundational UI types and component primitives

/**
 * Card footer component props
 */
export interface CardFooterProps {
  className?: string;
  children?: React.ReactNode;
}

/**
 * UI theme mode type definition
 */
export type UIThemeMode = 'light' | 'dark' | 'system';

/**
 * Component variant type
 */
export type ComponentVariant =
  | 'default'
  | 'primary'
  | 'secondary'
  | 'success'
  | 'warning'
  | 'error';

/**
 * Component size type
 */
export type ComponentSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

/**
 * Layout direction type
 */
export type LayoutDirection = 'horizontal' | 'vertical';

/**
 * Alignment type
 */
export type Alignment = 'start' | 'center' | 'end' | 'stretch' | 'baseline';

/**
 * Justify content type
 */
export type JustifyContent = 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';

/**
 * Responsive breakpoint type
 */
export type Breakpoint = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
