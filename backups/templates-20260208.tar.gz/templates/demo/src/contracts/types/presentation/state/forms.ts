// =======
// FORM STATE TYPES
// =======

/**
 * Form State Pattern with validation
 */
export type FormState<T> =
  | { status: 'idle' }
  | { status: 'editing'; data: T; errors?: Record<string, string[]> }
  | { status: 'submitting'; data: T }
  | { status: 'success'; data: T }
  | {
      status: 'error';
      data: T;
      error: Error;
      errors?: Record<string, string[]>;
    };
