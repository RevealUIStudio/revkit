// ====================================================================
// PREVIEW TYPES
// ====================================================================
// Types for Next.js draft/preview mode

/**
 * Preview user interface
 */
export interface PreviewUser {
  id: string;
  email: string;
  name?: string;
  role?: string;
}

/**
 * Preview token revealui
 */
export interface PreviewToken {
  user: PreviewUser;
  exp: number;
  iat: number;
}
