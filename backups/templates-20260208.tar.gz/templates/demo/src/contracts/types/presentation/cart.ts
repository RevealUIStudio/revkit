// ====================================================================
// CART PRESENTATION TYPES
// ====================================================================

export interface ProductData {
  name: string;
  description?: string;
  sku?: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  images?: string[];
  categories?: string[];
}

export interface CustomizationData {
  type: 'text' | 'image' | 'color' | 'size';
  label: string;
  value: string;
  price?: number;
}

export interface Address {
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export interface CartItem {
  productId: string;
  variantId?: string;
  quantity: number;
  price: number;
  compareAtPrice?: number;
  lineTotal: number;
  productData?: ProductData;
  customizations?: CustomizationData[];
}

export interface CartTotals {
  subtotal: number;
  discount: number;
  tax: number;
  shipping: number;
  total: number;
}

export interface Cart {
  id: string;
  userId?: string;
  sessionId?: string;
  status: 'active' | 'abandoned' | 'converted' | 'expired';
  currency: string;
  items: CartItem[];
  totals: CartTotals;
  appliedDiscounts?: Array<{
    code: string;
    type: 'percentage' | 'fixed' | 'free_shipping';
    value: number;
    appliedAt: string;
  }>;
  shippingAddress?: Address;
  billingAddress?: Address;
  shippingMethod?: string;
  // Using Record<string, unknown> because cart metadata structure varies by cart type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because cart metadata structure varies by cart type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  expiresAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateCartData {
  userId?: string;
  sessionId?: string;
  items?: CartItem[];
  currency?: string;
}

export interface UpdateCartData {
  items?: CartItem[];
  shippingAddress?: Address;
  billingAddress?: Address;
  shippingMethod?: string;
  appliedDiscounts?: Array<{
    code: string;
    type: 'percentage' | 'fixed' | 'free_shipping';
    value: number;
  }>;
}

export interface CartSummary {
  itemCount: number;
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  currency: string;
}

export interface AddToCartData {
  productId: string;
  variantId?: string;
  quantity: number;
  customizations?: CustomizationData[];
}

export interface UpdateCartItemData {
  itemId: string;
  quantity?: number;
  customizations?: CustomizationData[];
}

export interface CouponData {
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minimumAmount?: number;
  maximumDiscount?: number;
  expiresAt?: string;
  usageLimit?: number;
  usedCount?: number;
}

// RevealUI Content Engine cart response type (before transformation to our Cart type)
export interface RevealUICartResponse {
  id: string;
  userId?: string;
  sessionId?: string;
  status: string;
  currency: string;
  items: CartItem[];
  totals: CartTotals;
  appliedDiscounts?: Array<{
    code: string;
    type: string;
    value: number;
    appliedAt: string;
  }>;
  shippingAddress?: Address;
  billingAddress?: Address;
  shippingMethod?: string;
  // Using Record<string, unknown> because cart metadata structure varies by cart type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because cart metadata structure varies by cart type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  expiresAt?: string;
  createdAt: string;
  updatedAt: string;
}
