// =======
// AUTHENTICATION TYPES
// =======
// Consolidated authentication interfaces and types
// This file consolidates the best patterns from interfaces/auth.ts and interfaces/features/auth/auth.ts

import type { ErrorDetails } from '@/contracts';

type User = {
  id: string;
  email?: string;
  role?: string;
  [key: string]: unknown;
};

type UserDTO = User;

/**
 * Authentication state for React components
 */
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isError: boolean;
  error: string | null;
}

/**
 * Login credentials
 */
export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

/**
 * User registration data
 */
export interface RegisterData {
  email: string;
  password: string;
  name: string;
  confirmPassword: string;
  role?: string;
  acceptTerms: boolean;
  marketingConsent?: boolean;
}

/**
 * Options for useAuth hook
 */
export interface UseAuthOptions {
  // RevealUI Content Engine integration
  // Using Record<string, unknown> because RevealUI Content Engine RevealUI type structure varies and cannot be strictly typed here
  revealui?: Record<string, unknown>; // RevealUI type

  // Session management
  sessionKey?: string;
  autoRefresh?: boolean;
  refreshInterval?: number;

  // Security
  csrfProtection?: boolean;
  rateLimit?: boolean;

  // Callbacks
  onLogin?: (user: User) => void;
  onLogout?: () => void;
  onError?: (error: string) => void;

  // Redirects
  loginRedirect?: string;
  logoutRedirect?: string;
  protectedRoutes?: string[];
}

/**
 * Result from useAuth hook
 */
export interface UseAuthResult {
  // State
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isError: boolean;
  error: string | null;

  // Actions
  login: (credentials: LoginCredentials) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (data: RegisterData) => Promise<boolean>;
  refreshToken: () => Promise<boolean>;
  forgotPassword: (email: string) => Promise<boolean>;
  resetPassword: (token: string, password: string) => Promise<boolean>;
  updateProfile: (data: Partial<User>) => Promise<boolean>;

  // Utilities
  hasPermission: (permission: string) => boolean;
  hasRole: (role: string) => boolean;
  isAdmin: boolean;
  isUser: boolean;
  isGuest: boolean;

  // Session management
  clearSession: () => void;
  getSession: () => User | null;
  setSession: (user: User) => void;
}

/**
 * Authentication context type for React context
 */
export interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string, csrfToken?: string | null) => Promise<AuthResult>;
  logout: () => Promise<AuthResult<void>>;
  register: (email: string, password: string, name?: string, csrfToken?: string | null) => Promise<AuthResult>;
  refreshUser: () => Promise<void>;
  clearError: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

/**
 * Props for AuthProvider component
 */
export interface AuthProviderProps {
  children: React.ReactNode;
  initialUser?: User | null;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

/**
 * Authentication result from API calls
 */
export interface AuthResult<T = UserDTO> {
  user: T;
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  sessionId: string;
}

/**
 * Base authentication state for state management
 */
export interface BaseAuthState {
  isAuthenticated: boolean;
  session: AuthSession | null;
  isLoggingIn: boolean;
  isLoggingOut: boolean;
  isRegistering: boolean;
}

/**
 * Two-factor authentication setup data
 */
export interface TwoFactorSetup {
  secret: string;
  qrCode: string;
  backupCodes: string[];
  method: 'authenticator' | 'sms' | 'email';
}

/**
 * Authentication session data
 */
export interface AuthSession {
  id: string;
  userId: string;
  token: string;
  device: {
    id: string;
    type: string;
    platform: string;
    ip: string | null;
    userAgent: string | null;
  };
  expiresAt: string;
  lastActiveAt: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

/**
 * Password reset request data
 */
export interface ForgotPasswordData {
  email: string;
}

/**
 * Password reset data
 */
export interface ResetPasswordData {
  token: string;
  password: string;
  confirmPassword: string;
}

/**
 * Authentication error types
 */
export enum AuthErrorType {
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  USER_NOT_FOUND = 'USER_NOT_FOUND',
  USER_DISABLED = 'USER_DISABLED',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',
  TOKEN_INVALID = 'TOKEN_INVALID',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',
  NETWORK_ERROR = 'NETWORK_ERROR',
}

/**
 * Authentication error
 */
export interface AuthError {
  type: AuthErrorType;
  message: string;
  details?: ErrorDetails;
}
