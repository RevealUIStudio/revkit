// ====================================================================
// BUTTON UI COMPONENT TYPES
// ====================================================================

export interface ButtonGroupProps {
  children: React.ReactNode;
  className?: string;
  orientation?: 'horizontal' | 'vertical';
  spacing?: 'none' | 'tight' | 'default' | 'loose';
}
