// ====================================================================
// TRANSFORM MAPPER TYPES
// ====================================================================
// Typed mapper function structures
// Provides type-safe mapping interfaces

import type { ServiceResult } from '../../domain/service-results';

/**
 * Basic mapper function
 * Maps input type T to output type U
 */
export type MapperFunction<T, U> = (input: T) => U;

/**
 * Safe mapper function with error handling
 * Returns ServiceResult instead of throwing
 */
export type SafeMapperFunction<T, U> = (input: T) => ServiceResult<U>;

/**
 * Partial mapper function
 * Maps partial input to partial output
 */
export type PartialMapper<T, U> = (input: Partial<T>) => Partial<U>;

/**
 * Mapper with context
 * Includes additional context for mapping operations
 */
export type ContextualMapper<T, U, C = unknown> = (input: T, context: C) => U;

/**
 * Safe contextual mapper
 */
export type SafeContextualMapper<T, U, C = unknown> = (input: T, context: C) => ServiceResult<U>;

/**
 * Field mapper
 * Maps a specific field from input to output
 */
export type FieldMapper<T, U, K extends keyof T> = (
  value: T[K]
) => U[K extends keyof U ? K : never];

/**
 * Conditional mapper
 * Maps based on a condition
 */
export type ConditionalMapper<T, U> = (input: T, condition: (input: T) => boolean) => U | null;

/**
 * Mapper configuration
 */
export interface MapperConfig {
  /** Whether to include undefined fields */
  includeUndefined?: boolean;
  /** Whether to include null fields */
  includeNull?: boolean;
  /** Field mappings */
  fieldMappings?: {
    [key: string]: string | MapperFunction<unknown, unknown>;
  };
  /** Default values for missing fields */
  defaults?: {
    [key: string]: unknown;
  };
}

/**
 * Mapping result with metadata
 */
export interface MappingResult<T> extends ServiceResult<T> {
  /** Mapping duration in milliseconds */
  duration?: number;
  /** Fields mapped */
  fieldsMapped?: string[];
  /** Fields skipped */
  fieldsSkipped?: string[];
  /** Mapping metadata */
  mappingMetadata?: {
    [key: string]: unknown;
  };
}
