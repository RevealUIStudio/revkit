// ====================================================================
// TRANSFORM PIPELINE TYPES
// ====================================================================
// Typed transform pipeline structures
// Provides type-safe transformation interfaces

import type { ServiceResult } from '../../domain/service-results';

/**
 * Basic transformation function
 * Transforms input type T to output type U
 */
export type Transformation<T, U> = (input: T) => U;

/**
 * Safe transformation function with error handling
 * Returns ServiceResult instead of throwing
 */
export type SafeTransformation<T, U> = (input: T) => ServiceResult<U>;

/**
 * Lazy transformation function
 * Returns a function that produces the result when called
 */
export type LazyTransformation<U> = () => U;

/**
 * Batch transformation function
 * Transforms an array of inputs to an array of outputs
 */
export type BatchTransformation<T, U> = (input: T[]) => U[];

/**
 * Transformation context
 * Provides additional context for transformations
 */
export interface TransformationContext {
  /** Transformation name or identifier */
  name?: string;
  /** Additional metadata */
  metadata?: {
    [key: string]: unknown;
  };
  /** Error handling strategy */
  errorStrategy?: 'throw' | 'return-error' | 'skip';
}

/**
 * Pipeline configuration
 */
export interface PipelineConfig {
  /** Whether to stop on first error */
  stopOnError?: boolean;
  /** Maximum number of transformations */
  maxTransformations?: number;
  /** Context for transformations */
  context?: TransformationContext;
}

/**
 * Transformation result with metadata
 */
export interface TransformationResult<T> extends ServiceResult<T> {
  /** Transformation duration in milliseconds */
  duration?: number;
  /** Number of transformations applied */
  transformationsApplied?: number;
  /** Transformation metadata */
  transformationMetadata?: {
    [key: string]: unknown;
  };
}
