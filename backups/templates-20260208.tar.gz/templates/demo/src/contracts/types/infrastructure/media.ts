export interface MediaUploadContext {
  collection: string;
  filename?: string;
  file?: { size?: number; mimetype?: string };
}
