// ====================================================================
// QUERY FILTER TYPES
// ====================================================================
// Typed query filter structures for repositories
// Replaces Record<string, unknown> with specific interfaces

import type { RevealUIEntity } from './extended-revealui';
import type { RevealUIWhere } from './revealui-utils';

/**
 * Base query filter structure
 */
export interface BaseQueryFilter {
  /** Logical AND operator */
  AND?: QueryFilter[];
  /** Logical OR operator */
  OR?: QueryFilter[];
  /** Logical NOT operator */
  NOT?: QueryFilter;
}

/**
 * Field comparison operators
 */
export interface FieldComparisonOperators<T> {
  /** Equals */
  equals?: T;
  /** Not equals */
  not_equals?: T;
  /** In array */
  in?: T[];
  /** Not in array */
  not_in?: T[];
  /** Greater than */
  greater_than?: T;
  /** Greater than or equal */
  greater_than_equal?: T;
  /** Less than */
  less_than?: T;
  /** Less than or equal */
  less_than_equal?: T;
  /** Like (string matching) */
  like?: string;
  /** Contains (for arrays) */
  contains?: T;
}

/**
 * String field filter
 */
export interface StringFieldFilter extends FieldComparisonOperators<string> {
  /** Case-insensitive equals */
  equals_case_insensitive?: string;
  /** Case-insensitive like */
  like_case_insensitive?: string;
}

/**
 * Number field filter
 */
export interface NumberFieldFilter extends FieldComparisonOperators<number> {}

/**
 * Boolean field filter
 */
export interface BooleanFieldFilter {
  equals?: boolean;
}

/**
 * Date field filter
 */
export interface DateFieldFilter extends FieldComparisonOperators<Date | string> {}

/**
 * Array field filter
 */
export interface ArrayFieldFilter<T> {
  contains?: T;
  contains_all?: T[];
  contains_any?: T[];
  equals?: T[];
}

/**
 * Relation field filter
 */
export interface RelationFieldFilter {
  equals?: string;
  not_equals?: string;
  in?: string[];
  not_in?: string[];
  exists?: boolean;
}

/**
 * Union type for all field filters
 */
export type FieldFilter =
  | StringFieldFilter
  | NumberFieldFilter
  | BooleanFieldFilter
  | DateFieldFilter
  | ArrayFieldFilter<unknown>
  | RelationFieldFilter;

/**
 * Query filter structure
 * Can be used for generic repository queries
 */
export interface QueryFilter extends BaseQueryFilter {
  /** Field filters */
  [field: string]: FieldFilter | QueryFilter[] | QueryFilter | unknown;
}

/**
 * Entity-specific query filter
 * Uses RevealUI Content Engine where clause structure for type safety
 */
export type EntityQueryFilter<T extends RevealUIEntity> = RevealUIWhere<T>;

/**
 * Type guard to check if filter is StringFieldFilter
 */
export function isStringFieldFilter(filter: FieldFilter): filter is StringFieldFilter {
  return 'like' in filter || 'equals_case_insensitive' in filter;
}

/**
 * Type guard to check if filter is NumberFieldFilter
 */
export function isNumberFieldFilter(filter: FieldFilter): filter is NumberFieldFilter {
  return 'greater_than' in filter || 'less_than' in filter;
}

/**
 * Type guard to check if filter is BooleanFieldFilter
 */
export function isBooleanFieldFilter(filter: FieldFilter): filter is BooleanFieldFilter {
  return 'equals' in filter && typeof (filter as BooleanFieldFilter).equals === 'boolean';
}

/**
 * Type guard to check if filter is DateFieldFilter
 */
export function isDateFieldFilter(filter: FieldFilter): filter is DateFieldFilter {
  return 'equals' in filter && (filter.equals instanceof Date || typeof filter.equals === 'string');
}

/**
 * Type guard to check if filter is ArrayFieldFilter
 */
export function isArrayFieldFilter(filter: FieldFilter): filter is ArrayFieldFilter<unknown> {
  return 'contains_all' in filter || 'contains_any' in filter;
}

/**
 * Type guard to check if filter is RelationFieldFilter
 */
export function isRelationFieldFilter(filter: FieldFilter): filter is RelationFieldFilter {
  return 'exists' in filter || ('equals' in filter && typeof filter.equals === 'string');
}
