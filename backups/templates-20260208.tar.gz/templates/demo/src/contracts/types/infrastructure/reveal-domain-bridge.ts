// ====================================================================
// REVEALUI-DOMAIN BRIDGE SYSTEM
// ====================================================================
// Maps and connects RevealUI types to domain types
// Creates type-safe transformations between layers
// Establishes relationships: RevealUIEntity → EnhancedEntity → DomainEntity

import type {
  Cart as RevealUICart,
  Category as RevealUICategory,
  Media as RevealUIMedia,
  Menu as RevealUIMenu,
  Order as RevealUIOrder,
  Post as RevealUIPost,
  Product as RevealUIProduct,
  Tag as RevealUITag,
  User as RevealUIUser,
} from '@revealui/infrastructure/cms/db/reveal-types';
import type { DomainCart } from '../domain/entities/cart';
import type { DomainCategory } from '../domain/entities/category';
import type { DomainMedia } from '../domain/entities/media';
import type { DomainMenu } from '../domain/entities/menu';
import type { DomainOrder, OrderStatus } from '../domain/entities/order';
import type { DomainPost, PostStatus } from '../domain/entities/post';
import type { DomainProduct, ProductStatus, ProductType } from '../domain/entities/product';
import type { DomainTag } from '../domain/entities/tag';
import type { DomainUser, UserRole, UserStatus } from '../domain/entities/user';
import type { ExtractRevealUIEntity, RevealUIEntityInput, RevealUIRichText } from './extended-reveal';
import type { RevealUICreateInput, RevealUIRelation, RevealUIUpdateInput } from './reveal-utils';

// ====================================================================
// BRANDED TYPES
// ====================================================================

/**
 * Branded type for RevealUI-derived entities
 * Provides compile-time tracking of entity origin
 */
type RevealUIDerived<T> = T & { readonly __source: 'revealui' };

/**
 * Branded type for domain entities
 * Provides compile-time tracking of entity origin
 */
type DomainDerived<T> = T & { readonly __source: 'domain' };

// ====================================================================
// TYPE MAPPINGS
// ====================================================================

/**
 * Map RevealUI Content Engine Post fields to domain-friendly types
 * Handles rich text extraction and type conversions
 */
export type RevealUIToDomainPostMapper<T extends RevealUIPost> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  title: T['title'];
  slug: string; // Ensure string from potentially null
  content?: string; // Extract from rich text
  excerpt: string;
  status: PostStatus;
  publishedDate?: string;
  meta?: {
    title?: string;
    description?: string;
    keywords?: string;
    image?: string;
  };
  categories?: ExtractRevealUIEntity<T['categories']>[];
  tags?: string[];
  authors?: ExtractRevealUIEntity<T['authors']>[];
  featuredImage?: string;
  views?: number;
  featured?: boolean;
  paywall?: boolean;
};

/**
 * Map RevealUI Content Engine User fields to domain-friendly types
 */
export type RevealUIToDomainUserMapper<T extends RevealUIUser> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  email: T['email'];
  username?: string;
  name?: string;
  role: UserRole;
  status?: UserStatus;
  avatar?: string;
  bio?: string;
  socialMedia?: {
    twitter?: string;
    instagram?: string;
    youtube?: string;
  };
  // Using Record<string, unknown> because user preferences structure varies by user type and cannot be strictly typed
  preferences?: /* Using Record<string, unknown> because user preferences structure varies by user type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
};

/**
 * Map RevealUI Content Engine Product fields to domain-friendly types
 */
export type RevealUIToDomainProductMapper<T extends RevealUIProduct> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  title: T['title'];
  description: string; // Extract from rich text
  slug: string;
  type: ProductType;
  category: string;
  price: {
    amount: number;
    currency: string;
    formatted: string;
    originalAmount?: number;
    isOnSale: boolean;
    saleEndsAt?: string;
    discountPercentage?: number;
  };
  inventory: {
    stock: number;
    reserved: number;
    available: number;
    lowStockThreshold: number;
    isUnlimited: boolean;
  };
  media: {
    images: ExtractRevealUIEntity<T['images']>[];
    videos?: ExtractRevealUIEntity<T['gallery']>[];
    thumbnail: ExtractRevealUIEntity<T['featuredImage']>;
    gallery: ExtractRevealUIEntity<T['gallery']>[];
  };
  variants?: Array<{
    id: string;
    createdAt: string;
    updatedAt: string;
    name: string;
    sku: string;
    // Using Record<string, unknown> because product price structure varies by pricing model and cannot be strictly typed
    price: /* Using Record<string, unknown> because product price structure varies by pricing model and cannot be strictly typed */ Record<
      string,
      unknown
    >;
    // Using Record<string, unknown> because product inventory structure varies by inventory system and cannot be strictly typed
    inventory: /* Using Record<string, unknown> because product inventory structure varies by inventory system and cannot be strictly typed */ Record<
      string,
      unknown
    >;
    attributes: Record<string, string>;
  }>;
  metadata: {
    seo?: {
      title?: string;
      description?: string;
      keywords?: string[];
    };
    // Using Record<string, unknown> because product dimensions structure varies by product type and cannot be strictly typed
    dimensions?: /* Using Record<string, unknown> because product dimensions structure varies by product type and cannot be strictly typed */ Record<
      string,
      unknown
    >;
    // Using Record<string, unknown> because product shipping structure varies by shipping provider and cannot be strictly typed
    shipping?: /* Using Record<string, unknown> because product shipping structure varies by shipping provider and cannot be strictly typed */ Record<
      string,
      unknown
    >;
  };
  status: ProductStatus;
  featured: boolean;
};

/**
 * Map RevealUI Content Engine Cart fields to domain-friendly types
 */
export type RevealUIToDomainCartMapper<T extends RevealUICart> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  userId?: string;
  sessionId?: string;
  items: Array<{
    id: string;
    productId: string;
    product: ExtractRevealUIEntity<T['items'][number]['productId']>;
    variantId?: string;
    variant?: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  totals: {
    subtotal: number;
    tax: number;
    shipping: number;
    discount: number;
    total: number;
    currency: string;
  };
  appliedCoupons?: Array<{
    code: string;
    discount: number;
    type: 'percentage' | 'fixed';
  }>;
  shippingAddress?: DomainOrder['shipping'] extends { address: infer A } ? A : never;
  billingAddress?: DomainOrder['billingAddress'];
  expiresAt?: string;
};

/**
 * Map RevealUI Content Engine Order fields to domain-friendly types
 */
export type RevealUIToDomainOrderMapper<T extends RevealUIOrder> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  userId: string;
  items: Array<{
    id: string;
    productId: string;
    product: ExtractRevealUIEntity<T['items'][number]['productId']>;
    variantId?: string;
    variant?: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  totals: {
    subtotal: number;
    tax: number;
    shipping: number;
    discount: number;
    total: number;
  };
  status: OrderStatus;
  payment: {
    status: T['paymentStatus'];
    method: string;
    transactionId?: string;
    amount: number;
    currency: string;
    processedAt?: string;
  };
  shipping?: {
    address: {
      firstName: string;
      lastName: string;
      address1: string;
      city: string;
      state: string;
      postalCode: string;
      country: string;
    };
    method: string;
    trackingNumber?: string;
    estimatedDelivery?: string;
    shippedAt?: string;
    deliveredAt?: string;
  };
  metadata: {
    notes?: string;
    tags?: string[];
    source: 'web' | 'mobile' | 'admin';
    ipAddress?: string;
    userAgent?: string;
  };
};

/**
 * Map RevealUI Content Engine Category fields to domain-friendly types
 */
export type RevealUIToDomainCategoryMapper<T extends RevealUICategory> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  name: string;
  slug: string;
  description?: string;
  parent?: ExtractRevealUIEntity<T['parent']>;
  children?: ExtractRevealUIEntity<T['parent']>[];
  image?: string;
  meta?: {
    title?: string;
    description?: string;
    keywords?: string;
  };
  featured?: boolean;
  sortOrder?: number;
};

/**
 * Map RevealUI Content Engine Tag fields to domain-friendly types
 */
export type RevealUIToDomainTagMapper<T extends RevealUITag> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  name: string;
  slug: string;
  description?: string;
};

/**
 * Map RevealUI Content Engine Menu fields to domain-friendly types
 */
export type RevealUIToDomainMenuMapper<T extends RevealUIMenu> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  name: string;
  location: DomainMenu['location'];
  isActive: boolean;
  sortOrder: number;
  items: DomainMenu['items'];
  status: DomainMenu['status'];
};

/**
 * Map RevealUI Content Engine Media fields to domain-friendly types
 */
export type RevealUIToDomainMediaMapper<T extends RevealUIMedia> = {
  id: T['id'];
  createdAt: T['createdAt'];
  updatedAt: T['updatedAt'];
  filename: string;
  alt?: string;
  url?: string;
  mimeType?: string;
  filesize?: number;
  width?: number;
  height?: number;
  prefix?: ExtractRevealUIEntity<T['prefix']>;
};

// ====================================================================
// ENHANCED ENTITIES (HYBRID TYPES)
// ====================================================================

/**
 * Enhanced Post that combines RevealUI Content Engine and domain properties
 * Useful for application layer that needs both
 */
export type EnhancedPost = RevealUIPost &
  Partial<DomainPost> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced User that combines RevealUI Content Engine and domain properties
 */
export type EnhancedUser = RevealUIUser &
  Partial<DomainUser> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Product that combines RevealUI Content Engine and domain properties
 */
export type EnhancedProduct = RevealUIProduct &
  Partial<DomainProduct> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Cart that combines RevealUI Content Engine and domain properties
 */
export type EnhancedCart = RevealUICart &
  Partial<DomainCart> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Order that combines RevealUI Content Engine and domain properties
 */
export type EnhancedOrder = RevealUIOrder &
  Partial<DomainOrder> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Category that combines RevealUI Content Engine and domain properties
 */
export type EnhancedCategory = RevealUICategory &
  Partial<DomainCategory> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Tag that combines RevealUI Content Engine and domain properties
 */
export type EnhancedTag = RevealUITag &
  Partial<DomainTag> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Menu that combines RevealUI Content Engine and domain properties
 */
export type EnhancedMenu = RevealUIMenu &
  Partial<DomainMenu> & {
    readonly __enhanced: true;
  };

/**
 * Enhanced Media that combines RevealUI Content Engine and domain properties
 */
export type EnhancedMedia = RevealUIMedia &
  Partial<DomainMedia> & {
    readonly __enhanced: true;
  };

// ====================================================================
// TRANSFORMATION TYPE HELPERS
// ====================================================================

/**
 * Transform RevealUI Content Engine entity to domain entity
 * Generic helper for safe conversions
 */
export type ToDomainMapper<TRevealUI> = TRevealUI extends RevealUIPost
  ? RevealUIToDomainPostMapper<TRevealUI>
  : TRevealUI extends RevealUIUser
    ? RevealUIToDomainUserMapper<TRevealUI>
    : TRevealUI extends RevealUIProduct
      ? RevealUIToDomainProductMapper<TRevealUI>
      : TRevealUI extends RevealUICart
        ? RevealUIToDomainCartMapper<TRevealUI>
        : TRevealUI extends RevealUIOrder
          ? RevealUIToDomainOrderMapper<TRevealUI>
          : TRevealUI extends RevealUICategory
            ? RevealUIToDomainCategoryMapper<TRevealUI>
            : TRevealUI extends RevealUITag
              ? RevealUIToDomainTagMapper<TRevealUI>
              : TRevealUI extends RevealUIMenu
                ? RevealUIToDomainMenuMapper<TRevealUI>
                : TRevealUI extends RevealUIMedia
                  ? RevealUIToDomainMediaMapper<TRevealUI>
                  : TRevealUI;

/**
 * Transform domain entity to RevealUI Content Engine entity
 * Generic helper for safe conversions
 */
export type ToRevealUIMapper<TDomain> = TDomain extends DomainPost
  ? RevealUIEntityInput<RevealUIPost>
  : TDomain extends DomainUser
    ? RevealUIEntityInput<RevealUIUser>
    : TDomain extends DomainProduct
      ? RevealUIEntityInput<RevealUIProduct>
      : TDomain extends DomainCart
        ? RevealUIEntityInput<RevealUICart>
        : TDomain extends DomainOrder
          ? RevealUIEntityInput<RevealUIOrder>
          : TDomain extends DomainCategory
            ? RevealUIEntityInput<RevealUICategory>
            : TDomain extends DomainTag
              ? RevealUIEntityInput<RevealUITag>
              : TDomain extends DomainMenu
                ? RevealUIEntityInput<RevealUIMenu>
                : TDomain extends DomainMedia
                  ? RevealUIEntityInput<RevealUIMedia>
                  : TDomain;

/**
 * Create hybrid entity that includes both layers
 */
export type HybridEntity<TRevealUI, TDomain> = TRevealUI &
  Partial<TDomain> & {
    readonly __source: 'hybrid';
  };

// ====================================================================
// TYPE-SAFE TRANSFORMATION HELPERS
// ====================================================================

/**
 * Verify if a transformation is type-safe
 * Compile-time check that mapped types are compatible
 */
// Using Record<string, unknown> because mapper structure varies by transformation type and cannot be strictly typed
export type VerifyTransformation<TSource, TTarget, TMapper> =
  TMapper extends /* Using Record<string, unknown> because mapper structure varies by transformation type and cannot be strictly typed */ Record<
    string,
    unknown
  >
    ? {
        [K in keyof TMapper]: K extends keyof TTarget
          ? TMapper[K] extends TTarget[K]
            ? true
            : false
          : false;
      } extends Record<string, true>
      ? true
      : false
    : false;

/**
 * Create a branded domain entity from RevealUI Content Engine entity
 */
export type CreateDomainEntity<T> = DomainDerived<T>;

/**
 * Create a branded RevealUI Content Engine entity from domain entity
 */
export type CreateRevealUIEntity<T> = RevealUIDerived<T>;

// ====================================================================
// FIELD-LEVEL MAPPINGS
// ====================================================================

/**
 * Map specific field from RevealUI Content Engine to domain format
 * Handles rich text, relationships, enums, etc.
 */
export type MapField<TRevealUIField, TDomainField> = TRevealUIField extends RevealUIRichText
  ? string // Rich text → plain string
  : TRevealUIField extends string | null | undefined
    ? TDomainField
    : TRevealUIField extends object
      ? // Relationship field
        ExtractRevealUIEntity<TRevealUIField>
      : TRevealUIField;

/**
 * Map all fields from RevealUI Content Engine entity to domain entity
 */
export type MapAllFields<TRevealUI, TDomain> = {
  [K in keyof TRevealUI]: K extends keyof TDomain ? MapField<TRevealUI[K], TDomain[K]> : never;
};

// ====================================================================
// CONDITIONAL TYPE TRANSFORMATIONS
// ====================================================================

/**
 * Conditionally transform based on entity type
 * Provides type-safe transformations based on the input type
 */
export type ConditionalTransform<T> = T extends RevealUIPost
  ? DomainPost
  : T extends RevealUIUser
    ? DomainUser
    : T extends RevealUIProduct
      ? DomainProduct
      : T extends RevealUICart
        ? DomainCart
        : T extends RevealUIOrder
          ? DomainOrder
          : T extends RevealUICategory
            ? DomainCategory
            : T extends RevealUITag
              ? DomainTag
              : T extends RevealUIMenu
                ? DomainMenu
                : T extends RevealUIMedia
                  ? DomainMedia
                  : T;

/**
 * Reverse transformation (domain to revealui)
 */
export type ReverseTransform<T> = T extends DomainPost
  ? RevealUIPost
  : T extends DomainUser
    ? RevealUIUser
    : T extends DomainProduct
      ? RevealUIProduct
      : T extends DomainCart
        ? RevealUICart
        : T extends DomainOrder
          ? RevealUIOrder
          : T extends DomainCategory
            ? RevealUICategory
            : T extends DomainTag
              ? RevealUITag
              : T extends DomainMenu
                ? RevealUIMenu
                : T extends DomainMedia
                  ? RevealUIMedia
                  : T;

// ====================================================================
// TRANSFORMATION UTILITIES
// ====================================================================

/**
 * Check if entities are compatible for transformation
 */
export type AreCompatible<TSource, TTarget> = {
  [K in keyof TTarget]: K extends keyof TSource ? true : false;
} extends Record<keyof TTarget, true>
  ? true
  : false;

/**
 * Extract transformation errors
 * Shows which fields cannot be mapped
 */
export type ExtractTransformationErrors<TSource, TTarget> = {
  [K in keyof TTarget]: K extends keyof TSource
    ? TSource[K] extends TTarget[K]
      ? true
      : { error: 'type_mismatch'; source: TSource[K]; target: TTarget[K] }
    : { error: 'missing_field' };
};

// ====================================================================
// COMPOSITE TYPES
// ====================================================================

/**
 * RevealUI Content Engine entity with domain metadata
 * Useful for keeping domain context with RevealUI Content Engine entities
 */
export interface RevealUIWithDomainContext<TRevealUI, TDomain> {
  revealui: TRevealUI;
  domain: Partial<TDomain>;
  metadata: {
    transformed: boolean;
    transformedAt: Date;
    transformationErrors?: Array<{
      field: string;
      error: string;
    }>;
  };
}

/**
 * Domain entity with RevealUI Content Engine source
 * Useful for tracking original RevealUI Content Engine data
 */
export interface DomainWithRevealUISource<TDomain, TRevealUI> {
  domain: TDomain;
  originalRevealUI?: TRevealUI;
  metadata: {
    extractedFromRevealUI: boolean;
    extractionDate: Date;
  };
}

// ====================================================================
// ADVANCED TRANSFORMATIONS
// ====================================================================

/**
 * Deep transformation of nested structures
 * Recursively maps all fields including nested objects
 */
export type DeepToDomain<T> = T extends RevealUIPost
  ? DeepMapPost<T>
  : T extends RevealUIUser
    ? DeepMapUser<T>
    : T extends RevealUIProduct
      ? DeepMapProduct<T>
      : T extends RevealUICart
        ? DeepMapCart<T>
        : T extends RevealUIOrder
          ? DeepMapOrder<T>
          : T extends RevealUICategory
            ? DeepMapCategory<T>
            : T extends RevealUITag
              ? DeepMapTag<T>
              : T extends RevealUIMenu
                ? DeepMapMenu<T>
                : T extends RevealUIMedia
                  ? DeepMapMedia<T>
                  : T;

/**
 * Deep map Post entity
 */
type DeepMapPost<T extends RevealUIPost> = {
  [K in keyof T]: T[K] extends RevealUIRichText
    ? string
    : T[K] extends RevealUIRelation<infer R>
      ? R extends RevealUIUser
        ? DeepMapUser<R>
        : R
      : T[K];
};

/**
 * Deep map User entity
 */
type DeepMapUser<T extends RevealUIUser> = {
  [K in keyof T]: T[K] extends RevealUIRelation<infer R>
    ? R extends RevealUIPost
      ? DeepMapPost<R>
      : R
    : T[K];
};

/**
 * Deep map Product entity
 */
type DeepMapProduct<T extends RevealUIProduct> = {
  [K in keyof T]: T[K] extends RevealUIRichText
    ? string
    : T[K] extends RevealUIRelation<infer R>
      ? R
      : T[K];
};

/**
 * Deep map Cart entity
 */
type DeepMapCart<T extends RevealUICart> = {
  [K in keyof T]: T[K] extends RevealUIRelation<infer R>
    ? R extends RevealUIProduct
      ? DeepMapProduct<R>
      : R
    : T[K];
};

/**
 * Deep map Order entity
 */
type DeepMapOrder<T extends RevealUIOrder> = {
  [K in keyof T]: T[K] extends RevealUIRelation<infer R>
    ? R extends RevealUIProduct
      ? DeepMapProduct<R>
      : R
    : T[K];
};

/**
 * Deep map Category entity
 */
type DeepMapCategory<T extends RevealUICategory> = {
  [K in keyof T]: T[K] extends RevealUIRelation<infer R>
    ? R extends RevealUICategory
      ? DeepMapCategory<R>
      : R
    : T[K];
};

/**
 * Deep map Tag entity
 */
type DeepMapTag<T extends RevealUITag> = {
  [K in keyof T]: T[K];
};

/**
 * Deep map Menu entity
 */
type DeepMapMenu<T extends RevealUIMenu> = {
  [K in keyof T]: T[K];
};

/**
 * Deep map Media entity
 */
type DeepMapMedia<T extends RevealUIMedia> = {
  [K in keyof T]: T[K] extends RevealUIRelation<infer R> ? R : T[K];
};

// ====================================================================
// TYPE GUARDS AND UTILITIES
// ====================================================================

/**
 * Type guard to check if value is an enhanced entity
 */
export function isEnhancedEntity(
  value: unknown
): value is
  | EnhancedPost
  | EnhancedUser
  | EnhancedProduct
  | EnhancedCart
  | EnhancedOrder
  | EnhancedCategory
  | EnhancedTag
  | EnhancedMenu
  | EnhancedMedia {
  return (
    typeof value === 'object' &&
    value !== null &&
    '__enhanced' in value &&
    (value as { __enhanced: boolean }).__enhanced === true
  );
}

/**
 * Create enhanced entity from RevealUI Content Engine and domain entities
 */
export function createEnhancedEntity<TRevealUI, TDomain>(
  revealui: TRevealUI,
  domain: Partial<TDomain>
): HybridEntity<TRevealUI, TDomain> {
  return {
    ...revealui,
    ...domain,
    __source: 'hybrid',
  } as HybridEntity<TRevealUI, TDomain>;
}

/**
 * Type guard to check if value is a specific enhanced entity type
 */
export function isEnhancedPost(value: unknown): value is EnhancedPost {
  return isEnhancedEntity(value) && typeof value === 'object' && value !== null && 'title' in value;
}

/**
 * Type guard to check if value is an enhanced user
 */
export function isEnhancedUser(value: unknown): value is EnhancedUser {
  return isEnhancedEntity(value) && typeof value === 'object' && value !== null && 'email' in value;
}

/**
 * Type guard to check if value is an enhanced product
 */
export function isEnhancedProduct(value: unknown): value is EnhancedProduct {
  return (
    isEnhancedEntity(value) &&
    typeof value === 'object' &&
    value !== null &&
    'title' in value &&
    'pricing' in value
  );
}

/**
 * Type guard to check if value is an enhanced cart
 */
export function isEnhancedCart(value: unknown): value is EnhancedCart {
  return (
    isEnhancedEntity(value) &&
    typeof value === 'object' &&
    value !== null &&
    'items' in value &&
    'totals' in value
  );
}

/**
 * Type guard to check if value is an enhanced order
 */
export function isEnhancedOrder(value: unknown): value is EnhancedOrder {
  return (
    isEnhancedEntity(value) &&
    typeof value === 'object' &&
    value !== null &&
    'items' in value &&
    'orderNumber' in value
  );
}

/**
 * Type guard to check if value is an enhanced category
 */
export function isEnhancedCategory(value: unknown): value is EnhancedCategory {
  return isEnhancedEntity(value) && typeof value === 'object' && value !== null && 'title' in value;
}

/**
 * Type guard to check if value is an enhanced tag
 */
export function isEnhancedTag(value: unknown): value is EnhancedTag {
  return isEnhancedEntity(value) && typeof value === 'object' && value !== null && 'title' in value;
}

/**
 * Type guard to check if value is an enhanced menu
 */
export function isEnhancedMenu(value: unknown): value is EnhancedMenu {
  return (
    isEnhancedEntity(value) &&
    typeof value === 'object' &&
    value !== null &&
    'items' in value &&
    'location' in value
  );
}

/**
 * Type guard to check if value is an enhanced media
 */
export function isEnhancedMedia(value: unknown): value is EnhancedMedia {
  return (
    isEnhancedEntity(value) && typeof value === 'object' && value !== null && 'filename' in value
  );
}
