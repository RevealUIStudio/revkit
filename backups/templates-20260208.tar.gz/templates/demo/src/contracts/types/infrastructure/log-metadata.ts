// ====================================================================
// LOG METADATA TYPES
// ====================================================================
// Typed log metadata structures
// Replaces Record<string, unknown> with specific interfaces

/**
 * Base log metadata structure
 * Contains additional metadata that can be attached to log entries
 */
export interface BaseLogMetadata {
  /** Additional custom properties */
  [key: string]: unknown;
}

/**
 * Request metadata
 */
export interface RequestLogMetadata extends BaseLogMetadata {
  /** Request body (sanitized) */
  requestBody?: unknown;
  /** Request parameters */
  requestParams?: {
    [key: string]: unknown;
  };
  /** Query parameters */
  queryParams?: {
    [key: string]: unknown;
  };
  /** Request size in bytes */
  requestSize?: number;
}

/**
 * Response metadata
 */
export interface ResponseLogMetadata extends BaseLogMetadata {
  /** Response body (sanitized) */
  responseBody?: unknown;
  /** Response size in bytes */
  responseSize?: number;
  /** Cache status */
  cacheStatus?: 'hit' | 'miss' | 'bypass';
  /** Cache key if applicable */
  cacheKey?: string;
}

/**
 * Database metadata
 */
export interface DatabaseLogMetadata extends BaseLogMetadata {
  /** Query string (sanitized) */
  query?: string;
  /** Query parameters */
  queryParams?: unknown[];
  /** Indexes used */
  indexesUsed?: string[];
  /** Execution plan (if available) */
  executionPlan?: unknown;
}

/**
 * Error metadata
 */
export interface ErrorLogMetadata extends BaseLogMetadata {
  /** Error details */
  errorDetails?: {
    [key: string]: unknown;
  };
  /** Error context */
  errorContext?: {
    [key: string]: unknown;
  };
  /** Retry information */
  retryInfo?: {
    attempt: number;
    maxAttempts: number;
    nextRetryAt?: Date;
  };
}

/**
 * Performance metadata
 */
export interface PerformanceLogMetadata extends BaseLogMetadata {
  /** Performance breakdown by component */
  breakdown?: {
    [component: string]: number;
  };
  /** Memory usage in bytes */
  memoryUsage?: number;
  /** CPU usage percentage */
  cpuUsage?: number;
  /** Network latency in milliseconds */
  networkLatency?: number;
}

/**
 * Business event metadata
 */
export interface BusinessEventLogMetadata extends BaseLogMetadata {
  /** Event type */
  eventType?: string;
  /** Event category */
  eventCategory?: string;
  /** Business entity ID */
  entityId?: string;
  /** Business entity type */
  entityType?: string;
  /** Action performed */
  action?: string;
}

/**
 * Union type for all log metadata types
 */
export type LogMetadata =
  | BaseLogMetadata
  | RequestLogMetadata
  | ResponseLogMetadata
  | DatabaseLogMetadata
  | ErrorLogMetadata
  | PerformanceLogMetadata
  | BusinessEventLogMetadata;

/**
 * Type guard to check if metadata is RequestLogMetadata
 */
export function isRequestLogMetadata(metadata: LogMetadata): metadata is RequestLogMetadata {
  return 'requestBody' in metadata || 'requestParams' in metadata || 'queryParams' in metadata;
}

/**
 * Type guard to check if metadata is ResponseLogMetadata
 */
export function isResponseLogMetadata(metadata: LogMetadata): metadata is ResponseLogMetadata {
  return 'responseBody' in metadata || 'responseSize' in metadata || 'cacheStatus' in metadata;
}

/**
 * Type guard to check if metadata is DatabaseLogMetadata
 */
export function isDatabaseLogMetadata(metadata: LogMetadata): metadata is DatabaseLogMetadata {
  return 'query' in metadata || 'queryParams' in metadata || 'indexesUsed' in metadata;
}

/**
 * Type guard to check if metadata is ErrorLogMetadata
 */
export function isErrorLogMetadata(metadata: LogMetadata): metadata is ErrorLogMetadata {
  return 'errorDetails' in metadata || 'errorContext' in metadata || 'retryInfo' in metadata;
}

/**
 * Type guard to check if metadata is PerformanceLogMetadata
 */
export function isPerformanceLogMetadata(
  metadata: LogMetadata
): metadata is PerformanceLogMetadata {
  return 'breakdown' in metadata || 'memoryUsage' in metadata || 'cpuUsage' in metadata;
}

/**
 * Type guard to check if metadata is BusinessEventLogMetadata
 */
export function isBusinessEventLogMetadata(
  metadata: LogMetadata
): metadata is BusinessEventLogMetadata {
  return 'eventType' in metadata || 'eventCategory' in metadata || 'entityId' in metadata;
}
