// ====================================================================
// REVEALUI UTILITIES
// ====================================================================
// Utility types for safe RevealUI type manipulation and transformation
// Provides type-safe helpers for common RevealUI operations
//
// NOTE: For generic type utilities not specific to RevealUI entities,
// see shared/helpers.ts. This file focuses on RevealUI-specific utilities
// that require RevealUIEntity constraints.

import type { RevealUIEntity } from './extended-reveal';

// ====================================================================
// FIELD MANIPULATION UTILITIES
// ====================================================================

/**
 * Pick specific fields from a RevealUI entity type
 * Type-safe field picking with autocomplete support
 */
export type PickRevealUIFields<T extends RevealUIEntity, K extends keyof T> = Pick<T, K>;

/**
 * Omit specific fields from a RevealUI entity type
 * Useful for excluding system fields
 */
export type OmitRevealUIFields<T extends RevealUIEntity, K extends keyof T> = Omit<T, K>;

/**
 * Extract only the data fields (no system fields)
 * Removes id, createdAt, updatedAt, and other RevealUI system fields
 */
export type RevealUIDataFields<T extends RevealUIEntity> = Omit<T, 'id' | 'createdAt' | 'updatedAt'>;

// ====================================================================
// RELATIONSHIP FIELD UTILITIES
// ====================================================================

/**
 * Handle RevealUI relation fields that can be string | Entity
 * Extracts the entity type from a relation field
 */
export type RevealUIRelation<T> = T extends string | infer Entity ? Entity : never;

/**
 * Check if a field is a relation field (string | Entity union)
 */
export type IsRelationField<T> = T extends string | object ? true : false;

/**
 * Get the ID type from a relation field
 * Returns string for string IDs, never for non-relation fields
 */
export type RelationId<T> = T extends string ? T : T extends { id: string } ? string : never;

// ====================================================================
// INPUT TYPE GENERATORS
// ====================================================================

/**
 * Generate create input type for RevealUI entity
 * Removes system fields and makes relations optional
 */
export type RevealUICreateInput<T extends RevealUIEntity> = {
  [K in keyof Omit<T, 'id' | 'createdAt' | 'updatedAt'>]: T[K] extends string | object
    ? // Relation field
      RevealUIRelation<T[K]> | string | undefined
    : // Regular field
      T[K] | undefined;
};

/**
 * Generate update input type for RevealUI entity
 * Makes all fields optional except ID, and handles relations
 */
export type RevealUIUpdateInput<T extends RevealUIEntity> = {
  [K in keyof Omit<T, 'id' | 'createdAt' | 'updatedAt'>]?: T[K] extends string | object
    ? // Relation field
      RevealUIRelation<T[K]> | string | null
    : // Regular field
      T[K] | null;
} & {
  // Make ID required
  id: T['id'];
};

/**
 * Generate upsert input type (combines create and update)
 */
export type RevealUIUpsertInput<T extends RevealUIEntity> = RevealUICreateInput<T> & {
  id?: T['id'];
};

// ====================================================================
// SELECT FIELD UTILITIES
// ====================================================================

/**
 * Type-safe select field configuration
 * Ensures only valid field names can be selected
 */
export type RevealUISelect<T extends RevealUIEntity> = {
  [K in keyof T]?: boolean;
};

/**
 * Generate array of select fields
 */
export type RevealUISelectFields<T extends RevealUIEntity> = Array<keyof T>;

/**
 * Type-safe select with nested relations
 */
export type RevealUIDeepSelect<T extends RevealUIEntity> = {
  [K in keyof T]?: boolean | (T[K] extends RevealUIEntity ? RevealUIDeepSelect<T[K]> : never);
};

// ====================================================================
// WHERE CLAUSE UTILITIES
// ====================================================================

/**
 * Generate where clause type for RevealUI entity
 * Supports nested conditions and operators
 */
export type RevealUIWhere<T extends RevealUIEntity> = {
  [K in keyof T]?: T[K] extends string
    ? T[K] | { equals?: T[K]; not_equals?: T[K]; like?: string; in?: T[K][] }
    : T[K] extends number
      ? T[K] | { equals?: T[K]; not_equals?: T[K]; greater_than?: T[K]; less_than?: T[K] }
      : T[K] extends boolean
        ? T[K] | { equals?: boolean }
        : T[K] extends object
          ? // Relation field
            RevealUIWhere<RevealUIRelation<T[K]>>
          : T[K] extends Array<infer U>
            ? // Array field
              U[] | { contains?: U; in?: U[] }
            : // Fallback for unknown types - use unknown instead of any
              unknown;
} & {
  // Logical operators
  OR?: RevealUIWhere<T>[];
  AND?: RevealUIWhere<T>[];
};

// ====================================================================
// SORT UTILITIES
// ====================================================================

/**
 * Type-safe sort configuration
 * Ensures only valid field names and sort directions
 */
export type RevealUISortField<T extends RevealUIEntity> = {
  field: keyof T;
  direction: 'asc' | 'desc';
};

/**
 * Generate sort array type
 */
export type RevealUISort<T extends RevealUIEntity> = Array<RevealUISortField<T>>;

// ====================================================================
// PAGINATION UTILITIES
// ====================================================================

/**
 * Pagination input for RevealUI queries
 */
export interface RevealUIPaginationInput {
  limit?: number;
  page?: number;
  offset?: number;
}

/**
 * Paginated response metadata
 */
export interface RevealUIPaginationMeta {
  totalDocs: number;
  limit: number;
  totalPages: number;
  page?: number;
  pagingCounter: number;
  hasPrevPage: boolean;
  hasNextPage: boolean;
  prevPage?: number | null;
  nextPage?: number | null;
}

/**
 * Paginated response wrapper
 */
export interface RevealUIPaginatedResponse<T> {
  docs: T[];
  totalDocs: number;
  limit: number;
  totalPages: number;
  page?: number;
  pagingCounter: number;
  hasPrevPage: boolean;
  hasNextPage: boolean;
  prevPage?: number | null;
  nextPage?: number | null;
}

// ====================================================================
// QUERY OPTIONS
// ====================================================================

/**
 * Complete query options for RevealUI
 */
export interface RevealUIQueryOptions<T extends RevealUIEntity> {
  where?: RevealUIWhere<T>;
  select?: RevealUISelect<T>;
  sort?: RevealUISort<T>;
  limit?: number;
  page?: number;
  offset?: number;
  depth?: number;
  locale?: string;
  fallbackLocale?: string;
}

/**
 * Full-text search options
 */
export interface RevealUISearchOptions<T extends RevealUIEntity> extends RevealUIQueryOptions<T> {
  query: string;
  fields?: Array<keyof T>;
  operator?: 'or' | 'and';
  minimumShouldMatch?: string | number;
}

// ====================================================================
// NESTED FIELD ACCESS UTILITIES
// ====================================================================

/**
 * Get nested field path type
 * Example: 'category.name' from Post entity
 */
export type NestedFieldPath<
  T extends RevealUIEntity,
  Path extends string,
> = Path extends `${infer Head}.${infer Tail}`
  ? Head extends keyof T
    ? Tail extends keyof T[Head] | ''
      ? T[Head][Tail]
      : never
    : never
  : Path extends keyof T
    ? T[Path]
    : never;

/**
 * Extract all possible nested paths
 */
export type AllFieldPaths<T extends RevealUIEntity> = {
  [K in keyof T]: T[K] extends RevealUIEntity
    ? K | `${K & string}.${AllFieldPaths<T[K]> & string}`
    : K;
}[keyof T];

// ====================================================================
// FIELD TYPE INSPECTION
// ====================================================================

/**
 * Check if a field is optional (nullable)
 */
export type IsOptional<T> = undefined extends T ? true : false;

/**
 * Check if a field is required
 */
export type IsRequired<T> = undefined extends T ? false : true;

/**
 * Get all required fields from an entity
 */
export type RequiredFields<T> = {
  [K in keyof T]-?: undefined extends T[K] ? never : K;
}[keyof T];

/**
 * Get all optional fields from an entity
 */
export type OptionalFields<T> = {
  [K in keyof T]-?: undefined extends T[K] ? K : never;
}[keyof T];

// ====================================================================
// COMPUTED FIELD UTILITIES
// ====================================================================

/**
 * Add computed fields to a RevealUI Content Engine entity
 * Useful for adding derived/calculated properties
 */
// Using Record<string, unknown> because computed fields structure varies by entity type and cannot be strictly typed
export type WithComputedFields<
  T extends RevealUIEntity,
  TComputed extends
    /* Using Record<string, unknown> because computed fields structure varies by entity type and cannot be strictly typed */ Record<
      string,
      unknown
    >,
> = T & TComputed;

/**
 * Remove computed fields (get base entity back)
 */
// Using Record<string, unknown> because entity and computed fields structure varies by entity type and cannot be strictly typed
export type WithoutComputedFields<
  T extends RevealUIEntity &
    /* Using Record<string, unknown> because entity structure varies by entity type and cannot be strictly typed */ Record<
      string,
      unknown
    >,
  TComputed extends
    /* Using Record<string, unknown> because computed fields structure varies by entity type and cannot be strictly typed */ Record<
      string,
      unknown
    >,
> = Omit<T, keyof TComputed> extends RevealUIEntity ? Omit<T, keyof TComputed> : never;

// ====================================================================
// UTILITY HELPERS
// ====================================================================

/**
 * Make all fields deeply required
 */
export type DeepRequired<T> = T extends object
  ? {
      [P in keyof T]-?: DeepRequired<T[P]>;
    }
  : T;

/**
 * Make all fields deeply partial
 */
export type DeepPartial<T> = T extends object
  ? {
      [P in keyof T]?: DeepPartial<T[P]>;
    }
  : T;

/**
 * Make all fields deeply readonly
 */
export type DeepReadonly<T> = T extends object
  ? {
      readonly [P in keyof T]: DeepReadonly<T[P]>;
    }
  : T;

/**
 * Extract only required fields from a type
 */
export type RequiredOnly<T> = {
  [K in keyof T as undefined extends T[K] ? never : K]: T[K];
};

/**
 * Extract only optional fields from a type
 */
export type OptionalOnly<T> = {
  [K in keyof T as undefined extends T[K] ? K : never]?: T[K];
};
