// ====================================================================
// SHELL EXECUTION TYPES
// ====================================================================
// Types for shell command execution utilities

export interface ExecuteOptions {
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  timeout?: number;
  maxBuffer?: number;
  shell?: string;
  onProgress?: ProgressCallback;
}

export interface ExecuteResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  success: boolean;
  error?: Error;
}

export type ProgressCallback = (message: string) => void;
