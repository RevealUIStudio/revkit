// ====================================================================
// REVEALUI COLLECTIONS TYPE HELPERS
// ====================================================================
// Type-safe collection name helpers and entity extraction utilities
// Provides autocomplete and type safety for RevealUI collections

import type { CollectionName as SharedCollectionName } from '@revealui/core/shared-types';
import type { Config } from '@revealui/infrastructure/cms/db/reveal-types';
import type { RevealUIEntity } from './extended-reveal';
import type { RevealUIWhere } from './reveal-utils';

// ====================================================================
// COLLECTION NAME UTILITIES
// ====================================================================

/**
 * Union of all RevealUI collection names
 * Extracted from Config['collections']
 */
export type CollectionName = Extract<SharedCollectionName, string>;

/**
 * Get collection type by slug/name
 * Type-safe collection lookup with autocomplete
 */
export type GetCollection<T extends CollectionName> = Config['collections'][T];

// ====================================================================
// COLLECTION GROUPING
// ====================================================================

/**
 * Content collections (posts, pages, categories, tags, media)
 */
export type ContentCollections =
  | 'posts'
  | 'pages'
  | 'categories'
  | 'tags'
  | 'media'
  | 'help-articles';

/**
 * E-commerce collections (products, carts, orders, coupons)
 */
export type EcommerceCollections = 'products' | 'carts' | 'orders' | 'coupons' | 'brands';

/**
 * User management collections
 */
export type UserCollections = 'users' | 'sessions' | 'tenants';

/**
 * Video/Multi-media collections
 */
export type VideoCollections = 'videos' | 'video-purchases' | 'video-requests';

/**
 * System/Admin collections
 */
export type SystemCollections =
  | 'folders'
  | 'menus'
  | 'redirects'
  | 'search'
  | 'forms'
  | 'form-submissions'
  | 'versions'
  | 'performance-metrics';

/**
 * Business/SaaS collections
 */
export type BusinessCollections =
  | 'businesses'
  | 'business-features'
  | 'industry-templates'
  | 'paywalls';

/**
 * Internal RevealUICMS collections
 */
export type InternalCollections =
  | 'revealui-jobs'
  | 'revealui-locked-documents'
  | 'revealui-preferences'
  | 'revealui-migrations';

/**
 * All collection category unions
 */
export type AllCollectionCategories =
  | ContentCollections
  | EcommerceCollections
  | UserCollections
  | VideoCollections
  | SystemCollections
  | BusinessCollections
  | InternalCollections;

// ====================================================================
// COLLECTION ENTITY EXTRACTION
// ====================================================================

/**
 * Extract entity type from a collection
 * Helper for getting the type from a collection name
 */
export type CollectionEntity<T extends CollectionName> = GetCollection<T>;

/**
 * Type-safe collection entity lookup
 * Usage: CollectionEntity<'posts'> → Post
 */
export type EntityOf<T extends CollectionName> = Config['collections'][T];

// ====================================================================
// COLLECTION OPERATIONS
// ====================================================================

/**
 * Collection select fields configuration
 * From Config['collectionsSelect']
 */
export type CollectionSelectFields<T extends CollectionName> = Config['collectionsSelect'][T];

/**
 * Get select fields for a collection
 */
export type GetCollectionSelect<T extends CollectionName> = Config['collectionsSelect'][T];

// ====================================================================
// COLLECTION TYPE GUARDS
// ====================================================================

/**
 * Type predicate to check if a value is a specific collection entity
 */
export function isCollectionEntityOfType<T extends CollectionName>(
  value: unknown,
  collection: T
): value is EntityOf<T> {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'createdAt' in value &&
    'updatedAt' in value
  );
}

/**
 * Type predicate factory for collection entities
 * Returns a type guard for a specific collection
 */
export function createCollectionGuard<T extends CollectionName>(
  collection: T
): (value: unknown) => value is EntityOf<T> {
  return (value: unknown): value is EntityOf<T> => isCollectionEntityOfType(value, collection);
}

// ====================================================================
// COLLECTION METADATA
// ====================================================================

/**
 * Collection metadata information
 */
export interface CollectionMetadata<T extends CollectionName> {
  name: T;
  slug: string;
  label: string;
  description?: string;
  entityType: EntityOf<T>;
}

/**
 * Get collection metadata by name
 * Helper for runtime collection information
 */
export function getCollectionMetadata<T extends CollectionName>(name: T): CollectionMetadata<T> {
  // This would be populated from actual collection config in runtime
  // For now, just return a minimal structure
  return {
    name,
    slug: name.toString(),
    label: name.toString(),
    // Using EntityOf<T> assertion because entityType is not available at runtime but type system requires it
    entityType: undefined as unknown as EntityOf<T>, // Type-safe but not runtime-safe
  };
}

// ====================================================================
// QUERY BUILDER HELPERS
// ====================================================================

/**
 * Type-safe query builder for collections
 */
export interface CollectionQuery<T extends CollectionName> {
  collection: T;
  where?: RevealUIWhere<EntityOf<T>>;
  select?: Record<string, boolean>;
  sort?: Array<{ field: string; direction: 'asc' | 'desc' }>;
  limit?: number;
  page?: number;
}

/**
 * Create a type-safe query for a collection
 */
export function createCollectionQuery<T extends CollectionName>(collection: T): CollectionQuery<T> {
  return {
    collection,
  };
}

// ====================================================================
// COLLECTION RELATIONSHIPS
// ====================================================================

/**
 * Extract all collections that reference a specific collection
 * Useful for finding related collections
 */
export type CollectionsReferencing<T extends CollectionName> = {
  // Using Record<string, unknown> because entity structure varies by collection and cannot be strictly typed
  [K in CollectionName]: EntityOf<K> extends Record<string, unknown>
    ? {
        [P in keyof EntityOf<K>]: EntityOf<K>[P] extends T | (T | null) | (T | undefined)
          ? K
          : never;
      }[keyof EntityOf<K>]
    : never;
}[CollectionName];

/**
 * Get related collections from Config
 * This would need to be computed at runtime or via code generation
 */
export function getRelatedCollections<T extends CollectionName>(collection: T): CollectionName[] {
  // This would analyze the Config to find relationships
  // For now, return empty array
  return [];
}

// ====================================================================
// COLLECTION AGGREGATIONS
// ====================================================================

/**
 * Aggregate collection statistics
 */
export interface CollectionStats {
  totalDocuments: number;
  publishedDocuments: number;
  draftDocuments: number;
  archivedDocuments: number;
  lastUpdated: Date;
}

/**
 * Type-safe collection stats builder
 */
export function createCollectionStats(): CollectionStats {
  return {
    totalDocuments: 0,
    publishedDocuments: 0,
    draftDocuments: 0,
    archivedDocuments: 0,
    lastUpdated: new Date(),
  };
}

// ====================================================================
// UTILITY TYPES
// ====================================================================

/**
 * Extract all entity types as a union
 */
export type AllCollectionEntities =
  | Config['collections']['brands']
  | Config['collections']['business-features']
  | Config['collections']['businesses']
  | Config['collections']['industry-templates']
  | Config['collections']['users']
  | Config['collections']['media']
  | Config['collections']['videos']
  | Config['collections']['video-purchases']
  | Config['collections']['video-requests']
  | Config['collections']['help-articles']
  | Config['collections']['pages']
  | Config['collections']['posts']
  | Config['collections']['prefixes']
  | Config['collections']['tags']
  | Config['collections']['sessions']
  | Config['collections']['categories']
  | Config['collections']['folders']
  | Config['collections']['menus']
  | Config['collections']['paywalls']
  | Config['collections']['products']
  | Config['collections']['carts']
  | Config['collections']['orders']
  | Config['collections']['coupons']
  | Config['collections']['tenants']
  | Config['collections']['versions']
  | Config['collections']['performance-metrics']
  | Config['collections']['redirects']
  | Config['collections']['search']
  | Config['collections']['forms']
  | Config['collections']['form-submissions']
  | Config['collections']['revealui-jobs']
  | Config['collections']['revealui-locked-documents']
  | Config['collections']['revealui-preferences']
  | Config['collections']['revealui-migrations'];

/**
 * Check if a collection name exists
 */
export type IsValidCollection<T extends string> = T extends CollectionName ? true : false;

/**
 * Validate collection name at compile time
 */
export function assertCollectionName<T extends CollectionName>(name: T): T {
  return name;
}
