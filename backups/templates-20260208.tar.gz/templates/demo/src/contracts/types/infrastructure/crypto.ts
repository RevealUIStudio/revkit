// =======
// CRYPTO TYPES
// =======
// Cryptography and authenticated encryption types

/**
 * Enhanced crypto types for authenticated encryption
 */
export interface EnhancedAuthenticatedCipher {
  getAuthTag(): Buffer;
  setAuthTag(buffer: Buffer): void;
  setAAD(buffer: Buffer): void;
}

/**
 * Enhanced decipher type for authenticated decryption
 */
export interface EnhancedAuthenticatedDecipher {
  setAuthTag(buffer: Buffer): void;
  setAAD?(buffer: Buffer): void;
}

/**
 * Encryption algorithm types
 */
export type EncryptionAlgorithm = 'aes-256-gcm' | 'aes-128-gcm' | 'chacha20-poly1305';

/**
 * Key derivation function types
 */
export type KDFAlgorithm = 'pbkdf2' | 'scrypt' | 'argon2';

/**
 * Crypto operation result
 */
export interface CryptoResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  algorithm?: EncryptionAlgorithm;
  keyId?: string;
}
