// ====================================================================
// MIDDLEWARE TYPES
// ====================================================================
// Typed middleware input/output structures
// Replaces unknown with specific interfaces

/**
 * Middleware request context
 */
export interface MiddlewareRequest {
  /** Request method */
  method: string;
  /** Request URL */
  url: string;
  /** Request headers */
  headers: {
    [key: string]: string | string[] | undefined;
  };
  /** Request body */
  body?: unknown;
  /** Query parameters */
  query?: {
    [key: string]: string | string[] | undefined;
  };
  /** Path parameters */
  params?: {
    [key: string]: string | undefined;
  };
  /** User information if authenticated */
  user?: {
    id: string;
    [key: string]: unknown;
  };
  /** Request ID for tracking */
  requestId?: string;
  /** IP address */
  ip?: string;
}

/**
 * Middleware response context
 */
export interface MiddlewareResponse {
  /** Response status code */
  statusCode?: number;
  /** Response headers */
  headers?: {
    [key: string]: string | string[] | undefined;
  };
  /** Response body */
  body?: unknown;
  /** Whether response was sent */
  sent?: boolean;
}

/**
 * Middleware context
 */
export interface MiddlewareContext {
  /** Request object */
  request: MiddlewareRequest;
  /** Response object */
  response: MiddlewareResponse;
  /** Additional context data */
  [key: string]: unknown;
}

/**
 * Next function for middleware chain
 */
export type NextFunction = () => Promise<void> | void;

/**
 * Middleware function type
 */
export type MiddlewareFunction = (
  context: MiddlewareContext,
  next: NextFunction
) => Promise<void> | void;
