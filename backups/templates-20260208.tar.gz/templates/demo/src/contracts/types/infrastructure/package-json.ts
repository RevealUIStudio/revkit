/**
 * Package.json Type Definitions
 * Standard structure for package.json files
 */

export interface PackageJson {
  name?: string;
  version?: string;
  description?: string;
  main?: string;
  module?: string;
  types?: string;
  type?: 'module' | 'commonjs';
  scripts?: Record<string, string>;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
  optionalDependencies?: Record<string, string>;
  bundledDependencies?: string[];
  engines?: Record<string, string>;
  author?: string | { name: string; email?: string; url?: string };
  license?: string;
  repository?: string | { type: string; url: string; directory?: string };
  bugs?: string | { url: string; email?: string };
  homepage?: string;
  keywords?: string[];
  // Using Record<string, unknown> because publishConfig can include various npm-specific fields
  publishConfig?: /* Using Record<string, unknown> because publishConfig can include various npm-specific fields */ Record<
    string,
    unknown
  >;
  // Using Record<string, unknown> because exports field has complex conditional structure that varies by package
  exports?: /* Using Record<string, unknown> because exports field has complex conditional structure that varies by package */ Record<
    string,
    unknown
  >;
  files?: string[];
  [key: string]: unknown; // Allow additional fields
}

/**
 * Package info from npm registry
 */
export interface NpmPackageInfo {
  name: string;
  version: string;
  description?: string;
  'dist-tags'?: {
    latest?: string;
    [tag: string]: string | undefined;
  };
  homepage?: string;
  repository?: {
    type?: string;
    url?: string;
  };
  [key: string]: unknown; // Allow additional fields from npm registry
}
