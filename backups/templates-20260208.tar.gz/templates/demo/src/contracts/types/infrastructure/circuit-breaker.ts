// =======
// CIRCUIT BREAKER TYPES
// =======

import type { FailureDetectionStrategy } from '@revealui/core/shared-types';

/**
 * Circuit breaker types
 */
export type CircuitBreakerState = 'closed' | 'open' | 'half-open';

export type CircuitBreakerErrorType = Error | { status?: number; code?: string; message?: string };

/**
 * Circuit breaker metrics
 */
export interface CircuitBreakerMetrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  lastFailureTime?: Date;
  lastSuccessTime?: Date;
  currentState: CircuitBreakerState;
}

export type CircuitBreakerFailureDetectionStrategy = 'count' | 'latency' | 'percentage';

export interface CircuitBreakerMetricsOptions {
  enabled: boolean;
  exportInterval?: number;
}

// Using Record<string, unknown> because circuit breaker fallback return type varies by operation and cannot be strictly typed
export interface CircuitBreakerOptions<
  TFallback extends
    /* Using Record<string, unknown> because circuit breaker fallback return type varies by operation and cannot be strictly typed */ Record<
      string,
      unknown
    >,
> {
  failureThreshold: number;
  resetTimeout: number;
  monitorInterval: number;
  fallback: () => Promise<TFallback>;
  metricsEnabled: boolean;
  failureDetectionStrategy: CircuitBreakerFailureDetectionStrategy;
  latencyThreshold: number;
  failurePercentageThreshold: number;
  maxConcurrentExecutions: number;
  metrics?: CircuitBreakerMetricsOptions;
}
