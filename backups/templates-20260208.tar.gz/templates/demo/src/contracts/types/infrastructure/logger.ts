// ====================================================================
// LOGGER TYPES
// ====================================================================
// Logging-related types for the application

import type { LogContext } from './log-context';
import type { LogMetadata } from './log-metadata';

/**
 * Log level enum
 */
export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'fatal';

/**
 * Logger interface
 */
export interface DomainLogger {
  readonly loggerName: string;
  debug(message: string, meta?: LogMetadata): void;
  info(message: string, meta?: LogMetadata): void;
  warn(message: string, meta?: LogMetadata): void;
  error(message: string, meta?: LogMetadata): void;
  fatal?(message: string, meta?: LogMetadata): void;
  logError?(error: Error, context?: LogContext): void;
  child?(meta: LogMetadata): DomainLogger;
}

/**
 * Log entry interface
 */
export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: Date;
  context?: LogContext;
  metadata?: LogMetadata;
  error?: Error;
}
