// ======
// INFRASTRUCTURE SERVICE TYPES
// ======

export type ServiceConfig = {
  name: string;
  version?: string;
  description?: string;
  retry?: {
    maxAttempts: number;
    backoffMs: number;
    jitter: boolean;
  };
  timeout?: {
    request: number;
    response: number;
  };
  healthCheck?: {
    enabled: boolean;
    interval: number;
    timeout: number;
  };
  logging?: {
    level: string; // LogLevel type
    enabled: boolean;
  };
};

export const DEFAULT_SERVICE_CONFIG: ServiceConfig = {
  name: 'UnknownService',
  version: '1.0.0',
  retry: {
    maxAttempts: 3,
    backoffMs: 1000,
    jitter: true,
  },
  timeout: {
    request: 30000,
    response: 60000,
  },
  healthCheck: {
    enabled: true,
    interval: 30000,
    timeout: 5000,
  },
  logging: {
    level: 'info',
    enabled: true,
  },
};

export type ServiceMetadata = {
  name: string;
  version: string;
  description?: string;
  capabilities: string[];
  dependencies: string[];
  // Using Record<string, unknown> because service configuration structure varies by service type and cannot be strictly typed
  configuration: /* Using Record<string, unknown> because service configuration structure varies by service type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
};

export type HealthStatus = 'healthy' | 'unhealthy' | 'degraded';

export type CacheType = 'memory' | 'vercel' | 'cloudflare';

// ServiceResult type moved to core module

export type CreateData<T> = Omit<T, 'id' | 'createdAt' | 'updatedAt'>;

export type UpdateData<T> = Partial<CreateData<T>>;

export type InfrastructureEventData = {
  type: string;
  source: string;
  timestamp: string;
  // Using Record<string, unknown> because event data structure varies by event type and cannot be strictly typed
  data: /* Using Record<string, unknown> because event data structure varies by event type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  // Using Record<string, unknown> because event metadata structure varies by event type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because event metadata structure varies by event type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
};

// ================================================================
// SERVICE INTERFACES - Infrastructure service contracts
// ================================================================

/**
 * Base service interface for all infrastructure services
 */
export interface IBaseService {
  initialize(): Promise<void>;
  dispose(): Promise<void>;
  isHealthy(): Promise<boolean>;
  getConfig(): ServiceConfig;
}

/**
 * Async service interface for services that need start/stop lifecycle
 */
export interface IAsyncService extends IBaseService {
  start(): Promise<void>;
  stop(): Promise<void>;
  isRunning(): boolean;
}

/**
 * Logger service interface
 */
export interface ILogger {
  // Using Record<string, unknown> because log metadata structure varies by log level and operation
  debug(
    message: string,
    meta?: /* Using Record<string, unknown> because log metadata structure varies by log level and operation */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because log metadata structure varies by log level and operation
  info(
    message: string,
    meta?: /* Using Record<string, unknown> because log metadata structure varies by log level and operation */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because log metadata structure varies by log level and operation
  warn(
    message: string,
    meta?: /* Using Record<string, unknown> because log metadata structure varies by log level and operation */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because log metadata structure varies by log level and operation
  error(
    message: string,
    meta?: /* Using Record<string, unknown> because log metadata structure varies by log level and operation */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because log metadata structure varies by log level and operation
  fatal?(
    message: string,
    meta?: /* Using Record<string, unknown> because log metadata structure varies by log level and operation */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because error context structure varies by error type and cannot be strictly typed
  logError?(
    error: Error,
    context?: /* Using Record<string, unknown> because error context structure varies by error type and cannot be strictly typed */ Record<
      string,
      unknown
    >
  ): void;
  // Using Record<string, unknown> because logger child metadata structure varies by logger implementation
  child?(
    meta: /* Using Record<string, unknown> because logger child metadata structure varies by logger implementation */ Record<
      string,
      unknown
    >
  ): ILogger;
}

/**
 * Event bus service interface
 */
export interface IEventBus {
  publish(event: string, data: unknown): Promise<void>;
  subscribe(event: string, handler: (data: unknown) => Promise<void>): void;
  unsubscribe(event: string, handler: (data: unknown) => Promise<void>): void;
}

/**
 * Cache service interface
 */
export interface ICacheService {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttl?: number): Promise<void>;
  delete(key: string): Promise<void>;
  clear(): Promise<void>;
  has(key: string): Promise<boolean>;
  size(): Promise<number>;
}

/**
 * Database connection interface
 */
export interface IDatabaseConnection {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  query<T>(sql: string, params?: unknown[]): Promise<T[]>;
  transaction<T>(callback: () => Promise<T>): Promise<T>;
  isConnected(): Promise<boolean>;
}

/**
 * Service context for passing request-scoped data
 */
export interface ServiceContext {
  userId?: string;
  requestId?: string;
  correlationId?: string;
  timestamp: Date;
  // Using Record<string, unknown> because service context metadata structure varies by service type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because service context metadata structure varies by service type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  logger?: ILogger;
}

/**
 * Service dependencies for dependency injection
 */
export interface ServiceDependencies {
  logger?: ILogger;
  eventBus?: IEventBus;
  cache?: ICacheService;
  database?: IDatabaseConnection;
  [key: string]: unknown;
}

/**
 * Service metrics for monitoring and observability
 */
export interface ServiceMetrics {
  executionTime: number;
  memoryUsage: number;
  cpuUsage?: number;
  errorCount: number;
  successCount: number;
  requestCount?: number;
  timestamp: Date;
}

/**
 * Enhanced service result with metrics and context
 * NOTE: Use ServiceResult from @/contracts/types/domain/service-results for standard operations
 */
export interface EnhancedServiceResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: ServiceError;
  metadata?: ServiceMetrics;
  context?: ServiceContext;
}

/**
 * Service error interface
 */
export interface ServiceError {
  code: string;
  message: string;
  // Using Record<string, unknown> because service error details structure varies by error type and cannot be strictly typed
  details?: /* Using Record<string, unknown> because service error details structure varies by error type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
  stack?: string;
  timestamp: Date;
  context?: ServiceContext;
}

// ================================================================
// UTILITY INTERFACES - Additional infrastructure services
// ================================================================

/**
 * Event bus service interface (enhanced)
 */
export interface EventBus {
  publish(event: string, data?: unknown): Promise<void>;
  subscribe(event: string, handler: (data: unknown) => Promise<void>): Promise<void>;
  unsubscribe(event: string): Promise<void>;
}

/**
 * Analytics service interface
 */
export interface AnalyticsService {
  trackEvent(event: string, data?: unknown): Promise<void>;
  trackPageView(page: string, data?: unknown): Promise<void>;
  trackUserAction(action: string, userId?: string, data?: unknown): Promise<void>;
}

/**
 * Email service contract
 */
export interface EmailServiceContract<TOptions = unknown, TResult = unknown> {
  sendEmail(options: TOptions): Promise<TResult>;
}

/**
 * Storage service contract
 */
export interface StorageServiceContract {
  // Using Record<string, unknown> because file upload options structure varies by storage provider and cannot be strictly typed
  uploadFile(
    file: File | Blob,
    options?: /* Using Record<string, unknown> because file upload options structure varies by storage provider and cannot be strictly typed */ Record<
      string,
      unknown
    >
  ): Promise<{ url: string; key?: string }>;
  deleteFile(url: string): Promise<void>;
  getFile(url: string): Promise<Blob>;
  listFiles(prefix?: string): Promise<Array<{ url: string; key: string; size?: number }>>;
}

/**
 * Queue service interface for background jobs
 */
export interface IQueueService {
  enqueue(
    jobType: string,
    data: unknown,
    options?: { delay?: number; priority?: number }
  ): Promise<string>;
  dequeue(jobType: string): Promise<{ id: string; data: unknown } | null>;
  acknowledge(jobId: string): Promise<void>;
  retry(jobId: string, delay?: number): Promise<void>;
}

/**
 * Rate limiter service interface
 */
export interface IRateLimiterService {
  check(
    key: string,
    limit: number,
    windowMs: number
  ): Promise<{ allowed: boolean; remaining: number; resetTime: Date }>;
  increment(key: string): Promise<void>;
  reset(key: string): Promise<void>;
}
