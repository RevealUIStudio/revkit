// ====================================================================
// CONTROLLER TYPES
// ====================================================================
// Typed controller request/response structures
// Replaces unknown with specific interfaces

import type { ServiceResult } from '../../domain/service-results';

/**
 * Controller request data
 */
export interface ControllerRequest<T = unknown> {
  /** Request body */
  body?: T;
  /** Query parameters */
  query?: {
    [key: string]: string | string[] | undefined;
  };
  /** Path parameters */
  params?: {
    [key: string]: string | undefined;
  };
  /** Request headers */
  headers?: {
    [key: string]: string | string[] | undefined;
  };
  /** User information if authenticated */
  user?: {
    id: string;
    [key: string]: unknown;
  };
}

/**
 * Controller response data
 */
export interface ControllerResponse<T = unknown> {
  /** Response status code */
  statusCode: number;
  /** Response body */
  body: ServiceResult<T>;
  /** Response headers */
  headers?: {
    [key: string]: string | string[] | undefined;
  };
}

/**
 * Controller validation result
 */
export interface ControllerValidationResult {
  /** Whether validation passed */
  isValid: boolean;
  /** Validation errors */
  errors?: Array<{
    field: string;
    message: string;
    code?: string;
  }>;
  /** Validated data */
  data?: unknown;
}
