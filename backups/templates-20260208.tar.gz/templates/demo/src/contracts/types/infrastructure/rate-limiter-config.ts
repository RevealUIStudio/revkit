/**
 * Rate Limiter Type Definitions
 * Configuration and statistics types for rate limiting
 */

/**
 * Rate limiter default configuration
 * Using Record<string, unknown> because configuration can include custom algorithm-specific options
 */
export type RateLimiterDefaultConfig =
  /* Using Record<string, unknown> because configuration can include custom algorithm-specific options */ Record<
    string,
    unknown
  >;

/**
 * Base rate limiter statistics
 */
export interface RateLimiterStats {
  totalRequests: number;
  allowedRequests: number;
  deniedRequests: number;
  startTime: number;
  uptime: number;
  successRate: number;
  limiterStats: TokenBucketStats | SlidingWindowStats | FixedWindowStats | null;
  config: RateLimitConfigData;
}

/**
 * Token bucket specific statistics
 */
export interface TokenBucketStats {
  tokens: number;
  requestCount: number;
  lastRequest: number | null;
  nextRefill: number;
}

/**
 * Sliding window specific statistics
 */
export interface SlidingWindowStats {
  requestCount: number;
  totalRequests: number;
  lastRequest: number | null;
  windowStart: number;
}

/**
 * Fixed window specific statistics
 */
export interface FixedWindowStats {
  requestCount: number;
  windowStart: number;
  lastRequest: number | null;
}

/**
 * Rate limit configuration data
 */
export interface RateLimitConfigData {
  algorithm: string;
  maxRequests: number;
  windowSize: number;
  bucketSize: number;
  refillRate: number;
  burstSize: number;
  skipSuccessful: boolean;
  skipFailed: boolean;
  [key: string]: unknown; // Allow additional config fields
}
