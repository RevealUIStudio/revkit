// ====================================================================
// LOG CONTEXT TYPES
// ====================================================================
// Typed log context structures
// Replaces Record<string, unknown> with specific interfaces

/**
 * Base log context structure
 * Contains standard fields commonly used in logging
 */
export interface BaseLogContext {
  /** Service name that generated the log */
  service?: string;
  /** Operation name being performed */
  operation?: string;
  /** User ID associated with the operation */
  userId?: string;
  /** Request ID for tracking requests */
  requestId?: string;
  /** Correlation ID for tracking related operations */
  correlationId?: string;
  /** Session ID */
  sessionId?: string;
  /** IP address */
  ipAddress?: string;
  /** User agent string */
  userAgent?: string;
  /** Duration in milliseconds */
  duration?: number;
  /** Tenant ID for multi-tenant systems */
  tenantId?: string;
  /** Environment (development, staging, production) */
  environment?: string;
}

/**
 * HTTP request log context
 */
export interface HttpLogContext extends BaseLogContext {
  /** HTTP method */
  method?: string;
  /** Request URL */
  url?: string;
  /** HTTP status code */
  statusCode?: number;
  /** Request headers */
  headers?: {
    [key: string]: string | string[] | undefined;
  };
  /** Response time in milliseconds */
  responseTime?: number;
}

/**
 * Database operation log context
 */
export interface DatabaseLogContext extends BaseLogContext {
  /** Database name */
  database?: string;
  /** Collection or table name */
  collection?: string;
  /** Query operation type */
  queryType?: 'select' | 'insert' | 'update' | 'delete' | 'aggregate';
  /** Query duration in milliseconds */
  queryDuration?: number;
  /** Number of records affected */
  recordsAffected?: number;
}

/**
 * Error log context
 */
export interface ErrorLogContext extends BaseLogContext {
  /** Error name or type */
  errorName?: string;
  /** Error code */
  errorCode?: string;
  /** Error message */
  errorMessage?: string;
  /** Stack trace */
  stackTrace?: string;
  /** Component or module where error occurred */
  component?: string;
  /** Error category */
  errorCategory?: 'validation' | 'business' | 'system' | 'external' | 'unknown';
}

/**
 * Performance log context
 */
export interface PerformanceLogContext extends BaseLogContext {
  /** Performance metric name */
  metric?: string;
  /** Metric value */
  value?: number;
  /** Metric unit */
  unit?: string;
  /** Resource name */
  resource?: string;
  /** Additional performance metrics */
  metrics?: {
    [key: string]: number | undefined;
  };
}

/**
 * Authentication log context
 */
export interface AuthLogContext extends BaseLogContext {
  /** Authentication method */
  authMethod?: string;
  /** Authentication provider */
  authProvider?: string;
  /** Whether authentication was successful */
  success?: boolean;
  /** Failure reason if authentication failed */
  failureReason?: string;
}

/**
 * Union type for all log context types
 */
export type LogContext =
  | BaseLogContext
  | HttpLogContext
  | DatabaseLogContext
  | ErrorLogContext
  | PerformanceLogContext
  | AuthLogContext;

/**
 * Type guard to check if context is HttpLogContext
 */
export function isHttpLogContext(context: LogContext): context is HttpLogContext {
  return 'method' in context || 'url' in context || 'statusCode' in context;
}

/**
 * Type guard to check if context is DatabaseLogContext
 */
export function isDatabaseLogContext(context: LogContext): context is DatabaseLogContext {
  return 'database' in context || 'collection' in context || 'queryType' in context;
}

/**
 * Type guard to check if context is ErrorLogContext
 */
export function isErrorLogContext(context: LogContext): context is ErrorLogContext {
  return 'errorName' in context || 'errorCode' in context || 'errorMessage' in context;
}

/**
 * Type guard to check if context is PerformanceLogContext
 */
export function isPerformanceLogContext(context: LogContext): context is PerformanceLogContext {
  return 'metric' in context || 'value' in context || 'resource' in context;
}

/**
 * Type guard to check if context is AuthLogContext
 */
export function isAuthLogContext(context: LogContext): context is AuthLogContext {
  return 'authMethod' in context || 'authProvider' in context || 'success' in context;
}
