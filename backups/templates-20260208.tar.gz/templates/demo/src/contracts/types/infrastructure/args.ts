// =======
// NEXT.JS ARGS TYPES
// =======

/**
 * Next.js page props args type
 */
export type Args = {
  params: Promise<{
    slug?: string;
  }>;
};

/**
 * Dynamic route parameters
 */
export interface DynamicParams {
  [key: string]: string | string[];
}

/**
 * Search params type
 */
export interface SearchParams {
  [key: string]: string | string[] | undefined;
}
