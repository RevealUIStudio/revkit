export interface DateConfig {
  defaultLocale: string;
  defaultTimeZone: string;
}
