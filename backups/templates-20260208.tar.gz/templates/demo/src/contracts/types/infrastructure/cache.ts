// ====================================================================
// CACHE TYPES
// ====================================================================
// Cache-related types for infrastructure services

/**
 * Cache entry with expiration
 */
export interface CacheEntry<T = unknown> {
  key: string;
  value: T;
  expiresAt: number;
  createdAt: number;
}

/**
 * Cache options for configuration
 */
export interface CacheOptions {
  ttl?: number;
  maxSize?: number;
  strategy?: 'sqlite' | 'memory' | 'nextjs' | 'auto';
}

/**
 * Cache metrics for monitoring
 */
export interface CacheMetrics {
  totalEntries: number;
  hitCount: number;
  missCount: number;
  hitRate: number;
  averageAccessTime: number;
  memoryUsage: number;
  evictionCount: number;
}

/**
 * Cache statistics
 */
export interface CacheStats {
  size: number;
  maxSize: number;
  hitRate: number;
  averageTTL: number;
}
