// ====================================================================
// SECURITY AUDIT TYPES
// ====================================================================
// Types for security auditing and vulnerability scanning

export interface PnpmAuditResult {
  advisories: Record<string, SecurityAdvisory>;
  metadata: AuditMetadata;
}

export interface SecurityAdvisory {
  id: number;
  title: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  vulnerable_versions: string;
  patched_versions: string;
  overview: string;
  recommendation: string;
  references: string[];
  cves: string[];
}

export interface AuditMetadata {
  vulnerabilities: {
    low: number;
    moderate: number;
    high: number;
    critical: number;
    total: number;
  };
  dependencies: number;
  devDependencies: number;
  optionalDependencies: number;
  totalDependencies: number;
}

export interface SecurityIssue {
  id: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  title: string;
  package: string;
  version: string;
  fixedIn?: string;
  description: string;
  cves: string[];
  references: string[];
}

export interface SecurityReport {
  timestamp: string;
  totalIssues: number;
  criticalIssues: number;
  highIssues: number;
  moderateIssues: number;
  lowIssues: number;
  issues: SecurityIssue[];
  summary: string;
}
