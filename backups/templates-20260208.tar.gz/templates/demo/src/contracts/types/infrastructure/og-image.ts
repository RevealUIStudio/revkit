// =======
// OPEN GRAPH IMAGE TYPES
// =======

/**
 * Open Graph image type
 */
export type OGImage = { url: string } | { url: string; [key: string]: unknown };

/**
 * Open Graph metadata
 */
export interface OGMetadata {
  title?: string;
  description?: string;
  image?: OGImage;
  url?: string;
  type?: string;
  siteName?: string;
  locale?: string;
}

/**
 * Twitter card metadata
 */
export interface TwitterMetadata {
  card?: 'summary' | 'summary_large_image' | 'app' | 'player';
  title?: string;
  description?: string;
  image?: string;
  site?: string;
  creator?: string;
}
