/**
 * Base Filter Options
 * Common filter options used across all services
 */
export interface FilterOptions {
  status?: string;
  search?: string;
  category?: string;
  tags?: string[];
  dateFrom?: Date | string;
  dateTo?: Date | string;
  [key: string]: unknown;
}

/**
 * Pagination Options
 */
export interface PaginationOptions {
  page?: number;
  limit?: number;
  offset?: number;
}

/**
 * Sort Options
 */
export interface SortOptions {
  field: string;
  direction: 'asc' | 'desc';
}

/**
 * Query Options
 * Combined options for repository queries
 */
export interface QueryOptions extends PaginationOptions {
  sort?: SortOptions[];
  include?: string[];
  select?: string[];
  cache?: boolean;
  ttl?: number;
}

/**
 * Search Options
 * Extended options for search operations
 */
export interface SearchOptions extends FilterOptions, QueryOptions {
  fuzzy?: boolean;
  highlight?: boolean;
  fields?: string[];
}
