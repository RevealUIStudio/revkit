import type { User as RevealUIUser } from '@revealui/infrastructure/cms/db/reveal-types';
import type { RevealUI } from '@revealui/content';

/**
 * RevealUI Request Context
 * Standardized request interface for RevealUI operations
 */
export interface RevealUIRequest<TUser = User> {
  user?: TUser;
  revealui: RevealUI;
  locale?: string;
  fallbackLocale?: string;
  [key: string]: unknown;
}

/**
 * Access Control Context
 * Used in RevealUI access control functions
 */
export interface AccessContext<TDoc = unknown> {
  req: RevealUIRequest;
  doc?: TDoc;
  data?: Partial<TDoc>;
}

/**
 * RevealUI Field Types
 * Common field types used throughout the application
 */
export interface RevealUIField {
  name: string;
  type: string;
  required?: boolean;
  defaultValue?: unknown;
  validate?: (value: unknown) => boolean | string;
}

/**
 * RevealUI Collection Configuration
 */
export interface CollectionConfig {
  slug: string;
  fields: RevealUIField[];
  access?: Record<string, (context: AccessContext) => boolean>;
  hooks?: Record<string, (...args: unknown[]) => unknown>;
}

/**
 * Request with Socket information
 * Extends RevealUI request to include Node.js socket information
 * Used for accessing remote address and connection details
 */
export interface RequestWithSocket extends RevealUIRequest {
  socket?: {
    remoteAddress?: string;
    remotePort?: number;
    [key: string]: unknown;
  };
  headers?: {
    get?: (name: string) => string | null;
    [key: string]: unknown;
  };
}
