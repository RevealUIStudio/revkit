/**
 * RevealUI Field Helper Types
 *
 * Type definitions for RevealUI field condition functions' siblingData parameter.
 * These enable type-safe dot notation access instead of bracket notation.
 *
 * @module contracts/types/infrastructure/revealui-field-helpers
 */

/**
 * Type helper for link field siblingData
 * Enables type-safe dot notation access in condition functions
 */
export interface LinkFieldSiblingData {
  type?: 'reference' | 'custom';
  reference?: string | number | { id: string | number };
  url?: string;
  newTab?: boolean;
  appearance?: 'default' | 'outline';
}

/**
 * Type helper for archive block siblingData
 * Based on ArchiveBlock structure from revealui-types.ts
 */
export interface ArchiveBlockSiblingData {
  populateBy?: 'collection' | 'selection';
  relationTo?: 'posts' | 'pages';
  categories?: Array<string | { id: string }>;
  limit?: number;
  selectedDocs?: Array<{ relationTo: string; value: string | { id: string } }>;
  display?: {
    layout?: 'grid' | 'list' | 'masonry';
    columns?: '1' | '2' | '3' | '4';
    showImage?: boolean;
    showDate?: boolean;
    showAuthor?: boolean;
    showExcerpt?: boolean;
    excerptLength?: number;
  };
  advancedOptions?: {
    pagination?: {
      enablePagination?: boolean;
      itemsPerPage?: number;
      showPageNumbers?: boolean;
    };
  };
  // Allow access to nested properties with dot notation
  layout?: 'grid' | 'list' | 'masonry';
  showExcerpt?: boolean;
  enablePagination?: boolean;
}

/**
 * Type helper for form block siblingData
 */
export interface FormBlockSiblingData {
  width?: 'full' | 'narrow' | 'wide' | 'custom';
  customWidth?: string;
  alignment?: 'left' | 'center' | 'right';
  theme?: 'default' | 'custom';
}

/**
 * Type helper for call-to-action block siblingData
 */
export interface CallToActionBlockSiblingData {
  appearance?: {
    background?: {
      type?: 'none' | 'color' | 'image' | 'gradient';
      color?: 'primary' | 'secondary' | 'light' | 'dark' | 'custom';
      customColor?: string;
      image?: string | { id: string };
      gradient?: string;
    };
  };
  // Allow direct access to nested properties
  type?: 'color' | 'image' | 'gradient';
  color?: 'primary' | 'secondary' | 'light' | 'dark' | 'custom';
  customColor?: string;
  image?: string | { id: string };
  gradient?: string;
  trackClicks?: boolean;
}

/**
 * Type helper for media block siblingData
 */
export interface MediaBlockSiblingData {
  showGallery?: boolean;
  defaultView?: 'grid' | 'list' | 'filesystem';
  showThumbnails?: boolean;
}

/**
 * Type helper for banner block siblingData
 */
export interface BannerBlockSiblingData {
  type?: 'custom';
  dismissible?: boolean;
  enabled?: boolean;
}

/**
 * Type helper for related posts block siblingData
 */
export interface RelatedPostsBlockSiblingData {
  matchBy?: 'custom';
  layout?: 'grid' | 'list' | 'carousel';
  showExcerpt?: boolean;
  autoplay?: boolean;
}

/**
 * Type helper for menu item siblingData (used in Menus collection)
 */
export interface MenuItemSiblingData {
  type?: 'link' | 'page' | 'post' | 'category';
  link?: {
    url?: string;
  };
  page?: string | { id: string };
  post?: string | { id: string };
  category?: string | { id: string };
}
