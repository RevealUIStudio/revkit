/**
 * Metadata Type Helpers
 *
 * Common metadata interfaces to replace Record<string, unknown> where structure is known.
 * This enables type-safe dot notation access instead of bracket notation.
 *
 * @module contracts/types/infrastructure/metadata-types
 */

/**
 * Generic metadata structure with known common fields
 */
export interface BaseMetadata {
  [key: string]: unknown;
}

/**
 * Metadata for backup operations
 */
export interface BackupMetadata extends BaseMetadata {
  backup?: {
    id: string;
    name: string;
    type: 'full' | 'incremental';
    status: 'pending' | 'processing' | 'completed' | 'failed';
    size?: number;
    completedAt?: string;
    error?: string;
    collections?: string[];
  };
  schedule?: {
    id: string;
    frequency: 'daily' | 'weekly' | 'monthly';
    time?: string;
    enabled: boolean;
  };
  restoreRequest?: {
    id: string;
    backupId: string;
    requestedAt: string;
    status: 'pending' | 'processing' | 'completed' | 'failed';
  };
}

/**
 * Metadata for subscription operations
 */
export interface SubscriptionMetadata extends BaseMetadata {
  interval?: 'month' | 'year';
  trialEndsAt?: string;
  canceledAt?: string;
  cancelReason?: string;
  tenantId?: string;
  [key: string]: unknown;
}

/**
 * Metadata for payment operations
 */
export interface PaymentMetadata extends BaseMetadata {
  orderId?: string;
  idempotencyKey?: string;
  customerId?: string;
  tenantId?: string;
  [key: string]: unknown;
}

/**
 * Metadata for GDPR operations
 */
export interface GdprMetadata extends BaseMetadata {
  scheduledDeletionAt?: string;
  error?: string;
  tenantId?: string;
  format?: string;
  [key: string]: unknown;
}

/**
 * Metadata for webhook events
 */
export interface WebhookMetadata extends BaseMetadata {
  retryAttempt?: number;
  lastError?: string;
  tenantId?: string;
  [key: string]: unknown;
}

/**
 * Metadata for audit log entries
 */
export interface AuditLogMetadata extends BaseMetadata {
  backup?: BackupMetadata['backup'];
  restoreRequest?: BackupMetadata['restoreRequest'];
  schedule?: BackupMetadata['schedule'];
  [key: string]: unknown;
}
