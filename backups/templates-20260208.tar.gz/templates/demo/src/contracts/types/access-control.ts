// ====================================================================
// ACCESS CONTROL TYPES
// ====================================================================
// Type definitions for access control (re-exported from interfaces for convenience)

export type {
  PermissionCheckData,
  RoleCheckData,
  ModuleAccessData,
  ActionPermissionData,
} from '../interfaces/access-control';
