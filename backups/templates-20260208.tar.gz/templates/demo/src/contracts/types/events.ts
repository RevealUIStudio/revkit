/**
 * Event System Types
 *
 * Type definitions for the event bus and event handlers.
 * Used to replace explicit `any` types in event system.
 *
 * @module contracts/types/events
 */

/**
 * Base event interface
 */
export interface BaseEvent {
  type: string;
  timestamp: Date;
  source?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Generic event handler
 */
export type EventHandler<T extends BaseEvent = BaseEvent> = (event: T) => Promise<void> | void;

/**
 * Event handler with context
 */
export type EventHandlerWithContext<T extends BaseEvent = BaseEvent, TContext = unknown> = (
  event: T,
  context: TContext
) => Promise<void> | void;

/**
 * Webhook event
 */
export interface WebhookEvent<T = unknown> extends BaseEvent {
  type: 'webhook';
  revealui: T;
  headers?: Record<string, string>;
  signature?: string;
}

/**
 * Domain event
 */
export interface DomainEvent extends BaseEvent {
  type: string;
  aggregateId: string;
  aggregateType: string;
  version: number;
}

/**
 * User event
 */
export interface UserEvent extends DomainEvent {
  type: 'user.created' | 'user.updated' | 'user.deleted';
  userId: string;
  data?: Record<string, unknown>;
}

/**
 * Order event
 */
export interface OrderEvent extends DomainEvent {
  type: 'order.created' | 'order.updated' | 'order.completed' | 'order.canceled';
  orderId: string;
  data?: Record<string, unknown>;
}

