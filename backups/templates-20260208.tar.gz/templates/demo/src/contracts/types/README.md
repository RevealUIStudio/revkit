# Type System Architecture Guide

## Overview

This document describes the comprehensive type system that blends RevealUI Content Engine
generated types with domain-specific types, creating a robust and type-safe
foundation for the application.

## Architecture Layers

### 1. RevealUI Content Engine Layer (`revealui-types.ts`)

**Location:** `src/infrastructure/cms/db/revealui-types.ts`

Auto-generated types from RevealUI Content Engine schema definitions. These represent the
exact structure of data as stored in the database.

**Key Features:**

- Auto-generated from `revealui.config.ts`
- Rich text structures with Lexical format
- Relationship fields as `string | Entity` unions
- Includes all RevealUI Content Engine system fields (id, createdAt, updatedAt, etc.)

**Example:**

```typescript
import type { Post as RevealUIPost } from '@revealui/infrastructure/cms/db/revealui-types';

// RevealUIPost includes all RevealUI Content Engine fields including:
// - Rich text content structures
// - Union types for relations
// - All system-generated fields
```

### 2. Extended RevealUI Content Engine Layer (`extended-revealui.ts`)

**Location:** `src/contracts/types/infrastructure/extended-revealui.ts`

Utility types and helpers for working with RevealUI Content Engine entities.

**Key Types:**

- `CollectionName` - Union of all collection names
- `CollectionBySlug<T>` - Get collection type by name
- `RevealUIEntity` - Union of all RevealUI Content Engine entities
- `RevealUIRelation<T>` - Extract entity from relation field
- `RevealUIEntityInput<T>` - Create input type (no system fields)
- `RevealUIEntityUpdate<T>` - Update input type
- `RevealUIRichText` - Rich text structure definition

**Type Guards:**

- `isRevealUIEntity(value)` - Check if value is a RevealUI Content Engine entity
- `isPublishedEntity(entity)` - Check if entity is published
- `isDraftEntity(entity)` - Check if entity is draft
- `isArchivedEntity(entity)` - Check if entity is archived
- `hasEntityStatus(entity, status)` - Check if entity has specific status
- `isRevealUIRelation(value)` - Check if value is a relation (string ID or
  entity)
- `isRevealUIRelationEntity(value)` - Check if relation is full entity (not just
  ID)
- `isRevealUIRelationId(value)` - Check if relation is just an ID string

**Example:**

```typescript
import type { RevealUIEntity, RevealUIEntityInput } from '@/contracts/types';

type PostInput = RevealUIEntityInput<RevealUIPost>; // Omits id, createdAt, updatedAt
```

### 3. RevealUI Content Engine Utilities (`revealui-utils.ts`)

**Location:** `src/contracts/types/infrastructure/revealui-utils.ts`

Comprehensive utilities for RevealUI Content Engine type manipulation.

**Key Types:**

- `PickRevealUIFields<T, K>` - Pick specific fields
- `OmitRevealUIFields<T, K>` - Omit specific fields
- `RevealUICreateInput<T>` - Generate create input
- `RevealUIUpdateInput<T>` - Generate update input
- `RevealUISelect<T>` - Type-safe field selection
- `RevealUIWhere<T>` - Type-safe where clauses
- `RevealUISort<T>` - Type-safe sorting

**Pagination:**

- `RevealUIPaginationInput` - Pagination parameters
- `RevealUIPaginationMeta` - Pagination metadata
- `RevealUIPaginatedResponse<T>` - Complete paginated response

**Example:**

```typescript
import type {
  RevealUIQueryOptions,
  RevealUIPaginatedResponse,
} from '@/contracts/types';

const queryOptions: RevealUIQueryOptions<RevealUIPost> = {
  where: { status: { equals: 'published' } },
  select: { title: true, excerpt: true },
  sort: [{ field: 'createdAt', direction: 'desc' }],
  limit: 10,
  page: 1,
};
```

### 4. Collection Helpers (`revealui-collections.ts`)

**Location:** `src/contracts/types/infrastructure/revealui-collections.ts`

Type-safe collection name utilities and entity extraction.

**Key Types:**

- `CollectionName` - All collection names
- `GetCollection<T>` - Get entity type by name
- `EntityOf<T>` - Extract entity from collection
- `CollectionSelectFields<T>` - Get select fields type

**Collection Groups:**

- `ContentCollections` - posts, pages, categories, etc.
- `EcommerceCollections` - products, carts, orders, etc.
- `UserCollections` - users, sessions, tenants
- `VideoCollections` - videos, video-purchases, etc.
- `SystemCollections` - folders, menus, redirects, etc.

**Example:**

```typescript
import type { EntityOf, CollectionName } from '@/contracts/types';

type PostEntity = EntityOf<'posts'>; // RevealUIPost
type ProductEntity = EntityOf<'products'>; // RevealUIProduct
```

### 5. RevealUI-Domain Bridge (`revealui-domain-bridge.ts`)

**Location:** `src/contracts/types/infrastructure/revealui-domain-bridge.ts`

Maps and transforms between RevealUI Content Engine and Domain types.

**Key Types:**

- `EnhancedPost` - Hybrid RevealUI Content Engine + Domain Post
- `EnhancedUser` - Hybrid RevealUI Content Engine + Domain User
- `EnhancedProduct` - Hybrid RevealUI Content Engine + Domain Product
- `EnhancedCart` - Hybrid RevealUI Content Engine + Domain Cart
- `EnhancedOrder` - Hybrid RevealUI Content Engine + Domain Order
- `EnhancedCategory` - Hybrid RevealUI Content Engine + Domain Category
- `EnhancedTag` - Hybrid RevealUI Content Engine + Domain Tag
- `EnhancedMenu` - Hybrid RevealUI Content Engine + Domain Menu
- `EnhancedMedia` - Hybrid RevealUI Content Engine + Domain Media
- `RevealUIToDomainPostMapper<T>` - Transform RevealUI Content Engine → Domain
- `RevealUIToDomainCartMapper<T>` - Transform Cart RevealUI Content Engine → Domain
- `RevealUIToDomainOrderMapper<T>` - Transform Order RevealUI Content Engine → Domain
- `ToDomainMapper<T>` - Generic domain mapper
- `HybridEntity<TRevealUI, TDomain>` - Combined entity type

**Transformations:**

- `ToDomainMapper<TRevealUI>` - Transform to domain
- `ToRevealUIMapper<TDomain>` - Transform to revealui
- `DeepToDomain<T>` - Deep transformation
- `ConditionalTransform<T>` - Smart transformation

**Enhanced Entity Type Guards:**

- `isEnhancedEntity(value)` - Check if value is any enhanced entity
- `isEnhancedPost(value)` - Check if value is enhanced post
- `isEnhancedUser(value)` - Check if value is enhanced user
- `isEnhancedProduct(value)` - Check if value is enhanced product
- `isEnhancedCart(value)` - Check if value is enhanced cart
- `isEnhancedOrder(value)` - Check if value is enhanced order
- `isEnhancedCategory(value)` - Check if value is enhanced category
- `isEnhancedTag(value)` - Check if value is enhanced tag
- `isEnhancedMenu(value)` - Check if value is enhanced menu
- `isEnhancedMedia(value)` - Check if value is enhanced media

**Example:**

```typescript
import type {
  EnhancedPost,
  HybridEntity,
  isEnhancedPost,
} from '@/contracts/types';

// Enhanced entity has both RevealUI Content Engine and domain properties
const post: EnhancedPost = { ...revealuiPost, ...domainPost, __enhanced: true };

// Type guard usage
if (isEnhancedPost(someValue)) {
  // someValue is now typed as EnhancedPost
}
```

### 6. Domain Entities (`domain/entities/*.ts`)

**Location:** `src/contracts/types/domain/entities/`

Business logic types representing domain concepts.

**Key Types:**

- `DomainPost` - Post domain entity
- `DomainUser` - User domain entity
- `DomainProduct` - Product domain entity

**Enhanced Variants:**

- `PostWithRevealUI` - Domain Post with RevealUI Content Engine data
- `UserWithRevealUI` - Domain User with RevealUI Content Engine data
- `ProductWithRevealUI` - Domain Product with RevealUI Content Engine data

**Mappers:**

- `PostFromRevealUI<T>` - Transform RevealUI Content Engine Post to Domain
- `UserFromRevealUI<T>` - Transform RevealUI Content Engine User to Domain
- `ProductFromRevealUI<T>` - Transform RevealUI Content Engine Product to Domain

**Example:**

```typescript
import type { DomainPost, PostWithRevealUI } from '@/contracts/types';

// Pure domain post
const domainPost: DomainPost = { ... };

// Domain post enhanced with RevealUI Content Engine data
const enhancedPost: PostWithRevealUI = { ...revealuiData, ...domainData, __source: 'hybrid' };
```

### 7. Shared Helpers (`shared/helpers.ts`)

**Location:** `src/contracts/types/shared/helpers.ts`

Common utilities for both RevealUI Content Engine and Domain operations.

**Helpers:**

- `revealRichTextToString()` - Extract plain text from rich text
- `extractRevealRelationId()` - Get ID from relation field
- `revealTimestampToDate()` - Convert timestamp to Date
- `revealNumberCoerce()` - Safe number conversion
- `revealStringCoerce()` - Safe string conversion
- `revealBooleanCoerce()` - Safe boolean conversion

**Type Utilities:**

- `ExtractRichTextContent<T>` - Get text from rich text
- `IsRevealUIRelation<T>` - Check if relation field
- `RequireFields<T, K>` - Make specific fields required (takes field keys)
- `OptionalFields<T, K>` - Make specific fields optional (takes field keys)
- `StringFields<T>` - Get string fields only (union of keys)
- `NumberFields<T>` - Get number fields only (union of keys)
- `BooleanFields<T>` - Get boolean fields only (union of keys)
- `ArrayFields<T>` - Get array fields only (union of keys)

**NOTE:** This file contains GENERIC utilities. For RevealUI Content Engine-specific
utilities that require `RevealUIEntity` constraints, see `revealui-utils.ts`:

- `RequiredFields<T>` - Extract which fields are required (no keys parameter)
- `OptionalFields<T>` - Extract which fields are optional (no keys parameter)
- `NestedFieldPath<T, Path>` - RevealUI Content Engine-specific nested path access

**Example:**

```typescript
import {
  revealRichTextToString,
  extractRevealRelationId,
} from '@/contracts/types';

const plainText = revealRichTextToString(post.content);
const authorId = extractRevealRelationId(post.author);
```

## Usage Patterns

### Pattern 1: Using RevealUI Content Engine Types Directly

**When:** Infrastructure layer, data access, repositories

```typescript
import type {
  Post,
  User,
  Product,
} from '@revealui/infrastructure/cms/db/revealui-types';

// Working directly with RevealUI Content Engine types
async function getPost(id: string): Promise<Post | null> {
  return await revealui.findByID({ collection: 'posts', id });
}
```

### Pattern 2: Using Domain Types

**When:** Business logic, application services, use cases

```typescript
import type { DomainPost, DomainUser } from '@/contracts/types';

// Pure domain entities for business logic
function validatePost(post: DomainPost): boolean {
  return post.status === 'published' && post.title.length > 0;
}
```

### Pattern 3: Using Enhanced/Hybrid Types

**When:** Presentation layer, components, API responses

```typescript
import type { EnhancedPost, PostWithRevealUI } from '@/contracts/types';

// Hybrid types with both RevealUI Content Engine and domain data
function PostCard({ post }: { post: PostWithRevealUI }) {
  // Access both layers
  const title = post.title; // Domain
  const muxData = post.mux; // RevealUI Content Engine (if applicable)
  return <div>{title}</div>;
}
```

### Pattern 4: Transformation Between Layers

**When:** Adapters, mappers, data transformers

```typescript
import type { Post, DomainPost, PostFromRevealUI } from '@/contracts/types';

// Transform RevealUI Content Engine to Domain
function revealToDomain(revealuiPost: Post): DomainPost {
  return {
    id: revealuiPost.id,
    title: revealuiPost.title,
    content: revealRichTextToString(revealuiPost.content),
    excerpt: revealuiPost.excerpt,
    status: revealuiPost.status || 'draft',
    // ... map other fields
  };
}

// Or use the mapper type
type MappedPost = PostFromRevealUI<Post>;
```

## Best Practices

### 1. Layer Boundaries

- **Infrastructure:** Use RevealUI Content Engine types directly
- **Domain:** Use domain entities only
- **Application:** Use enhanced/hybrid types
- **Presentation:** Use enhanced/hybrid types

### 2. Type Safety

Always leverage TypeScript's type checking:

```typescript
// Good: Type-safe
const posts: Post[] = await findMany({
  where: { status: { equals: 'published' } },
});

// Avoid: Using `any`
const posts: any[] = await findMany({ where: { status: 'published' } });
```

### 3. Transformation

Use type-safe transformations:

```typescript
// Good: Use helper functions
const text = revealRichTextToString(post.content);
const authorId = extractRevealRelationId(post.author);

// Avoid: Manual extraction
const text = post.content.root.children.map(c => c.text).join('');
```

### 4. Query Building

Use type-safe query builders:

```typescript
// Good: Type-safe where clause
const options: RevealUIQueryOptions<RevealUIPost> = {
  where: { status: { equals: 'published' } },
  select: { title: true, excerpt: true },
  limit: 10,
};

// Avoid: Plain objects without type safety
const options = { where: { status: 'published' } };
```

### 5. Error Handling

Use type guards for runtime safety:

```typescript
// Good: Type guards
if (isPublishedEntity(post)) {
  // TypeScript knows post is PublishedEntity
  renderPost(post);
}

// Avoid: Manual checks
if (post.status === 'published') {
  renderPost(post); // post might still be any type
}
```

## Common Transformations

### Rich Text to String

```typescript
import { revealRichTextToString } from '@/contracts/types';

const excerpt = revealRichTextToString(post.content);
```

### Relation to ID

```typescript
import { extractRevealRelationId } from '@/contracts/types';

const categoryId = extractRevealRelationId(post.categories?.[0]);
```

### Timestamp to Date

```typescript
import { revealTimestampToDate } from '@/contracts/types';

const publishedDate = revealTimestampToDate(post.createdAt);
```

### Create Input Generation

```typescript
import type { RevealUICreateInput } from '@/contracts/types';

type NewPost = RevealUICreateInput<Post>;
const postData: NewPost = {
  title: 'New Post',
  content: '...',
  // No id, createdAt, updatedAt needed
};
```

### Update Input Generation

```typescript
import type { RevealUIUpdateInput } from '@/contracts/types';

type PostUpdate = RevealUIUpdateInput<Post>;
const update: PostUpdate = {
  id: 'post-id', // Required
  title: 'Updated Title', // Optional
};
```

## Migration Guide

### Migrating Existing Code

**Step 1: Identify Current Usage**

```typescript
// Before
import type { Post } from '@revealui/infrastructure/cms/db/revealui-types';
function getPost(id: string): Promise<Post> { ... }
```

**Step 2: Determine Appropriate Type**

```typescript
// For infrastructure layer
import type { Post } from '@revealui/infrastructure/cms/db/revealui-types';

// For domain layer
import type { DomainPost } from '@/contracts/types';

// For application/presentation layer
import type { EnhancedPost } from '@/contracts/types';
```

**Step 3: Apply Transformations**

```typescript
// Add transformation where needed
import { revealRichTextToString } from '@/contracts/types';

const excerpt = revealRichTextToString(post.content);
```

**Step 4: Update Type Guards**

```typescript
// Use built-in guards
import { isPublishedEntity, isDraftEntity } from '@/contracts/types';

if (isPublishedEntity(post)) {
  // Handle published post
}
```

## Type System Benefits

### 1. Compile-Time Safety

- Catch errors before runtime
- Intellisense support for all operations
- Refactoring confidence

### 2. Self-Documenting Code

- Types serve as documentation
- Clear layer boundaries
- Explicit contracts between layers

### 3. Reduced Duplication

- Single source of truth in RevealUI Content Engine
- Domain extends rather than duplicates
- DRY principles enforced

### 4. Better Developer Experience

- Autocomplete for all operations
- Type-safe transformations
- Helpful error messages

### 5. Maintainability

- Easy to update schema changes propagate
- Clear transformation paths
- Consistent patterns throughout codebase

## Troubleshooting

### Issue: Type conflicts between RevealUI Content Engine and Domain

**Solution:** Use hybrid types or proper transformation:

```typescript
// Use hybrid types
type MyPost = HybridEntity<RevealUIPost, DomainPost>;

// Or transform properly
const domainPost: DomainPost = revealToDomain(revealuiPost);
```

### Issue: Rich text extraction not working

**Solution:** Use the helper function:

```typescript
import { revealRichTextToString } from '@/contracts/types';

const text = revealRichTextToString(post.content);
```

### Issue: Relation fields causing type errors

**Solution:** Use the relation helpers:

```typescript
import { extractRevealRelationId } from '@/contracts/types';

const id = extractRevealRelationId(post.author); // Works for string | User
```

### Issue: Need to access nested RevealUI Content Engine fields

**Solution:** Use deep select or type the full structure:

```typescript
import type { RevealUIDeepSelect } from '@/contracts/types';

const select: RevealUIDeepSelect<Post> = {
  title: true,
  author: {
    name: true,
    email: true,
  },
};
```

## Further Reading

- [RevealUI Content Engine Types Documentation](https://revealui.com/docs/typescript/overview)
- [Domain-Driven Design](https://martinfowler.com/bliki/DomainDrivenDesign.html)
- [TypeScript Utility Types](https://www.typescriptlang.org/docs/handbook/utility-types.html)
- [Type System Patterns in Large Applications](https://effectivetypescript.com/)

## Contributors

This type system was designed to support Clean Architecture and Domain-Driven
Design principles while maintaining full compatibility with RevealUI Content Engine generated
types.
