import type { DatabaseConfig, RevealUILoggerAdapterConfig } from '@revealui/core/shared-types';
import { z } from 'zod';

export interface AuthConfig {
  jwt: {
    secret: string;
    expiresIn: string;
    refreshExpiresIn: string;
    issuer: string;
    audience: string;
  };
  session: {
    secret: string;
    maxAge: number;
    secure: boolean;
    httpOnly: boolean;
    sameSite: 'strict' | 'lax' | 'none';
  };
  password: {
    minLength: number;
    requireUppercase: boolean;
    requireLowercase: boolean;
    requireNumbers: boolean;
    requireSpecialChars: boolean;
    saltRounds: number;
  };
  twoFactor: {
    enabled: boolean;
    issuer: string;
    algorithm: string;
    digits: number;
    period: number;
    window: number;
  };
  oauth: Record<
    string,
    {
      enabled: boolean;
      clientId?: string;
      clientSecret?: string;
      callbackUrl?: string;
      [key: string]: unknown;
    }
  >;
}

export interface EmailConfig {
  provider: 'resend' | 'smtp' | 'mock';
  smtp?: {
    host: string;
    port: number;
    secure: boolean;
    username?: string;
    password?: string;
  };
  from?: string | { email: string; name?: string };
  templates?: {
    directory: string;
    engine: string;
  };
}

export type { DatabaseConfig, RevealUILoggerAdapterConfig };

/**
 * Environment Variables Type Definitions
 *
 * Defines all environment variables used throughout the application
 */

/**
 * Environment Variable Schema using Zod
 * Validates environment variables at runtime
 */
export const EnvironmentSchema = z
  .object({
    // App Configuration
    APP_ENV: z.enum(['development', 'production', 'test']).default('development'),
    APP_NAME: z.string().default('reveal UI CMS'),
    PORT: z.coerce.number().default(3000),
    ORG_NAME: z.string().default('reveal-UI'),
    TIMING: z.coerce.number().optional(),
    DEBUG: z.coerce.boolean().default(false),

    // Server URLs
    NEXT_PUBLIC_SERVER_URL: z.string().url().optional(),
    NEXT_PUBLIC_BASE_URL: z.string().url().optional(),
    NEXT_PUBLIC_API_URL: z.string().url().optional(),
    NEXT_PUBLIC_STORAGE_URL: z.string().url().optional(),
    NEXT_PUBLIC_STRIPE_PRICE_ID: z.string().optional(),
    NEXT_PUBLIC_STRIPE_BASIC_PLAN_ID: z.string().optional(),

    // Database
    POSTGRES_URL: z.string().optional(),
    DATABASE_URL: z.string().optional(),
    NEON_BRANCH: z.string().optional(),
    NEON_DB_USER: z.string().optional(),
    PGHOST: z.string().optional(),
    PGDATABASE: z.string().optional(),
    PGUSER: z.string().optional(),
    PGPASSWORD: z.string().optional(),

    // RevealUI Content Engine
    REVEAL_DROP_DATABASE: z.coerce.boolean().default(false),
    REVEAL_DATABASE_POOLING: z.coerce.boolean().default(true),
    REVEAL_DATABASE_PUSH: z.coerce.boolean().default(true),
    REVEAL_DATABASE_MIGRATE: z.coerce.boolean().default(false),
    REVEAL_DATABASE_MIGRATE_DIR: z.string().optional(),
    REVEAL_SERVER_URL: z.string().url().optional(),
    REVEAL_PUBLIC_CLIENT_URL: z.string().url().optional(),
    REVEAL_PREVIEW_SECRET: z.string().optional(),
    REVEAL_EMAIL_FROM: z.string().email().optional(),
    REVEAL_PREVIEW_TOKEN: z.string().optional(),
    REVEAL_PUBLIC_SERVER_URL: z.string().url().optional(),
    REVEAL_SECRET: z.string().min(32).optional(),
    REVEAL_TOKEN: z.string().optional(),
    REVEAL_ADMIN_NAME: z.string().optional(),
    REVEAL_ADMIN_EMAIL: z.string().email().optional(),
    REVEAL_ADMIN_PASSWORD: z.string().optional(),
    REVEAL_JWT_SECRET_BASE: z.string().optional(),
    REVEAL_EMAIL_FROM_NAME: z.string().optional(),
    REVEAL_AUTH_COOKIE_NAME: z.string().default('auth-token'),
    REVEAL_PUBLIC_API_URL: z.string().url().optional(),
    REVEAL_AUTH_TOKEN_EXPIRY: z.coerce.number().default(604800),
    REVEAL_STORAGE_MAX_SIZE: z.coerce.number().default(5242880),
    REVEAL_STORAGE_ALLOWED_TYPES: z.string().default('image/*,video/*'),
    REVEAL_PUBLIC_DRAFT_SECRET: z.string().optional(),

    // Super Admin Auto-Seeding
    REVEAL_SUPERADMIN_EMAIL: z.string().email().optional(),
    REVEAL_SUPERADMIN_PASSWORD: z.string().min(8).optional(),
    REVEAL_SUPERADMIN_USERNAME: z.string().min(3).max(50).optional(),
    REVEAL_SUPERADMIN_NAME: z.string().optional(),
    REVEAL_SUPERADMIN_AUTOLOGIN: z.coerce.boolean().default(false),
    REVEAL_SUPERADMIN_AUTOLOGIN_WHITELIST: z.string().optional(),
    REVEAL_AUTO_SEED_HOMEPAGE: z.coerce.boolean().default(false),

    // Security
    CSRF_SECRET: z.string().optional(),
    CRON_SECRET: z.string().optional(),
    PREVIEW_SECRET: z.string().optional(),
    AUTO_PUSH: z.coerce.boolean().default(false),
    ENCRYPTION_KEY: z.string().optional(),
    AUTH_SECRET: z.string().optional(),

    // Storage (Vercel Blob)
    BLOB_STORAGE_URL: z.string().url().optional(),
    BLOB_READ_WRITE_TOKEN: z.string().optional(),

    // Email (Resend)
    RESEND_API_KEY: z.string().optional(),

    // Plugins
    ENABLE_PLUGIN_AUDIT_LOG: z.coerce.boolean().default(false),
    ENABLE_PLUGIN_RATE_LIMIT: z.coerce.boolean().default(false),
    ENABLE_PLUGIN_PERFORMANCE_MONITOR: z.coerce.boolean().default(false),
    SLOW_QUERY_THRESHOLD: z.coerce.number().default(1000),
    PERFORMANCE_SAMPLE_RATE: z.coerce.number().default(0.1),

    // Media (Mux)
    MUX_TOKEN_ID: z.string().optional(),
    MUX_TOKEN_SECRET: z.string().optional(),
    VERCEL_PROJECT_PRODUCTION_URL: z.string().url().optional(),

    // AI Configuration
    AI_PROVIDER: z.enum(['ai-gateway', 'openai', 'anthropic', 'google']).default('ai-gateway'),
    AI_MODEL: z.string().optional(),
    AI_GATEWAY_API_KEY: z.string().optional(),
    AI_API_KEY: z.string().optional(),

    // Logging
    LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  })
  .passthrough(); // Allow additional environment variables

/**
 * Environment Variables Type
 * Inferred from the Zod schema
 */
export type EnvironmentVariables = z.infer<typeof EnvironmentSchema>;

