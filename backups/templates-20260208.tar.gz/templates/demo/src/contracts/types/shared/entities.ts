// =======
// ENTITY TYPES
// =======
// Standard entity interfaces with timestamps and IDs

/**
 * Standard entity with timestamps
 */
export interface TimestampedEntity {
  createdAt: string;
  updatedAt: string;
}

/**
 * Standard entity with ID
 */
export interface IdentifiableEntity {
  id: string;
}

/**
 * Complete entity combining ID and timestamps
 */
export interface StandardEntity extends IdentifiableEntity, TimestampedEntity {}
