// =======
// FILTER TYPES
// =======
// Search, filtering, sorting, and query options

/**
 * Base filter interface for search and filtering operations
 */
export interface BaseFilter {
  search?: string;
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Generic filter for any entity type
 */
export type EntityFilter<T> = Partial<T> & BaseFilter;

/**
 * Generic search options
 */
export interface SearchOptions {
  query?: string;
  fields?: string[];
  fuzzy?: boolean;
  caseSensitive?: boolean;
  regex?: boolean;
}

/**
 * Sorting options
 */
export interface SortOptions {
  field: string;
  direction: 'asc' | 'desc';
}

/**
 * Query options combining filtering, pagination, and sorting
 */
export interface QueryOptions extends BaseFilter {
  include?: string[];
  select?: string[];
  populate?: string[];
  sort?: SortOptions[];
}
