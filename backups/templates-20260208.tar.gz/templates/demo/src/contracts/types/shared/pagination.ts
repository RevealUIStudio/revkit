// =======
// PAGINATION TYPES
// =======
// Standard pagination parameters and result wrappers

/**
 * Pagination parameters interface
 */
export interface PaginationParams {
  page?: number;
  limit?: number;
  sort?: string;
  order?: 'asc' | 'desc';
  search?: string;
}

/**
 * Paginated result wrapper with enhanced metadata
 */
export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
  hasNextPage?: boolean; // Alternative naming for compatibility
  hasPrevPage?: boolean; // Alternative naming for compatibility
}
