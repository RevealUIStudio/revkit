// =======
// TYPE HELPER UTILITIES
// =======
// Generic type helper utilities for data manipulation and RevealUI transformations.
//
// NOTE: This file contains GENERIC utilities that work with any types.
// For RevealUI-specific utilities that require RevealUIEntity constraints,
// see infrastructure/reveal-utils.ts.

import type { RevealUIRichText } from '@revealui/infrastructure/extended-reveal';

/**
 * Create data type helper - removes system-generated fields
 */
export type CreateData<T> = Omit<T, 'id' | 'createdAt' | 'updatedAt'>;

/**
 * Update data type helper - makes all fields optional except system fields
 */
export type UpdateData<T> = Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt'>>;

// ====================================================================
// REVEALUI-SPECIFIC HELPERS
// ====================================================================

/**
 * Extract plain text content from RevealUI rich text field
 * Handles both string and rich text object formats
 */
export type ExtractRichTextContent<T> = T extends RevealUIRichText
  ? string
  : T extends string
    ? string
    : T extends null | undefined
      ? string | undefined
      : never;

/**
 * Convert RevealUI rich text to string
 * Runtime helper for extracting text from rich text fields
 */
export function revealRichTextToString(
  value: RevealUIRichText | string | null | undefined
): string {
  if (typeof value === 'string') return value;
  if (!value || typeof value !== 'object') return '';
  if ('root' in value && value.root && typeof value.root === 'object') {
    const children = value.root.children;
    if (Array.isArray(children)) {
      return children
        .map((child: unknown) => {
          if (
            child &&
            typeof child === 'object' &&
            'text' in child &&
            typeof child.text === 'string'
          ) {
            return child.text;
          }
          if (
            child &&
            typeof child === 'object' &&
            'children' in child &&
            Array.isArray(child.children)
          ) {
            return child.children
              .map((c: unknown) =>
                c && typeof c === 'object' && 'text' in c && typeof c.text === 'string'
                  ? c.text
                  : ''
              )
              .join('');
          }
          return '';
        })
        .join(' ');
    }
  }
  return '';
}

/**
 * Extract ID from RevealUI Content Engine relation field
 * Handles both string ID and full entity object
 */
export function extractRevealRelationId<T extends string | { id: string }>(relation: T): string {
  if (typeof relation === 'string') return relation;
  if (relation && typeof relation === 'object' && 'id' in relation) {
    return relation.id;
  }
  return '';
}

/**
 * Coerce RevealUI Content Engine timestamp to Date object
 * Handles both string and Date formats
 */
export function revealTimestampToDate(timestamp: string | Date): Date {
  return timestamp instanceof Date ? timestamp : new Date(timestamp);
}

/**
 * Coerce RevealUI Content Engine optional timestamp to Date or null
 */
export function optionalRevealTimestampToDate(
  timestamp: string | Date | null | undefined
): Date | null {
  if (!timestamp) return null;
  return revealTimestampToDate(timestamp);
}

/**
 * Safe number coercion from RevealUI Content Engine fields
 * Handles null, undefined, and string conversion
 */
export function revealNumberCoerce(value: unknown): number {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const parsed = parseFloat(value);
    return Number.isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

/**
 * Safe string coercion from RevealUI Content Engine fields
 * Handles null and undefined
 */
export function revealStringCoerce(value: unknown): string {
  if (typeof value === 'string') return value;
  if (value === null || value === undefined) return '';
  return String(value);
}

/**
 * Safe boolean coercion from RevealUI Content Engine fields
 * Handles null and undefined
 */
export function revealBooleanCoerce(value: unknown): boolean {
  if (typeof value === 'boolean') return value;
  if (value === null || value === undefined) return false;
  return Boolean(value);
}

// ====================================================================
// CONDITIONAL TYPE EXTRACTORS
// ====================================================================

/**
 * Extract the entity type from a RevealUI Content Engine relation field
 * Handles: string | Entity → Entity
 */
export type ExtractRevealUIRelationEntity<T> = T extends string
  ? never
  : T extends object
    ? T
    : never;

/**
 * Check if a field is a RevealUI Content Engine relation
 */
export type IsRevealUIRelation<T> = T extends string | object ? true : false;

/**
 * Get all relation fields from a type
 */
export type RelationFields<T> = {
  [K in keyof T]: IsRevealUIRelation<T[K]> extends true ? K : never;
}[keyof T];

/**
 * Get all non-relation fields from a type
 */
export type NonRelationFields<T> = {
  [K in keyof T]: IsRevealUIRelation<T[K]> extends true ? never : K;
}[keyof T];

// ====================================================================
// NESTED FIELD ACCESS
// ====================================================================

/**
 * Get nested field type by dot-notation path
 * Example: NestedFieldType<Post, 'author.profile.name'>
 *
 * NOTE: For RevealUI Content Engine-specific nested paths with RevealUIEntity constraints,
 * use NestedFieldPath from infrastructure/revealui-utils.ts
 */
export type NestedFieldType<T, Path extends string> = Path extends `${infer K}.${infer Rest}`
  ? K extends keyof T
    ? NestedFieldType<T[K], Rest>
    : never
  : Path extends keyof T
    ? T[Path]
    : never;

/**
 * Flatten RevealUI Content Engine entity to a flat object
 * Useful for transformation and comparison
 */
export type FlattenRevealUIEntity<T> = T extends object ? { [K in keyof T]: T[K] } : T;

// ====================================================================
// TYPE UTILITIES FOR REVEALUI OPERATIONS
// ====================================================================

/**
 * Mark specific fields as required in a type
 * Useful for creating strict types from entities
 *
 * NOTE: For extracting which fields are required (keys), see RequiredFields
 * from infrastructure/revealui-utils.ts
 */
export type RequireFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

/**
 * Mark specific fields as optional in a type
 * Useful for creating flexible types from entities
 *
 * NOTE: For extracting which fields are optional (keys), see OptionalFields
 * from infrastructure/revealui-utils.ts (different signature)
 */
export type OptionalFields<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

/**
 * Exclude null from RevealUI Content Engine nullable fields
 */
export type NonNullableFields<T> = {
  [K in keyof T]: null extends T[K] ? Exclude<T[K], null> : T[K];
};

/**
 * Make all nullable fields required (not null)
 */
export type RequiredNonNullable<T> = {
  [K in keyof T]: NonNullable<T[K]>;
};

// ====================================================================
// FIELD EXTRACTION UTILITIES
// ====================================================================

/**
 * Get fields of a specific type
 */
export type FieldsOfType<T, U> = {
  [K in keyof T]: T[K] extends U ? K : never;
}[keyof T];

/**
 * Get string fields only
 */
export type StringFields<T> = FieldsOfType<T, string>;

/**
 * Get number fields only
 */
export type NumberFields<T> = FieldsOfType<T, number>;

/**
 * Get boolean fields only
 */
export type BooleanFields<T> = FieldsOfType<T, boolean>;

/**
 * Get array fields only
 */
export type ArrayFields<T> = FieldsOfType<T, unknown[]>;
