/**
 * Analytics Event Data Type Definitions
 * Types for analytics tracking and event data
 */

/**
 * Base event data structure
 * Using Record<string, unknown> because event data structure varies by event type
 */
export type EventData =
  /* Using Record<string, unknown> because event data structure varies by event type */ Record<
    string,
    unknown
  >;

/**
 * Page view event data
 */
export interface PageViewEventData extends EventData {
  page: string;
  title?: string;
  referrer?: string;
  path?: string;
  query?: Record<string, string>;
}

/**
 * User action event data
 */
export interface UserActionEventData extends EventData {
  action: string;
  category?: string;
  label?: string;
  value?: number;
}

/**
 * Performance event data
 */
export interface PerformanceEventData extends EventData {
  metric: string;
  value: number;
  unit?: string;
  collection?: string;
  operation?: string;
  duration?: number;
}

/**
 * Error event data
 */
export interface ErrorEventData extends EventData {
  message: string;
  stack?: string;
  errorType?: string;
  errorCode?: string;
  url?: string;
  lineNumber?: number;
  columnNumber?: number;
}

/**
 * Custom event data
 * Using Record<string, unknown> because custom events can have any structure
 */
export type CustomEventData = EventData;

/**
 * Analytics event metadata
 * Using Record<string, unknown> because metadata structure varies by provider and use case
 */
export type AnalyticsMetadata =
  /* Using Record<string, unknown> because metadata structure varies by provider and use case */ Record<
    string,
    unknown
  >;

/**
 * Tracking options for analytics events
 */
export interface TrackingOptions {
  timestamp?: number;
  userId?: string;
  sessionId?: string;
  // Using AnalyticsMetadata because metadata structure varies by provider and use case
  metadata?: AnalyticsMetadata;
}

/**
 * Analytics event types
 */
export type EventType = 'page_view' | 'user_action' | 'performance' | 'error' | 'custom';

/**
 * Base analytics event structure
 */
export interface AnalyticsEvent {
  type: EventType;
  name: string;
  data: EventData;
  timestamp: number;
  userId?: string;
  sessionId?: string;
  // Using AnalyticsMetadata because metadata structure varies by provider and use case
  metadata?: AnalyticsMetadata;
}
