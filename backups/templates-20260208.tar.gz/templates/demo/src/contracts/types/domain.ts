// ====================================================================
// DOMAIN PLUGIN TYPES
// ====================================================================
// Types for RevealUI Content Engine domain plugins and event system

import type { RevealUIRequest } from '@revealui/content';
import type { ExtendedRevealUIRequest } from './infrastructure/extended-revealui';

/**
 * Domain event data structure
 */
export interface DomainEventData {
  id: string | number;
  collection: string;
  data: unknown;
  previousData?: unknown;
}

/**
 * Domain events plugin options
 */
export interface DomainEventsPluginOptions {
  /**
   * Collections to monitor (empty array = all collections)
   */
  collections?: string[];
  /**
   * Enable global event handlers registration
   * @default true
   */
  enableGlobalHooks?: boolean;
  /**
   * Logging level for event operations
   * @default 'info'
   */
  logLevel?: 'debug' | 'info' | 'warn' | 'error';
}

/**
 * Before sync plugin options
 */
export interface BeforeSyncPluginOptions {
  /**
   * Enable or disable the plugin
   * @default true
   */
  enabled?: boolean;
  /**
   * Collections to process (empty = all)
   */
  collections?: string[];
  /**
   * Generate searchable content
   * @default true
   */
  enableSearchIndexing?: boolean;
  /**
   * Run custom validators
   * @default true
   */
  enableValidation?: boolean;
  /**
   * Run custom transformers
   * @default false
   */
  enableTransformation?: boolean;
  /**
   * Map of collection slugs to validation functions
   */
  validators?: Record<string, (data: unknown, revealui: unknown) => Promise<boolean> | boolean>;
  /**
   * Map of collection slugs to transformation functions
   */
  transformers?: Record<string, (data: unknown, revealui: unknown) => Promise<unknown> | unknown>;
}

/**
 * Sync event structure
 */
export interface SyncEvent {
  type: 'before_sync' | 'validation_passed' | 'validation_failed' | 'transformation_applied';
  collection: string;
  operation: string;
  timestamp: Date;
  metadata?: Record<string, unknown>;
}

/**
 * Multi-tenant plugin options
 */
export interface MultiTenantPluginOptions {
  /**
   * Enable or disable the plugin
   * @default true
   */
  enabled?: boolean;
  /**
   * Tenant collection slug
   * @default 'tenants'
   */
  tenantCollection?: string;
  /**
   * Function to resolve tenant ID from request
   */
  resolveTenant?: (req: RevealUIRequest) => string | null;
}

/**
 * Re-export ExtendedRevealUIRequest for convenience
 */
export type { ExtendedRevealUIRequest } from './infrastructure/extended-revealui';

/**
 * Performance monitoring plugin types
 */
export interface PerformanceMetricData {
  collection: string;
  operation: 'create' | 'read' | 'update' | 'delete' | 'find' | 'findOne';
  duration: number;
  timestamp: Date;
  userId?: string;
  queryComplexity?: number;
  memoryUsage?: {
    heapUsed: number;
    heapTotal: number;
    external: number;
    rss: number;
  };
  metadata?: Record<string, unknown>;
}

export interface ResponseTimeData {
  operation: string;
  collection: string;
  duration: number;
  timestamp: Date;
  userId?: string;
  queryComplexity?: number;
}

export interface PerformanceMonitorPluginOptions {
  enabled?: boolean;
  collections?: string[];
  trackQueries?: boolean;
  trackResponseTimes?: boolean;
  trackMemoryUsage?: boolean;
  slowQueryThreshold?: number;
  sampleRate?: number;
  onPerformanceMetric?: (metric: PerformanceMetricData) => void;
  enableDetailedLogging?: boolean;
  storeInDatabase?: boolean;
}

/**
 * Audit log plugin types
 */
export interface AuditLogEntry {
  collection: string;
  createdAt: string;
  documentId: string;
  operation: 'create' | 'read' | 'update' | 'delete';
  userId?: string;
  userEmail?: string;
  previousData?: Record<string, unknown>;
  newData?: Record<string, unknown>;
  changes?: Record<string, unknown>;
  metadata?: {
    timestamp?: string;
    ip?: string;
    userAgent?: string;
    requestId?: string;
  };
}

export interface AuditLogPluginOptions {
  collections?: string[];
  enabled?: boolean;
  excludeFields?: string[];
  includeMetadata?: boolean;
  includeUser?: boolean;
  maxLogs?: number;
  onAuditLog?: (entry: AuditLogEntry) => void;
  operations?: Array<'create' | 'read' | 'update' | 'delete'>;
  storeInDatabase?: boolean;
}

/**
 * Cache plugin types
 */
export interface CacheEvent {
  type: 'cache_hit' | 'cache_miss' | 'cache_set' | 'cache_invalidation';
  collection: string;
  operation: string;
  key: string;
  latency: number;
  timestamp: Date;
}

export interface CacheAnalytics {
  hits: number;
  misses: number;
  sets: number;
  invalidations: number;
  totalLatency: number;
}

export interface RevealUICachePluginOptions {
  enabled?: boolean;
  collections?: string[];
  ttl?: number;
  enableAnalytics?: boolean;
  keyGenerator?: (collection: string, operation: string, params: Record<string, unknown>) => string;
  skip?: (req: ExtendedRevealUIRequest) => boolean;
}

/**
 * Plugin management types
 */
export interface PluginConfig {
  name: string;
  plugin: unknown; // Plugin type from revealui
  enabled: boolean;
  priority: number;
  version?: string;
  dependencies?: string[];
  performance?: {
    enableMetrics?: boolean;
    slowThreshold?: number;
    memoryThreshold?: number;
  };
  environment?: {
    development?: boolean;
    production?: boolean;
    test?: boolean;
  };
}

export interface PluginLifecycleEvent {
  pluginName: string;
  state: string;
  timestamp: number;
  error?: Error;
  metrics?: PluginPerformanceMetrics;
}

export interface PluginManagerOptions {
  maxRetries?: number;
  retryDelay?: number;
  enableErrorRecovery?: boolean;
  onLifecycleEvent?: (event: PluginLifecycleEvent) => void;
}

export interface PluginPerformanceMetrics {
  initializationTime?: number;
  memoryUsage?: number;
  errorCount?: number;
  successCount?: number;
}

/**
 * Cache plugin interface
 */
export interface CachePlugin {
  name: string;
  onBeforeGet(key: string): Promise<void>;
  onAfterGet(key: string, hit: boolean): Promise<void>;
  onBeforeSet(key: string): Promise<void>;
  onAfterSet(key: string): Promise<void>;
  onBeforeDelete(key: string): Promise<void>;
  onAfterDelete(key: string): Promise<void>;
  onBeforeInvalidate(tags: string[]): Promise<void>;
  onAfterInvalidate(tags: string[]): Promise<void>;
  getMetrics(): import('../types/infrastructure/cache').CacheMetrics;
  cleanup(): void;
}
