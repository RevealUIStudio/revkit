/**
 * MCP (Model Context Protocol) Integration Types
 *
 * Type definitions for MCP service interfaces.
 * Used to replace explicit `any` types in MCP service.
 *
 * @module contracts/types/integrations/mcp
 */

/**
 * MCP Agent status
 */
export interface MCPAgent {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  capabilities?: string[];
  metadata?: Record<string, unknown>;
}

/**
 * MCP Task
 */
export interface MCPTask {
  id: string;
  type: string;
  revealui: Record<string, unknown>;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  metadata?: Record<string, unknown>;
}

/**
 * MCP Task execution result
 */
export interface MCPTaskResult {
  success: boolean;
  data?: unknown;
  error?: string;
}

/**
 * MCP Audit log entry
 */
export interface MCPAuditLogEntry {
  id: string;
  timestamp: Date;
  action: string;
  agentId?: string;
  taskId?: string;
  details?: Record<string, unknown>;
}

/**
 * MCP Pending approval
 */
export interface MCPPendingApproval {
  id: string;
  taskId: string;
  requestedAt: Date;
  requesterId?: string;
  details?: Record<string, unknown>;
}

