/**
 * RevealUI Integration Types
 *
 * Type definitions for RevealUI API responses and webhook revealuis.
 * Used to replace explicit `any` types in CMS integrations.
 *
 * @module contracts/types/integrations/reveal
 */

/**
 * RevealUI collection document
 */
export interface RevealUIDocument {
  id: string;
  createdAt: string;
  updatedAt: string;
  [key: string]: unknown;
}

/**
 * RevealUI API response
 */
export interface RevealUIApiResponse<T = RevealUIDocument> {
  docs: T[];
  totalDocs: number;
  limit: number;
  totalPages: number;
  page?: number;
  pagingCounter: number;
  hasPrevPage: boolean;
  hasNextPage: boolean;
  prevPage?: number | null;
  nextPage?: number | null;
}

/**
 * RevealUI find query result
 */
export interface RevealUIFindResult<T = RevealUIDocument> extends RevealUIApiResponse<T> {
  docs: T[];
}

/**
 * RevealUI webhook revealui
 */
export interface RevealUIWebhookRevealUI {
  event: 'create' | 'update' | 'delete';
  collection: string;
  doc: RevealUIDocument;
  previousDoc?: RevealUIDocument;
}

