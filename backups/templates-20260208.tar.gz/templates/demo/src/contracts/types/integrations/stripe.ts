/**
 * Stripe Integration Types
 *
 * Type definitions for Stripe webhook revealuis and API responses.
 * Used to replace explicit `any` types in payment strategies.
 *
 * @module contracts/types/integrations/stripe
 */

/**
 * Stripe webhook event types
 */
export type StripeWebhookEventType =
  | 'payment_intent.succeeded'
  | 'payment_intent.payment_failed'
  | 'payment_intent.canceled'
  | 'charge.succeeded'
  | 'charge.failed'
  | 'charge.refunded'
  | 'customer.subscription.created'
  | 'customer.subscription.updated'
  | 'customer.subscription.deleted'
  | 'invoice.payment_succeeded'
  | 'invoice.payment_failed';

/**
 * Stripe webhook event revealui
 */
export interface StripeWebhookEvent {
  id: string;
  type: StripeWebhookEventType;
  data: {
    object: StripeWebhookDataObject;
  };
  created: number;
  livemode: boolean;
  pending_webhooks: number;
  request?: {
    id: string;
    idempotency_key: string | null;
  };
}

/**
 * Stripe webhook data object (payment intent, charge, etc.)
 */
export interface StripeWebhookDataObject {
  id: string;
  object: string;
  amount?: number;
  currency?: string;
  status?: string;
  customer?: string;
  metadata?: Record<string, string>;
  [key: string]: unknown;
}

/**
 * Stripe payment intent
 */
export interface StripePaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'succeeded' | 'processing' | 'requires_payment_method' | 'requires_confirmation' | 'requires_action' | 'canceled';
  client_secret: string;
  customer?: string;
  metadata?: Record<string, string>;
}

/**
 * Stripe charge
 */
export interface StripeCharge {
  id: string;
  amount: number;
  currency: string;
  status: 'succeeded' | 'pending' | 'failed';
  customer?: string;
  payment_intent?: string;
  metadata?: Record<string, string>;
}

