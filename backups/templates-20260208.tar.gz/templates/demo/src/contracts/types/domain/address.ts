/**
 * Address Interface
 * Standardized address structure for shipping, billing, and user addresses
 */
export interface Address {
  street1: string;
  street2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

/**
 * Shipping Address
 * Extends base address with shipping-specific fields
 */
export interface ShippingAddress extends Address {
  method?: string;
  trackingNumber?: string;
  deliveryInstructions?: string;
}

/**
 * Billing Address
 * Extends base address with billing-specific fields
 */
export interface BillingAddress extends Address {
  company?: string;
  taxId?: string;
}

/**
 * Address Validation Result
 */
export interface AddressValidationResult {
  isValid: boolean;
  errors: string[];
  suggestions?: string[];
}
