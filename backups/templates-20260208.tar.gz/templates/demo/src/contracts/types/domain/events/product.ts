// ====================================================================
// PRODUCT DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';
import type { UpdateEventChanges } from './metadata';

export interface ProductCreatedEvent extends DomainEvent<'product.created'> {
  data: {
    productId: string;
    title: string;
    category: string;
    createdBy: string;
  };
}

export interface ProductUpdatedEvent extends DomainEvent<'product.updated'> {
  data: {
    productId: string;
    changes: UpdateEventChanges;
    updatedBy: string;
  };
}

export interface ProductPublishedEvent extends DomainEvent<'product.published'> {
  data: {
    productId: string;
    publishedBy: string;
    publishedAt: string;
  };
}

export interface ProductDeletedEvent extends DomainEvent<'product.deleted'> {
  data: {
    productId: string;
    deletedBy: string;
    reason?: string;
  };
}
