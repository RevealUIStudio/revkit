// ====================================================================
// BASE DOMAIN PATTERNS
// ====================================================================
// Core domain pattern interfaces and types

/**
 * Base domain entity interface
 */
export interface DomainEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * Domain value object base
 */
export interface ValueObject {
  equals(other: ValueObject): boolean;
}

/**
 * Domain aggregate root marker
 */
export interface AggregateRoot extends DomainEntity {
  readonly __aggregate: 'AggregateRoot';
}

/**
 * Common domain filter interface
 */
export interface WhereFilter {
  [key: string]: unknown;
}
