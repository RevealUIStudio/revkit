// ====================================================================
// SUBSCRIPTION DOMAIN SERVICE
// ====================================================================

import type { Subscription as RevealUISubscription } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { ServiceResult } from '../service-results';

/**
 * Create Subscription Input
 */
export interface CreateSubscriptionInput {
  userId: string;
  plan: string;
  paymentMethod: string;
}

/**
 * Subscription domain service interface
 */
export interface ISubscriptionDomainService {
  createSubscription(data: CreateSubscriptionInput): Promise<ServiceResult<Subscription>>;

  renewSubscription(id: string): Promise<ServiceResult<Subscription>>;
  cancelSubscription(
    id: string,
    cancelAtPeriodEnd: boolean,
    reason?: string
  ): Promise<ServiceResult<Subscription>>;
  reactivateSubscription(id: string): Promise<ServiceResult<Subscription>>;
  changeSubscriptionPlan(id: string, newPlan: string): Promise<ServiceResult<Subscription>>;
  getSubscription(id: string): Promise<ServiceResult<Subscription>>;
  getSubscriptionsByUser(userId: string): Promise<ServiceResult<Subscription[]>>;
  getSubscriptions(filters?: FilterOptions): Promise<ServiceResult<Subscription[]>>;
  processSubscriptionPayment(id: string): Promise<ServiceResult<Subscription>>;
}
