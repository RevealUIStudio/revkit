// ====================================================================
// USER DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';
import type { UpdateEventChanges } from './metadata';

export interface UserRegisteredEvent extends DomainEvent<'user.registered'> {
  data: {
    userId: string;
    email: string;
    username: string;
    registrationMethod: string;
  };
}

export interface UserUpdatedEvent extends DomainEvent<'user.updated'> {
  data: {
    userId: string;
    changes: UpdateEventChanges;
    updatedBy: string;
  };
}

export interface UserDeletedEvent extends DomainEvent<'user.deleted'> {
  data: {
    userId: string;
    deletedBy: string;
    reason?: string;
  };
}

export interface UserLoginEvent extends DomainEvent<'user.login'> {
  data: {
    userId: string;
    sessionId: string;
    loginMethod: string;
    ipAddress?: string;
    userAgent?: string;
  };
}

export interface UserLogoutEvent extends DomainEvent<'user.logout'> {
  data: {
    userId: string;
    sessionId: string;
    logoutReason: 'user' | 'expired' | 'admin' | 'security';
  };
}
