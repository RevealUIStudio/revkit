// ====================================================================
// DOMAIN ERRORS
// ====================================================================
// Domain-specific error classes

import { DomainError as BaseDomainError } from '@/domain/errors/BaseDomainError';
import type { ErrorDetails } from '../errors/error-details';

/**
 * Domain error base class
 * Extends base DomainError for contract/pattern layer
 */
export class DomainError extends BaseDomainError {
  constructor(
    message: string,
    code: string = 'DOMAIN_ERROR',
    details?: ErrorDetails,
    cause?: Error
  ) {
    super(message, code, details, cause);
  }

  static fromError(
    error: Error,
    code: string = 'DOMAIN_ERROR',
    details?: ErrorDetails
  ): DomainError {
    return new DomainError(error.message, code, details, error);
  }
}

/**
 * Business rule violation error
 */
export class BusinessRuleViolationError extends DomainError {
  constructor(rule: string, details?: ErrorDetails) {
    super(`Business rule violated: ${rule}`, 'BUSINESS_RULE_VIOLATION', details);
  }
}

/**
 * Entity not found error
 */
export class EntityNotFoundError extends DomainError {
  constructor(entityType: string, entityId: string) {
    super(`${entityType} with id ${entityId} not found`, 'ENTITY_NOT_FOUND', {
      entityType,
      entityId,
    });
  }
}

/**
 * Validation error for domain objects
 */
export class DomainValidationError extends DomainError {
  constructor(field: string, message: string, value?: unknown, details?: ErrorDetails) {
    super(`Validation failed for field '${field}': ${message}`, 'VALIDATION_ERROR', {
      field,
      message,
      value,
      ...details,
    } as ErrorDetails);
  }
}

/**
 * Concurrency conflict error
 */
export class ConcurrencyError extends DomainError {
  constructor(resourceType: string, resourceId: string, expectedVersion: number) {
    super(`Concurrency conflict on ${resourceType} ${resourceId}`, 'CONCURRENCY_CONFLICT', {
      resourceType,
      resourceId,
      expectedVersion,
    });
  }
}

/**
 * Authorization error
 */
export class AuthorizationError extends DomainError {
  constructor(action: string, userId?: string, details?: ErrorDetails) {
    super(`Unauthorized action: ${action}`, 'AUTHORIZATION_ERROR', {
      action,
      userId,
      ...details,
    } as ErrorDetails);
  }
}

/**
 * Type guard for domain errors
 */
export function isDomainError(error: unknown): error is DomainError {
  return error instanceof DomainError;
}
