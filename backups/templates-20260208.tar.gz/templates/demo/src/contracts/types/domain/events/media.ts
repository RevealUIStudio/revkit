// ====================================================================
// MEDIA DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';

export interface MediaUploadedEvent extends DomainEvent<'media.uploaded'> {
  data: {
    mediaId: string;
    filename: string;
    mimeType: string;
    size: number;
    uploadedBy: string;
  };
}

export interface MediaProcessedEvent extends DomainEvent<'media.processed'> {
  data: {
    mediaId: string;
    processingType: 'thumbnail' | 'optimization' | 'conversion';
    originalSize: number;
    processedSize: number;
    processingTime: number;
  };
}

export interface MediaDeletedEvent extends DomainEvent<'media.deleted'> {
  data: {
    mediaId: string;
    deletedBy: string;
    reason?: string;
  };
}
