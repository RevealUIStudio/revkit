// ====================================================================
// FIGHT DOMAIN SERVICE
// ====================================================================

import type { Fight as RevealUIFight } from '@revealui/infrastructure/cms/db/revealui-types';
import type { ServiceResult, ValidationResult } from '../../../core';
import type { FilterOptions } from '@revealui/infrastructure/query';

/**
 * Create Fight Input
 */
export interface CreateFightInput {
  title: string;
  description: string;
  scheduledDate: string;
  weightClass: string;
  fighterIds: string[];
  location: string;
  venue?: string;
  ticketPrice?: number;
  streamPrice?: number;
  payPerView: boolean;
}

/**
 * Update Fight Input
 */
export interface UpdateFightInput {
  title?: string;
  description?: string;
  scheduledDate?: string;
  weightClass?: string;
  fighterIds?: string[];
  location?: string;
  venue?: string;
  ticketPrice?: number;
  streamPrice?: number;
  payPerView?: boolean;
}

/**
 * Fight Result
 */
export interface FightResult {
  winner: string;
  method: string;
  round: number;
  time: string;
  notes?: string;
}

/**
 * Fight domain service interface
 */
export interface IFightDomainService {
  createFight(data: CreateFightInput): Promise<ServiceResult<Fight>>;

  updateFight(id: string, data: UpdateFightInput): Promise<ServiceResult<Fight>>;

  completeFight(id: string, result: FightResult): Promise<ServiceResult<Fight>>;

  cancelFight(id: string, reason: string): Promise<ServiceResult<Fight>>;
  getFight(id: string): Promise<ServiceResult<Fight>>;
  getFights(filters?: FilterOptions): Promise<ServiceResult<Fight[]>>;
  validateFightData(
    data: CreateFightInput | UpdateFightInput
  ): Promise<ValidationResult<CreateFightInput | UpdateFightInput>>;
}
