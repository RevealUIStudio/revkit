// ====================================================================
// CATEGORY DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';
import type { UpdateEventChanges } from './metadata';

export interface CategoryCreatedEvent extends DomainEvent<'category.created'> {
  data: {
    categoryId: string;
    name: string;
    slug: string;
    parentId?: string;
  };
}

export interface CategoryUpdatedEvent extends DomainEvent<'category.updated'> {
  data: {
    categoryId: string;
    changes: UpdateEventChanges;
    updatedBy: string;
  };
}

export interface CategoryDeletedEvent extends DomainEvent<'category.deleted'> {
  data: {
    categoryId: string;
    deletedBy: string;
    reason?: string;
  };
}
