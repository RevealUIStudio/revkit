// ====================================================================
// ORDER DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';

export interface OrderCreatedEvent extends DomainEvent<'order.created'> {
  data: {
    orderId: string;
    userId: string;
    total: number;
    currency: string;
    items: Array<{
      productId: string;
      quantity: number;
      price: number;
    }>;
  };
}

export interface OrderPaidEvent extends DomainEvent<'order.paid'> {
  data: {
    orderId: string;
    paymentId: string;
    amount: number;
    currency: string;
    paymentMethod: string;
  };
}

export interface OrderShippedEvent extends DomainEvent<'order.shipped'> {
  data: {
    orderId: string;
    trackingNumber?: string;
    carrier?: string;
    shippedAt: string;
  };
}

export interface OrderDeliveredEvent extends DomainEvent<'order.delivered'> {
  data: {
    orderId: string;
    deliveredAt: string;
  };
}

export interface OrderCancelledEvent extends DomainEvent<'order.cancelled'> {
  data: {
    orderId: string;
    cancelledBy: string;
    reason: string;
    refundAmount?: number;
  };
}
