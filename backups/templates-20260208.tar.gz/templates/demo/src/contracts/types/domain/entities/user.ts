// ====================================================================
// USER DOMAIN ENTITIES
// ====================================================================

import type { User as RevealUIUser } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedUser,
  HybridEntity,
  RevealUIToDomainUserMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';
import type { BaseEntity } from './base';

export type UserRole = 'super-admin' | 'admin' | 'editor' | 'user' | 'guest';
export type UserPermission = 'read' | 'write' | 'delete' | 'admin' | 'moderate' | 'publish';
export type UserStatus = 'active' | 'inactive' | 'suspended';

export interface UserPreferences {
  emailNotifications: boolean;
  pushNotifications: boolean;
  privacyLevel: 'public' | 'friends' | 'private';
  theme: 'light' | 'dark' | 'auto';
  language: string;
  timezone: string;
  currency: string;
}

export interface DomainUser extends BaseEntity {
  email: string;
  username?: string;
  name?: string;
  role: UserRole;
  status?: UserStatus;
  avatar?: string;
  bio?: string;
  socialMedia?: {
    twitter?: string;
    instagram?: string;
    youtube?: string;
  };
  preferences?: UserPreferences;
}

/**
 * Enhanced User entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
export type UserWithRevealUI = HybridEntity<RevealUIUser, DomainUser>;

/**
 * Enhanced User entity from bridge system
 */
export type UserEnhanced = EnhancedUser;

/**
 * Mapped User from RevealUI Content Engine to domain structure
 * Used when transforming RevealUI Content Engine users to domain users
 */
export type UserFromRevealUI<T extends RevealUIUser = RevealUIUser> = RevealUIToDomainUserMapper<T>;

/**
 * Type predicate to check if a value is a user with revealui data
 */
export function isUserWithRevealUI(value: unknown): value is UserWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'email' in value &&
    '__source' in value &&
    // Using Record<string, unknown> because value structure varies and __source property cannot be strictly typed
    (value as Record<string, unknown>)['__source'] === 'hybrid'
  );
}

export interface UserDelegation extends BaseEntity {
  delegatorId: string;
  delegateId: string;
  permissions: UserPermission[];
  scope: 'global' | 'tenant' | 'resource';
  expiresAt?: string;
  isActive: boolean;
  // Using Record<string, unknown> because user metadata structure varies by user type and cannot be strictly typed
  metadata: /* Using Record<string, unknown> because user metadata structure varies by user type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

export interface DelegationAnalytics {
  totalDelegationsGiven: number;
  totalDelegationsReceived: number;
  activeDelegationsGiven: number;
  activeDelegationsReceived: number;
  expiredDelegations: number;
  revokedDelegations: number;
  delegationSuccessRate: number;
  mostDelegatedPermissions: UserPermission[];
  delegationTimeline: Array<{
    date: string;
    delegationsGiven: number;
    delegationsReceived: number;
  }>;
}
