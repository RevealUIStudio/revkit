// This file has been consolidated into cart.ts
// Service interface moved to interfaces/domain/services/ICartService.ts
// Data types remain in types/domain/services/cart.ts
