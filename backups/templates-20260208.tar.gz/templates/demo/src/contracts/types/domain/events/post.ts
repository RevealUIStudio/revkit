// ====================================================================
// POST DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';
import type { UpdateEventChanges } from './metadata';

export interface PostCreatedEvent extends DomainEvent<'post.created'> {
  data: {
    postId: string;
    authorId: string;
    title: string;
    status: string;
  };
}

export interface PostPublishedEvent extends DomainEvent<'post.published'> {
  data: {
    postId: string;
    publishedBy: string;
    publishedAt: string;
  };
}

export interface PostUpdatedEvent extends DomainEvent<'post.updated'> {
  data: {
    postId: string;
    changes: UpdateEventChanges;
    updatedBy: string;
  };
}

export interface PostDeletedEvent extends DomainEvent<'post.deleted'> {
  data: {
    postId: string;
    deletedBy: string;
    reason?: string;
  };
}

export interface PostViewedEvent extends DomainEvent<'post.viewed'> {
  data: {
    postId: string;
    userId?: string;
    sessionId: string;
    ipAddress?: string;
    userAgent?: string;
  };
}
