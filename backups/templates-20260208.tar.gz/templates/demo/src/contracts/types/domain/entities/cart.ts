// ====================================================================
// CART DOMAIN ENTITIES
// ====================================================================

import type {
  Cart as RevealUICart,
  Product as RevealUIProduct,
} from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedCart,
  HybridEntity,
  RevealUIToDomainCartMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';
import type { BaseEntity } from './base';
import type { BillingAddress, Currency, ShippingAddress } from './order';

/**
 * Cart item interface
 * Note: variantId and price use base types (string, number) directly
 * as they are simple primitives. Future enhancements may introduce
 * specific types for ProductVariant and Price structures.
 */
export interface CartItem {
  id: string;
  productId: string;
  product: RevealUIProduct | string;
  variantId?: string;
  variant?: string;
  quantity: number;
  price: number;
  total: number;
}

export interface CartTotals {
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
}

export interface DomainCart extends BaseEntity {
  userId?: string;
  sessionId?: string;
  items: CartItem[];
  totals: {
    subtotal: number;
    tax: number;
    shipping: number;
    discount: number;
    total: number;
    currency: Currency;
  };
  appliedCoupons?: Array<{
    code: string;
    discount: number;
    type: 'percentage' | 'fixed';
  }>;
  shippingAddress?: ShippingAddress;
  billingAddress?: BillingAddress;
  expiresAt?: string;
}

// Alias for backward compatibility
export type Cart = DomainCart;

// Re-export address types from order for consistency
export type { ShippingAddress, BillingAddress } from './order';

/**
 * Enhanced Cart entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
export type CartWithRevealUI = HybridEntity<RevealUICart, DomainCart>;

/**
 * Enhanced Cart entity from bridge system
 */
export type CartEnhanced = EnhancedCart;

/**
 * Cart transformed from RevealUI Content Engine
 */
export type CartFromRevealUI<T extends RevealUICart = RevealUICart> = RevealUIToDomainCartMapper<T>;

/**
 * Type guard to check if cart has RevealUI Content Engine data
 */
export function isCartWithRevealUI(value: unknown): value is CartWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'items' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
