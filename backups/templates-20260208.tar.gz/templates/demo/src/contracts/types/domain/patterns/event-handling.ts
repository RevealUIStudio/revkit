// ====================================================================
// EVENT HANDLING PATTERNS
// ====================================================================
// Domain event publisher and handler interfaces

import type { DomainEvent } from '../events/base';

/**
 * Domain event publisher interface
 */
export interface DomainEventPublisher {
  publish(event: DomainEvent): Promise<void>;
  publishAll(events: DomainEvent[]): Promise<void>;
}

/**
 * Domain event handler interface
 */
export interface DomainEventHandler<T extends DomainEvent = DomainEvent> {
  handle(event: T): Promise<void>;
  canHandle(event: DomainEvent): event is T;
}
