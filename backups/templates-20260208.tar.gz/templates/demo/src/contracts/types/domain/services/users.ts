export interface UserFilters {
  role?: string;
  status?: string;
  searchTerm?: string;
  createdAfter?: string;
  createdBefore?: string;
  isVerified?: boolean;
  lastLoginAfter?: string;
  lastLoginBefore?: string;
}

export interface UserSortOptions {
  field: 'createdAt' | 'updatedAt' | 'lastLoginAt' | 'email' | 'name';
  direction: 'asc' | 'desc';
}

export interface UserListResponse {
  users: Array<{
    id: string;
    email: string;
    username?: string;
    role: string;
    status: string;
    isVerified: boolean;
    createdAt: string;
    lastLoginAt?: string;
  }>;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface UserProfileUpdate {
  username?: string;
  firstName?: string;
  lastName?: string;
  bio?: string;
  avatar?: string;
  socialMedia?: {
    twitter?: string;
    instagram?: string;
    youtube?: string;
    website?: string;
  };
  preferences?: {
    theme?: 'light' | 'dark' | 'auto';
    language?: string;
    timezone?: string;
    currency?: string;
    emailNotifications?: boolean;
    pushNotifications?: boolean;
  };
}
