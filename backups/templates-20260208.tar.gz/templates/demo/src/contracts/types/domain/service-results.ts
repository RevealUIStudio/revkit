// =======
// SERVICE RESULT TYPES
// =======
// Re-exports from unified result system

import type { ServiceResult as SharedServiceResult } from "@revealui/core/shared-types";
import type { ServiceMetadata } from "./service-metadata";

// Service result interface
export type ServiceResult<T> = SharedServiceResult<T> & {
  details?: unknown;
  metadata?: ServiceMetadata;
};

// Validation error interface
export interface ValidationError {
  field: string;
  message: string;
  code: string;
  value?: unknown;
}

// Validation result interface
export interface ValidationResult<T> {
  success: boolean;
  data?: T;
  errors: ValidationError[];
  warnings?: string[];
}

/**
 * Service paginated result wrapper
 */
export interface ServicePaginatedResult<T> {
  success: boolean;
  data?: T[];
  error?: string;
  totalPages?: number;
  totalDocs?: number;
  page?: number;
}

/**
 * Service validation result interface with enhanced error details
 * NOTE: This wraps ValidationResult from validation layer for service operations
 */
export interface ServiceValidationResult<T> {
  isValid: boolean;
  data?: T;
  errors?: Array<{
    field: string;
    message: string;
    code?: string;
    value?: unknown;
  }>;
}

/**
 * Convert ValidationResult to ServiceValidationResult
 */
export function validationResultToServiceValidation<T>(
  validationResult: ValidationResult<T>
): ServiceValidationResult<T> {
  const result: ServiceValidationResult<T> = {
    isValid: validationResult.success,
  };

  if (validationResult.success && validationResult.data !== undefined) {
    result.data = validationResult.data;
  }

  if (validationResult.errors.length > 0) {
    result.errors = validationResult.errors;
  }

  return result;
}
