// ====================================================================
// CART SERVICE TYPES
// ====================================================================
// Data types for cart domain service operations

/**
 * Cart item data structure
 */
export interface CartItemData {
  productId: string;
  variantId?: string;
  quantity: number;
}

/**
 * Cart totals data structure
 */
export interface CartTotalsData {
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  currency: string;
}

/**
 * Cart response structure
 */
export interface CartResponse {
  id: string;
  userId?: string;
  sessionId?: string;
  items: Array<{
    id: string;
    productId: string;
    variantId?: string;
    quantity: number;
    price: number;
    total: number;
    product: { name: string; image?: string; sku?: string };
  }>;
  totals: CartTotalsData;
  appliedCoupons?: Array<{ code: string; discount: number; type: 'percentage' | 'fixed' }>;
  expiresAt?: string;
  updatedAt: string;
}
