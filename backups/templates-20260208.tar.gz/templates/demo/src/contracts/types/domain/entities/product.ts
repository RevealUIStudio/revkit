// ====================================================================
// PRODUCT DOMAIN ENTITIES
// ====================================================================

import type { Product as RevealUIProduct } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedProduct,
  HybridEntity,
  RevealUIToDomainProductMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';
import type { BaseEntity } from './base';
import type { DomainMedia } from './media';

export type ProductType = 'physical' | 'digital' | 'service';
export type ProductCategory =
  | 'clothing'
  | 'equipment'
  | 'accessories'
  | 'media'
  | 'tickets'
  | 'subscriptions';
export type ProductStatus = 'draft' | 'published' | 'archived';

export interface ProductPrice {
  amount: number;
  currency: string;
  formatted: string;
  originalAmount?: number;
  isOnSale: boolean;
  saleEndsAt?: string;
  discountPercentage?: number;
}

export interface ProductInventory {
  stock: number;
  reserved: number;
  available: number;
  lowStockThreshold: number;
  isUnlimited: boolean;
}

export interface ProductMedia {
  images: DomainMedia[];
  videos?: DomainMedia[];
  thumbnail: DomainMedia;
  gallery: DomainMedia[];
}

export interface ProductVariant extends BaseEntity {
  name: string;
  sku: string;
  price: ProductPrice;
  inventory: ProductInventory;
  attributes: Record<string, string>;
}

export interface ProductMetadata {
  seo?: {
    title?: string;
    description?: string;
    keywords?: string[];
  };
  dimensions?: {
    length: number;
    width: number;
    height: number;
    weight: number;
  };
  shipping?: {
    weight: number;
    requiresSpecialHandling: boolean;
  };
}

export interface DomainProduct extends BaseEntity {
  title: string;
  description: string;
  slug: string;
  type: ProductType;
  category: ProductCategory;
  price: ProductPrice;
  inventory: ProductInventory;
  media: ProductMedia;
  variants?: ProductVariant[];
  metadata: ProductMetadata;
  status: ProductStatus;
  featured: boolean;
}

/**
 * Enhanced Product entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
export type ProductWithRevealUI = HybridEntity<RevealUIProduct, DomainProduct>;

/**
 * Enhanced Product entity from bridge system
 */
export type ProductEnhanced = EnhancedProduct;

/**
 * Mapped Product from RevealUI Content Engine to domain structure
 * Used when transforming RevealUI Content Engine products to domain products
 */
export type ProductFromRevealUI<T extends RevealUIProduct = RevealUIProduct> =
  RevealUIToDomainProductMapper<T>;

/**
 * Type predicate to check if a value is a product with revealui data
 */
export function isProductWithRevealUI(value: unknown): value is ProductWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'title' in value &&
    '__source' in value &&
    (value as any).__source === 'hybrid'
  );
}
