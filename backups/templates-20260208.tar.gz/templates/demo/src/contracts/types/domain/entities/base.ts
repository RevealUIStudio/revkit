import type { BaseEntity, BasePost, BaseUser } from "@revealui/core/shared-types";

export type { BaseEntity, BasePost, BaseUser };
