// ====================================================================
// SPECIFICATION PATTERN
// ====================================================================
// Specification pattern for domain logic composition

/**
 * Specification pattern base interface
 */
export interface Specification<T> {
  isSatisfiedBy(candidate: T): boolean;
  and(other: Specification<T>): Specification<T>;
  or(other: Specification<T>): Specification<T>;
  not(): Specification<T>;
}
