// ====================================================================
// MEDIA DTOs
// ====================================================================
// Data Transfer Objects for media operations

/**
 * Upload media DTO
 */
export interface UploadMediaDTO {
  file: File;
  alt?: string;
  caption?: string;
  folder?: string;
  tags?: string[];
  metaFields?: Record<string, unknown>;
}

/**
 * Update media DTO
 */
export interface UpdateMediaDTO {
  alt?: string;
  caption?: string;
  tags?: string[];
  metaFields?: Record<string, unknown>;
}

/**
 * Media filters DTO
 */
export interface MediaFiltersDTO {
  filename?: string;
  alt?: string;
  mimeType?: string;
  folder?: string;
  tags?: string[];
  sizeMin?: number;
  sizeMax?: number;
  widthMin?: number;
  widthMax?: number;
  heightMin?: number;
  heightMax?: number;
  createdAfter?: string;
  createdBefore?: string;
  limit?: number;
  page?: number;
  sortBy?: 'filename' | 'size' | 'createdAt' | 'updatedAt';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Media search DTO
 */
export interface MediaSearchDTO {
  query: string;
  filters?: MediaFiltersDTO;
  includeVariants?: boolean;
}

/**
 * Media resize DTO
 */
export interface MediaResizeDTO {
  mediaId: string;
  width?: number;
  height?: number;
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp' | 'avif';
  maintainAspectRatio?: boolean;
}

/**
 * Media crop DTO
 */
export interface MediaCropDTO {
  mediaId: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Media folder DTO
 */
export interface MediaFolderDTO {
  name: string;
  parentId?: string;
  description?: string;
}
