import type { ProductStatus, ProductType } from '../entities';

export interface ProductFilters {
  status?: ProductStatus;
  categoryId?: string;
  type?: ProductType;
  searchTerm?: string;
  priceMin?: number;
  priceMax?: number;
  featured?: boolean;
  inStock?: boolean;
}

export interface ProductSortOptions {
  field: 'createdAt' | 'updatedAt' | 'name' | 'price' | 'stock';
  direction: 'asc' | 'desc';
}

export interface ProductListResponse {
  products: Array<{
    id: string;
    name: string;
    description: string;
    price: number;
    currency: string;
    status: ProductStatus;
    featured: boolean;
    inStock: boolean;
    stock: number;
    categoryId?: string;
    images?: string[];
  }>;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// NOTE: CreateProductData and UpdateProductData moved to @/contracts/validation/product
// Import from there for DTO types used in create/update operations
