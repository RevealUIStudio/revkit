// ====================================================================
// ORDER DOMAIN ENTITIES
// ====================================================================

import type {
  Order as RevealUIOrder,
  Product as RevealUIProduct,
} from '@revealui/infrastructure/cms/db/revealui-types';
import type { PaymentMethod, ShippingMethod } from '../enums/ecommerce';
import type { BaseEntity } from './base';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'CAD' | 'AUD';
export type OrderStatus =
  | 'pending'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';
export type PaymentStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'refunded';

export interface Address {
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export type BillingAddress = Address;
export type ShippingAddress = Address;

export interface PaymentInfo {
  status: PaymentStatus;
  method: PaymentMethod;
  transactionId?: string;
  amount: number;
  currency: string;
  processedAt?: string;
}

export interface ShippingInfo {
  address: ShippingAddress;
  method: ShippingMethod;
  trackingNumber?: string;
  estimatedDelivery?: string;
  shippedAt?: string;
  deliveredAt?: string;
}

export interface OrderMetadata {
  notes?: string;
  tags?: string[];
  source: 'web' | 'mobile' | 'admin';
  ipAddress?: string;
  userAgent?: string;
}

/**
 * Product variant identifier - currently just a string ID
 * Future: Replace with proper ProductVariant type when available
 */
export type ProductVariantId = string;

/**
 * Product price - stored as number in order items
 */
export type ProductPrice = number;

export interface OrderItem {
  id: string;
  productId: string;
  product: RevealUIProduct | string;
  variantId?: string;
  variant?: ProductVariantId;
  quantity: number;
  price: ProductPrice;
  total: number;
}

export interface OrderTotals {
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
}

export interface DomainOrder extends BaseEntity {
  userId: string;
  items: OrderItem[];
  totals: OrderTotals;
  status: OrderStatus;
  payment: PaymentInfo;
  shipping?: ShippingInfo;
  metadata: OrderMetadata;
}

// Alias for backward compatibility
export type Order = DomainOrder;

/**
 * Enhanced Order entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type {
  EnhancedOrder,
  HybridEntity,
  RevealUIToDomainOrderMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

export type OrderWithRevealUI = HybridEntity<RevealUIOrder, DomainOrder>;

/**
 * Enhanced Order entity from bridge system
 */
export type OrderEnhanced = EnhancedOrder;

/**
 * Order transformed from RevealUI Content Engine
 */
export type OrderFromRevealUI<T extends RevealUIOrder = RevealUIOrder> = RevealUIToDomainOrderMapper<T>;

/**
 * Type guard to check if order has RevealUI Content Engine data
 */
export function isOrderWithRevealUI(value: unknown): value is OrderWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'items' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
