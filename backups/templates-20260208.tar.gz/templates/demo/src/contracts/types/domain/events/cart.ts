// ====================================================================
// CART DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';

export interface CartCreatedEvent extends DomainEvent<'cart.created'> {
  data: {
    cartId: string;
    userId?: string;
    sessionId: string;
  };
}

export interface CartItemAddedEvent extends DomainEvent<'cart.item.added'> {
  data: {
    cartId: string;
    productId: string;
    quantity: number;
    price: number;
  };
}

export interface CartItemRemovedEvent extends DomainEvent<'cart.item.removed'> {
  data: {
    cartId: string;
    productId: string;
    quantity: number;
  };
}
