// ====================================================================
// DOMAIN PATTERNS - Barrel Export
// ====================================================================
// Re-exports all domain pattern definitions and utilities

export * from './base';
export * from './commands';
export * from './errors';
export * from './event-handling';
export * from './repository';
export * from './specifications';
