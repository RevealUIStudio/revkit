export type PostVisibility = 'public' | 'private' | 'password';

export interface PostSortOptions {
  field: 'createdAt' | 'updatedAt' | 'publishedAt' | 'title' | 'views';
  direction: 'asc' | 'desc';
}
