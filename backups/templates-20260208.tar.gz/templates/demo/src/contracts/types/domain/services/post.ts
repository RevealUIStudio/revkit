// ====================================================================
// POST DOMAIN SERVICE
// ====================================================================

import type { Post as RevealUIPost } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { ServiceResult } from '../service-results';

/**
 * Create Post Input
 */
export interface CreatePostInput {
  title: string;
  content: string;
  authorId: string;
  categoryIds?: string[];
  tags?: string[];
  featured?: boolean;
}

/**
 * Update Post Input
 */
export interface UpdatePostInput {
  title?: string;
  content?: string;
  categoryIds?: string[];
  tags?: string[];
  featured?: boolean;
}

/**
 * Post domain service interface
 */
export interface IPostDomainService {
  createPost(data: CreatePostInput): Promise<ServiceResult<Post>>;

  updatePost(id: string, data: UpdatePostInput): Promise<ServiceResult<Post>>;

  publishPost(id: string): Promise<ServiceResult<Post>>;
  unpublishPost(id: string): Promise<ServiceResult<Post>>;
  deletePost(id: string): Promise<ServiceResult<boolean>>;
  getPost(id: string): Promise<ServiceResult<Post>>;
  getPosts(filters?: FilterOptions): Promise<ServiceResult<Post[]>>;
  getPostsByAuthor(authorId: string): Promise<ServiceResult<Post[]>>;
  incrementPostViews(id: string): Promise<ServiceResult<boolean>>;
}
