/**
 * Result Type Adapters
 * 
 * Adapters for converting between different result type systems at layer boundaries.
 * These adapters maintain type safety while allowing inter-layer communication.
 * 
 * @module contracts/types/domain/result-adapters
 */

import type { ApiResponse } from '../presentation/state/patterns';
import type { ApiMetadata } from '../presentation/api-metadata';
import type { ServiceMetadata } from './service-metadata';
import type { ServiceResult, ServiceValidationResult } from './service-results';

/**
 * Convert ServiceResult to ApiResponse for HTTP endpoints
 * 
 * Use this adapter when returning ServiceResult from API routes
 * that need to return ApiResponse format.
 */
export function serviceResultToApiResponse<T>(
  result: ServiceResult<T>
): ApiResponse<T> {
  if (result.success && result.data !== undefined) {
    return {
      status: 'success',
      data: result.data,
      // Meta is optional - only include if metadata structure is compatible
      ...(result.metadata ? { meta: result.metadata as unknown as ApiMetadata } : {}),
    };
  }

  return {
    status: 'error',
    error: result.error || 'Unknown error',
    code: 500,
    details: result.details,
  };
}

/**
 * Convert ServiceValidationResult to ApiResponse
 * 
 * Use this adapter when returning ServiceValidationResult from API routes.
 */
export function serviceValidationResultToApiResponse<T>(
  result: ServiceValidationResult<T>
): ApiResponse<T> {
  if (result.isValid && result.data !== undefined) {
    return {
      status: 'success',
      data: result.data,
    };
  }

  const errorMessage =
    result.errors && result.errors.length > 0
      ? result.errors.map(e => e.message).join(', ')
      : 'Validation failed';

  return {
    status: 'error',
    error: errorMessage,
    code: 400,
    details: result.errors,
  };
}

/**
 * Convert ApiResponse to ServiceResult
 * 
 * Use this adapter when converting external API responses to ServiceResult.
 */
export function apiResponseToServiceResult<T>(
  response: ApiResponse<T>
): ServiceResult<T> {
  if (response.status === 'success') {
    return {
      success: true,
      data: response.data,
      ...(response.meta ? { metadata: response.meta as unknown as ServiceMetadata } : {}),
    };
  }

  return {
    success: false,
    error: response.error,
    ...(response.code ? { details: { code: response.code } } : {}),
    ...(response.details ? { details: response.details } : {}),
  };
}

/**
 * Convert ServiceResult to a simple success/error object
 * 
 * Use this for simple cases where you only need success/failure.
 */
export function serviceResultToSimple<T>(
  result: ServiceResult<T>
): { success: boolean; data?: T; error?: string } {
  return {
    success: result.success,
    ...(result.data !== undefined ? { data: result.data } : {}),
    ...(result.error ? { error: result.error } : {}),
  };
}

/**
 * Convert ServiceValidationResult to ServiceResult
 * 
 * Use this when you need to convert validation results to service results.
 */
export function serviceValidationResultToServiceResult<T>(
  result: ServiceValidationResult<T>
): ServiceResult<T> {
  if (result.isValid) {
    return {
      success: true,
      ...(result.data !== undefined ? { data: result.data } : {}),
    };
  }

  const errorMessage =
    result.errors && result.errors.length > 0
      ? result.errors.map(e => `${e.field}: ${e.message}`).join(', ')
      : 'Validation failed';

  return {
    success: false,
    error: errorMessage,
    details: result.errors,
  };
}

/**
 * Convert ServiceResult to ServiceValidationResult
 * 
 * Use this when you need to convert service results to validation results.
 */
export function serviceResultToServiceValidationResult<T>(
  result: ServiceResult<T>
): ServiceValidationResult<T> {
  if (result.success) {
    return {
      isValid: true,
      ...(result.data !== undefined ? { data: result.data } : {}),
    };
  }

  return {
    isValid: false,
    errors: [
      {
        field: 'unknown',
        message: result.error || 'Operation failed',
        code: 'SERVICE_ERROR',
        value: result.details,
      },
    ],
  };
}

