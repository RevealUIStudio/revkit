// ====================================================================
// ORDER DOMAIN SERVICE
// ====================================================================

import type { Order as RevealUIOrder } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { BillingAddress, ShippingAddress } from '../address';
import type { ServiceResult } from '../service-results';

/**
 * Payment Data Interface
 */
export interface PaymentData {
  method: string;
  amount: number;
  currency: string;
  // Using Record<string, unknown> because payment metadata structure varies by payment provider and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because payment metadata structure varies by payment provider and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

/**
 * Create Order Input
 */
export interface CreateOrderInput {
  userId: string;
  cartId: string;
  shippingAddress: ShippingAddress;
  billingAddress: BillingAddress;
  paymentMethod: string;
}

/**
 * Order domain service interface
 */
export interface IOrderDomainService {
  createOrder(data: CreateOrderInput): Promise<ServiceResult<Order>>;

  processPayment(orderId: string, paymentData: PaymentData): Promise<ServiceResult<Order>>;
  fulfillOrder(orderId: string): Promise<ServiceResult<Order>>;
  shipOrder(
    orderId: string,
    trackingNumber: string,
    carrier?: string
  ): Promise<ServiceResult<Order>>;
  deliverOrder(orderId: string): Promise<ServiceResult<Order>>;
  cancelOrder(orderId: string, reason: string): Promise<ServiceResult<Order>>;
  refundOrder(orderId: string, amount: number, reason: string): Promise<ServiceResult<Order>>;
  getOrder(id: string): Promise<ServiceResult<Order>>;
  getOrdersByUser(userId: string): Promise<ServiceResult<Order[]>>;
  getOrders(filters?: FilterOptions): Promise<ServiceResult<Order[]>>;
  updateOrderStatus(id: string, status: string): Promise<ServiceResult<Order>>;
}
