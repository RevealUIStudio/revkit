// ====================================================================
// CATEGORY DTOs
// ====================================================================
// Data Transfer Objects for category operations

/**
 * Create category DTO
 */
export interface CreateCategoryDTO {
  name: string;
  slug: string;
  description?: string;
  parentId?: string;
  sortOrder?: number;
  status: 'draft' | 'published' | 'archived';
  image?: string;
  seoTitle?: string;
  seoDescription?: string;
  metaFields?: Record<string, unknown>;
}

/**
 * Update category DTO
 */
export interface UpdateCategoryDTO {
  name?: string;
  slug?: string;
  description?: string;
  parentId?: string;
  sortOrder?: number;
  status?: 'draft' | 'published' | 'archived';
  image?: string;
  seoTitle?: string;
  seoDescription?: string;
  metaFields?: Record<string, unknown>;
}

/**
 * Category filters DTO
 */
export interface CategoryFiltersDTO {
  name?: string;
  slug?: string;
  status?: 'draft' | 'published' | 'archived';
  parentId?: string;
  hasChildren?: boolean;
  createdAfter?: string;
  createdBefore?: string;
  limit?: number;
  page?: number;
  sortBy?: 'name' | 'sortOrder' | 'createdAt' | 'updatedAt';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Category hierarchy DTO
 */
export interface CategoryHierarchyDTO {
  rootCategories: string[];
  categoryTree: Record<string, string[]>;
}

/**
 * Category reorder DTO
 */
export interface CategoryReorderDTO {
  categoryId: string;
  newSortOrder: number;
  parentId?: string;
}

/**
 * Category statistics DTO
 */
export interface CategoryStatisticsDTO {
  totalCategories: number;
  activeCategories: number;
  archivedCategories: number;
  categoriesWithChildren: number;
  averageProductsPerCategory: number;
}
