// ====================================================================
// FIGHT DOMAIN ENTITIES
// ====================================================================

import type { BaseEntity } from './base';
import type { DomainCategory } from './category';
import type { DomainMedia } from './media';
import type { DomainUser } from './user';

export type FightStatus = 'scheduled' | 'in-progress' | 'completed' | 'cancelled' | 'postponed';
export type WeightClass =
  | 'flyweight'
  | 'bantamweight'
  | 'featherweight'
  | 'lightweight'
  | 'welterweight'
  | 'middleweight'
  | 'light-heavyweight'
  | 'heavyweight';
export type FightStance = 'orthodox' | 'southpaw' | 'switch';

export interface FightRecord {
  wins: number;
  losses: number;
  draws: number;
  knockouts: number;
  submissions: number;
  decisions: number;
}

export interface FighterStats {
  totalFights: number;
  winStreak: number;
  lossStreak: number;
  averageFightTime: number;
  knockoutPercentage: number;
  submissionPercentage: number;
  decisionPercentage: number;
}

export interface FightResult {
  winner: string;
  method: 'knockout' | 'submission' | 'decision' | 'technical' | 'disqualification';
  round: number;
  time: string;
  notes?: string;
  highlights?: string[];
}

export interface FightRevenue {
  ticketSales: number;
  payPerView: number;
  merchandise: number;
  sponsorships: number;
  total: number;
}

export interface FightAnalytics {
  views: number;
  uniqueViews: number;
  watchTime: number;
  engagementRate: number;
  socialShares: number;
  revenuePerView: number;
}

export interface Fighter extends BaseEntity {
  userId: string;
  user: DomainUser;
  nickname?: string;
  weightClass: WeightClass;
  record: FightRecord;
  bio?: string;
  profileImage?: DomainMedia;
  socialMedia?: {
    instagram?: string;
    twitter?: string;
    youtube?: string;
  };
  stats: FighterStats;
  isActive: boolean;
}

export interface Fight extends BaseEntity {
  title: string;
  description: string;
  status: FightStatus;
  scheduledDate: string;
  location: string;
  venue?: string;
  weightClass: WeightClass;
  rounds: number;
  roundDuration: number;
  fighters: Fighter[];
  result?: FightResult;
  videoUrl?: string;
  thumbnail?: DomainMedia;
  categories: DomainCategory[];
  tags: string[];
  featured: boolean;
  payPerView: boolean;
  ticketPrice?: number;
  streamPrice?: number;
  revenue: FightRevenue;
  analytics: FightAnalytics;
}

export interface FightFilters {
  status?: FightStatus;
  weightClass?: WeightClass;
  location?: string;
  featured?: boolean;
  scheduledDate?: string;
  limit?: number;
  page?: number;
  sortBy?: string;
}
