// ====================================================================
// SERVICE RESULT METADATA TYPES
// ====================================================================
// Typed metadata structures for service results
// Replaces Record<string, unknown> with specific interfaces

/**
 * Base service result metadata
 */
export interface BaseServiceMetadata {
  /** Service name that generated the result */
  serviceName?: string;
  /** Operation name */
  operation?: string;
  /** Request ID for tracking */
  requestId?: string;
  /** Correlation ID for tracking related operations */
  correlationId?: string;
  /** Response timestamp */
  timestamp?: Date;
  /** Processing duration in milliseconds */
  duration?: number;
}

/**
 * Service metrics metadata
 */
export interface ServiceMetricsMetadata extends BaseServiceMetadata {
  /** Number of successful operations */
  successCount?: number;
  /** Number of failed operations */
  failureCount?: number;
  /** Total number of operations */
  totalCount?: number;
  /** Average response time in milliseconds */
  averageResponseTime?: number;
  /** Error rate (0-1) */
  errorRate?: number;
}

/**
 * Validation metadata
 */
export interface ValidationServiceMetadata extends BaseServiceMetadata {
  /** Number of validation errors */
  errorCount?: number;
  /** Number of validation warnings */
  warningCount?: number;
  /** Validation rules applied */
  rulesApplied?: string[];
  /** Validation duration in milliseconds */
  validationDuration?: number;
}

/**
 * Database operation metadata
 */
export interface DatabaseServiceMetadata extends BaseServiceMetadata {
  /** Database name */
  database?: string;
  /** Collection or table name */
  collection?: string;
  /** Query execution time in milliseconds */
  queryTime?: number;
  /** Number of records affected */
  recordsAffected?: number;
  /** Indexes used */
  indexesUsed?: string[];
}

/**
 * Cache operation metadata
 */
export interface CacheServiceMetadata extends BaseServiceMetadata {
  /** Cache operation type */
  cacheOperation?: 'get' | 'set' | 'delete' | 'clear';
  /** Cache key used */
  cacheKey?: string;
  /** Cache hit or miss */
  cacheHit?: boolean;
  /** Cache TTL in seconds */
  cacheTtl?: number;
}

/**
 * External service call metadata
 */
export interface ExternalServiceMetadata extends BaseServiceMetadata {
  /** External service name */
  externalService?: string;
  /** External API endpoint */
  endpoint?: string;
  /** HTTP status code from external service */
  statusCode?: number;
  /** External service response time in milliseconds */
  responseTime?: number;
  /** Number of retries attempted */
  retries?: number;
}

/**
 * Union type for all service metadata types
 */
export type ServiceMetadata =
  | BaseServiceMetadata
  | ServiceMetricsMetadata
  | ValidationServiceMetadata
  | DatabaseServiceMetadata
  | CacheServiceMetadata
  | ExternalServiceMetadata;

/**
 * Type guard to check if metadata is ServiceMetricsMetadata
 */
export function isServiceMetricsMetadata(
  metadata: ServiceMetadata
): metadata is ServiceMetricsMetadata {
  return 'successCount' in metadata || 'failureCount' in metadata || 'totalCount' in metadata;
}

/**
 * Type guard to check if metadata is ValidationServiceMetadata
 */
export function isValidationServiceMetadata(
  metadata: ServiceMetadata
): metadata is ValidationServiceMetadata {
  return 'errorCount' in metadata || 'warningCount' in metadata || 'rulesApplied' in metadata;
}

/**
 * Type guard to check if metadata is DatabaseServiceMetadata
 */
export function isDatabaseServiceMetadata(
  metadata: ServiceMetadata
): metadata is DatabaseServiceMetadata {
  return 'database' in metadata || 'collection' in metadata || 'queryTime' in metadata;
}

/**
 * Type guard to check if metadata is CacheServiceMetadata
 */
export function isCacheServiceMetadata(
  metadata: ServiceMetadata
): metadata is CacheServiceMetadata {
  return 'cacheOperation' in metadata || 'cacheKey' in metadata || 'cacheHit' in metadata;
}

/**
 * Type guard to check if metadata is ExternalServiceMetadata
 */
export function isExternalServiceMetadata(
  metadata: ServiceMetadata
): metadata is ExternalServiceMetadata {
  return 'externalService' in metadata || 'endpoint' in metadata || 'responseTime' in metadata;
}
