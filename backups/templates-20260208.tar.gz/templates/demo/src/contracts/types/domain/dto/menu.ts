// ====================================================================
// MENU DTOs
// ====================================================================
// Data Transfer Objects for Menu domain entities

export interface MenuItemData {
  label: string;
  href: string;
  children?: MenuItemData[];
}

/**
 * Create menu DTO
 */
export interface CreateMenuDTO {
  name: string;
  location: 'header' | 'footer' | 'sidebar';
  isActive?: boolean;
  sortOrder?: number;
  items: MenuItemData[];
  status?: 'active' | 'inactive';
}

/**
 * Update menu DTO
 */
export interface UpdateMenuDTO {
  name?: string;
  location?: 'header' | 'footer' | 'sidebar';
  isActive?: boolean;
  sortOrder?: number;
  items?: MenuItemData[];
  status?: 'active' | 'inactive';
}

/**
 * Menu filters DTO
 */
export interface MenuFiltersDTO {
  location?: 'header' | 'footer' | 'sidebar';
  status?: 'active' | 'inactive';
  isActive?: boolean;
  searchTerm?: string;
  limit?: number;
  page?: number;
}
