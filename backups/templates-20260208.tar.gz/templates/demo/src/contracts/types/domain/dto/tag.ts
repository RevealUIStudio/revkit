// ====================================================================
// TAG DTOs
// ====================================================================
// Data Transfer Objects for Tag domain entities

/**
 * Create tag DTO
 */
export interface CreateTagDTO {
  name: string;
  slug: string;
  description?: string;
}

/**
 * Update tag DTO
 */
export interface UpdateTagDTO {
  name?: string;
  slug?: string;
  description?: string;
}

/**
 * Tag filters DTO
 */
export interface TagFiltersDTO {
  searchTerm?: string;
  limit?: number;
  page?: number;
  sortBy?: 'name' | 'slug' | 'createdAt' | 'updatedAt';
  sortOrder?: 'asc' | 'desc';
}
