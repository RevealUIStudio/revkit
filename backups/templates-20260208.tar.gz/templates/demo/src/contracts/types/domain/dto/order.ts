// ====================================================================
// ORDER DTOs
// ====================================================================
// Data Transfer Objects for order operations

/**
 * Create order DTO
 */
export interface CreateOrderDTO {
  cartId: string;
  customerEmail: string;
  customerName?: string;
  shippingAddress: {
    street1: string;
    street2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  billingAddress?: {
    street1: string;
    street2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  paymentMethod: {
    type: 'card' | 'paypal' | 'stripe';
    token: string;
  };
  notes?: string;
}

/**
 * Update order DTO
 */
export interface UpdateOrderDTO {
  status?: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  trackingNumber?: string;
  notes?: string;
  shippingAddress?: {
    street1: string;
    street2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
}

/**
 * Order filters DTO
 */
export interface OrderFiltersDTO {
  status?: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  customerEmail?: string;
  createdAfter?: string;
  createdBefore?: string;
  totalMin?: number;
  totalMax?: number;
  limit?: number;
  page?: number;
  sortBy?: 'createdAt' | 'total' | 'status';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Order status update DTO
 */
export interface OrderStatusUpdateDTO {
  orderId: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  notes?: string;
  trackingNumber?: string;
}

/**
 * Order refund DTO
 */
export interface OrderRefundDTO {
  orderId: string;
  amount?: number; // If not provided, refunds full amount
  reason: string;
  notes?: string;
}
