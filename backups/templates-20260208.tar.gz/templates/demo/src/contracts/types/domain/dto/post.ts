// ====================================================================
// POST & CATEGORY DTO TYPES
// ====================================================================

import type { UserDTO } from './user';

export interface CategoryDTO {
  id: string;
  name: string;
  slug: string;
  description?: string;
  parent?: CategoryDTO;
  children?: CategoryDTO[];
  image?: string;
  featured?: boolean;
  sortOrder?: number;
  postCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface PostDTO {
  id: string;
  title: string;
  slug: string;
  content?: string;
  excerpt?: string;
  status: 'draft' | 'published' | 'archived';
  publishedDate?: string;
  author: UserDTO;
  categories: CategoryDTO[];
  tags: string[];
  featuredImage?: string;
  views?: number;
  featured?: boolean;
  readingTime?: number;
  wordCount?: number;
  seo?: {
    metaTitle?: string;
    metaDescription?: string;
    keywords?: string[];
  };
  createdAt: string;
  updatedAt: string;
}

export interface CreatePostDTO {
  title: string;
  content: string;
  excerpt?: string;
  categoryIds: string[];
  tags?: string[];
  featured?: boolean;
  featuredImage?: string;
  seo?: {
    metaTitle?: string;
    metaDescription?: string;
    keywords?: string[];
  };
}

export interface UpdatePostDTO {
  title?: string;
  content?: string;
  excerpt?: string;
  categoryIds?: string[];
  tags?: string[];
  featured?: boolean;
  featuredImage?: string;
  seo?: PostDTO['seo'];
}
