// ====================================================================
// DOMAIN EVENT METADATA TYPES
// ====================================================================
// Typed metadata structures for domain events
// Replaces Record<string, unknown> with specific interfaces

/**
 * Base event metadata structure
 */
export interface BaseEventMetadata {
  /** Correlation ID for tracking related events */
  correlationId?: string;
  /** Causation ID for tracking event chains */
  causationId?: string;
  /** User ID who triggered the event */
  userId?: string;
  /** Request ID for API requests */
  requestId?: string;
  /** Session ID */
  sessionId?: string;
  /** IP address */
  ipAddress?: string;
  /** User agent */
  userAgent?: string;
  /** Timestamp when metadata was created */
  timestamp?: Date;
}

/**
 * User-related event metadata
 */
export interface UserEventMetadata extends BaseEventMetadata {
  /** User ID (required for user events) */
  userId: string;
  /** User email */
  email?: string;
  /** User role */
  role?: string;
  /** Tenant ID for multi-tenant systems */
  tenantId?: string;
}

/**
 * System event metadata
 */
export interface SystemEventMetadata extends BaseEventMetadata {
  /** Service name that generated the event */
  serviceName?: string;
  /** Operation name */
  operation?: string;
  /** Environment (development, staging, production) */
  environment?: string;
  /** Deployment version */
  version?: string;
}

/**
 * Performance event metadata
 */
export interface PerformanceEventMetadata extends BaseEventMetadata {
  /** Duration in milliseconds */
  duration?: number;
  /** Resource name (collection, table, etc.) */
  resource?: string;
  /** Operation type */
  operation?: string;
  /** Additional performance metrics */
  metrics?: {
    memoryUsage?: number;
    cpuUsage?: number;
    [key: string]: number | undefined;
  };
}

/**
 * Error event metadata
 */
export interface ErrorEventMetadata extends BaseEventMetadata {
  /** Error code */
  errorCode?: string;
  /** Error category */
  errorCategory?: 'validation' | 'business' | 'system' | 'external' | 'unknown';
  /** Stack trace */
  stackTrace?: string;
  /** Component or module where error occurred */
  component?: string;
  /** Additional error context */
  context?: {
    [key: string]: unknown;
  };
}

/**
 * Audit event metadata
 */
export interface AuditEventMetadata extends BaseEventMetadata {
  /** User ID who performed the action (required for audit) */
  userId: string;
  /** Action performed */
  action: string;
  /** Resource affected */
  resource?: string;
  /** Resource ID */
  resourceId?: string;
  /** Previous state (for updates) */
  previousState?: unknown;
  /** New state (for updates) */
  newState?: unknown;
  /** Reason for the action */
  reason?: string;
}

/**
 * Change tracking metadata for update events
 */
export interface ChangeTrackingMetadata {
  /** Field name that changed */
  field: string;
  /** Previous value */
  oldValue: unknown;
  /** New value */
  newValue: unknown;
  /** Change type */
  changeType?: 'added' | 'modified' | 'removed';
}

/**
 * Update event changes structure
 * Replaces Record<string, unknown> with typed change tracking
 */
export interface UpdateEventChanges {
  /** Array of field changes */
  changes: ChangeTrackingMetadata[];
  /** User who made the changes */
  updatedBy: string;
  /** Timestamp of the update */
  updatedAt: Date;
  /** Optional reason for the update */
  reason?: string;
}

/**
 * Union type for all metadata types
 */
export type EventMetadata =
  | BaseEventMetadata
  | UserEventMetadata
  | SystemEventMetadata
  | PerformanceEventMetadata
  | ErrorEventMetadata
  | AuditEventMetadata;

/**
 * Type guard to check if metadata is UserEventMetadata
 */
export function isUserEventMetadata(metadata: EventMetadata): metadata is UserEventMetadata {
  return 'userId' in metadata && typeof metadata.userId === 'string';
}

/**
 * Type guard to check if metadata is SystemEventMetadata
 */
export function isSystemEventMetadata(metadata: EventMetadata): metadata is SystemEventMetadata {
  return 'serviceName' in metadata || 'operation' in metadata;
}

/**
 * Type guard to check if metadata is PerformanceEventMetadata
 */
export function isPerformanceEventMetadata(
  metadata: EventMetadata
): metadata is PerformanceEventMetadata {
  return 'duration' in metadata || 'resource' in metadata;
}

/**
 * Type guard to check if metadata is ErrorEventMetadata
 */
export function isErrorEventMetadata(metadata: EventMetadata): metadata is ErrorEventMetadata {
  return 'errorCode' in metadata || 'errorCategory' in metadata;
}

/**
 * Type guard to check if metadata is AuditEventMetadata
 */
export function isAuditEventMetadata(metadata: EventMetadata): metadata is AuditEventMetadata {
  return 'userId' in metadata && 'action' in metadata;
}
