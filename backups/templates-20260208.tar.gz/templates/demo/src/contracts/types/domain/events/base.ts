// ====================================================================
// BASE DOMAIN EVENT
// ====================================================================

import type { EventMetadata } from './metadata';

/**
 * Base domain event interface
 */
export interface DomainEvent<TType extends string = string> {
  readonly type: TType;
  readonly aggregateId: string;
  readonly occurredAt: Date;
  readonly eventVersion: number;
  readonly correlationId?: string;
  readonly causationId?: string;
  readonly metadata?: EventMetadata;
}
