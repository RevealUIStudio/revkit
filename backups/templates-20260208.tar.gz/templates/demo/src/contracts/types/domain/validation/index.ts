// ====================================================================
// DOMAIN VALIDATION - Barrel Export
// ====================================================================
// Re-exports all validation-related types

export * from './architecture';
export * from './errors';
export * from './results';
