// ====================================================================
// PRODUCT DTOs
// ====================================================================
// Data Transfer Objects for product operations

/**
 * Create product DTO
 */
export interface CreateProductDTO {
  name: string;
  description: string;
  sku: string;
  price: number;
  compareAtPrice?: number;
  cost?: number;
  trackQuantity: boolean;
  quantity?: number;
  allowBackorder: boolean;
  weight?: number;
  weightUnit: 'kg' | 'lb' | 'g' | 'oz';
  status: 'draft' | 'published' | 'archived';
  type: 'physical' | 'digital' | 'service';
  categoryId?: string;
  tags: string[];
  images: string[];
  seoTitle?: string;
  seoDescription?: string;
  // Using Record<string, unknown> because product meta fields structure varies by product type and cannot be strictly typed
  metaFields?: /* Using Record<string, unknown> because product meta fields structure varies by product type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

/**
 * Update product DTO
 */
export interface UpdateProductDTO {
  name?: string;
  description?: string;
  sku?: string;
  price?: number;
  compareAtPrice?: number;
  cost?: number;
  trackQuantity?: boolean;
  quantity?: number;
  allowBackorder?: boolean;
  weight?: number;
  weightUnit?: 'kg' | 'lb' | 'g' | 'oz';
  status?: 'draft' | 'published' | 'archived';
  type?: 'physical' | 'digital' | 'service';
  categoryId?: string;
  tags?: string[];
  images?: string[];
  seoTitle?: string;
  seoDescription?: string;
  // Using Record<string, unknown> because product meta fields structure varies by product type and cannot be strictly typed
  metaFields?: /* Using Record<string, unknown> because product meta fields structure varies by product type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

/**
 * Product variant DTO
 */
export interface ProductVariantDTO {
  id?: string;
  name: string;
  sku: string;
  price: number;
  compareAtPrice?: number;
  cost?: number;
  trackQuantity: boolean;
  quantity?: number;
  weight?: number;
  weightUnit: 'kg' | 'lb' | 'g' | 'oz';
  options: Record<string, string>;
  images: string[];
}

/**
 * Create product variant DTO
 */
export interface CreateProductVariantDTO {
  productId: string;
  variant: ProductVariantDTO;
}

/**
 * Update product variant DTO
 */
export interface UpdateProductVariantDTO {
  variantId: string;
  variant: Partial<ProductVariantDTO>;
}

/**
 * Product filters DTO
 */
export interface ProductFiltersDTO {
  name?: string;
  sku?: string;
  status?: 'draft' | 'published' | 'archived';
  type?: 'physical' | 'digital' | 'service';
  categoryId?: string;
  tags?: string[];
  priceMin?: number;
  priceMax?: number;
  inStock?: boolean;
  createdAfter?: string;
  createdBefore?: string;
  limit?: number;
  page?: number;
  sortBy?: 'name' | 'price' | 'createdAt' | 'updatedAt';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Product search DTO
 */
export interface ProductSearchDTO {
  query: string;
  filters?: ProductFiltersDTO;
  includeVariants?: boolean;
  includeCategories?: boolean;
}
