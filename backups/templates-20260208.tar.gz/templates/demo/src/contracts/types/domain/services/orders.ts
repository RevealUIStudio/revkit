import type { OrderStatus, PaymentStatus } from '../entities';

export interface OrderFilters {
  status?: OrderStatus;
  userId?: string;
  createdAfter?: string;
  createdBefore?: string;
  totalMin?: number;
  totalMax?: number;
}

export interface OrderSortOptions {
  field: 'createdAt' | 'updatedAt' | 'total' | 'status';
  direction: 'asc' | 'desc';
}

export interface OrderItemData {
  productId: string;
  variantId?: string;
  quantity: number;
  price: number;
  discount?: number;
}

export interface ShippingAddressData {
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export interface CreateOrderData {
  userId: string;
  items: OrderItemData[];
  shippingAddress: ShippingAddressData;
  billingAddress?: ShippingAddressData;
  paymentMethodId: string;
  couponCode?: string;
  notes?: string;
  // Using Record<string, unknown> because order metadata structure varies by order type and cannot be strictly typed
  metadata?: /* Using Record<string, unknown> because order metadata structure varies by order type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

export interface OrderResponse {
  id: string;
  userId: string;
  items: Array<{
    productId: string;
    variantId?: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  currency: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  shippingAddress: ShippingAddressData;
  billingAddress?: ShippingAddressData;
  paymentMethod: string;
  trackingNumber?: string;
  shippedAt?: string;
  deliveredAt?: string;
  createdAt: string;
  updatedAt: string;
}
