// ====================================================================
// DOMAIN COMMANDS
// ====================================================================
// Command pattern interfaces for domain operations

/**
 * Domain command base interface
 */
export interface DomainCommand<TType extends string = string> {
  readonly type: TType;
  readonly aggregateId: string;
  readonly commandId: string;
  readonly issuedAt: Date;
  readonly issuedBy?: string;
  // Using Record<string, unknown> because command metadata structure varies by command type and cannot be strictly typed
  readonly metadata?: /* Using Record<string, unknown> because command metadata structure varies by command type and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}
