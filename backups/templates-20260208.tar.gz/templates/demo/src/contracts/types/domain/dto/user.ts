// ====================================================================
// USER DTO TYPES
// ====================================================================
// Data Transfer Objects for User domain entities

export interface UserDTO {
  id: string;
  email: string;
  username?: string;
  name?: string;
  role: string;
  status?: string;
  avatar?: string;
  bio?: string;
  preferences?: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    privacyLevel: 'public' | 'friends' | 'private';
    theme: 'light' | 'dark' | 'auto';
    language: string;
    timezone: string;
    currency: string;
  };
  lastLogin?: string;
  profileCompleteness?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateUserDTO {
  email: string;
  username: string;
  name: string;
  password: string;
  role?: string;
  acceptTerms: boolean;
  marketingConsent?: boolean;
}

export interface UpdateUserDTO {
  name?: string;
  username?: string;
  email?: string;
  bio?: string;
  avatar?: string;
  role?: string;
  status?: string;
  preferences?: Partial<UserDTO['preferences']>;
}

export interface LoginCredentialsDTO {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterDataDTO {
  email: string;
  username: string;
  name: string;
  password: string;
  confirmPassword: string;
  role?: string;
  acceptTerms: boolean;
  marketingConsent?: boolean;
}

export interface AuthResultDTO {
  user: UserDTO;
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  sessionId: string;
}
