// ====================================================================
// USER DOMAIN SERVICE
// ====================================================================

import type { ServiceResult, ValidationResult } from '../../../core';

// Note: User, CreateUserData, UpdateUserData types are defined locally in this file

/**
 * User domain service interface with domain-specific business logic
 */
export interface IUserDomainService {
  // Core user operations
  createUser(data: CreateUserData): Promise<ServiceResult<User>>;
  updateUser(id: string, data: UpdateUserData): Promise<ServiceResult<User>>;
  deleteUser(id: string): Promise<ServiceResult<boolean>>;
  getUser(id: string): Promise<ServiceResult<User>>;

  // User profile management
  updateUserProfile(id: string, data: UpdateUserData): Promise<ServiceResult<User>>;
  getUserProfile(id: string): Promise<ServiceResult<User>>;

  // User role and permission management
  changeUserRole(id: string, role: string): Promise<ServiceResult<User>>;
  validateUserPermissions(user: User, action: string): Promise<ServiceResult<boolean>>;
  getUserPermissions(id: string): Promise<ServiceResult<string[]>>;

  // User status management
  activateUser(id: string): Promise<ServiceResult<User>>;
  deactivateUser(id: string): Promise<ServiceResult<User>>;
  suspendUser(id: string, reason: string): Promise<ServiceResult<User>>;

  // User validation
  validateUserData(data: Partial<User>): Promise<ValidationResult<User>>;
  validateEmail(email: string): Promise<ServiceResult<boolean>>;
  validateUsername(username: string): Promise<ServiceResult<boolean>>;

  // User analytics
  getUserStats(id: string): Promise<
    ServiceResult<{
      totalLogins: number;
      lastLogin: string;
      activityScore: number;
      profileCompleteness: number;
    }>
  >;
}
