// ====================================================================
// MEDIA DOMAIN ENTITIES
// ====================================================================

import type { BaseEntity } from './base';

export interface DomainMedia extends BaseEntity {
  filename: string;
  alt?: string;
  url?: string;
  mimeType?: string;
  filesize?: number;
  width?: number;
  height?: number;
  prefix?: DomainPrefix;
}

export interface DomainPrefix extends BaseEntity {
  name: string;
  slug: string;
  description?: string;
  path: string;
  isActive: boolean;
  sortOrder?: number;
}

/**
 * Enhanced Media entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type { Media as RevealUIMedia } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedMedia,
  HybridEntity,
  RevealUIToDomainMediaMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

export type MediaWithRevealUI = HybridEntity<RevealUIMedia, DomainMedia>;

/**
 * Enhanced Media entity from bridge system
 */
export type MediaEnhanced = EnhancedMedia;

/**
 * Media transformed from RevealUI Content Engine
 */
export type MediaFromRevealUI<T extends RevealUIMedia = RevealUIMedia> = RevealUIToDomainMediaMapper<T>;

/**
 * Type guard to check if media has RevealUI Content Engine data
 */
export function isMediaWithRevealUI(value: unknown): value is MediaWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
