// ====================================================================
// VALIDATION RESULTS
// ====================================================================
// Validation result types and form validation state

import type { ValidationError } from './errors';

/**
 * Generic validation result with enhanced error details
 */
export interface GenericValidationResult<T> {
  isValid: boolean;
  data?: T;
  errors?: ValidationError[];
}

/**
 * Form validation state with discriminated unions
 */
export type FormValidationState<T> =
  | { status: 'valid'; data: T }
  | { status: 'invalid'; errors: ValidationError[]; data: Partial<T> }
  | { status: 'validating'; data: Partial<T> };
