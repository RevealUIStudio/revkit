// =======
// ECOMMERCE DOMAIN ENUMS
// =======
// Business domain enumerations for e-commerce

/**
 * Shipping method enumeration
 */
export type ShippingMethod = 'standard' | 'express' | 'overnight' | 'pickup';

/**
 * Payment method enumeration
 */
export type PaymentMethod = 'stripe' | 'paypal' | 'crypto' | 'bank-transfer';

/**
 * Coupon type enumeration
 */
export type CouponType = 'percentage' | 'fixed' | 'free-shipping';

/**
 * Product availability status
 */
export type AvailabilityStatus = 'in-stock' | 'out-of-stock' | 'pre-order' | 'discontinued';

/**
 * Order fulfillment status
 */
export type FulfillmentStatus = 'unfulfilled' | 'partially-fulfilled' | 'fulfilled' | 'cancelled';

/**
 * Refund status enumeration
 */
export type RefundStatus = 'pending' | 'processing' | 'completed' | 'failed';

/**
 * Tax calculation method
 */
export type TaxCalculationMethod = 'inclusive' | 'exclusive' | 'auto';

/**
 * Discount application type
 */
export type DiscountApplicationType = 'automatic' | 'manual' | 'coupon';
