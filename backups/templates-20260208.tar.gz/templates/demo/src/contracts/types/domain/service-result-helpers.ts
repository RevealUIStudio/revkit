/**
 * Service Result Helper Functions
 * 
 * Utilities for creating ServiceResult and ServiceValidationResult objects
 * that comply with exactOptionalPropertyTypes: true.
 * 
 * These helpers ensure optional properties are omitted rather than set to undefined,
 * preventing type errors with strict TypeScript configuration.
 * 
 * @module contracts/types/domain/service-result-helpers
 */

import type { ServiceMetadata } from './service-metadata';
import type { ServiceResult, ServiceValidationResult } from './service-results';

/**
 * Create a successful ServiceResult
 * Only includes optional properties if they have values
 * For void types, data property is omitted
 */
export function createServiceResultSuccess<T>(
  data: T,
  options?: {
    message?: string;
    metadata?: ServiceMetadata;
  }
): ServiceResult<T> {
  return {
    success: true,
    ...(data !== undefined ? { data } : {}),
    ...(options?.message ? { message: options.message } : {}),
    ...(options?.metadata ? { metadata: options.metadata } : {}),
  };
}

/**
 * Create a failed ServiceResult
 * Only includes optional properties if they have values
 */
export function createServiceResultFailure<T>(
  error: string,
  options?: {
    message?: string;
    details?: unknown;
    metadata?: ServiceMetadata;
  }
): ServiceResult<T> {
  return {
    success: false,
    error,
    ...(options?.message ? { message: options.message } : {}),
    ...(options?.details !== undefined ? { details: options.details } : {}),
    ...(options?.metadata ? { metadata: options.metadata } : {}),
  };
}

/**
 * Create a successful ServiceValidationResult
 * Only includes optional properties if they have values
 */
export function createServiceValidationSuccess<T>(
  data: T
): ServiceValidationResult<T> {
  return {
    isValid: true,
    data,
  };
}

/**
 * Create a failed ServiceValidationResult
 * Only includes optional properties if they have values
 */
export function createServiceValidationFailure<T>(
  errors: Array<{
    field: string;
    message: string;
    code?: string;
    value?: unknown;
  }>
): ServiceValidationResult<T> {
  return {
    isValid: false,
    ...(errors.length > 0 ? { errors } : {}),
  };
}

/**
 * Create a ServiceValidationResult from a boolean and optional data
 */
export function createServiceValidation<T>(
  isValid: boolean,
  data?: T,
  errors?: Array<{
    field: string;
    message: string;
    code?: string;
    value?: unknown;
  }>
): ServiceValidationResult<T> {
  return {
    isValid,
    ...(data !== undefined ? { data } : {}),
    ...(errors && errors.length > 0 ? { errors } : {}),
  };
}

/**
 * Helper to conditionally include a property in an object
 * Useful for exactOptionalPropertyTypes compliance
 */
export function includeIf<T, K extends string>(
  condition: boolean,
  key: K,
  value: T
): Record<K, T> | Record<string, never> {
  return condition ? ({ [key]: value } as Record<K, T>) : ({} as Record<string, never>);
}

/**
 * Helper to conditionally include a property if value is not undefined
 * Useful for exactOptionalPropertyTypes compliance
 */
export function includeIfDefined<T, K extends string>(
  value: T | undefined,
  key: K
): Record<K, T> | Record<string, never> {
  return value !== undefined ? ({ [key]: value } as Record<K, T>) : ({} as Record<string, never>);
}

