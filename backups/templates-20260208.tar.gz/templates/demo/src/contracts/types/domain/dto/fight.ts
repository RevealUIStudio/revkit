// ====================================================================
// FIGHT DTOs
// ====================================================================
// Data Transfer Objects for Fight domain operations

/**
 * Create Fight DTO
 */
export interface CreateFightDTO {
  title: string;
  description: string;
  scheduledDate: string;
  weightClass: string;
  fighterIds: string[];
  location: string;
  venue?: string;
  ticketPrice?: number;
  streamPrice?: number;
  payPerView: boolean;
}

/**
 * Update Fight DTO
 */
export interface UpdateFightDTO {
  title?: string;
  description?: string;
  scheduledDate?: string;
  weightClass?: string;
  fighterIds?: string[];
  location?: string;
  venue?: string;
  ticketPrice?: number;
  streamPrice?: number;
  payPerView?: boolean;
}
