// ====================================================================
// DOMAIN EVENTS - Barrel Export
// ====================================================================
// Re-exports all domain event definitions organized by domain

export * from './base';
export * from './cart';
export * from './category';
export * from './fight';
export * from './media';
export * from './metadata';
export * from './order';
export * from './post';
export * from './product';
export * from './subscription';
export * from './user';

import type { CartCreatedEvent, CartItemAddedEvent, CartItemRemovedEvent } from './cart';
import type { CategoryCreatedEvent, CategoryDeletedEvent, CategoryUpdatedEvent } from './category';
import type {
  FightCancelledEvent,
  FightCompletedEvent,
  FightScheduledEvent,
  FighterRegisteredEvent,
} from './fight';
import type { MediaDeletedEvent, MediaProcessedEvent, MediaUploadedEvent } from './media';
import type {
  OrderCancelledEvent,
  OrderCreatedEvent,
  OrderDeliveredEvent,
  OrderPaidEvent,
  OrderShippedEvent,
} from './order';
import type {
  PostCreatedEvent,
  PostDeletedEvent,
  PostPublishedEvent,
  PostUpdatedEvent,
  PostViewedEvent,
} from './post';
import type {
  ProductCreatedEvent,
  ProductDeletedEvent,
  ProductPublishedEvent,
  ProductUpdatedEvent,
} from './product';
import type {
  SubscriptionCancelledEvent,
  SubscriptionCreatedEvent,
  SubscriptionExpiredEvent,
  SubscriptionRenewedEvent,
} from './subscription';
import type {
  UserDeletedEvent,
  UserLoginEvent,
  UserLogoutEvent,
  UserRegisteredEvent,
  UserUpdatedEvent,
} from './user';

/**
 * Union type of all domain events in the system
 */
export type AllDomainEvents =
  | UserRegisteredEvent
  | UserUpdatedEvent
  | UserDeletedEvent
  | UserLoginEvent
  | UserLogoutEvent
  | PostCreatedEvent
  | PostPublishedEvent
  | PostUpdatedEvent
  | PostDeletedEvent
  | PostViewedEvent
  | CategoryCreatedEvent
  | CategoryUpdatedEvent
  | CategoryDeletedEvent
  | MediaUploadedEvent
  | MediaProcessedEvent
  | MediaDeletedEvent
  | FightScheduledEvent
  | FightCompletedEvent
  | FightCancelledEvent
  | FighterRegisteredEvent
  | ProductCreatedEvent
  | ProductUpdatedEvent
  | ProductPublishedEvent
  | ProductDeletedEvent
  | CartCreatedEvent
  | CartItemAddedEvent
  | CartItemRemovedEvent
  | OrderCreatedEvent
  | OrderPaidEvent
  | OrderShippedEvent
  | OrderDeliveredEvent
  | OrderCancelledEvent
  | SubscriptionCreatedEvent
  | SubscriptionRenewedEvent
  | SubscriptionCancelledEvent
  | SubscriptionExpiredEvent;
