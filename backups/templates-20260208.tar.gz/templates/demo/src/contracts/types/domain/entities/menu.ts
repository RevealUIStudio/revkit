// ====================================================================
// MENU DOMAIN ENTITIES
// ====================================================================

import type { BaseEntity } from './base';

export type MenuLocation = 'header' | 'footer' | 'sidebar';
export type MenuStatus = 'active' | 'inactive';

export interface MenuItemData {
  label: string;
  href: string;
  children?: MenuItemData[];
}

export interface DomainMenu extends BaseEntity {
  name: string;
  location: MenuLocation;
  isActive: boolean;
  sortOrder: number;
  items: MenuItemData[];
  status: MenuStatus;
}

/**
 * Enhanced Menu entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type { Menu as RevealUIMenu } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedMenu,
  HybridEntity,
  RevealUIToDomainMenuMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

export type MenuWithRevealUI = HybridEntity<RevealUIMenu, DomainMenu>;

/**
 * Enhanced Menu entity from bridge system
 */
export type MenuEnhanced = EnhancedMenu;

/**
 * Menu transformed from RevealUI Content Engine
 */
export type MenuFromRevealUI<T extends RevealUIMenu = RevealUIMenu> = RevealUIToDomainMenuMapper<T>;

/**
 * Type guard to check if menu has RevealUI Content Engine data
 */
export function isMenuWithRevealUI(value: unknown): value is MenuWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
