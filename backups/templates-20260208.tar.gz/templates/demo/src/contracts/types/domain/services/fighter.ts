// ====================================================================
// FIGHTER DOMAIN SERVICE
// ====================================================================

import type { Fighter as RevealUIFighter } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { ServiceResult } from '../service-results';

/**
 * Fight Record Result
 */
export interface FightRecordResult {
  fightId: string;
  opponent: string;
  result: 'win' | 'loss' | 'draw' | 'no_contest';
  method: string;
  round: number;
  date: string;
}

/**
 * Register Fighter Input
 */
export interface RegisterFighterInput {
  userId: string;
  weightClass: string;
  bio?: string;
  socialMedia?: Record<string, string>;
  hometown?: string;
  nationality?: string;
  team?: string;
  coach?: string;
  manager?: string;
  agent?: string;
  medicalClearance: boolean;
}

/**
 * Update Fighter Input
 */
export interface UpdateFighterInput {
  weightClass?: string;
  bio?: string;
  socialMedia?: Record<string, string>;
  hometown?: string;
  nationality?: string;
  team?: string;
  coach?: string;
  manager?: string;
  agent?: string;
  medicalClearance?: boolean;
}

/**
 * Fighter domain service interface
 */
export interface IFighterDomainService {
  registerFighter(data: RegisterFighterInput): Promise<ServiceResult<Fighter>>;

  updateFighter(id: string, data: UpdateFighterInput): Promise<ServiceResult<Fighter>>;

  activateFighter(id: string): Promise<ServiceResult<Fighter>>;
  deactivateFighter(id: string): Promise<ServiceResult<Fighter>>;
  getFighter(id: string): Promise<ServiceResult<Fighter>>;
  getFighters(filters?: FilterOptions): Promise<ServiceResult<Fighter[]>>;
  updateFightRecord(id: string, result: FightRecordResult): Promise<ServiceResult<Fighter>>;
}
