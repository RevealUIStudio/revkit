import type { ServiceContext } from '@revealui/infrastructure/service';

export interface AuthServiceContext extends ServiceContext {
  userId: string;
  sessionId?: string;
  ipAddress?: string;
  userAgent?: string;
  deviceFingerprint?: string;
  loginMethod?: 'password' | 'oauth' | 'magic_link' | 'totp';
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
  totpCode?: string;
}

export interface RegistrationData {
  email: string;
  password: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  acceptTerms: boolean;
  marketingOptIn?: boolean;
}

export interface AuthResult {
  user: {
    id: string;
    email: string;
    username?: string;
    role: string;
    isVerified: boolean;
    lastLoginAt?: string;
  };
  accessToken: string;
  refreshToken?: string;
  expiresAt: Date;
  tokenType: 'Bearer';
  scope?: string[];
}
