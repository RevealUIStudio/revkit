// ====================================================================
// REPOSITORY PATTERN
// ====================================================================
// Repository and Unit of Work patterns for data access abstraction

import type { DomainEntity } from './base';

/**
 * Repository pattern base interface
 */
export interface Repository<T extends DomainEntity> {
  findById(id: string): Promise<T | null>;
  findAll(): Promise<T[]>;
  save(entity: T): Promise<void>;
  delete(id: string): Promise<void>;
  exists(id: string): Promise<boolean>;
}

/**
 * Unit of Work pattern interface
 */
export interface UnitOfWork {
  begin(): Promise<void>;
  commit(): Promise<void>;
  rollback(): Promise<void>;
  isActive(): boolean;
}
