// ====================================================================
// MEDIA DOMAIN SERVICE
// ====================================================================

import type { ServiceResult, ValidationResult } from '../../../core';

/**
 * Media domain service interface
 */
export interface IMediaDomainService {
  uploadMedia(
    file: File,
    metadata?: {
      alt?: string;
      prefix?: string;
      tags?: string[];
    }
  ): Promise<ServiceResult<any>>;

  processMedia(
    mediaId: string,
    operations: {
      resize?: { width: number; height: number };
      optimize?: boolean;
      convert?: string;
    }
  ): Promise<ServiceResult<any>>;

  deleteMedia(id: string): Promise<ServiceResult<boolean>>;
  getMedia(id: string): Promise<ServiceResult<any>>;
  getMediaByPrefix(prefix: string): Promise<ServiceResult<any[]>>;
  validateMediaFile(file: File): Promise<ValidationResult<File>>;
}
