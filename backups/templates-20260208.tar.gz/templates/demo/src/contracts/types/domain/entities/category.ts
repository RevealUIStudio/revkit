// ====================================================================
// CATEGORY DOMAIN ENTITIES
// ====================================================================

import type { BaseEntity } from './base';

export interface DomainCategory extends BaseEntity {
  name: string;
  slug: string;
  description?: string;
  parent?: DomainCategory;
  children?: DomainCategory[];
  image?: string;
  meta?: {
    title?: string;
    description?: string;
    keywords?: string;
  };
  featured?: boolean;
  sortOrder?: number;
}

export interface CategoryTree {
  id: string;
  title: string;
  slug: string;
  children: CategoryTree[];
  postCount: number;
  featured: boolean;
}

export interface CategoryFilters {
  status?: string;
  parentId?: string;
  searchTerm?: string;
  limit?: number;
  page?: number;
  sortBy?: string;
}

export interface CreateCategoryData {
  name: string;
  slug?: string;
  description?: string;
  parentId?: string;
  sortOrder?: number;
  isActive?: boolean;
}

export interface UpdateCategoryData {
  name?: string;
  slug?: string;
  description?: string;
  parentId?: string;
  sortOrder?: number;
  isActive?: boolean;
}

/**
 * Enhanced Category entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type { Category as RevealUICategory } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedCategory,
  HybridEntity,
  RevealUIToDomainCategoryMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

export type CategoryWithRevealUI = HybridEntity<RevealUICategory, DomainCategory>;

/**
 * Enhanced Category entity from bridge system
 */
export type CategoryEnhanced = EnhancedCategory;

/**
 * Category transformed from RevealUI Content Engine
 */
export type CategoryFromRevealUI<T extends RevealUICategory = RevealUICategory> =
  RevealUIToDomainCategoryMapper<T>;

/**
 * Type guard to check if category has RevealUI Content Engine data
 */
export function isCategoryWithRevealUI(value: unknown): value is CategoryWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
