// ====================================================================
// FIGHT DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';

export interface FightScheduledEvent extends DomainEvent<'fight.scheduled'> {
  data: {
    fightId: string;
    scheduledDate: string;
    location: string;
    weightClass: string;
  };
}

export interface FightCompletedEvent extends DomainEvent<'fight.completed'> {
  data: {
    fightId: string;
    result: {
      winner: string;
      method: string;
      round: number;
      time: string;
    };
    revenue: {
      total: number;
      ticketSales: number;
      payPerView: number;
    };
  };
}

export interface FightCancelledEvent extends DomainEvent<'fight.cancelled'> {
  data: {
    fightId: string;
    cancelledBy: string;
    reason: string;
    refundAmount?: number;
  };
}

export interface FighterRegisteredEvent extends DomainEvent<'fighter.registered'> {
  data: {
    fighterId: string;
    userId: string;
    weightClass: string;
  };
}
