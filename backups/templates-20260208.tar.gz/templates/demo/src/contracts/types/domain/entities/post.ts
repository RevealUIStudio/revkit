// ====================================================================
// POST DOMAIN ENTITIES
// ====================================================================

import type { Post as RevealUIPost } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedPost,
  HybridEntity,
  RevealUIToDomainPostMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';
import type { BaseEntity } from './base';
import type { DomainCategory } from './category';
import type { DomainUser } from './user';

export type PostStatus = 'draft' | 'published' | 'archived';

export interface DomainPost extends BaseEntity {
  title: string;
  slug: string;
  content?: string;
  excerpt?: string;
  status: PostStatus;
  publishedDate?: string;
  meta?: {
    title?: string;
    description?: string;
    keywords?: string;
    image?: string;
  };
  categories?: DomainCategory[];
  tags?: string[];
  authors?: DomainUser[];
  featuredImage?: string;
  views?: number;
  featured?: boolean;
  paywall?: boolean;
}

/**
 * Enhanced Post entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
export type PostWithRevealUI = HybridEntity<RevealUIPost, DomainPost>;

/**
 * Enhanced Post entity from bridge system
 */
export type PostEnhanced = EnhancedPost;

/**
 * Mapped Post from RevealUI Content Engine to domain structure
 * Used when transforming RevealUI Content Engine posts to domain posts
 */
export type PostFromRevealUI<T extends RevealUIPost = RevealUIPost> = RevealUIToDomainPostMapper<T>;

/**
 * Type predicate to check if a value is a post with revealui data
 */
export function isPostWithRevealUI(value: unknown): value is PostWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'title' in value &&
    '__source' in value &&
    (value as any).__source === 'hybrid'
  );
}

export interface PostFilters {
  status?: string;
  category?: string;
  author?: string;
  limit?: number;
  page?: number;
  searchTerm?: string;
  sortBy?: string;
}
