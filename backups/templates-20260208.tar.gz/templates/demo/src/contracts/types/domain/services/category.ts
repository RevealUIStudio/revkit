// ====================================================================
// CATEGORY DOMAIN SERVICE
// ====================================================================

import type { Category as RevealUICategory } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { ServiceResult } from '../service-results';

/**
 * Create Category Input
 */
export interface CreateCategoryInput {
  name: string;
  slug: string;
  description?: string;
  parentId?: string;
}

/**
 * Update Category Input
 */
export interface UpdateCategoryInput {
  name?: string;
  slug?: string;
  description?: string;
  parentId?: string;
}

/**
 * Category domain service interface
 */
export interface ICategoryDomainService {
  createCategory(data: CreateCategoryInput): Promise<ServiceResult<Category>>;

  updateCategory(id: string, data: UpdateCategoryInput): Promise<ServiceResult<Category>>;

  deleteCategory(id: string): Promise<ServiceResult<boolean>>;
  getCategory(id: string): Promise<ServiceResult<Category>>;
  getCategories(filters?: FilterOptions): Promise<ServiceResult<Category[]>>;
  getCategoryHierarchy(): Promise<ServiceResult<Category[]>>;
  validateCategoryHierarchy(categoryId: string, parentId: string): Promise<ServiceResult<boolean>>;
}
