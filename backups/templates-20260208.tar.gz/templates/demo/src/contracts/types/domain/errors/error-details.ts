// ====================================================================
// ERROR DETAIL TYPES
// ====================================================================
// Typed error detail structures
// Replaces Record<string, unknown> and unknown with specific interfaces

/**
 * Error category types
 */
export type ErrorCategory = 'validation' | 'business' | 'system' | 'external' | 'unknown';

/**
 * Base error details structure
 */
export interface BaseErrorDetails {
  /** Error code */
  code?: string;
  /** Error category */
  category?: ErrorCategory;
  /** Component or module where error occurred */
  component?: string;
  /** Stack trace */
  stackTrace?: string;
  /** Timestamp when error occurred */
  timestamp?: Date;
}

/**
 * Validation error details
 */
export interface ValidationErrorDetails extends BaseErrorDetails {
  /** Field that failed validation */
  field: string;
  /** Validation error message */
  message: string;
  /** Value that failed validation */
  value?: unknown;
  /** Validation rule that was violated */
  rule?: string;
  /** Additional validation context */
  validationContext?: {
    [key: string]: unknown;
  };
}

/**
 * Entity error details
 */
export interface EntityErrorDetails extends BaseErrorDetails {
  /** Entity type */
  entityType: string;
  /** Entity ID */
  entityId: string;
  /** Operation that was attempted */
  operation?: string;
}

/**
 * Concurrency error details
 */
export interface ConcurrencyErrorDetails extends BaseErrorDetails {
  /** Resource type */
  resourceType: string;
  /** Resource ID */
  resourceId: string;
  /** Expected version */
  expectedVersion: number;
  /** Actual version */
  actualVersion?: number;
}

/**
 * Authorization error details
 */
export interface AuthorizationErrorDetails extends BaseErrorDetails {
  /** Action that was attempted */
  action: string;
  /** User ID who attempted the action */
  userId?: string;
  /** Resource that was accessed */
  resource?: string;
  /** Required permissions */
  requiredPermissions?: string[];
}

/**
 * Infrastructure error details
 */
export interface InfrastructureErrorDetails extends BaseErrorDetails {
  /** Service name */
  service?: string;
  /** Operation name */
  operation?: string;
  /** Request ID */
  requestId?: string;
  /** Retry information */
  retryInfo?: {
    attempt: number;
    maxAttempts: number;
    nextRetryAt?: Date;
  };
  /** Additional infrastructure context */
  infrastructureContext?: {
    [key: string]: unknown;
  };
}

/**
 * External service error details
 */
export interface ExternalServiceErrorDetails extends BaseErrorDetails {
  /** External service name */
  externalService: string;
  /** Endpoint that was called */
  endpoint?: string;
  /** HTTP status code */
  statusCode?: number;
  /** Response body */
  responseBody?: unknown;
  /** Number of retries attempted */
  retries?: number;
}

/**
 * Business rule error details
 */
export interface BusinessRuleErrorDetails extends BaseErrorDetails {
  /** Business rule that was violated */
  rule: string;
  /** Rule context */
  ruleContext?: {
    [key: string]: unknown;
  };
}

/**
 * Union type for all error details
 */
export type ErrorDetails =
  | BaseErrorDetails
  | ValidationErrorDetails
  | EntityErrorDetails
  | ConcurrencyErrorDetails
  | AuthorizationErrorDetails
  | InfrastructureErrorDetails
  | ExternalServiceErrorDetails
  | BusinessRuleErrorDetails;

/**
 * Error context structure
 */
export interface ErrorContext {
  /** Operation name */
  operation?: string;
  /** Service name */
  service?: string;
  /** User ID */
  userId?: string;
  /** Request ID */
  requestId?: string;
  /** Correlation ID */
  correlationId?: string;
  /** Additional context */
  [key: string]: unknown;
}

/**
 * Type guard to check if details is ValidationErrorDetails
 */
export function isValidationErrorDetails(details: ErrorDetails): details is ValidationErrorDetails {
  return 'field' in details && 'message' in details;
}

/**
 * Type guard to check if details is EntityErrorDetails
 */
export function isEntityErrorDetails(details: ErrorDetails): details is EntityErrorDetails {
  return 'entityType' in details && 'entityId' in details;
}

/**
 * Type guard to check if details is ConcurrencyErrorDetails
 */
export function isConcurrencyErrorDetails(
  details: ErrorDetails
): details is ConcurrencyErrorDetails {
  return 'resourceType' in details && 'resourceId' in details && 'expectedVersion' in details;
}

/**
 * Type guard to check if details is AuthorizationErrorDetails
 */
export function isAuthorizationErrorDetails(
  details: ErrorDetails
): details is AuthorizationErrorDetails {
  return 'action' in details;
}

/**
 * Type guard to check if details is InfrastructureErrorDetails
 */
export function isInfrastructureErrorDetails(
  details: ErrorDetails
): details is InfrastructureErrorDetails {
  return 'service' in details || 'operation' in details;
}

/**
 * Type guard to check if details is ExternalServiceErrorDetails
 */
export function isExternalServiceErrorDetails(
  details: ErrorDetails
): details is ExternalServiceErrorDetails {
  return 'externalService' in details;
}

/**
 * Type guard to check if details is BusinessRuleErrorDetails
 */
export function isBusinessRuleErrorDetails(
  details: ErrorDetails
): details is BusinessRuleErrorDetails {
  return 'rule' in details;
}
