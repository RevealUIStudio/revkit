// ====================================================================
// INDUSTRY TEMPLATE ENTITIES
// ====================================================================

export interface IndustryTemplateTerminology {
  users: string;
  products: string;
  events: string;
  categories: string;
  revenue: string;
  analytics: string;
}

export interface IndustryTemplateColors {
  primary: string;
  secondary: string;
  accent: string;
  success: string;
  warning: string;
  error: string;
}

export interface IndustryTemplateIcons {
  dashboard: string;
  users: string;
  products: string;
  events: string;
  analytics: string;
  revenue: string;
  settings: string;
}

export interface IndustryTemplateLayout {
  sidebarPosition: 'left' | 'right' | 'top' | 'bottom';
  navigationStyle: 'vertical' | 'horizontal' | 'tabs' | 'breadcrumbs';
  cardLayout: 'grid' | 'list' | 'masonry' | 'carousel';
}

export interface IndustryTemplateUIConfig {
  terminology: IndustryTemplateTerminology;
  colors: IndustryTemplateColors;
  icons: IndustryTemplateIcons;
  layout: IndustryTemplateLayout;
}

export interface IndustryTemplateWorkflow {
  userOnboarding: {
    enabled: boolean;
    steps: Array<{
      step: string;
      description?: string;
      required: boolean;
      order: number;
      estimatedTime?: number;
    }>;
  };
  productWorkflow: {
    draftReview: boolean;
    publishReview: boolean;
    approvalRequired: boolean;
  };
  orderWorkflow: {
    autoFulfillment: boolean;
    requirePayment: boolean;
    allowCancellation: boolean;
  };
}

export interface IndustryTemplate {
  id: string;
  name: string;
  industry: string;
  description: string;
  uiConfig: IndustryTemplateUIConfig;
  workflow: IndustryTemplateWorkflow;
  features: string[];
  createdAt: string;
  updatedAt: string;
}
