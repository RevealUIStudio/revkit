// ====================================================================
// PRODUCT DOMAIN SERVICE
// ====================================================================

import type { Product as RevealUIProduct } from '@revealui/infrastructure/cms/db/revealui-types';
import type { FilterOptions } from '@revealui/infrastructure/query';
import type { ServiceResult } from '../service-results';

/**
 * Product Inventory Interface
 */
export interface ProductInventory {
  stock: number;
  lowStockThreshold: number;
}

/**
 * Create Product Input
 */
export interface CreateProductInput {
  title: string;
  description: string;
  slug: string;
  type: string;
  category: string;
  price: number;
  currency: string;
  inventory: ProductInventory;
  featured?: boolean;
}

/**
 * Update Product Input
 */
export interface UpdateProductInput {
  title?: string;
  description?: string;
  slug?: string;
  type?: string;
  category?: string;
  price?: number;
  currency?: string;
  inventory?: Partial<ProductInventory>;
  featured?: boolean;
}

/**
 * Product domain service interface
 */
export interface IProductDomainService {
  createProduct(data: CreateProductInput): Promise<ServiceResult<Product>>;

  updateProduct(id: string, data: UpdateProductInput): Promise<ServiceResult<Product>>;

  publishProduct(id: string): Promise<ServiceResult<Product>>;
  unpublishProduct(id: string): Promise<ServiceResult<Product>>;
  deleteProduct(id: string): Promise<ServiceResult<boolean>>;
  getProduct(id: string): Promise<ServiceResult<Product>>;
  getProducts(filters?: FilterOptions): Promise<ServiceResult<Product[]>>;
  updateInventory(
    id: string,
    quantity: number,
    operation: 'add' | 'subtract' | 'set'
  ): Promise<ServiceResult<Product>>;
  checkLowStock(): Promise<ServiceResult<Product[]>>;
}
