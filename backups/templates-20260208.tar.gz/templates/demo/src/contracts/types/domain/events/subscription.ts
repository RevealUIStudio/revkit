// ====================================================================
// SUBSCRIPTION DOMAIN EVENTS
// ====================================================================

import type { DomainEvent } from './base';

export interface SubscriptionCreatedEvent extends DomainEvent<'subscription.created'> {
  data: {
    subscriptionId: string;
    userId: string;
    plan: string;
    price: number;
    currency: string;
  };
}

export interface SubscriptionRenewedEvent extends DomainEvent<'subscription.renewed'> {
  data: {
    subscriptionId: string;
    renewedAt: string;
    nextRenewalDate: string;
    amount: number;
    currency: string;
  };
}

export interface SubscriptionCancelledEvent extends DomainEvent<'subscription.cancelled'> {
  data: {
    subscriptionId: string;
    cancelledAt: string;
    cancelAtPeriodEnd: boolean;
    cancelledBy: string;
    reason?: string;
  };
}

export interface SubscriptionExpiredEvent extends DomainEvent<'subscription.expired'> {
  data: {
    subscriptionId: string;
    expiredAt: string;
    userId: string;
  };
}
