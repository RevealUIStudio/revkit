// ====================================================================
// ARCHITECTURE VALIDATION
// ====================================================================
// Project architecture validation types

/**
 * Architecture rules for project validation
 */
export interface ArchitectureRules {
  forbiddenPatterns: RegExp[];
  requiredDirectories: string[];
  layerBoundaries: Record<string, string[]>;
  namingConventions: {
    components: RegExp;
    services: RegExp;
    repositories: RegExp;
    types: RegExp;
    collections: RegExp;
  };
}

/**
 * Individual validation result
 */
export interface ValidationResult {
  category: string;
  passed: boolean;
  issues: string[];
  recommendations: string[];
}

/**
 * Build configuration
 */
export interface BuildConfig {
  outputDir: string;
  publicDir: string;
  assetsDir: string;
  sourceMaps: boolean;
  minify: boolean;
}

/**
 * Build validation result
 */
export interface BuildValidationResult {
  success: boolean;
  errors: string[];
  warnings: string[];
  duration: number;
  timestamp: string;
}
