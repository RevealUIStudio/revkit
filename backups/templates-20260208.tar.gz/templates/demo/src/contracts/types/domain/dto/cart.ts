// ====================================================================
// CART DTOs
// ====================================================================
// Data Transfer Objects for cart operations

/**
 * Create cart item DTO
 */
export interface CreateCartItemDTO {
  productId: string;
  variantId?: string;
  quantity: number;
}

/**
 * Update cart item DTO
 */
export interface UpdateCartItemDTO {
  itemId: string;
  quantity: number;
}

/**
 * Remove cart item DTO
 */
export interface RemoveCartItemDTO {
  itemId: string;
}

/**
 * Apply coupon DTO
 */
export interface ApplyCouponDTO {
  cartId: string;
  couponCode: string;
}

/**
 * Remove coupon DTO
 */
export interface RemoveCouponDTO {
  cartId: string;
  couponCode: string;
}

/**
 * Cart filters DTO
 */
export interface CartFiltersDTO {
  userId?: string;
  sessionId?: string;
  status?: 'active' | 'abandoned' | 'converted';
  createdAfter?: string;
  createdBefore?: string;
  limit?: number;
  page?: number;
}

/**
 * Cart totals calculation DTO
 */
export interface CartTotalsDTO {
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  currency: string;
}

/**
 * Cart checkout DTO
 */
export interface CartCheckoutDTO {
  cartId: string;
  shippingAddress: {
    street1: string;
    street2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  billingAddress?: {
    street1: string;
    street2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  paymentMethod: {
    type: 'card' | 'paypal' | 'stripe';
    token: string;
  };
  customerEmail?: string;
  customerName?: string;
  notes?: string;
}
