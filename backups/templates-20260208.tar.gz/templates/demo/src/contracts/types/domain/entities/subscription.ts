// ====================================================================
// SUBSCRIPTION DOMAIN ENTITIES
// ====================================================================

import type { BaseEntity } from './base';

export type SubscriptionStatus = 'active' | 'cancelled' | 'expired' | 'past_due';
export type SubscriptionPlan = 'basic' | 'premium' | 'pro' | 'enterprise';

export interface SubscriptionMetadata {
  notes?: string;
  tags?: string[];
  source: 'web' | 'mobile' | 'admin';
  ipAddress?: string;
  userAgent?: string;
}

export interface Subscription extends BaseEntity {
  userId: string;
  user: unknown; // Uses RevealUI Content Engine User type
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  payment: unknown; // PaymentInfo type
  metadata: SubscriptionMetadata;
}
