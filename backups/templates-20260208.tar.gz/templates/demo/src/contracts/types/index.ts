// ====================================================================
// TYPES INDEX - Single Source of Truth
// ====================================================================
// All types exported directly from definition files (no nested index files)
// Primary sources chosen to avoid duplicate exports

// ====================================================================
// SHARED TYPES (foundational - primary source for common patterns)
// ====================================================================
export * from './shared/entities';
export * from './shared/filters';
export * from './shared/helpers';
export * from './shared/pagination';

// ====================================================================
// DOMAIN TYPES (business logic)
// ====================================================================
// All domain types are now organized and re-exported from domain/index
export * from './domain';

// ====================================================================
// INFRASTRUCTURE TYPES (avoid duplicates from base)
// ====================================================================
// Export only unique types from infrastructure to avoid base/common duplicates
export type {
  AnalyticsService,
  CacheType,
  CircuitBreakerState,
  EmailServiceContract,
  EventBus,
  HealthStatus,
  LogLevel,
  ServiceContext,
  ServiceMetrics,
  StorageServiceContract,
} from './infrastructure/service';

export * from './infrastructure/args';
export * from './infrastructure/circuit-breaker';
export * from './infrastructure/crypto';
export * from './infrastructure/date';
export * from './infrastructure/extended-revealui';
export * from './infrastructure/logger';
export * from './infrastructure/media';
export * from './infrastructure/og-image';
export * from './infrastructure/revealui-utils';
export * from './infrastructure/revealui-collections';
export * from './infrastructure/revealui-domain-bridge';

// ====================================================================
// PRESENTATION TYPES (avoid Slug duplicate with base/primitives)
// ====================================================================
// Skip presentation/blocks due to Slug type conflict with base/primitives (via core)
export type {
  BannerBlockProps,
  Block, // Alias to avoid conflict
  CMSLinkType,
  CodeBlockProps,
  CodeBlockPropsExtended,
  CodeLanguage,
  CodeProps,
  DefaultTypedEditorState,
  DeletePostOperationInput,
  LinkAppearances,
  LinkGroupType,
  LinkType,
  MediaBlockProps,
  MediaBlockPropsExtended,
  MediaDisplayOptions,
  MediaGalleryProps,
  MenuItem,
  MenuItemType,
  Overrides,
  PostCard,
  PrefixBlockClientProps,
  PrefixBlockProps,
  Slug as PresentationSlug,
  Props,
  RelatedPostsProps,
  SlugComponentProps,
  ViewMode,
} from './presentation/blocks';
export * from './presentation/next';
export * from './presentation/preview';
export * from './presentation/state/auth';
export * from './presentation/state/forms';
// Skip presentation/state/patterns due to AsyncResult duplicate with base/result

// ====================================================================
// INFRASTRUCTURE TOOLS TYPES
// ====================================================================
export * from './infrastructure/security';
export * from './infrastructure/shell';

// ====================================================================
// PRESENTATION UI TYPES (primary source for UI-related types)
// ====================================================================
// Skip presentation/ui/auth due to AuthState duplicate with presentation/state/auth
export type {
  AuthContextType,
  AuthError,
  AuthErrorType,
  AuthProviderProps,
  AuthResult,
  AuthSession,
  // AuthState is from presentation/state/auth
  BaseAuthState,
  ForgotPasswordData,
  LoginCredentials,
  RegisterData,
  ResetPasswordData,
  TwoFactorSetup,
  UseAuthOptions,
  UseAuthResult,
} from './presentation/ui/auth';

export type {
  AccessibilityProps, // Aliased to avoid conflict with presentation/next
  Author,
  AuthorListProps,
  Category,
  CategoryListProps,
  FlexContainerProps,
  HeroType,
  InputProps,
  OrderSummaryProps,
  PageRangeProps,
  PaginationProps,
  PostCardProps,
  PostProps,
  ProductCardProps,
  ProductFiltersProps,
  ProductGridProps,
  SearchBarProps,
  SearchProps,
  SearchState,
  Tag,
  TagListProps,
  PageProps as UIPageProps,
  UserFormProps,
  UserFormState,
  UserProfileProps,
} from './presentation/ui/components';

export * from './presentation/ui/hooks';
// Skip presentation/ui/link due to LinkAppearances duplicate with presentation/blocks
export * from './presentation/ui/primitives';
export * from './presentation/ui/theme';
