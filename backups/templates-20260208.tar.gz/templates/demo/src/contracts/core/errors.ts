// ====================================================================
// CONTRACT ERROR HANDLING
// ====================================================================
// Contract-specific error types and error handling utilities

import type {z} from 'zod';

/**
 * Contract validation error
 */
export class ContractValidationError extends Error {
  constructor(
    public contractName: string,
    public schemaName: string,
    public zodError: z.ZodError,
    message?: string
  ) {
    super(
      message || `Contract validation failed for ${contractName}.${schemaName}: ${zodError.message}`
    );
    this.name = 'ContractValidationError';
  }

  /**
   * Get formatted error message
   */
  getFormattedMessage(): string {
    const issues = this.zodError.issues.map(issue => {
      const path = issue.path.join('.');
      return `  - ${path}: ${issue.message}`;
    });
    return `Validation failed for ${this.contractName}.${this.schemaName}:\n${issues.join('\n')}`;
  }

  /**
   * Get field errors
   */
  getFieldErrors(): Record<string, string[]> {
    const fieldErrors: Record<string, string[]> = {};
    for (const issue of this.zodError.issues) {
      const path = issue.path.join('.');
      if (!fieldErrors[path]) {
        fieldErrors[path] = [];
      }
      fieldErrors[path].push(issue.message);
    }
    return fieldErrors;
  }
}

/**
 * Contract not found error
 */
export class ContractNotFoundError extends Error {
  constructor(public contractName: string) {
    super(`Contract '${contractName}' not found in registry`);
    this.name = 'ContractNotFoundError';
  }
}

/**
 * Contract dependency error
 */
export class ContractDependencyError extends Error {
  constructor(
    public contractName: string,
    public missingDependency: string
  ) {
    super(`Contract '${contractName}' has missing dependency: '${missingDependency}'`);
    this.name = 'ContractDependencyError';
  }
}

/**
 * Contract circular dependency error
 */
export class ContractCircularDependencyError extends Error {
  constructor(public cycle: string[]) {
    super(`Circular dependency detected: ${cycle.join(' -> ')}`);
    this.name = 'ContractCircularDependencyError';
  }
}

/**
 * Contract version mismatch error
 */
export class ContractVersionMismatchError extends Error {
  constructor(
    public contractName: string,
    public expectedVersion: string,
    public actualVersion: string
  ) {
    super(
      `Contract '${contractName}' version mismatch: expected ${expectedVersion}, got ${actualVersion}`
    );
    this.name = 'ContractVersionMismatchError';
  }
}

/**
 * Contract error recovery strategies
 */

/**
 * Try to recover from validation error by providing defaults
 */
export function recoverWithDefaults<T>(
  error: ContractValidationError,
  defaults: Partial<T>
): Partial<T> {
  const recovered: Partial<T> = { ...defaults };
  const fieldErrors = error.getFieldErrors();

  // Try to use defaults for missing required fields
  for (const field of Object.keys(fieldErrors)) {
    if (defaults[field as keyof T] !== undefined) {
      recovered[field as keyof T] = defaults[field as keyof T];
    }
  }

  return recovered;
}

/**
 * Try to recover by removing invalid fields
 */
export function recoverByRemovingInvalid<T>(error: ContractValidationError, data: T): Partial<T> {
  const recovered: Partial<T> = {};
  const invalidFields = new Set(error.zodError.issues.map(issue => issue.path.join('.')));

  for (const [key, value] of Object.entries(data)) {
    if (!invalidFields.has(key)) {
      recovered[key as keyof T] = value as T[keyof T];
    }
  }

  return recovered;
}

/**
 * Contract error logging utilities
 */

/**
 * Log validation error with context
 */
export function logValidationError(
  error: ContractValidationError,
  context?: Record<string, unknown>
): void {
  console.error('Contract Validation Error:', {
    contract: error.contractName,
    schema: error.schemaName,
    message: error.message,
    fieldErrors: error.getFieldErrors(),
    context,
  });
}

/**
 * Log contract error in structured format
 */
export function logContractError(
  error: Error,
  contractName?: string,
  context?: Record<string, unknown>
): void {
  console.error('Contract Error:', {
    name: error.name,
    message: error.message,
    contract: contractName,
    context,
    stack: error.stack,
  });
}

/**
 * Format contract error for user display
 */
export function formatContractError(error: unknown): string {
  if (error instanceof ContractValidationError) {
    return error.getFormattedMessage();
  }

  if (error instanceof ContractNotFoundError) {
    return `Contract '${error.contractName}' not found`;
  }

  if (error instanceof ContractDependencyError) {
    return `Missing dependency: ${error.missingDependency} for contract ${error.contractName}`;
  }

  if (error instanceof ContractCircularDependencyError) {
    return `Circular dependency: ${error.cycle.join(' -> ')}`;
  }

  if (error instanceof Error) {
    return error.message;
  }

  return 'Unknown contract error';
}

/**
 * Check if error is a contract error
 */
export function isContractError(
  error: unknown
): error is
  | ContractValidationError
  | ContractNotFoundError
  | ContractDependencyError
  | ContractCircularDependencyError
  | ContractVersionMismatchError {
  return (
    error instanceof ContractValidationError ||
    error instanceof ContractNotFoundError ||
    error instanceof ContractDependencyError ||
    error instanceof ContractCircularDependencyError ||
    error instanceof ContractVersionMismatchError
  );
}
