// ====================================================================
// RUNTIME CONTRACT VALIDATION
// ====================================================================
// Runtime validation for contract completeness, versions, and dependencies

import type {ContractName} from '../registry';
import {ContractUtils} from '../registry';
import {
  ContractNotFoundError,
} from './errors';

/**
 * Runtime contract validation result
 */
export interface RuntimeValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validate contract completeness at runtime
 */
export function validateContractCompleteness(contractName: ContractName): RuntimeValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const contract = ContractUtils.get(contractName);
    const validation = ContractUtils.validate(contractName);

    if (!validation.valid) {
      errors.push(...validation.errors);
    }

    if (validation.warnings.length > 0) {
      warnings.push(...validation.warnings);
    }

    // Check structure
    if (!contract.shape) {
      errors.push('Contract shape is missing');
    }
    if (!contract.behavior) {
      errors.push('Contract behavior is missing');
    }
    if (!contract.validation) {
      errors.push('Contract validation is missing');
    }
    if (!contract.metadata) {
      errors.push('Contract metadata is missing');
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  } catch (error) {
    if (error instanceof ContractNotFoundError) {
      return {
        valid: false,
        errors: [error.message],
        warnings: [],
      };
    }
    return {
      valid: false,
      errors: [error instanceof Error ? error.message : 'Unknown error'],
      warnings: [],
    };
  }
}

/**
 * Validate contract version
 */
export function validateContractVersion(
  contractName: ContractName,
  expectedVersion: string
): RuntimeValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const contract = ContractUtils.get(contractName);
    const actualVersion = contract.version;

    if (actualVersion !== expectedVersion) {
      errors.push(`Version mismatch: expected ${expectedVersion}, got ${actualVersion}`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  } catch (error) {
    return {
      valid: false,
      errors: [error instanceof Error ? error.message : 'Unknown error'],
      warnings: [],
    };
  }
}

/**
 * Validate contract dependencies at runtime
 */
export function validateContractDependencies(contractName: ContractName): RuntimeValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  try {
    const contract = ContractUtils.get(contractName);
    const dependsOn = contract.metadata?.dependsOn ?? [];

    // Check all dependencies exist
    for (const dep of dependsOn) {
      if (!ContractUtils.has(dep)) {
        errors.push(`Missing dependency: ${dep}`);
      }
    }

    // Check for circular dependencies
    const circularDeps = ContractUtils.detectCircularDependencies();
    for (const cycle of circularDeps) {
      if (cycle.includes(contractName)) {
        errors.push(`Circular dependency detected: ${cycle.join(' -> ')}`);
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  } catch (error) {
    return {
      valid: false,
      errors: [error instanceof Error ? error.message : 'Unknown error'],
      warnings: [],
    };
  }
}

/**
 * Validate all contracts at runtime
 */
export function validateAllContracts(): Map<ContractName, RuntimeValidationResult> {
  const results = new Map<ContractName, RuntimeValidationResult>();
  const contractNames = ContractUtils.getNames();

  for (const name of contractNames) {
    const completeness = validateContractCompleteness(name);
    const dependencies = validateContractDependencies(name);

    results.set(name, {
      valid: completeness.valid && dependencies.valid,
      errors: [...completeness.errors, ...dependencies.errors],
      warnings: [...completeness.warnings, ...dependencies.warnings],
    });
  }

  return results;
}

/**
 * Contract health monitoring
 */
export class ContractHealthMonitor {
  private healthCache = new Map<ContractName, RuntimeValidationResult>();
  private lastCheck = 0;
  private checkInterval: number;

  constructor(checkInterval: number = 60000) {
    this.checkInterval = checkInterval;
  }

  /**
   * Check contract health
   */
  checkHealth(contractName: ContractName, force: boolean = false): RuntimeValidationResult {
    const now = Date.now();
    const cached = this.healthCache.get(contractName);

    if (!force && cached && now - this.lastCheck < this.checkInterval) {
      return cached;
    }

    const completeness = validateContractCompleteness(contractName);
    const dependencies = validateContractDependencies(contractName);

    const result: RuntimeValidationResult = {
      valid: completeness.valid && dependencies.valid,
      errors: [...completeness.errors, ...dependencies.errors],
      warnings: [...completeness.warnings, ...dependencies.warnings],
    };

    this.healthCache.set(contractName, result);
    this.lastCheck = now;

    return result;
  }

  /**
   * Check all contracts health
   */
  checkAllHealth(force: boolean = false): Map<ContractName, RuntimeValidationResult> {
    const results = new Map<ContractName, RuntimeValidationResult>();
    const contractNames = ContractUtils.getNames();

    for (const name of contractNames) {
      results.set(name, this.checkHealth(name, force));
    }

    return results;
  }

  /**
   * Get unhealthy contracts
   */
  getUnhealthyContracts(): ContractName[] {
    const unhealthy: ContractName[] = [];
    const health = this.checkAllHealth();

    for (const [name, result] of health.entries()) {
      if (!result.valid) {
        unhealthy.push(name);
      }
    }

    return unhealthy;
  }

  /**
   * Clear health cache
   */
  clearCache(): void {
    this.healthCache.clear();
    this.lastCheck = 0;
  }
}

/**
 * Global health monitor instance
 */
export const contractHealthMonitor = new ContractHealthMonitor();
