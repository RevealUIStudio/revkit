// ====================================================================
// CONTRACT TREE-SHAKING SUPPORT
// ====================================================================
// Utilities to ensure contracts are properly tree-shaken

/**
 * Tree-shaking optimization guide
 *
 * To ensure contracts are properly tree-shaken:
 *
 * 1. Use named exports instead of default exports
 * 2. Import only what you need: `import { UserContract, type User } from '@/contracts'`
 * 3. Avoid importing entire contract objects when you only need types
 * 4. Use type-only imports for types: `import type { User } from '@/contracts'`
 * 5. Use contract utilities that support tree-shaking
 *
 * Example of tree-shakeable import:
 * ```typescript
 * import { UserContract, type User, type CreateUser } from '@/contracts';
 * // Only UserContract and types are included, not the entire contracts module
 * ```
 *
 * Example of non-tree-shakeable import:
 * ```typescript
 * import * as Contracts from '@/contracts';
 * // Entire contracts module is included
 * ```
 */

/**
 * Check if an import is tree-shakeable
 */
export function isTreeShakeableImport(importStatement: string): boolean {
  // Named imports are tree-shakeable
  if (importStatement.includes('import {') && importStatement.includes('} from')) {
    return true;
  }

  // Type-only imports are tree-shakeable
  if (importStatement.includes('import type')) {
    return true;
  }

  // Namespace imports are NOT tree-shakeable
  if (importStatement.includes('import *')) {
    return false;
  }

  // Default imports are tree-shakeable if the module uses named exports
  return true;
}

/**
 * Contract tree-shaking analyzer
 */
export class TreeShakingAnalyzer {
  /**
   * Analyze contract imports for tree-shaking opportunities
   */
  analyzeImports(imports: string[]): {
    treeShakeable: number;
    notTreeShakeable: number;
    recommendations: string[];
  } {
    let treeShakeable = 0;
    let notTreeShakeable = 0;
    const recommendations: string[] = [];

    for (const imp of imports) {
      if (isTreeShakeableImport(imp)) {
        treeShakeable++;
      } else {
        notTreeShakeable++;
        if (imp.includes('import *')) {
          recommendations.push(
            `Replace namespace import with named imports: ${imp.substring(0, 50)}...`
          );
        }
      }
    }

    return {
      treeShakeable,
      notTreeShakeable,
      recommendations,
    };
  }
}

/**
 * Global tree-shaking analyzer
 */
export const treeShakingAnalyzer = new TreeShakingAnalyzer();
