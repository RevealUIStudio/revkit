// ====================================================================
// CONTRACT PERFORMANCE MONITORING
// ====================================================================
// Performance monitoring and metrics tracking for contracts

import { ContractUtils } from '../registry';
import type { ContractName } from '../registry';
import { contractUsageTracker } from '../utils';
import { performanceMonitor } from './performance';
import { contractHealthMonitor } from './runtime';

/**
 * Performance metrics for contracts
 */
export interface ContractMetrics {
  contractName: ContractName;
  validationCount: number;
  averageValidationTime: number;
  cacheHitRate: number;
  errorRate: number;
  healthStatus: 'healthy' | 'degraded' | 'unhealthy';
  lastAccess: number;
  usageCount: number;
}

/**
 * Overall contract system metrics
 */
export interface SystemMetrics {
  totalContracts: number;
  healthyContracts: number;
  totalValidations: number;
  averageValidationTime: number;
  cacheHitRate: number;
  adoptionRate: number;
  timestamp: string;
}

/**
 * Contract performance monitor
 */
export class ContractPerformanceMonitor {
  /**
   * Get metrics for a specific contract
   */
  getContractMetrics(contractName: ContractName): ContractMetrics {
    const health = contractHealthMonitor.checkHealth(contractName);
    const usageStats = contractUsageTracker.getUsageStats();
    const contractUsage = usageStats.find(s => s.contract === contractName);
    const perfMetrics = performanceMonitor.getMetrics();

    const validationMetrics = perfMetrics.get('validation') || {
      count: 0,
      totalTime: 0,
      average: 0,
    };
    const cacheMetrics = perfMetrics.get('validation_cache_hit') || {
      count: 0,
      totalTime: 0,
      average: 0,
    };

    const totalValidations = validationMetrics.count + cacheMetrics.count;
    const cacheHitRate = totalValidations > 0 ? (cacheMetrics.count / totalValidations) * 100 : 0;

    return {
      contractName,
      validationCount: validationMetrics.count,
      averageValidationTime: validationMetrics.average,
      cacheHitRate,
      errorRate: 0, // Would need error tracking
      healthStatus: health.valid ? 'healthy' : 'unhealthy',
      lastAccess: contractUsage?.lastAccess || 0,
      usageCount: contractUsage?.count || 0,
    };
  }

  /**
   * Get metrics for all contracts
   */
  getAllMetrics(): Map<ContractName, ContractMetrics> {
    const metrics = new Map<ContractName, ContractMetrics>();
    const contractNames = ContractUtils.getNames();

    for (const name of contractNames) {
      metrics.set(name, this.getContractMetrics(name));
    }

    return metrics;
  }

  /**
   * Get system-wide metrics
   */
  getSystemMetrics(): SystemMetrics {
    const contractNames = ContractUtils.getNames();
    const allMetrics = this.getAllMetrics();

    let totalValidations = 0;
    let totalValidationTime = 0;
    let totalCacheHits = 0;
    let healthyCount = 0;

    for (const metrics of allMetrics.values()) {
      totalValidations += metrics.validationCount;
      totalValidationTime += metrics.averageValidationTime * metrics.validationCount;
      totalCacheHits += metrics.cacheHitRate * metrics.validationCount;
      if (metrics.healthStatus === 'healthy') {
        healthyCount++;
      }
    }

    const averageValidationTime = totalValidations > 0 ? totalValidationTime / totalValidations : 0;
    const cacheHitRate = totalValidations > 0 ? totalCacheHits / totalValidations : 0;

    // Calculate adoption rate (simplified - would need actual usage tracking)
    const adoptionRate = (healthyCount / contractNames.length) * 100;

    return {
      totalContracts: contractNames.length,
      healthyContracts: healthyCount,
      totalValidations,
      averageValidationTime,
      cacheHitRate,
      adoptionRate,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Get performance report
   */
  getPerformanceReport(): string {
    const systemMetrics = this.getSystemMetrics();
    const allMetrics = this.getAllMetrics();

    const report: string[] = [
      '# Contract Performance Report',
      '',
      `Generated: ${systemMetrics.timestamp}`,
      '',
      '## System Metrics',
      '',
      `- Total Contracts: ${systemMetrics.totalContracts}`,
      `- Healthy Contracts: ${systemMetrics.healthyContracts}`,
      `- Total Validations: ${systemMetrics.totalValidations}`,
      `- Average Validation Time: ${systemMetrics.averageValidationTime.toFixed(2)}ms`,
      `- Cache Hit Rate: ${systemMetrics.cacheHitRate.toFixed(1)}%`,
      `- Adoption Rate: ${systemMetrics.adoptionRate.toFixed(1)}%`,
      '',
      '## Contract Metrics',
      '',
    ];

    for (const [name, metrics] of allMetrics.entries()) {
      report.push(`### ${name}`);
      report.push(`- Validations: ${metrics.validationCount}`);
      report.push(`- Avg Time: ${metrics.averageValidationTime.toFixed(2)}ms`);
      report.push(`- Cache Hit Rate: ${metrics.cacheHitRate.toFixed(1)}%`);
      report.push(`- Health: ${metrics.healthStatus}`);
      report.push(`- Usage Count: ${metrics.usageCount}`);
      report.push('');
    }

    return report.join('\n');
  }

  /**
   * Clear all metrics
   */
  clearMetrics(): void {
    performanceMonitor.clear();
    contractHealthMonitor.clearCache();
    contractUsageTracker.clear();
  }
}

/**
 * Global performance monitor instance
 */
export const contractPerformanceMonitor = new ContractPerformanceMonitor();
