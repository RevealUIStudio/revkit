// ====================================================================
// CONTRACT CORE TYPES
// ====================================================================
// Core type definitions for the unified contract snapshot system

export type {
  ContractBehavior,
  ContractConfig,
  ContractDTOs,
  ContractLayer,
  ContractMetadata,
  ContractRegistry,
  ContractShape,
  ContractSnapshot,
  ContractValidation,
  ExtractCreateDTO,
  ExtractEntity,
  ExtractService,
  ExtractUpdateDTO,
  ContractName,
  GetContract,
} from '@revealui/core/shared-types';
