// ====================================================================
// CONTRACT PERFORMANCE OPTIMIZATIONS
// ====================================================================
// Performance optimizations for contract system including:
// - Schema compilation caching
// - Lazy contract loading
// - Registry lookup optimization
// - Contract memoization
// - Tree-shaking support

import type { z } from 'zod';
import type { ContractSnapshot } from './types';

/**
 * Schema compilation cache
 * Caches compiled Zod schemas to avoid re-compilation
 */
class SchemaCache {
  private cache = new Map<string, z.ZodTypeAny>();
  private maxSize: number;

  constructor(maxSize: number = 100) {
    this.maxSize = maxSize;
  }

  /**
   * Get a cached schema or compile and cache it
   */
  get(key: string, factory: () => z.ZodTypeAny): z.ZodTypeAny {
    if (this.cache.has(key)) {
      return this.cache.get(key)!;
    }

    const schema = factory();

    // Evict oldest entries if cache is full
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    this.cache.set(key, schema);
    return schema;
  }

  /**
   * Clear the cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Get cache size
   */
  size(): number {
    return this.cache.size;
  }

  /**
   * Check if key exists in cache
   */
  has(key: string): boolean {
    return this.cache.has(key);
  }
}

/**
 * Contract memoization cache
 * Caches contract access results
 */
class ContractMemoCache {
  private cache = new Map<string, unknown>();
  private maxSize: number;

  constructor(maxSize: number = 50) {
    this.maxSize = maxSize;
  }

  /**
   * Get or compute and cache a value
   */
  get<T>(key: string, factory: () => T): T {
    if (this.cache.has(key)) {
      return this.cache.get(key) as T;
    }

    const value = factory();

    // Evict oldest entries if cache is full
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    this.cache.set(key, value);
    return value;
  }

  /**
   * Clear the cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Get cache size
   */
  size(): number {
    return this.cache.size;
  }
}

/**
 * Global schema cache instance
 */
const globalSchemaCache = new SchemaCache(100);

/**
 * Global contract memo cache instance
 */
const globalContractMemoCache = new ContractMemoCache(50);

/**
 * Get or compile a schema with caching
 */
export function getCachedSchema(
  contractName: string,
  schemaName: string,
  factory: () => z.ZodTypeAny
): z.ZodTypeAny {
  const key = `${contractName}:${schemaName}`;
  return globalSchemaCache.get(key, factory);
}

/**
 * Memoize a contract operation
 */
export function memoizeContract<T>(contractName: string, operation: string, factory: () => T): T {
  const key = `${contractName}:${operation}`;
  return globalContractMemoCache.get(key, factory);
}

/**
 * Clear all performance caches
 */
export function clearPerformanceCaches(): void {
  globalSchemaCache.clear();
  globalContractMemoCache.clear();
}

/**
 * Get cache statistics
 */
export function getCacheStats(): {
  schemaCache: { size: number; maxSize: number };
  memoCache: { size: number; maxSize: number };
} {
  return {
    schemaCache: {
      size: globalSchemaCache.size(),
      maxSize: 100,
    },
    memoCache: {
      size: globalContractMemoCache.size(),
      maxSize: 50,
    },
  };
}

/**
 * Lazy contract loader
 * Loads contracts on-demand to reduce initial bundle size
 */
export class LazyContractLoader {
  private loadedContracts = new Map<string, ContractSnapshot>();
  private loaders = new Map<string, () => Promise<ContractSnapshot>>();

  /**
   * Register a contract loader
   */
  register(name: string, loader: () => Promise<ContractSnapshot>): void {
    this.loaders.set(name, loader);
  }

  /**
   * Load a contract (cached after first load)
   */
  async load(name: string): Promise<ContractSnapshot> {
    if (this.loadedContracts.has(name)) {
      return this.loadedContracts.get(name)!;
    }

    const loader = this.loaders.get(name);
    if (!loader) {
      throw new Error(`No loader registered for contract: ${name}`);
    }

    const contract = await loader();
    this.loadedContracts.set(name, contract);
    return contract;
  }

  /**
   * Preload a contract
   */
  async preload(name: string): Promise<void> {
    await this.load(name);
  }

  /**
   * Preload multiple contracts
   */
  async preloadMultiple(names: string[]): Promise<void> {
    await Promise.all(names.map(name => this.preload(name)));
  }

  /**
   * Check if contract is loaded
   */
  isLoaded(name: string): boolean {
    return this.loadedContracts.has(name);
  }

  /**
   * Clear loaded contracts (force reload)
   */
  clear(): void {
    this.loadedContracts.clear();
  }
}

/**
 * Global lazy contract loader instance
 */
export const lazyContractLoader = new LazyContractLoader();

/**
 * Optimized contract registry lookup
 * Uses memoization for frequently accessed contracts
 */
export class OptimizedContractRegistry {
  private lookupCache = new Map<string, ContractSnapshot>();
  private accessCounts = new Map<string, number>();

  /**
   * Get contract with memoization
   */
  get<T extends ContractSnapshot>(name: string, registry: Record<string, T>): T | undefined {
    // Track access count for potential optimization
    this.accessCounts.set(name, (this.accessCounts.get(name) || 0) + 1);

    // Use cache if available
    if (this.lookupCache.has(name)) {
      return this.lookupCache.get(name) as T;
    }

    const contract = registry[name];
    if (contract) {
      this.lookupCache.set(name, contract);
    }

    return contract;
  }

  /**
   * Clear lookup cache
   */
  clear(): void {
    this.lookupCache.clear();
    this.accessCounts.clear();
  }

  /**
   * Get access statistics
   */
  getAccessStats(): Array<{ name: string; count: number }> {
    return Array.from(this.accessCounts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }
}

/**
 * Global optimized registry instance
 */
export const optimizedRegistry = new OptimizedContractRegistry();

/**
 * Performance monitoring for contracts
 */
export class ContractPerformanceMonitor {
  private metrics = new Map<string, { count: number; totalTime: number }>();

  /**
   * Record a contract operation
   */
  record(operation: string, duration: number): void {
    const existing = this.metrics.get(operation) || { count: 0, totalTime: 0 };
    this.metrics.set(operation, {
      count: existing.count + 1,
      totalTime: existing.totalTime + duration,
    });
  }

  /**
   * Get average time for an operation
   */
  getAverageTime(operation: string): number {
    const metric = this.metrics.get(operation);
    if (!metric || metric.count === 0) {
      return 0;
    }
    return metric.totalTime / metric.count;
  }

  /**
   * Get all metrics
   */
  getMetrics(): Map<string, { count: number; totalTime: number; average: number }> {
    const result = new Map();
    for (const [operation, metric] of this.metrics.entries()) {
      result.set(operation, {
        ...metric,
        average: metric.count > 0 ? metric.totalTime / metric.count : 0,
      });
    }
    return result;
  }

  /**
   * Clear metrics
   */
  clear(): void {
    this.metrics.clear();
  }
}

/**
 * Global performance monitor instance
 */
export const performanceMonitor = new ContractPerformanceMonitor();
