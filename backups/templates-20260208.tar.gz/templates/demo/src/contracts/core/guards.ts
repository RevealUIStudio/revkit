// ====================================================================
// CONTRACT TYPE GUARDS
// ====================================================================
// Runtime type guards generated from contract schemas
// Provides type-safe runtime validation

import type {z} from 'zod';
import type {ContractName} from '../registry';
import {ContractUtils,Contracts} from '../registry';

/**
 * Type guard result
 */
export interface TypeGuardResult<T> {
  success: boolean;
  data?: T;
  errors?: z.ZodError;
}

/**
 * Create a type guard from a Zod schema
 */
export function createTypeGuard<T>(schema: z.ZodType<T>): (data: unknown) => data is T {
  return (data: unknown): data is T => {
    return schema.safeParse(data).success;
  };
}

/**
 * Create a type guard with detailed result
 */
export function createTypeGuardWithResult<T>(
  schema: z.ZodType<T>
): (data: unknown) => TypeGuardResult<T> {
  return (data: unknown): TypeGuardResult<T> => {
    const result = schema.safeParse(data);
    if (result.success) {
      return { success: true, data: result.data };
    }
    return { success: false, errors: result.error };
  };
}

/**
 * User contract type guards
 */
export const isUser = createTypeGuard(Contracts.user.validation.create);
export const isCreateUser = createTypeGuard(Contracts.user.validation.create);
export const isUpdateUser = createTypeGuard(Contracts.user.validation.update);

/**
 * Product contract type guards
 */
export const isProduct = createTypeGuard(Contracts.product.validation.create);
export const isCreateProduct = createTypeGuard(Contracts.product.validation.create);
export const isUpdateProduct = createTypeGuard(Contracts.product.validation.update);

/**
 * Cart contract type guards
 */
export const isCart = createTypeGuard(Contracts.cart.validation.create);
export const isCreateCartItem = createTypeGuard(Contracts.cart.validation.create);
export const isUpdateCartItem = createTypeGuard(Contracts.cart.validation.update);

/**
 * Order contract type guards
 */
export const isOrder = createTypeGuard(Contracts.order.validation.create);
export const isCreateOrder = createTypeGuard(Contracts.order.validation.create);
export const isUpdateOrder = createTypeGuard(Contracts.order.validation.update);

/**
 * Category contract type guards
 */
export const isCategory = createTypeGuard(Contracts.category.validation.create);
export const isCreateCategory = createTypeGuard(Contracts.category.validation.create);
export const isUpdateCategory = createTypeGuard(Contracts.category.validation.update);

/**
 * Post contract type guards
 */
export const isPost = createTypeGuard(Contracts.post.validation.create);
export const isCreatePost = createTypeGuard(Contracts.post.validation.create);
export const isUpdatePost = createTypeGuard(Contracts.post.validation.update);

/**
 * Fight contract type guards
 */
export const isFight = createTypeGuard(Contracts.fight.validation.create);
export const isCreateFight = createTypeGuard(Contracts.fight.validation.create);
export const isUpdateFight = createTypeGuard(Contracts.fight.validation.update);

/**
 * Media contract type guards
 */
export const isMedia = createTypeGuard(Contracts.media.validation['upload']);
export const isUploadMedia = createTypeGuard(Contracts.media.validation['upload']);
export const isUpdateMedia = createTypeGuard(Contracts.media.validation['update']);

/**
 * Menu contract type guards
 */
export const isMenu = createTypeGuard(Contracts.menu.validation.create);
export const isCreateMenu = createTypeGuard(Contracts.menu.validation.create);
export const isUpdateMenu = createTypeGuard(Contracts.menu.validation.update);

/**
 * Tag contract type guards
 */
export const isTag = createTypeGuard(Contracts.tag.validation.create);
export const isCreateTag = createTypeGuard(Contracts.tag.validation.create);
export const isUpdateTag = createTypeGuard(Contracts.tag.validation.update);

/**
 * Generic contract type guard factory
 * Creates type guards for any contract
 */
export function createContractTypeGuard<T extends ContractName>(
  contractName: T,
  schemaName: 'create' | 'update' | string = 'create'
): (data: unknown) => boolean {
  const contract = ContractUtils.get(contractName);
  const schema = contract.validation[schemaName as keyof typeof contract.validation];

  if (!schema || typeof schema !== 'object' || !('safeParse' in schema)) {
    throw new Error(`Invalid schema for ${contractName}.${schemaName}`);
  }

  return (data: unknown): boolean => {
    try {
      return (schema as z.ZodTypeAny).safeParse(data).success;
    } catch {
      return false;
    }
  };
}

/**
 * Generic contract type guard with result
 */
export function createContractTypeGuardWithResult<T extends ContractName>(
  contractName: T,
  schemaName: 'create' | 'update' | string = 'create'
): (data: unknown) => TypeGuardResult<unknown> {
  const contract = ContractUtils.get(contractName);
  const schema = contract.validation[schemaName as keyof typeof contract.validation];

  if (!schema || typeof schema !== 'object' || !('safeParse' in schema)) {
    throw new Error(`Invalid schema for ${contractName}.${schemaName}`);
  }

  return (data: unknown): TypeGuardResult<unknown> => {
    try {
      const result = (schema as z.ZodTypeAny).safeParse(data);
      if (result.success) {
        return { success: true, data: result.data };
      }
      return { success: false, errors: result.error };
    } catch {
      return { success: false };
    }
  };
}

/**
 * Validate multiple items with a type guard
 */
export function validateArray<T>(
  typeGuard: (data: unknown) => data is T,
  items: unknown[]
): { valid: T[]; invalid: unknown[] } {
  const valid: T[] = [];
  const invalid: unknown[] = [];

  for (const item of items) {
    if (typeGuard(item)) {
      valid.push(item);
    } else {
      invalid.push(item);
    }
  }

  return { valid, invalid };
}

/**
 * Assert that data matches a type guard, throwing if not
 */
export function assertType<T>(
  typeGuard: (data: unknown) => data is T,
  data: unknown,
  message?: string
): asserts data is T {
  if (!typeGuard(data)) {
    throw new Error(message || 'Type assertion failed');
  }
}
