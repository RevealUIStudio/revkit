// ====================================================================
// CONTRACT TESTING UTILITIES
// ====================================================================
// Utilities for generating test data and validating contracts in tests

import type { z } from 'zod';
import { ContractUtils, Contracts } from '../registry';
import type { ContractName } from '../registry';

/**
 * Generate test data from a Zod schema
 */
export function generateTestData<T>(schema: z.ZodType<T>): T {
  // Use Zod's built-in random generation if available
  // Otherwise, create minimal valid data
  try {
    // Try to generate from schema
    if ('_def' in schema && typeof (schema as any)._def === 'object') {
      // This is a simplified approach - in practice, you'd use a library like zod-mock
      return {} as T;
    }
  } catch {
    // Fallback to empty object
  }

  return {} as T;
}

/**
 * Generate test data for a contract
 */
export function generateContractTestData<T extends ContractName>(
  contractName: T,
  schemaName: 'create' | 'update' | string = 'create'
): unknown {
  const contract = ContractUtils.get(contractName);
  const schema = contract.validation[schemaName as keyof typeof contract.validation];

  if (!schema || typeof schema !== 'object') {
    throw new Error(`Invalid schema for ${contractName}.${schemaName}`);
  }

  return generateTestData(schema as z.ZodTypeAny);
}

/**
 * Create a contract mock
 */
export function createContractMock<T extends ContractName>(
  contractName: T,
  overrides?: Partial<unknown>
): unknown {
  const testData = generateContractTestData(contractName, 'create');
  return { ...testData, ...overrides };
}

/**
 * Validate test data against contract
 */
export function validateTestData<T extends ContractName>(
  contractName: T,
  data: unknown,
  schemaName: 'create' | 'update' | string = 'create'
): { valid: boolean; errors?: z.ZodError } {
  const contract = ContractUtils.get(contractName);
  const schema = contract.validation[schemaName as keyof typeof contract.validation];

  if (!schema || typeof schema !== 'object' || !('safeParse' in schema)) {
    return { valid: false };
  }

  const result = (schema as z.ZodTypeAny).safeParse(data);
  if (result.success) {
    return { valid: true };
  }

  return { valid: false, errors: result.error };
}

/**
 * Contract test helper functions
 */

/**
 * Create a valid test entity
 */
export function createValidEntity<T extends ContractName>(contractName: T): unknown {
  return generateContractTestData(contractName, 'create');
}

/**
 * Create an invalid test entity (missing required fields)
 */
export function createInvalidEntity<T extends ContractName>(contractName: T): unknown {
  return {};
}

/**
 * Create a partial test entity (for updates)
 */
export function createPartialEntity<T extends ContractName>(contractName: T): unknown {
  return generateContractTestData(contractName, 'update');
}

/**
 * Assert that data is valid for a contract
 */
export function assertValid<T extends ContractName>(
  contractName: T,
  data: unknown,
  schemaName: 'create' | 'update' | string = 'create'
): void {
  const result = validateTestData(contractName, data, schemaName);
  if (!result.valid) {
    throw new Error(
      `Data is not valid for ${contractName}.${schemaName}: ${result.errors?.message || 'Unknown error'}`
    );
  }
}

/**
 * Assert that data is invalid for a contract
 */
export function assertInvalid<T extends ContractName>(
  contractName: T,
  data: unknown,
  schemaName: 'create' | 'update' | string = 'create'
): void {
  const result = validateTestData(contractName, data, schemaName);
  if (result.valid) {
    throw new Error(`Data should be invalid for ${contractName}.${schemaName}`);
  }
}

/**
 * Contract integration test helper functions
 */

/**
 * Setup contract mocks for testing
 */
export function setupContractMocks(): void {
  // This would set up mocks for contract dependencies
  // Implementation depends on your testing framework
}

/**
 * Teardown contract mocks
 */
export function teardownContractMocks(): void {
  // Clean up mocks
}

/**
 * Test contract validation flow
 */
export async function testValidationFlow<T extends ContractName>(
  contractName: T,
  testData: unknown
): Promise<{ success: boolean; errors?: string[] }> {
  const result = validateTestData(contractName, testData, 'create');
  if (!result.valid) {
    return {
      success: false,
      errors: result.errors?.issues.map(i => i.message),
    };
  }
  return { success: true };
}
