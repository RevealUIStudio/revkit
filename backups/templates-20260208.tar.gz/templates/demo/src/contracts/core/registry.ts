// ====================================================================
// CONTRACT REGISTRY
// ====================================================================
// Registry system for managing all domain contracts

import type {
  ContractHealthStatus,
  ContractValidationResult,
  IContractRegistry,
} from '@revealui/core/shared-types';
import { ContractRegistryImpl } from '@revealui/core/shared-types';
import type { ContractSnapshot } from './types';

/**
 * Base contract registry implementation
 */
class BaseContractRegistry<T extends Record<string, ContractSnapshot>>
  implements IContractRegistry<T> {
  private readonly contracts: T;
  private validationCache: Map<string, ContractValidationResult> = new Map();
  private healthCache: Map<string, ContractHealthStatus> = new Map();

  constructor(contracts: T) {
    this.contracts = contracts;
    // Validate all contracts on construction
    this.validateAll();
  }

  getNames(): Array<keyof T> {
    return Object.keys(this.contracts) as Array<keyof T>;
  }

  get<K extends keyof T>(name: K): T[K] {
    if (!this.has(name)) {
      throw new Error(`Contract '${String(name)}' not found in registry`);
    }
    return this.contracts[name];
  }

  has<K extends keyof T>(name: K): boolean {
    return name in this.contracts;
  }

  getAll(): T {
    return this.contracts;
  }

  size(): number {
    return this.getNames().length;
  }

  validateContract<K extends keyof T>(name: K): ContractValidationResult {
    const cacheKey = String(name);

    // Return cached result if available
    if (this.validationCache.has(cacheKey)) {
      return this.validationCache.get(cacheKey)!;
    }

    const contract = this.contracts[name];
    const errors: string[] = [];
    const warnings: string[] = [];

    // Validate domain name
    if (!contract.domain || typeof contract.domain !== 'string') {
      errors.push('Contract must have a valid domain name');
    }

    // Validate version
    if (!contract.version || typeof contract.version !== 'string') {
      errors.push('Contract must have a valid version');
    }

    // Validate shape
    if (!contract.shape) {
      errors.push('Contract must have a shape definition');
    } else {
      if (!contract.shape.entity) {
        errors.push('Contract shape must have an entity definition');
      }
      if (!contract.shape.dto) {
        errors.push('Contract shape must have DTO definitions');
      } else {
        if (!contract.shape.dto.create) {
          errors.push('Contract shape must have a create DTO');
        }
        if (!contract.shape.dto.update) {
          errors.push('Contract shape must have an update DTO');
        }
      }
    }

    // Validate behavior
    if (!contract.behavior) {
      errors.push('Contract must have a behavior definition');
    } else {
      if (!contract.behavior.service) {
        errors.push('Contract behavior must have a service interface');
      }
    }

    // Validate validation schemas
    if (!contract.validation) {
      errors.push('Contract must have validation schemas');
    } else {
      if (!contract.validation.create) {
        errors.push('Contract must have a create validation schema');
      }
      if (!contract.validation.update) {
        errors.push('Contract must have an update validation schema');
      }
    }

    // Validate metadata
    if (!contract.metadata) {
      errors.push('Contract must have metadata');
    } else {
      if (!contract.metadata.layer) {
        errors.push('Contract metadata must have a layer');
      }
      if (!Array.isArray(contract.metadata.dependsOn)) {
        errors.push('Contract metadata dependsOn must be an array');
      }
      if (!Array.isArray(contract.metadata.usedBy)) {
        errors.push('Contract metadata usedBy must be an array');
      }
      if (!contract.metadata.lastModified) {
        warnings.push('Contract metadata should have lastModified timestamp');
      }
    }

    const result: ContractValidationResult = {
      valid: errors.length === 0,
      errors,
      warnings,
    };

    // Cache the result
    this.validationCache.set(cacheKey, result);

    return result;
  }

  validateAll(): Map<string, ContractValidationResult> {
    const results = new Map<string, ContractValidationResult>();

    for (const name of this.getNames()) {
      results.set(String(name), this.validateContract(name));
    }

    return results;
  }

  checkHealth<K extends keyof T>(name: K): ContractHealthStatus {
    const cacheKey = String(name);

    // Return cached result if available
    if (this.healthCache.has(cacheKey)) {
      return this.healthCache.get(cacheKey)!;
    }

    const contract = this.contracts[name];
    const issues: string[] = [];
    const missingDeps: string[] = [];
    const circularDeps: string[] = [];

    // Validate contract first
    const validation = this.validateContract(name);
    if (!validation.valid) {
      issues.push(...validation.errors);
    }

    // Check dependencies exist
    if (contract.metadata?.dependsOn) {
      for (const dep of contract.metadata.dependsOn) {
        if (!this.has(dep as keyof T)) {
          missingDeps.push(dep);
          issues.push(`Missing dependency: ${dep}`);
        }
      }
    }

    // Check for circular dependencies (basic check)
    const circular = this.detectCircularDependencies();
    const contractName = String(name);
    for (const cycle of circular) {
      if (cycle.includes(contractName)) {
        circularDeps.push(...cycle);
        issues.push(`Circular dependency detected: ${cycle.join(' -> ')}`);
      }
    }

    const health: ContractHealthStatus = {
      healthy: issues.length === 0,
      issues,
      dependencies: {
        missing: missingDeps,
        circular: circularDeps,
      },
    };

    // Cache the result
    this.healthCache.set(cacheKey, health);

    return health;
  }

  checkAllHealth(): Map<string, ContractHealthStatus> {
    const results = new Map<string, ContractHealthStatus>();

    for (const name of this.getNames()) {
      results.set(String(name), this.checkHealth(name));
    }

    return results;
  }

  getDependencies<K extends keyof T>(name: K): string[] {
    const contract = this.contracts[name];
    return contract.metadata?.dependsOn ?? [];
  }

  getDependents<K extends keyof T>(name: K): Array<keyof T> {
    const contractName = String(name);
    const dependents: Array<keyof T> = [];

    for (const contractKey of this.getNames()) {
      const contract = this.contracts[contractKey];
      const deps = contract.metadata?.dependsOn ?? [];
      if (deps.includes(contractName)) {
        dependents.push(contractKey);
      }
    }

    return dependents;
  }

  detectCircularDependencies(): string[][] {
    const cycles: string[][] = [];
    const visited = new Set<string>();
    const recursionStack = new Set<string>();

    const contractNames = this.getNames().map(String);

    const dfs = (name: string, path: string[]): void => {
      if (recursionStack.has(name)) {
        // Found a cycle
        const cycleStart = path.indexOf(name);
        const cycle = path.slice(cycleStart).concat(name);
        cycles.push(cycle);
        return;
      }

      if (visited.has(name)) {
        return;
      }

      visited.add(name);
      recursionStack.add(name);

      const contract = this.contracts[name as keyof T];
      const deps = contract.metadata?.dependsOn ?? [];

      for (const dep of deps) {
        if (contractNames.includes(dep)) {
          dfs(dep, [...path, name]);
        }
      }

      recursionStack.delete(name);
    };

    for (const name of contractNames) {
      if (!visited.has(name)) {
        dfs(name, []);
      }
    }

    return cycles;
  }

  /**
   * Clear validation and health caches
   */
  clearCache(): void {
    this.validationCache.clear();
    this.healthCache.clear();
  }
}

/**
 * Create a contract registry with validation
 *
 * @param contracts - Object mapping domain names to contract snapshots
 * @param options - Optional configuration
 * @returns Contract registry instance
 */
export function createContractRegistry<T extends Record<string, ContractSnapshot>>(
  contracts: T,
  options?: {
    validateOnCreation?: boolean;
    throwOnValidationError?: boolean;
  }
): IContractRegistry<T> {
  const registry = new BaseContractRegistry(contracts);

  // Validate all contracts on creation if requested
  if (options?.validateOnCreation !== false) {
    const validationResults = registry.validateAll();

    if (options?.throwOnValidationError) {
      const errors: string[] = [];
      for (const [name, result] of validationResults) {
        if (!result.valid) {
          errors.push(`Contract '${name}' validation failed: ${result.errors.join(', ')}`);
        }
      }
      if (errors.length > 0) {
        throw new Error(`Contract registry validation failed:\n${errors.join('\n')}`);
      }
    }
  }

  return registry;
}

/**
 * Contract registry factory
 */
export const ContractRegistryFactory = {
  /**
   * Create a new registry
   */
  create<T extends Record<string, ContractSnapshot>>(
    contracts: T,
    options?: {
      validateOnCreation?: boolean;
      throwOnValidationError?: boolean;
    }
  ): IContractRegistry<T> {
    return createContractRegistry(contracts, options);
  },

  /**
   * Create an empty registry
   */
  empty(): IContractRegistry<Record<string, never>> {
    return createContractRegistry({} as Record<string, never>);
  },
};
