// ====================================================================
// TYPE SYSTEM PERFORMANCE OPTIMIZATIONS
// ====================================================================
// Optimizations for type extraction, inference, and contract lookups

import { performanceMonitor } from './performance';
import type { ContractSnapshot } from './types';

/**
 * Type extraction cache
 * Caches type extraction results to avoid repeated computation
 */
class TypeExtractionCache {
  private cache = new Map<string, unknown>();
  private maxSize: number;

  constructor(maxSize: number = 50) {
    this.maxSize = maxSize;
  }

  /**
   * Get cached type extraction result
   */
  get<T>(key: string): T | null {
    return (this.cache.get(key) as T) || null;
  }

  /**
   * Set cached type extraction result
   */
  set<T>(key: string, value: T): void {
    // Evict oldest entries if cache is full
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    this.cache.set(key, value);
  }

  /**
   * Clear cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Get cache size
   */
  size(): number {
    return this.cache.size;
  }
}

/**
 * Global type extraction cache
 */
const typeCache = new TypeExtractionCache(50);

/**
 * Optimized entity type extraction
 */
export function extractEntityType<C extends ContractSnapshot>(contract: C): C['shape']['entity'] {
  const startTime = performance.now();
  const cacheKey = `${contract.domain}:entity`;

  // Try cache first
  const cached = typeCache.get<C['shape']['entity']>(cacheKey);
  if (cached) {
    performanceMonitor.record('type_extraction_cache_hit', performance.now() - startTime);
    return cached;
  }

  // Extract type (this is a type-level operation, but we cache the result shape)
  const entity = contract.shape.entity;
  typeCache.set(cacheKey, entity);

  const duration = performance.now() - startTime;
  performanceMonitor.record('type_extraction', duration);

  return entity;
}

/**
 * Optimized DTO type extraction
 */
export function extractCreateDTO<C extends ContractSnapshot>(
  contract: C
): C['shape']['dto']['create'] {
  const startTime = performance.now();
  const cacheKey = `${contract.domain}:dto:create`;

  const cached = typeCache.get<C['shape']['dto']['create']>(cacheKey);
  if (cached) {
    performanceMonitor.record('type_extraction_cache_hit', performance.now() - startTime);
    return cached;
  }

  const dto = contract.shape.dto.create;
  typeCache.set(cacheKey, dto);

  const duration = performance.now() - startTime;
  performanceMonitor.record('type_extraction', duration);

  return dto;
}

/**
 * Optimized update DTO type extraction
 */
export function extractUpdateDTO<C extends ContractSnapshot>(
  contract: C
): C['shape']['dto']['update'] {
  const startTime = performance.now();
  const cacheKey = `${contract.domain}:dto:update`;

  const cached = typeCache.get<C['shape']['dto']['update']>(cacheKey);
  if (cached) {
    performanceMonitor.record('type_extraction_cache_hit', performance.now() - startTime);
    return cached;
  }

  const dto = contract.shape.dto.update;
  typeCache.set(cacheKey, dto);

  const duration = performance.now() - startTime;
  performanceMonitor.record('type_extraction', duration);

  return dto;
}

/**
 * Optimized service type extraction
 */
export function extractServiceType<C extends ContractSnapshot>(
  contract: C
): C['behavior']['service'] {
  const startTime = performance.now();
  const cacheKey = `${contract.domain}:service`;

  const cached = typeCache.get<C['behavior']['service']>(cacheKey);
  if (cached) {
    performanceMonitor.record('type_extraction_cache_hit', performance.now() - startTime);
    return cached;
  }

  const service = contract.behavior.service;
  typeCache.set(cacheKey, service);

  const duration = performance.now() - startTime;
  performanceMonitor.record('type_extraction', duration);

  return service;
}

/**
 * Batch type extraction for multiple contracts
 */
export function extractTypesBatch<C extends ContractSnapshot>(
  contracts: C[]
): Array<{
  domain: string;
  entity: C['shape']['entity'];
  createDTO: C['shape']['dto']['create'];
  updateDTO: C['shape']['dto']['update'];
  service: C['behavior']['service'];
}> {
  const startTime = performance.now();

  const results = contracts.map(contract => ({
    domain: contract.domain,
    entity: extractEntityType(contract),
    createDTO: extractCreateDTO(contract),
    updateDTO: extractUpdateDTO(contract),
    service: extractServiceType(contract),
  }));

  const duration = performance.now() - startTime;
  performanceMonitor.record('type_extraction_batch', duration);

  return results;
}

/**
 * Clear type extraction cache
 */
export function clearTypeCache(): void {
  typeCache.clear();
}

/**
 * Get type cache statistics
 */
export function getTypeCacheStats(): {
  size: number;
  maxSize: number;
} {
  return {
    size: typeCache.size(),
    maxSize: 50,
  };
}
