// ====================================================================
// CONTRACT VERSIONING SYSTEM
// ====================================================================
// Contract version management with breaking change detection

import type { ContractName } from '../registry';
import { ContractUtils } from '../registry';
import { compareContractVersions, compareContracts } from '../utils';
import type { ContractSnapshot } from './types';

/**
 * Version change type
 */
export type VersionChangeType = 'major' | 'minor' | 'patch' | 'none';

/**
 * Breaking change type
 */
export interface BreakingChange {
  type: 'removed' | 'modified' | 'added' | 'type_changed';
  path: string;
  description: string;
  severity: 'high' | 'medium' | 'low';
}

/**
 * Version change analysis
 */
export interface VersionChangeAnalysis {
  contractName: ContractName;
  oldVersion: string;
  newVersion: string;
  changeType: VersionChangeType;
  breakingChanges: BreakingChange[];
  nonBreakingChanges: string[];
  migrationRequired: boolean;
}

/**
 * Analyze version changes between two contracts
 */
export function analyzeVersionChanges(
  contractName: ContractName,
  oldContract: ContractSnapshot,
  newContract: ContractSnapshot
): VersionChangeAnalysis {
  const comparison = compareContracts(oldContract, newContract);
  const versionComparison = compareContractVersions(
    contractName,
    oldContract.version,
    newContract.version
  );

  // Determine change type based on version
  const [oldMajor, oldMinor] = oldContract.version.split('.').map(Number);
  const [newMajor, newMinor] = newContract.version.split('.').map(Number);

  let changeType: VersionChangeType = 'none';
  if (newMajor > oldMajor) {
    changeType = 'major';
  } else if (newMinor > oldMinor) {
    changeType = 'minor';
  } else if (versionComparison > 0) {
    changeType = 'patch';
  }

  // Categorize changes
  const breakingChanges: BreakingChange[] = comparison.breakingChanges.map(change => ({
    type: change.includes('removed') ? 'removed' : 'modified',
    path: change,
    description: change,
    severity: change.includes('Shape') || change.includes('Behavior') ? 'high' : 'medium',
  }));

  const nonBreakingChanges = comparison.differences.filter(
    diff => !comparison.breakingChanges.includes(diff)
  );

  return {
    contractName,
    oldVersion: oldContract.version,
    newVersion: newContract.version,
    changeType,
    breakingChanges,
    nonBreakingChanges,
    migrationRequired: breakingChanges.length > 0 || changeType === 'major',
  };
}

/**
 * Detect breaking changes in a contract update
 */
export function detectBreakingChanges(
  oldContract: ContractSnapshot,
  newContract: ContractSnapshot
): BreakingChange[] {
  const comparison = compareContracts(oldContract, newContract);
  const breakingChanges: BreakingChange[] = [];

  // Check for removed validation schemas
  const oldSchemas = Object.keys(oldContract.validation);
  const newSchemas = Object.keys(newContract.validation);
  const removedSchemas = oldSchemas.filter(s => !newSchemas.includes(s));

  for (const schema of removedSchemas) {
    breakingChanges.push({
      type: 'removed',
      path: `validation.${schema}`,
      description: `Validation schema '${schema}' was removed`,
      severity: 'high',
    });
  }

  // Check for removed DTOs
  if (!newContract.shape.dto.create && oldContract.shape.dto.create) {
    breakingChanges.push({
      type: 'removed',
      path: 'shape.dto.create',
      description: 'Create DTO was removed',
      severity: 'high',
    });
  }

  if (!newContract.shape.dto.update && oldContract.shape.dto.update) {
    breakingChanges.push({
      type: 'removed',
      path: 'shape.dto.update',
      description: 'Update DTO was removed',
      severity: 'medium',
    });
  }

  // Check for service interface changes
  if (
    JSON.stringify(oldContract.behavior.service) !== JSON.stringify(newContract.behavior.service)
  ) {
    breakingChanges.push({
      type: 'modified',
      path: 'behavior.service',
      description: 'Service interface was modified',
      severity: 'high',
    });
  }

  return breakingChanges;
}

/**
 * Generate migration guide for version changes
 */
export function generateMigrationGuide(analysis: VersionChangeAnalysis): string {
  const guide: string[] = [
    `# Migration Guide: ${analysis.contractName} v${analysis.oldVersion} → v${analysis.newVersion}`,
    '',
    `**Change Type**: ${analysis.changeType}`,
    `**Migration Required**: ${analysis.migrationRequired ? 'Yes' : 'No'}`,
    '',
  ];

  if (analysis.breakingChanges.length > 0) {
    guide.push('## Breaking Changes', '');
    for (const change of analysis.breakingChanges) {
      guide.push(`### ${change.path} (${change.severity})`);
      guide.push(`- **Type**: ${change.type}`);
      guide.push(`- **Description**: ${change.description}`);
      guide.push('');
    }
  }

  if (analysis.nonBreakingChanges.length > 0) {
    guide.push('## Non-Breaking Changes', '');
    for (const change of analysis.nonBreakingChanges) {
      guide.push(`- ${change}`);
    }
    guide.push('');
  }

  if (analysis.migrationRequired) {
    guide.push('## Migration Steps', '');
    guide.push('1. Update imports if types have changed');
    guide.push('2. Update validation schema usage if schemas changed');
    guide.push('3. Update service implementations if interface changed');
    guide.push('4. Run tests to verify compatibility');
    guide.push('');
  }

  guide.push(`*Generated on ${new Date().toISOString()}*`);

  return guide.join('\n');
}

/**
 * Contract version manager
 */
export class ContractVersionManager {
  private versionHistory = new Map<
    ContractName,
    Array<{ version: string; contract: ContractSnapshot; timestamp: string }>
  >();

  /**
   * Register a contract version
   */
  registerVersion(contractName: ContractName, contract: ContractSnapshot): void {
    if (!this.versionHistory.has(contractName)) {
      this.versionHistory.set(contractName, []);
    }

    const history = this.versionHistory.get(contractName)!;
    history.push({
      version: contract.version,
      contract,
      timestamp: new Date().toISOString(),
    });

    // Sort by version
    history.sort((a, b) => compareContractVersions(contractName, a.version, b.version));
  }

  /**
   * Get version history for a contract
   */
  getVersionHistory(contractName: ContractName): Array<{ version: string; timestamp: string }> {
    const history = this.versionHistory.get(contractName);
    if (!history) return [];

    return history.map(h => ({
      version: h.version,
      timestamp: h.timestamp,
    }));
  }

  /**
   * Compare two versions of a contract
   */
  compareVersions(
    contractName: ContractName,
    version1: string,
    version2: string
  ): VersionChangeAnalysis | null {
    const history = this.versionHistory.get(contractName);
    if (!history) return null;

    const v1 = history.find(h => h.version === version1);
    const v2 = history.find(h => h.version === version2);

    if (!v1 || !v2) return null;

    return analyzeVersionChanges(contractName, v1.contract, v2.contract);
  }

  /**
   * Get latest version
   */
  getLatestVersion(contractName: ContractName): string | null {
    const history = this.versionHistory.get(contractName);
    if (!history || history.length === 0) return null;

    return history[history.length - 1].version;
  }
}

/**
 * Global version manager instance
 */
export const contractVersionManager = new ContractVersionManager();
