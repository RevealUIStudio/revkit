// ====================================================================
// CONTRACT BUILDER
// ====================================================================
// Utilities for creating contract snapshots

import type { ContractConfig, ContractSnapshot } from './types';

/**
 * Create a contract snapshot from configuration
 *
 * @param config - Contract configuration
 * @returns Complete contract snapshot
 *
 * @example
 * ```typescript
 * const UserContract = createContractSnapshot({
 *   domain: 'user',
 *   version: '1.0.0',
 *   shape: {
 *     entity: {} as DomainUser,
 *     dto: {
 *       create: {} as CreateUserDTO,
 *       update: {} as UpdateUserDTO,
 *     },
 *   },
 *   behavior: {
 *     service: {} as IUserDomainService,
 *   },
 *   validation: {
 *     create: createUserSchema,
 *     update: updateUserSchema,
 *   },
 *   metadata: {
 *     layer: 'domain',
 *     dependsOn: ['auth'],
 *   },
 * });
 * ```
 */
export function createContractSnapshot<Entity = unknown>(
  config: ContractConfig<Entity>
): ContractSnapshot<Entity> {
  const now = new Date().toISOString();

  return {
    domain: config.domain,
    version: config.version || '1.0.0',
    shape: config.shape,
    behavior: config.behavior,
    validation: config.validation,
    metadata: {
      layer: config.metadata.layer,
      usedBy: config.metadata.usedBy ?? [],
      dependsOn: config.metadata.dependsOn ?? [],
      lastModified: config.metadata.lastModified ?? now,
      ...(config.metadata.description !== undefined
        ? { description: config.metadata.description }
        : {}),
      ...(config.metadata.tags !== undefined ? { tags: config.metadata.tags } : {}),
    },
  };
}

/**
 * Create a contract registry from a collection of contracts
 *
 * @param contracts - Object mapping domain names to contract snapshots
 * @returns Type-safe contract registry
 *
 * @example
 * ```typescript
 * const Contracts = ContractRegistry.create({
 *   user: UserContract,
 *   product: ProductContract,
 * });
 * ```
 */
export const ContractRegistry = {
  create<T extends Record<string, ContractSnapshot>>(contracts: T): T {
    return contracts;
  },
};
