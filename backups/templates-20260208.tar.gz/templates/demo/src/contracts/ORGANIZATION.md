# Contracts Organization Guide

## Overview

The `contracts/` folder contains three main subdirectories that work together to
provide type safety, runtime validation, and service contracts for the entire
application.

```
contracts/
├── validation/     # Runtime validation (Zod schemas + DTOs)
├── types/          # Static type definitions
└── interfaces/     # Service contracts
```

## Design Principles

1. **Separation of Concerns**: Runtime validation vs static types vs service
   contracts
2. **Single Responsibility**: Each type lives in exactly one place
3. **Clear Dependencies**: validation → types ← interfaces
4. **Type Safety**: Full TypeScript inference from Zod schemas

## Folder Responsibilities

### validation/ - Runtime Validation

**Purpose**: Runtime data validation using Zod schemas and inferred DTOs

**Contains**:

- Zod validation schemas
- Inferred DTO types (Create/Update data structures)
- Validation result types
- Validation utilities

**Example**: `validation/user.ts`

```typescript
import { z } from 'zod';

export const createUserSchema = z.object({
  email: z.string().email(),
  username: z.string().min(3),
  name: z.string(),
  // ...
});

// Inferred DTO types
export type CreateUserData = z.infer<typeof createUserSchema>;
export type UpdateUserData = Partial<CreateUserData>;

// Validation suites
export const userValidationSchemas = createValidationSuites({
  createUser: createUserSchema,
  updateUser: updateUserSchema,
});
```

**Import from**:

```typescript
import {
  CreateUserData,
  userValidationSchemas,
} from '@/contracts/validation/user';
import { ValidationResult } from '@/contracts/validation/results';
```

---

### types/ - Static Type Definitions

**Purpose**: Static TypeScript type definitions for domain entities and shared
types

**Contains**:

- Domain entities (full object shapes)
- Service result types
- Enums and constants
- Shared utility types

**Example**: `types/domain/entities/user.ts`

```typescript
export interface DomainUser {
  id: string;
  email: string;
  username: string;
  name: string;
  role: UserRole;
  status: UserStatus;
  createdAt: string;
  updatedAt: string;
  // ... full entity shape
}

export type UserRole = 'super-admin' | 'admin' | 'editor' | 'user' | 'guest';
export type UserStatus = 'draft' | 'published' | 'archived';
```

**Import from**:

```typescript
import { DomainUser, UserRole } from '@/contracts/types/domain/entities';
import { ServiceResult } from '@/contracts/types/domain/service-results';
```

---

### interfaces/ - Service Contracts

**Purpose**: Define contracts for services across different layers

**Contains**:

- Domain service interfaces
- Infrastructure service interfaces
- Presentation service interfaces
- Base service interfaces

**Example**: `interfaces/domain/services/IUserDomainService.ts`

```typescript
import { ServiceResult } from '@/contracts/types/domain/service-results';
import { ValidationResult } from '@/contracts/validation/results';
import { CreateUserData, UpdateUserData } from '@/contracts/validation/user';
import { DomainUser } from '@/contracts/types/domain/entities';

export interface IUserDomainService {
  // Input: validation DTO, Output: domain entity
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
  updateUser(
    id: string,
    data: UpdateUserData
  ): Promise<ServiceResult<DomainUser>>;

  // Return domain entity
  getUser(id: string): Promise<ServiceResult<DomainUser>>;

  // Validation-specific
  validateUserData(
    data: Partial<DomainUser>
  ): Promise<ValidationResult<DomainUser>>;
}
```

**Import from**:

```typescript
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
```

---

## Integration Pattern

### The Split Pattern

**Inputs use validation DTOs, outputs use domain entities**

```typescript
// ✅ CORRECT: Input from validation, output from types
interface IUserService {
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
  //          ↑ from validation/      ↑ from types/
}

// ❌ INCORRECT: Mixed or duplicated types
interface IUserService {
  createUser(data: DomainUser): Promise<ServiceResult<DomainUser>>;
  //          ↑ Should use CreateUserData from validation/
}
```

### When to Use Each

| Operation | Input Type     | Output Type      | Example                                                                              |
| --------- | -------------- | ---------------- | ------------------------------------------------------------------------------------ |
| Create    | Validation DTO | Domain Entity    | `createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>`               |
| Update    | Validation DTO | Domain Entity    | `updateUser(id, data: UpdateUserData): Promise<ServiceResult<DomainUser>>`           |
| Read      | ID/Filter      | Domain Entity    | `getUser(id: string): Promise<ServiceResult<DomainUser>>`                            |
| Validate  | Partial Entity | ValidationResult | `validateUserData(data: Partial<DomainUser>): Promise<ValidationResult<DomainUser>>` |

---

## Decision Guide

### "Where should this type go?"

**Put it in validation/ if**:

- ✅ It's used for runtime validation (Zod schema)
- ✅ It's a Create/Update DTO
- ✅ It represents input data that needs validation
- ✅ It's a filter or query parameter that needs validation

**Put it in types/ if**:

- ✅ It's a complete domain entity
- ✅ It's a service result wrapper
- ✅ It's an enum or constant
- ✅ It's used for static type checking only

**Put it in interfaces/ if**:

- ✅ It's a service contract
- ✅ It defines operations/methods
- ✅ It's implemented by a service class

---

## Common Scenarios

### Scenario 1: Adding a New Entity

1. **Create domain entity** in `types/domain/entities/thing.ts`

```typescript
export interface DomainThing {
  id: string;
  name: string;
  // ...
}
```

2. **Create validation schemas** in `validation/thing.ts`

```typescript
export const createThingSchema = z.object({
  name: z.string(),
  // ...
});
export type CreateThingData = z.infer<typeof createThingSchema>;
```

3. **Create service interface** in `interfaces/domain/services/IThingService.ts`

```typescript
export interface IThingService {
  createThing(data: CreateThingData): Promise<ServiceResult<DomainThing>>;
}
```

### Scenario 2: Validating User Input

```typescript
import { userValidationSchemas } from '@/contracts/validation/user';

// Runtime validation
const result = userValidationSchemas.createUser.validate(inputData);
if (result.success) {
  // result.data is CreateUserData
  await userService.createUser(result.data);
}
```

### Scenario 3: Service Implementation

```typescript
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
import { CreateUserData } from '@/contracts/validation/user';
import { DomainUser } from '@/contracts/types/domain/entities';
import { ServiceResult } from '@/contracts/types/domain/service-results';

class UserService implements IUserDomainService {
  async createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>> {
    // Validation already done, data is clean
    const user = await this.repository.create(data);
    return { success: true, data: user };
  }
}
```

---

## Benefits

1. **Clear Separation**: Know exactly where to find what
2. **No Duplication**: Each type exists in one place
3. **Type Safety**: Full TypeScript + Zod validation
4. **Better DX**: Predictable import paths
5. **Maintainability**: Easy to update and refactor

---

## Import Path Reference

```typescript
// Validation (runtime checks + DTOs)
import { CreateUserData } from '@/contracts/validation/user';
import { ValidationResult } from '@/contracts/validation/results';

// Types (static definitions)
import { DomainUser } from '@/contracts/types/domain/entities';
import { ServiceResult } from '@/contracts/types/domain/service-results';

// Interfaces (service contracts)
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
```

---

## Migration Checklist

When working with contracts, ensure:

- [ ] DTOs use validation/ types
- [ ] Domain entities use types/ definitions
- [ ] Service interfaces reference both appropriately
- [ ] No duplicate types between folders
- [ ] ValidationResult from validation/
- [ ] ServiceResult from types/
- [ ] Proper imports (no relative paths across folders)

---

## Questions?

**Q: Why separate validation from types?** A: Runtime validation (Zod) serves a
different purpose than compile-time types. Keeping them separate makes the
codebase more maintainable.

**Q: Can I use domain entities in validation schemas?** A: No. Validation
schemas should be independent. Domain entities may have additional computed
properties or methods.

**Q: Where do enums go?** A: In `types/` - they're static definitions.

**Q: What about shared validation utilities?** A: In `validation/base.ts` and
exported via `validation/index.ts`.

**Q: Can interfaces reference validation types?** A: Yes! Interfaces reference
both validation (inputs) and types (outputs).

---

## ESLint Rule: enforce-contract-location

The `reveal/enforce-contract-location` rule automatically enforces architectural
boundaries by ensuring contract types are defined in `src/contracts/`.

### Rule Behavior

The rule only checks **exported** types/interfaces and uses pattern-based
detection:

**Enforces** (MUST be in contracts):

- `*Service` - Service interfaces
- `*Repository` - Repository interfaces
- `*DTO` - Data transfer objects
- `Domain*` - Domain entities
- `*Event` - Domain events
- `*Result` - Result types
- `*Response` - Response types

**Allows** (can stay in implementation files):

- `*Props` - Component props
- `*Variants` - Style variants (CVA)
- `*Config` - Configuration types
- `Internal*` - Internal helpers
- `_*` - Underscore-prefixed types

**File Location Exceptions**:

- Component files (`src/presentation/ui/**/*.tsx`)
- Style files (`src/presentation/styles/**/*.ts`)
- Test files (`*.test.tsx?`, `*.spec.tsx?`)

### Example

```typescript
// ✅ GOOD: Props can stay in component file
// src/presentation/ui/base/button.tsx
export interface ButtonProps {
  variant?: 'primary' | 'secondary';
}

// ❌ BAD: Service interface must be in contracts
// src/domain/services/UserService.ts
export interface IUserService {
  // ← Rule violation!
  createUser(): Promise<User>;
}

// ✅ GOOD: Service interface in contracts
// src/contracts/interfaces/domain/services/IUserService.ts
export interface IUserService {
  createUser(): Promise<User>;
}
```

### Disabling the Rule

Only disable when absolutely necessary and add an explanatory comment:

```typescript
/* eslint-disable reveal/enforce-contract-location */
// This file contains infrastructure-specific types that don't fit contract patterns
export interface ComplexInternalType { ... }
```

See [CONTRACT_GUIDELINES.md](./CONTRACT_GUIDELINES.md) for detailed guidance.
