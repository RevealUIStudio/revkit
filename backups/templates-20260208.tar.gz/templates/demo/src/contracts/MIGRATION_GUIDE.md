# Contract Migration Guide

**Last Updated**: 2024-12-19 **Status**: Active Migration

This guide helps you migrate from legacy contract imports to the unified
contract system.

---

## Quick Start

### Automated Migration

Run the automated migration tool:

```bash
# Dry run (see what would change)
pnpm migrate:contracts --dry-run

# Apply changes
pnpm migrate:contracts

# Migrate specific file
pnpm migrate:contracts src/domain/services/UserService.ts
```

### Manual Migration

If you prefer to migrate manually, follow the patterns below.

---

## Migration Patterns

### Pattern 1: Entity Types

**Before:**
```typescript
import { DomainUser } from '@/contracts/types/domain/entities/user';
import { DomainProduct } from '@/contracts/types/domain/entities/product';
```

**After:**
```typescript
import { type User, type Product } from '@/contracts';
```

### Pattern 2: DTO Types

**Before:**
```typescript
import { CreateUserDTO, UpdateUserDTO } from '@/contracts/types/domain/dto/user';
import { CreateProductDTO } from '@/contracts/types/domain/dto/product';
```

**After:**
```typescript
import { type CreateUser, type UpdateUser, type CreateProduct } from '@/contracts';
```

### Pattern 3: Service Interfaces

**Before:**
```typescript
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
import { IProductService } from '@/contracts/interfaces/domain/services/IProductService';
```

**After:**
```typescript
import { type UserService, type ProductService } from '@/contracts';
```

### Pattern 4: Validation Schemas

**Before:**
```typescript
import { createUserSchema, updateUserSchema } from '@/contracts/validation/schemas/user';
import { createProductSchema } from '@/contracts/validation/schemas/product';
```

**After:**
```typescript
import { UserValidation, ProductValidation } from '@/contracts';

// Usage
const result = UserValidation.create.parse(userData);
const productResult = ProductValidation.create.parse(productData);
```

### Pattern 5: Multiple Imports from Same Domain

**Before:**
```typescript
import { DomainUser } from '@/contracts/types/domain/entities/user';
import { CreateUserDTO } from '@/contracts/types/domain/dto/user';
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
import { createUserSchema } from '@/contracts/validation/schemas/user';
```

**After:**
```typescript
import {
  UserContract,
  type User,
  type CreateUser,
  type UserService,
  UserValidation,
} from '@/contracts';
```

---

## Complete Example

### Before

```typescript
import { DomainUser } from '@/contracts/types/domain/entities/user';
import { CreateUserDTO, UpdateUserDTO } from '@/contracts/types/domain/dto/user';
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
import { createUserSchema, updateUserSchema } from '@/contracts/validation/schemas/user';

export class UserService implements IUserDomainService {
  async createUser(data: CreateUserDTO): Promise<DomainUser> {
    const validated = createUserSchema.parse(data);
    // ... implementation
    return user;
  }

  async updateUser(id: string, data: UpdateUserDTO): Promise<DomainUser> {
    const validated = updateUserSchema.parse(data);
    // ... implementation
    return user;
  }
}
```

### After

```typescript
import {
  UserContract,
  type User,
  type CreateUser,
  type UpdateUser,
  type UserService,
  UserValidation,
} from '@/contracts';

export class UserService implements UserService {
  async createUser(data: CreateUser): Promise<User> {
    const validated = UserValidation.create.parse(data);
    // ... implementation
    return user;
  }

  async updateUser(id: string, data: UpdateUser): Promise<User> {
    const validated = UserValidation.update.parse(data);
    // ... implementation
    return user;
  }
}
```

---

## Type Mapping Reference

### User Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainUser` | `User` | Entity |
| `CreateUserDTO` | `CreateUser` | DTO |
| `UpdateUserDTO` | `UpdateUser` | DTO |
| `IUserDomainService` | `UserService` | Service |
| `createUserSchema` | `UserValidation.create` | Validation |
| `updateUserSchema` | `UserValidation.update` | Validation |
| `userFiltersSchema` | `UserValidation.filters` | Validation |
| `userProfileSchema` | `UserValidation.profile` | Validation |

### Product Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainProduct` | `Product` | Entity |
| `CreateProductDTO` | `CreateProduct` | DTO |
| `UpdateProductDTO` | `UpdateProduct` | DTO |
| `IProductService` | `ProductService` | Service |
| `createProductSchema` | `ProductValidation.create` | Validation |
| `updateProductSchema` | `ProductValidation.update` | Validation |
| `productFiltersSchema` | `ProductValidation.filters` | Validation |
| `productVariantSchema` | `ProductValidation.variant` | Validation |

### Cart Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainCart` | `Cart` | Entity |
| `CreateCartItemDTO` | `CreateCartItem` | DTO |
| `UpdateCartItemDTO` | `UpdateCartItem` | DTO |
| `ICartService` | `CartService` | Service |
| `createCartItemSchema` | `CartValidation.create` | Validation |
| `updateCartItemSchema` | `CartValidation.update` | Validation |
| `cartFiltersSchema` | `CartValidation.filters` | Validation |

### Order Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainOrder` | `Order` | Entity |
| `CreateOrderDTO` | `CreateOrder` | DTO |
| `UpdateOrderDTO` | `UpdateOrder` | DTO |
| `IOrderService` | `OrderService` | Service |
| `createOrderSchema` | `OrderValidation.create` | Validation |
| `updateOrderSchema` | `OrderValidation.update` | Validation |
| `orderFiltersSchema` | `OrderValidation.filters` | Validation |

### Category Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainCategory` | `Category` | Entity |
| `CreateCategoryDTO` | `CreateCategory` | DTO |
| `UpdateCategoryDTO` | `UpdateCategory` | DTO |
| `ICategoryDomainService` | `CategoryService` | Service |
| `createCategorySchema` | `CategoryValidation.create` | Validation |
| `updateCategorySchema` | `CategoryValidation.update` | Validation |
| `categoryFiltersSchema` | `CategoryValidation.filters` | Validation |

### Post Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainPost` | `Post` | Entity |
| `CreatePostDTO` | `CreatePost` | DTO |
| `UpdatePostDTO` | `UpdatePost` | DTO |
| `IPostDomainService` | `PostService` | Service |
| `createPostSchema` | `PostValidation.create` | Validation |
| `updatePostSchema` | `PostValidation.update` | Validation |
| `postFiltersSchema` | `PostValidation.filters` | Validation |

### Fight Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `Fight` | `Fight` | Entity |
| `CreateFightInput` | `CreateFight` | DTO |
| `UpdateFightInput` | `UpdateFight` | DTO |
| `IFightService` | `FightService` | Service |
| `createFightSchema` | `FightValidation.create` | Validation |
| `updateFightSchema` | `FightValidation.update` | Validation |
| `fightFiltersSchema` | `FightValidation.filters` | Validation |
| `fightResultSchema` | `FightValidation.result` | Validation |

### Media Domain

| Legacy Type | Unified Type | Category |
|------------|--------------|----------|
| `DomainMedia` | `Media` | Entity |
| `IMediaDomainService` | `MediaService` | Service |
| `uploadMediaSchema` | `MediaValidation.upload` | Validation |
| `updateMediaSchema` | `MediaValidation.update` | Validation |

---

## Common Scenarios

### Scenario 1: Service Implementation

**Before:**
```typescript
import { IUserDomainService } from '@/contracts/interfaces/domain/services/IUserDomainService';
import { CreateUserDTO } from '@/contracts/types/domain/dto/user';
import { DomainUser } from '@/contracts/types/domain/entities/user';

class UserService implements IUserDomainService {
  async createUser(data: CreateUserDTO): Promise<DomainUser> {
    // ...
  }
}
```

**After:**
```typescript
import { type UserService, type CreateUser, type User } from '@/contracts';

class UserService implements UserService {
  async createUser(data: CreateUser): Promise<User> {
    // ...
  }
}
```

### Scenario 2: Form Validation

**Before:**
```typescript
import { createUserSchema } from '@/contracts/validation/schemas/user';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

function UserForm() {
  const form = useForm({
    resolver: zodResolver(createUserSchema),
  });
}
```

**After:**
```typescript
import { UserValidation, type CreateUser } from '@/contracts';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

function UserForm() {
  const form = useForm<CreateUser>({
    resolver: zodResolver(UserValidation.create),
  });
}
```

### Scenario 3: API Route

**Before:**
```typescript
import { CreateUserDTO } from '@/contracts/types/domain/dto/user';
import { createUserSchema } from '@/contracts/validation/schemas/user';

export async function POST(req: Request) {
  const body = await req.json();
  const validated = createUserSchema.parse(body);
  // ...
}
```

**After:**
```typescript
import { UserValidation, type CreateUser } from '@/contracts';

export async function POST(req: Request) {
  const body: CreateUser = await req.json();
  const validated = UserValidation.create.parse(body);
  // ...
}
```

### Scenario 4: Using Contract Registry

**New Feature:** Access contracts via registry

```typescript
import { Contracts, ContractUtils } from '@/contracts';

// Get contract by name
const userContract = Contracts.get('user');

// Check if contract exists
if (ContractUtils.has('product')) {
  const productContract = ContractUtils.get('product');
}

// Get all contract names
const allDomains = ContractUtils.getNames();
```

---

## Troubleshooting

### Issue: "Cannot find module '@/contracts'"

**Solution**: Ensure `tsconfig.json` has path alias configured:
```json
{
  "compilerOptions": {
    "paths": {
      "@/contracts": ["./src/contracts"],
      "@/contracts/*": ["./src/contracts/*"]
    }
  }
}
```

### Issue: "Type 'X' is not assignable to type 'Y'"

**Solution**: Check that you're using the correct unified type name. Refer to
the type mapping table above.

### Issue: "Property 'create' does not exist on type..."

**Solution**: Validation schemas are now accessed via the validation object:
```typescript
// ❌ Wrong
import { createUserSchema } from '@/contracts';

// ✅ Correct
import { UserValidation } from '@/contracts';
const schema = UserValidation.create;
```

### Issue: Migration tool doesn't detect all imports

**Solution**: Some complex cases may need manual migration. Check the file
manually and use the patterns above.

### Issue: Circular dependency after migration

**Solution**: This usually means the file structure needs adjustment. Check that
contracts are not importing from implementation files.

---

## Migration Checklist

When migrating a file:

- [ ] Identify all legacy imports
- [ ] Map to unified types using the reference table
- [ ] Replace import statements
- [ ] Update type annotations
- [ ] Update validation schema usage
- [ ] Run type check: `pnpm lint:types`
- [ ] Run tests
- [ ] Verify functionality

---

## Benefits After Migration

1. **Single Import**: One import instead of multiple
2. **Type Safety**: Better TypeScript inference
3. **Consistency**: All contracts follow same pattern
4. **Maintainability**: Easier to update contracts
5. **Discoverability**: Easier to find related types

---

## Need Help?

- Check the [README](./README.md) for contract system overview
- Review [CONTRACT_GUIDELINES.md](./CONTRACT_GUIDELINES.md) for best practices
- See [ORGANIZATION.md](./ORGANIZATION.md) for folder structure

---

**Last Updated**: 2024-12-19
































