// ====================================================================
// ACCESS CONTROL INTERFACES
// ====================================================================
// Interfaces for role-based access control and permission checking

import type { User as RevealUIUser } from '@revealui/infrastructure/cms/db/revealui-types';

/**
 * Permission check data
 */
export interface PermissionCheckData {
  userId?: string;
  permission: string;
  user?: RevealUIUser;
}

/**
 * Role check data
 */
export interface RoleCheckData {
  userId?: string;
  role: string;
  user?: RevealUIUser;
}

/**
 * Module access check data
 */
export interface ModuleAccessData {
  userId?: string;
  module: string;
  user?: RevealUIUser;
}

/**
 * Action permission check data
 */
export interface ActionPermissionData {
  userId?: string;
  action: string;
  user?: RevealUIUser;
}

/**
 * Role permission configuration
 */
export interface RolePermission {
  role: string;
  permissions: string[];
  hierarchyLevel: number;
}

/**
 * Permission checker interface
 */
export interface IPermissionChecker {
  /**
   * Check if user has a specific permission
   */
  hasPermission(data: PermissionCheckData): boolean;

  /**
   * Check if user has a specific role
   */
  hasRole(data: RoleCheckData): boolean;

  /**
   * Check if user can access a specific module
   */
  canAccessModule(data: ModuleAccessData): boolean;

  /**
   * Check if user can perform a specific action
   */
  canPerformAction(data: ActionPermissionData): boolean;

  /**
   * Cache a user for synchronous access
   */
  cacheUser(userId: string, user: RevealUIUser): void;

  /**
   * Preload user into cache for synchronous access
   */
  preloadUser(userId: string): Promise<void>;

  /**
   * Clear user cache
   */
  clearCache(): void;

  /**
   * Clear expired entries from cache
   */
  clearExpiredCache(): void;
}
