// =====
// HEALTH SERVICE INTERFACES
// =====

import type { CpuUsage, MemoryUsage } from 'node:perf_hooks';
import type { DomainLogger } from '@/contracts';
import type { RevealUI } from '@revealui/content';

/**
 * Context for health service operations
 */
export interface HealthServiceContext {
  revealui: RevealUI;
  logger: DomainLogger;
  serviceStartTime: number;
  version: string;
  environment: string;
}

/**
 * System metrics for health monitoring
 */
export interface SystemMetrics {
  uptime: number;
  memory: MemoryUsage;
  cpu: CpuUsage;
  version: string;
  environment: string;
  timestamp: string;
}
