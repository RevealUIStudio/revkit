// ======
// SESSION INTERFACES
// ======
// Session-related interfaces for the application
// These interfaces define contracts for session management

/**
 * Session data interface
 */
export interface SessionData {
  id: string;
  userId: string;
  token: string;
  device: {
    id: string;
    type: string;
    platform: string;
    ip: string | null;
    userAgent: string | null;
  };
  expiresAt: string;
  lastActiveAt: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
