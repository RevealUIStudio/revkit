export interface IHomePageService {
  getHighlights(): Promise<unknown[]>;
}
