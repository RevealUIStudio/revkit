// =====
// URL SERVICE INTERFACES
// =====

import type { DomainLogger } from '@/contracts';
import type { RevealUI } from '@revealui/content';

/**
 * Context for URL service operations
 */
export interface URLServiceContext {
  revealui: RevealUI;
  logger: DomainLogger;
}

/**
 * Validation options for URL parameters
 */
export interface ValidationOptions {
  minLength?: number;
  maxLength?: number;
}
