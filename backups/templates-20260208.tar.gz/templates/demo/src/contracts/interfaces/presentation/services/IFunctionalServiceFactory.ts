// =====
// FUNCTIONAL SERVICE FACTORY INTERFACES
// =====

import type {
  DomainCategory,
  DomainPost,
  DomainUser,
  ICategoryRepository,
  IMediaRepository,
  IPostRepository,
  IUserRepository,
  ServiceResult,
} from '@/contracts';

export interface AnalyticsService {
  trackEvent(event: string, revealui?: Record<string, unknown>): Promise<void>;
}

export interface EventBus {
  publish(event: string, revealui: Record<string, unknown>): Promise<void>;
}

export interface Logger {
  info(message: string, metadata?: Record<string, unknown>): void;
  warn(message: string, metadata?: Record<string, unknown>): void;
  error(message: string, metadata?: Record<string, unknown>): void;
  debug?(message: string, metadata?: Record<string, unknown>): void;
}

export interface ServiceDependencies {
  repositories: {
    user: IUserRepository;
    post: IPostRepository;
    category: ICategoryRepository;
    media: IMediaRepository;
  };
  infrastructure: {
    eventBus: EventBus;
    logger: Logger;
    analytics: AnalyticsService;
  };
}

export interface ListOptions {
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  filter?: Record<string, unknown>;
}

export type ValidationResult = {
  isValid: boolean;
  errors: string[];
  warnings: string[];
};

export type CreateUserData = Pick<DomainUser, 'email' | 'role'> & Partial<DomainUser>;
export type UpdateUserData = Partial<DomainUser>;

export type CreatePostData = Pick<DomainPost, 'title' | 'slug'> & Partial<DomainPost>;
export type UpdatePostData = Partial<DomainPost>;

export type CreateCategoryData = Pick<DomainCategory, 'name'> & Partial<DomainCategory>;
export type UpdateCategoryData = Partial<DomainCategory>;

export interface UserService {
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
  getUserById(id: string): Promise<ServiceResult<DomainUser>>;
  getUserByEmail(email: string): Promise<ServiceResult<DomainUser>>;
  updateUser(id: string, data: UpdateUserData): Promise<ServiceResult<DomainUser>>;
  deleteUser(id: string): Promise<ServiceResult<boolean>>;
  listUsers(options?: ListOptions): Promise<ServiceResult<DomainUser[]>>;
}

export interface PostService {
  createPost(data: CreatePostData): Promise<ServiceResult<DomainPost>>;
  getPostById(id: string): Promise<ServiceResult<DomainPost>>;
  getPostBySlug(slug: string): Promise<ServiceResult<DomainPost>>;
  updatePost(id: string, data: UpdatePostData): Promise<ServiceResult<DomainPost>>;
  deletePost(id: string): Promise<ServiceResult<boolean>>;
  listPosts(options?: ListOptions): Promise<ServiceResult<DomainPost[]>>;
  publishPost(id: string): Promise<ServiceResult<DomainPost>>;
  archivePost(id: string): Promise<ServiceResult<DomainPost>>;
}

export interface CategoryService {
  createCategory(data: CreateCategoryData): Promise<ServiceResult<DomainCategory>>;
  getCategoryById(id: string): Promise<ServiceResult<DomainCategory>>;
  getCategoryBySlug(slug: string): Promise<ServiceResult<DomainCategory>>;
  updateCategory(id: string, data: UpdateCategoryData): Promise<ServiceResult<DomainCategory>>;
  deleteCategory(id: string): Promise<ServiceResult<boolean>>;
  listCategories(options?: ListOptions): Promise<ServiceResult<DomainCategory[]>>;
  getCategoryHierarchy(): Promise<ServiceResult<DomainCategory[]>>;
}

export interface FunctionalServiceFactory {
  readonly dependencies: ServiceDependencies;
  createUserService(): UserService;
  createPostService(): PostService;
  createCategoryService(): CategoryService;
}
