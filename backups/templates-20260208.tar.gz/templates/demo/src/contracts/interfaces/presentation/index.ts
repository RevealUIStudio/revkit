// ====================================================================
// PRESENTATION INTERFACES INDEX
// ====================================================================
// Presentation layer interfaces: UI components, application services, hooks

// ====================================================================
// PRESENTATION SERVICES (Application Layer)
// ====================================================================
export * from './services/IFunctionalServiceFactory';
export * from './services/IHealthService';
export * from './services/IHomePageService';
export * from './services/IMetaService';
export * from './services/IPrefixService';
export * from './services/IURLService';
export * from './services/IUserApplicationService';

// ====================================================================
// PRESENTATION COMPONENTS
// ====================================================================
export * from './components/props';
export * from './components/theme';
export * from './components/ui';

// ====================================================================
// PRESENTATION HOOKS
// ====================================================================
export * from './hooks';

// ====================================================================
// PRESENTATION PROVIDERS
// ====================================================================
export * from './provider';

// ====================================================================
// PRESENTATION AUTH
// ====================================================================
export * from './auth/session';
