// ====================================================================
// HERO COMPONENT INTERFACES
// ====================================================================
// Interfaces for hero-related presentation components

import type { ReactNode } from 'react';

/**
 * Base hero props
 */
export interface HeroProps {
  type?: 'none' | 'lowImpact' | 'mediumImpact' | 'highImpact';
  richText?: unknown;
  links?: unknown;
  title?: string;
}

/**
 * Post hero component props
 */
export interface PostHeroProps {
  title?: string;
  description?: unknown;
  image?: {
    url: string;
    alt: string;
  };
  className?: string;
}

/**
 * Page hero component props
 */
export interface PageHeroProps {
  title?: string;
  description?: unknown;
  image?: {
    url: string;
    alt: string;
  };
  className?: string;
}

/**
 * Medium impact hero component props
 */
export interface MediumImpactHeroProps {
  title?: string;
  description?: unknown;
  className?: string;
}

/**
 * Low impact hero component props
 */
export interface LowImpactHeroProps {
  title?: string;
  description?: unknown;
  className?: string;
}
