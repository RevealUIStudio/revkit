// ====================================================================
// ACCESSIBILITY COMPONENT INTERFACES
// ====================================================================
// Interfaces for accessibility utilities and components

import type { ReactNode, RefObject } from 'react';

/**
 * Focusable element type
 */
export type FocusableElement = HTMLElement | SVGElement;

/**
 * Accessibility options for useAccessibility hook
 */
export interface AccessibilityOptions {
  componentName?: string;
  enableFocusTrap?: boolean;
  enableKeyboardNav?: boolean;
  enableScreenReader?: boolean;
  enableSkipLinks?: boolean;
  enableHighContrast?: boolean;
  enableReducedMotion?: boolean;
}

/**
 * Return type for useAccessibility hook
 */
export interface AccessibilityReturn {
  baseId: string;
  liveRegionId: string;
  skipLinkId: string;
  isFocusTrapped: boolean;
  activeElement: FocusableElement | null;
  containerRef: RefObject<HTMLDivElement>;
  previousFocusRef: RefObject<FocusableElement | null>;
  liveRegionRef: RefObject<HTMLDivElement>;
  trapFocus: (container: HTMLElement) => void;
  releaseFocus: () => void;
  getFocusableElements: (container: HTMLElement) => FocusableElement[];
  handleKeyboardNav: (event: KeyboardEvent, elements: FocusableElement[]) => void;
  announceToScreenReader: (message: string, priority?: 'polite' | 'assertive') => void;
  restoreFocus: () => void;
  createSkipLink: (targetId: string, label?: string) => ReactNode;
}

/**
 * Props for AccessibleComponent
 */
export interface AccessibleComponentProps {
  label?: string;
  description?: string;
  onAction?: () => void;
  disabled?: boolean;
  className?: string;
  required?: boolean;
  error?: string;
  ariaLabel?: string;
  ariaDescribedBy?: string;
  children?: ReactNode;
  [key: string]: unknown;
}
