// =====
// META SERVICE INTERFACES
// =====

import type { DomainLogger } from '@/contracts';
import type { RevealUI } from '@revealui/content';

/**
 * Context for meta service operations
 */
export interface MetaServiceContext {
  revealui: RevealUI;
  logger: DomainLogger;
}

/**
 * Basic metadata structure
 */
export interface MetaData {
  title: string;
  description: string;
  keywords: string[];
  ogType: string;
  twitterCard: string;
  robots: string;
}

/**
 * Options for generating meta tags
 */
export interface MetaGenerationOptions {
  title?: string;
  description?: string;
  url?: string;
  image?: string;
  type?: 'website' | 'article' | 'profile';
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  section?: string;
  tags?: string[];
}

/**
 * Generated meta tags structure
 */
export interface GeneratedMetaTags {
  title: string;
  description: string;
  canonical: string;
  openGraph: {
    title: string;
    description: string;
    url: string;
    type: string;
    image?: string;
    publishedTime?: string;
    modifiedTime?: string;
    author?: string;
    section?: string;
    tags?: string[];
  };
  twitter: {
    card: string;
    title: string;
    description: string;
    image?: string;
  };
  additional: {
    keywords?: string;
    robots?: string;
    viewport: string;
    charset: string;
  };
  jsonLd: {
    '@type': string;
    headline?: string;
    description?: string;
    image?: string;
    datePublished?: string;
    dateModified?: string;
    author?: {
      '@type': string;
      name: string;
    };
    publisher?: {
      '@type': string;
      name: string;
    };
  };
}

/**
 * Validation result for meta data
 */
export interface MetaValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  suggestions: string[];
  score: number;
}

/**
 * Options for structured data generation
 */
export interface StructuredDataOptions {
  type: 'WebSite' | 'Article' | 'Organization' | 'Person' | 'BreadcrumbList';
  data: Record<string, unknown>;
}
