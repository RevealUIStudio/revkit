// =====
// PREFIX SERVICE INTERFACES
// =====

import type { DomainLogger } from '@/contracts';
import type { RevealUI } from '@revealui/content';

/**
 * Context for prefix service operations
 */
export interface PrefixServiceContext {
  revealui: RevealUI;
  logger: DomainLogger;
}

/**
 * Data structure for creating a new prefix
 */
export interface CreatePrefixData {
  name: string;
  path?: string;
  description?: string;
  allowedTypes?: ('image/jpeg' | 'image/png' | 'image/gif' | 'image/webp')[];
  active?: boolean;
}

/**
 * Data structure for updating an existing prefix
 */
export interface UpdatePrefixData {
  name?: string;
  path?: string;
  description?: string;
  allowedTypes?: ('image/jpeg' | 'image/png' | 'image/gif' | 'image/webp')[];
  active?: boolean;
}

/**
 * Filters for querying prefixes
 */
export interface PrefixFilters {
  active?: boolean;
  search?: string;
}

/**
 * Count statistics for prefixes
 */
export interface PrefixCounts {
  active: number;
  inactive: number;
  total: number;
}

/**
 * Validation options for string fields
 */
export interface ValidationOptions {
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
}
