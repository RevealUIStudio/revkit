// ====================================================================
// PROVIDER INTERFACES
// ====================================================================
// React provider component interfaces

import type { ReactNode } from 'react';

/**
 * App providers props
 */
export interface AppProvidersProps {
  children: ReactNode;
  enablePreview?: boolean;
}

/**
 * Base provider props
 */
export interface BaseProviderProps {
  children: ReactNode;
}
