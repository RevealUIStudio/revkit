// ====================================================================
// COMMON COMPONENT INTERFACES
// ====================================================================
// Common interfaces for presentation components

import type { ReactNode } from 'react';

/**
 * Header component props
 */
export interface HeaderProps {
  className?: string;
}

/**
 * Icon component props
 */
export interface IconProps {
  name: string;
  className?: string;
  size?: number;
}

/**
 * Live preview listener component props
 */
export interface LivePreviewListenerProps {
  children: ReactNode;
}
