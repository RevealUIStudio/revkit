import type {
  CreateUserDTO as CreateUserData,
  DomainUser,
  GetUsersOptions,
  ServiceResult,
  UpdateUserDTO as UpdateUserData,
  UserStatistics,
  UsersResult,
} from '@/contracts';

export interface IUserApplicationService {
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
  updateUser(id: string, data: UpdateUserData): Promise<ServiceResult<DomainUser>>;
  deleteUser(id: string): Promise<ServiceResult<boolean>>;
  getUserById(id: string): Promise<ServiceResult<DomainUser>>;
  getUserByEmail(email: string): Promise<ServiceResult<DomainUser>>;
  getUsers(options: GetUsersOptions): Promise<ServiceResult<UsersResult>>;
  getUserStatistics(): Promise<ServiceResult<UserStatistics>>;
}
