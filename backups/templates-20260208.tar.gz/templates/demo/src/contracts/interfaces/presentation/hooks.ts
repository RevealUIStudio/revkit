// ====================================================================
// HOOKS INTERFACES
// ====================================================================
// Interface definitions for custom React hooks

// ====================================================================
// STATE MANAGEMENT HOOKS
// ====================================================================

export interface UseStateManagementOptions<S> {
  initialState: S;
  enableHistory?: boolean;
  enablePersistence?: boolean;
  persistenceKey?: string;
  maxHistorySize?: number;
  onStateChange?: (state: S) => void;
}

export interface UseStateManagementReturn<S> {
  state: S;
  setState: (value: S) => void;
  updateState: (updates: Partial<S>) => void;
  resetState: () => void;
  clearState: () => void;
  canUndo: boolean;
  canRedo: boolean;
  undo: () => void;
  redo: () => void;
  saveToStorage: () => void;
  loadFromStorage: () => void;
  getHistorySize: () => number;
}

// ====================================================================
// DATA FETCHING HOOKS
// ====================================================================

export interface UseDataFetchingOptions<T> {
  endpoint?: string;
  collection?: string;
  revealui?: any; // RevealUI Content Engine instance
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  headers?: Record<string, string>;
  transform?: (data: any) => T;
  cacheTime?: number;
  onSuccess?: (data: T) => void;
  onError?: (error: Error) => void;
  enabled?: boolean;
  refetchInterval?: number;
  refetchOnWindowFocus?: boolean;
}

export interface UseDataFetchingResult<T> {
  data: T | null;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  refetch: () => Promise<void>;
  mutate: (data: T) => void;
  reset: () => void;
  create: (data: any) => Promise<T | null>;
  update: (id: string, data: any) => Promise<T | null>;
  delete: (id: string) => Promise<boolean>;
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasNext: boolean;
    hasPrev: boolean;
    nextPage: () => void;
    prevPage: () => void;
    setPage: (page: number) => void;
    setLimit: (limit: number) => void;
  };
  search: {
    query: string;
    setQuery: (query: string) => void;
    filters: Record<string, any>;
    setFilters: (filters: Record<string, any>) => void;
    sortBy: string;
    setSortBy: (sortBy: string) => void;
    sortOrder: 'asc' | 'desc';
    setSortOrder: (sortOrder: 'asc' | 'desc') => void;
  };
}

// ====================================================================
// AUTH HOOKS
// ====================================================================

export interface UseAuthOptions {
  redirectTo?: string;
  redirectIfFound?: boolean;
}

export interface UseAuthReturn {
  user: unknown | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (data: unknown) => Promise<void>;
}

// ====================================================================
// USER AUTH HOOKS
// ====================================================================

export interface UseUserAuthOptions {
  autoLogin?: boolean;
  redirectOnLogout?: string;
}

export interface UseUserAuthReturn {
  user: unknown | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: unknown) => Promise<void>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<void>;
}
