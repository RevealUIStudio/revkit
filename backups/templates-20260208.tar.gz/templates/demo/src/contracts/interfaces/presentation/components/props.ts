// ====================================================================
// COMPONENT PROPS INTERFACES
// ====================================================================
// Common component prop interfaces

import type { ReactNode } from 'react';

/**
 * Toast data interface
 */
export interface ToastData {
  id: string;
  title?: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

/**
 * Toast props
 */
export interface ToastProps {
  toast: ToastData;
  onClose: () => void;
}

/**
 * Search bar props
 */
export interface SearchBarProps {
  placeholder?: string;
  onSearch?: (query: string) => void;
  initialValue?: string;
  className?: string;
}

/**
 * Init theme props
 */
export interface InitThemeProps {
  storageKey?: string;
  defaultTheme?: 'light' | 'dark' | 'auto';
}

/**
 * Card footer props
 */
export interface CardFooterProps {
  children: ReactNode;
  className?: string;
}
