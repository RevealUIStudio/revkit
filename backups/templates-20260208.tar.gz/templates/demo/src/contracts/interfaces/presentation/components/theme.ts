// ====================================================================
// THEME INTERFACES
// ====================================================================
// Theme-related interfaces for the presentation layer
// Merged from presentation/theme.ts and shared/ui/theme.ts

import type { ReactNode } from 'react';

/**
 * Theme type - 'light' | 'dark' | 'system'
 */
export type Theme = 'light' | 'dark' | 'system';

/**
 * Theme context type
 */
export interface ThemeContextType {
  theme: Theme;
  resolvedTheme: 'light' | 'dark';
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  isSystemTheme: boolean;
  systemTheme: 'light' | 'dark';
}

/**
 * Theme provider props
 */
export interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
  onThemeChange?: (theme: Theme, resolvedTheme: 'light' | 'dark') => void;
  enableSystemTheme?: boolean;
}
