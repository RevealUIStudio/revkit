// ====================================================================
// UI COMPONENT INTERFACES
// ====================================================================
// Interface definitions for UI components

import type {
  ButtonHTMLAttributes,
  FormHTMLAttributes,
  HTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  TextareaHTMLAttributes,
} from 'react';

// ====================================================================
// CARD COMPONENT INTERFACES
// ====================================================================

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'elevated' | 'bordered' | 'interactive' | 'flat';
  size?: 'xs' | 'sm' | 'default' | 'lg' | 'xl';
  clickable?: boolean;
  asChild?: boolean;
}

export interface CardHeaderProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  size?: 'xs' | 'sm' | 'default' | 'lg' | 'xl';
}

export interface CardTitleProps extends HTMLAttributes<HTMLHeadingElement> {
  children: ReactNode;
  asChild?: boolean;
  level?: 1 | 2 | 3 | 4 | 5 | 6;
}

export interface CardDescriptionProps extends HTMLAttributes<HTMLParagraphElement> {
  children: ReactNode;
}

export interface CardContentProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  size?: 'xs' | 'sm' | 'default' | 'lg' | 'xl';
}

// ====================================================================
// BUTTON COMPONENT INTERFACES
// ====================================================================

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:
    | 'default'
    | 'primary'
    | 'secondary'
    | 'accent'
    | 'professional'
    | 'destructive'
    | 'outline'
    | 'ghost'
    | 'link'
    | 'success'
    | 'warning'
    | 'info'
    | 'UI';
  size?: 'default' | 'sm' | 'lg' | 'xl' | 'icon' | 'icon-sm' | 'icon-lg';
  asChild?: boolean;
  isLoading?: boolean;
  loadingText?: string;
  fullWidth?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  tooltip?: string;
}

export interface IconButtonProps extends Omit<ButtonProps, 'leftIcon' | 'rightIcon'> {
  icon: ReactNode;
  'aria-label': string;
}

export interface SubmitButtonProps extends ButtonProps {
  isSubmitting?: boolean;
  submitText?: string;
  submittingText?: string;
}

export interface ActionButtonProps extends ButtonProps {
  action: () => void | Promise<void>;
  confirmMessage?: string;
}

// ====================================================================
// FORM COMPONENT INTERFACES
// ====================================================================

export interface FormProps extends FormHTMLAttributes<HTMLFormElement> {
  children: ReactNode;
}

export interface FormFieldProps extends HTMLAttributes<HTMLDivElement> {
  label?: string;
  error?: string;
  required?: boolean;
  description?: string;
  children: ReactNode;
}

export interface FormSectionProps extends HTMLAttributes<HTMLDivElement> {
  title?: string;
  description?: string;
  children: ReactNode;
}

export interface FormFieldGroupProps extends HTMLAttributes<HTMLDivElement> {
  columns?: 1 | 2 | 3 | 4;
  children: ReactNode;
}

export interface FormActionsProps extends HTMLAttributes<HTMLDivElement> {
  alignment?: 'left' | 'center' | 'right' | 'between';
  children: ReactNode;
}

export interface FormMessageProps extends HTMLAttributes<HTMLDivElement> {
  type?: 'info' | 'success' | 'warning' | 'error';
  children: ReactNode;
}

// ====================================================================
// INPUT COMPONENT INTERFACES
// ====================================================================

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
}

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  resize?: 'none' | 'vertical' | 'horizontal' | 'both';
}

export interface SelectProps extends HTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  helperText?: string;
  options: Array<{ value: string; label: string }>;
}

// ====================================================================
// ACCESSIBILITY COMPONENT INTERFACES
// ====================================================================

export interface SkipToContentProps {
  href?: string;
  children?: ReactNode;
}

export interface ScreenReaderOnlyProps extends HTMLAttributes<HTMLSpanElement> {
  children: ReactNode;
}

// ====================================================================
// REDIRECT COMPONENT INTERFACES
// ====================================================================

export interface RedirectRule {
  from: string;
  to: string;
  preserveQuery?: boolean;
  statusCode?: number;
}

export interface RevealUIRedirectsProps {
  redirects?: RedirectRule[];
  url: string;
  disableNotFound?: boolean;
}

export interface FocusTrapProps {
  children: ReactNode;
  active?: boolean;
}

export interface LiveRegionProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  polite?: boolean;
}

// ====================================================================
// MODAL/DIALOG COMPONENT INTERFACES
// ====================================================================

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  closeOnOutsideClick?: boolean;
  closeOnEsc?: boolean;
}

// ====================================================================
// LOADING/SPINNER COMPONENT INTERFACES
// ====================================================================

export interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: string;
  className?: string;
  label?: string;
}

// ====================================================================
// ERROR BOUNDARY COMPONENT INTERFACES
// ====================================================================

export interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

export interface ErrorState {
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
  hasError: boolean;
}

// ====================================================================
// FORM SPECIFIC INTERFACES
// ====================================================================

export interface UserFormProps {
  userId?: string;
  onSuccess?: (user: unknown) => void;
  onError?: (error: Error) => void;
  mode?: 'create' | 'edit';
}

export interface UserFormState {
  isSubmitting: boolean;
  errors: Record<string, string>;
  values: Record<string, unknown>;
}

export interface PostFormProps {
  postId?: string;
  onSuccess?: (post: unknown) => void;
  onError?: (error: Error) => void;
  mode?: 'create' | 'edit';
}

// ====================================================================
// CACHE EXAMPLE COMPONENT INTERFACES
// ====================================================================

export interface CacheExampleProps {
  title?: string;
  description?: string;
}

// ====================================================================
// FORM SUBMISSION INTERFACES
// ====================================================================

export interface FormSubmissionResult {
  success: boolean;
  message: string;
  errors?: Array<{
    field: string;
    message: string;
  }>;
}
