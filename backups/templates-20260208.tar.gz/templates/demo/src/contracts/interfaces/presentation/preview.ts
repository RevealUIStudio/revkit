// ====================================================================
// PREVIEW INTERFACES
// ====================================================================
// Interfaces for preview mode in RevealUI Content Engine

import type { ReactNode } from 'react';

/**
 * Preview data structure
 */
export interface PreviewData {
  id: string;
  collection: string;
  data: Record<string, unknown>;
  timestamp: number;
}

/**
 * Preview context type
 */
export interface PreviewContextType {
  isPreview: boolean;
  previewData: PreviewData | null;
  setIsPreview: (isPreview: boolean) => void;
  setPreviewData: (data: PreviewData | null) => void;
  clearPreview: () => void;
  hasPreviewData: boolean;
  previewAge: number | null;
}

/**
 * Preview provider props
 */
export interface PreviewProviderProps {
  children: ReactNode;
  autoClear?: boolean;
  maxAge?: number;
}
