// =======
// FIGHT REPOSITORY INTERFACE
// =======
// Repository interface for fight-related data operations

import type { ServiceResult } from '../../../types/domain/service-results';
import type { Fight, FightResult, FightRevenue } from '../../domain/models/fight';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Fight repository interface extending base repository
 */
export interface IFightRepository extends IEntityRepository<Fight> {
  findByStatus(status: Fight['status']): Promise<ServiceResult<Fight[]>>;
  findByWeightClass(weightClass: Fight['weightClass']): Promise<ServiceResult<Fight[]>>;
  findByDateRange(startDate: string, endDate: string): Promise<ServiceResult<Fight[]>>;
  findByLocation(location: string): Promise<ServiceResult<Fight[]>>;
  findFeatured(): Promise<ServiceResult<Fight[]>>;
  findPayPerView(): Promise<ServiceResult<Fight[]>>;
  findUpcoming(): Promise<ServiceResult<Fight[]>>;
  findCompleted(): Promise<ServiceResult<Fight[]>>;
  updateResult(id: string, result: FightResult): Promise<ServiceResult<Fight>>;
  updateRevenue(id: string, revenue: FightRevenue): Promise<ServiceResult<Fight>>;
  searchFights(query: string): Promise<ServiceResult<Fight[]>>;
}
