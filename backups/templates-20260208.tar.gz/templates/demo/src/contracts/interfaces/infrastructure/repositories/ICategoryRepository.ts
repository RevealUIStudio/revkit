import type { DomainCategory as Category, ServiceResult } from '@/contracts';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Category repository interface with category-specific operations
 */
export interface ICategoryRepository extends IEntityRepository<Category> {
  // Category-specific query methods
  findBySlug(slug: string): Promise<ServiceResult<Category | null>>;
  findByParent(parentId: string): Promise<ServiceResult<Category[]>>;
  findRootCategories(): Promise<ServiceResult<Category[]>>;

  // Category hierarchy methods
  getCategoryTree(): Promise<ServiceResult<Category[]>>;
  getCategoryPath(id: string): Promise<ServiceResult<Category[]>>;
  getCategoryChildren(id: string): Promise<ServiceResult<Category[]>>;
  getCategoryAncestors(id: string): Promise<ServiceResult<Category[]>>;

  // Category management methods
  moveCategory(id: string, newParentId: string | null): Promise<ServiceResult<Category>>;
  reorderCategories(orderedIds: string[]): Promise<ServiceResult<Category[]>>;

  // Category search and analytics
  searchCategories(query: string): Promise<ServiceResult<Category[]>>;
  findFeaturedCategories(): Promise<ServiceResult<Category[]>>;
  getCategoryStats(id: string): Promise<
    ServiceResult<{
      postCount: number;
      subcategoryCount: number;
      totalViews: number;
    }>
  >;
}
