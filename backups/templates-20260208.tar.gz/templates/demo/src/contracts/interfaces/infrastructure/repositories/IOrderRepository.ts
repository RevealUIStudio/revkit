// =======
// ORDER REPOSITORY INTERFACE
// =======
// Repository interface for order-related data operations

import type { ServiceResult } from '../../../types/domain/service-results';
import type { Order, PaymentInfo } from '../../ecommerce';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Order repository interface extending base repository
 */
export interface IOrderRepository extends IEntityRepository<Order> {
  findByUserId(userId: string): Promise<ServiceResult<Order[]>>;
  findByStatus(status: Order['status']): Promise<ServiceResult<Order[]>>;
  findByDateRange(startDate: string, endDate: string): Promise<ServiceResult<Order[]>>;
  findPending(): Promise<ServiceResult<Order[]>>;
  findCompleted(): Promise<ServiceResult<Order[]>>;
  findCancelled(): Promise<ServiceResult<Order[]>>;
  updatePayment(id: string, payment: PaymentInfo): Promise<ServiceResult<Order>>;
  findOrdersByProduct(productId: string): Promise<ServiceResult<Order[]>>;
  getOrderTotals(dateRange?: { start: string; end: string }): Promise<
    ServiceResult<{
      total: number;
      count: number;
      average: number;
    }>
  >;
}
