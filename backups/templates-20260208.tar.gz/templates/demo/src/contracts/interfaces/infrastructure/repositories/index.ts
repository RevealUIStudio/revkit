// ====================================================================
// REPOSITORY CONTRACTS EXPORT SURFACE
// ====================================================================
// Centralized export surface for all repository interfaces and base types.
// Consumers should import from `@/contracts/interfaces/infrastructure/repositories`.

export * from './IBaseRepository';
export * from './ICartRepository';
export * from './ICategoryRepository';
export * from './IDomainMediaRepository';
export * from './IDomainMenuRepository';
export * from './IFighterRepository';
export * from './IFightRepository';
export * from './IMediaRepository';
export * from './IOrderRepository';
export * from './IPostRepository';
export * from './IProductRepository';
export * from './ITagRepository';
export * from './IUserRepository';
