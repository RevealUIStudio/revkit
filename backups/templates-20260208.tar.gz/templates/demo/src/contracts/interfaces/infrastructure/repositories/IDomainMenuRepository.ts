import type { DomainMenu, IEntityRepository } from '@/contracts';

/**
 * Domain repository interface for menu operations.
 * Provides data access methods for menu entities in the domain layer.
 */
export interface IDomainMenuRepository extends IEntityRepository<DomainMenu> {
  /**
   * Find menus by location
   */
  findByLocation(
    location: string
  ): Promise<{ success: boolean; data?: DomainMenu[]; error?: string }>;

  /**
   * Find active menus
   */
  findActive(): Promise<{
    success: boolean;
    data?: DomainMenu[];
    error?: string;
  }>;

  /**
   * Find menus by status
   */
  findByStatus(status: string): Promise<{ success: boolean; data?: DomainMenu[]; error?: string }>;

  /**
   * Get menu hierarchy
   */
  getHierarchy(): Promise<{
    success: boolean;
    data?: DomainMenu[];
    error?: string;
  }>;

  /**
   * Update menu items
   */
  updateItems(
    id: string,
    items: any[]
  ): Promise<{ success: boolean; data?: DomainMenu; error?: string }>;

  /**
   * Reorder menu items
   */
  reorderItems(
    id: string,
    itemIds: string[]
  ): Promise<{ success: boolean; data?: DomainMenu; error?: string }>;

  /**
   * Validate menu structure
   */
  validateStructure(
    menu: DomainMenu
  ): Promise<{ success: boolean; data?: boolean; error?: string }>;
}
