// =======
// PRODUCT REPOSITORY INTERFACE
// =======
// Repository interface for product-related data operations

import type { ServiceResult } from '../../../types/domain/service-results';
import type { Product, ProductInventory } from '../../ecommerce';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Product repository interface extending base repository
 */
export interface IProductRepository extends IEntityRepository<Product> {
  findByStatus(status: Product['status']): Promise<ServiceResult<Product[]>>;
  findFeatured(): Promise<ServiceResult<Product[]>>;
  findInStock(): Promise<ServiceResult<Product[]>>;
  findOutOfStock(): Promise<ServiceResult<Product[]>>;
  findByPriceRange(minPrice: number, maxPrice: number): Promise<ServiceResult<Product[]>>;
  updateInventory(id: string, inventory: ProductInventory): Promise<ServiceResult<Product>>;
  searchProducts(query: string): Promise<ServiceResult<Product[]>>;
  findRelatedProducts(productId: string, limit: number): Promise<ServiceResult<Product[]>>;
}
