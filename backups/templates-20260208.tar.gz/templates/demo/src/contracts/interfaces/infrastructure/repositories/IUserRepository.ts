import type { ServiceResult, DomainUser as User, UserRole } from '@/contracts';
import type { IEntityRepository } from './IBaseRepository';

/**
 * User repository interface with user-specific operations
 */
export interface IUserRepository extends IEntityRepository<User> {
  // User-specific query methods
  findByEmail(email: string): Promise<ServiceResult<User | null>>;
  findByUsername(username: string): Promise<ServiceResult<User | null>>;
  findByRole(role: UserRole): Promise<ServiceResult<User[]>>;
  findByStatus(status: string): Promise<ServiceResult<User[]>>;

  // User management methods
  updateUserRole(id: string, role: UserRole): Promise<ServiceResult<User>>;
  updateUserStatus(id: string, status: string): Promise<ServiceResult<User>>;
  deactivateUser(id: string): Promise<ServiceResult<User>>;
  activateUser(id: string): Promise<ServiceResult<User>>;

  // User search and analytics
  searchUsers(query: string): Promise<ServiceResult<User[]>>;
  getActiveUsers(): Promise<ServiceResult<User[]>>;
  getInactiveUsers(): Promise<ServiceResult<User[]>>;
  getUserCountByRole(): Promise<ServiceResult<Record<UserRole, number>>>;
}
