import type { DomainMedia, IEntityRepository } from '@/contracts';

/**
 * Domain repository interface for media operations.
 * Provides data access methods for media entities in the domain layer.
 */
export interface IDomainMediaRepository extends IEntityRepository<DomainMedia> {
  /**
   * Find media by MIME type
   */
  findByMimeType(
    mimeType: string
  ): Promise<{ success: boolean; data?: DomainMedia[]; error?: string }>;

  /**
   * Find unused media files
   */
  findUnused(): Promise<{
    success: boolean;
    data?: DomainMedia[];
    error?: string;
  }>;

  /**
   * Cleanup unused media files
   */
  cleanup(): Promise<{ success: boolean; data?: number; error?: string }>;
}
