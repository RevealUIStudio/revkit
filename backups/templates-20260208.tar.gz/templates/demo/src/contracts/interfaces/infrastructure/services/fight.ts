// =======
// FIGHT DOMAIN SERVICE INTERFACE
// =======
// Domain service interface for fight-related business logic

import type {
  CreateData,
  Fight,
  FightFilters,
  FightResult,
  FightRevenue,
  PaginatedResult,
  ServiceResult,
  UpdateData,
} from '@/contracts';
import type { ValidationResult } from '@/contracts/validation/results';

/**
 * Fight service interface for domain operations
 */
export interface IInfrastructureFightService {
  createFight(data: CreateData<Fight>): Promise<ServiceResult<Fight>>;
  updateFight(id: string, data: UpdateData<Fight>): Promise<ServiceResult<Fight>>;
  deleteFight(id: string): Promise<ServiceResult<void>>;
  getFight(id: string): Promise<ServiceResult<Fight>>;
  listFights(filters?: FightFilters): Promise<ServiceResult<PaginatedResult<Fight>>>;
  scheduleFight(fightId: string, scheduledDate: string): Promise<ServiceResult<Fight>>;
  completeFight(fightId: string, result: FightResult): Promise<ServiceResult<Fight>>;
  cancelFight(fightId: string, reason: string): Promise<ServiceResult<Fight>>;
  updateFightRevenue(fightId: string, revenue: FightRevenue): Promise<ServiceResult<Fight>>;
  getFightAnalytics(fightId: string): Promise<ServiceResult<Fight['analytics']>>;
  validateFightData(data: Partial<Fight>): Promise<ValidationResult<Fight>>;
}
