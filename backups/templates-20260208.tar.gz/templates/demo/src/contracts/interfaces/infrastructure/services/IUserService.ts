import type {
  CreateUserData,
  DomainUser,
  ServiceResult,
  UpdateUserData,
  UserRole,
  ValidationResult,
} from '@/contracts';

/**
 * User service interface for infrastructure layer
 */
export interface IInfrastructureUserService {
  createUser(data: CreateUserData): Promise<ServiceResult<DomainUser>>;
  updateUser(id: string, data: UpdateUserData): Promise<ServiceResult<DomainUser>>;
  deleteUser(id: string): Promise<ServiceResult<boolean>>;
  getUser(id: string): Promise<ServiceResult<DomainUser>>;
  // Using Record<string, unknown> because user filter structure varies by query type and cannot be strictly typed
  listUsers(
    filters?: /* Using Record<string, unknown> because user filter structure varies by query type and cannot be strictly typed */ Record<
      string,
      unknown
    >
  ): Promise<ServiceResult<DomainUser[]>>;
  updateUserProfile(id: string, data: UpdateUserData): Promise<ServiceResult<DomainUser>>;
  getUserProfile(id: string): Promise<ServiceResult<DomainUser>>;
  changeUserRole(id: string, role: UserRole): Promise<ServiceResult<DomainUser>>;
  validateUserPermissions(user: DomainUser, action: string): Promise<ServiceResult<boolean>>;
  getUserPermissions(id: string): Promise<ServiceResult<string[]>>;
  activateUser(id: string): Promise<ServiceResult<DomainUser>>;
  deactivateUser(id: string): Promise<ServiceResult<DomainUser>>;
  suspendUser(id: string, reason: string): Promise<ServiceResult<DomainUser>>;
  validateUserData(data: Partial<DomainUser>): Promise<ValidationResult<DomainUser>>;
  validateEmail(email: string): Promise<ServiceResult<boolean>>;
  validateUsername(username: string): Promise<ServiceResult<boolean>>;
  getUserStats(id: string): Promise<
    ServiceResult<{
      totalLogins: number;
      lastLogin: string;
      activityScore: number;
      profileCompleteness: number;
    }>
  >;
}
