import type { ServiceValidationResult } from '@/contracts';
import type { Tag as RevealUITag } from '@revealui/infrastructure/cms/db/revealui-types';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Tag repository interface with tag-specific operations
 * 
 * Note: This interface uses RevealUI Content Engine Tag type (RevealUITag) since TagRepository
 * works with RevealUI Content Engine types internally. For domain operations, use the toDomain()
 * method from IRevealUIRepository or Tag domain services.
 */
export interface ITagRepository extends IEntityRepository<RevealUITag> {
  // Tag-specific query methods
  findBySlug(slug: string): Promise<ServiceValidationResult<RevealUITag>>;
  findByName(name: string): Promise<ServiceValidationResult<RevealUITag>>;

  // Tag search methods
  findBySearchTerm(term: string): Promise<ServiceValidationResult<RevealUITag[]>>;
  findByDescription(description: string): Promise<ServiceValidationResult<RevealUITag[]>>;
  findRelatedTags(tagId: string): Promise<ServiceValidationResult<RevealUITag[]>>;

  // Tag filtering methods
  findPopular(limit?: number): Promise<ServiceValidationResult<RevealUITag[]>>;
  findUsedTags(): Promise<ServiceValidationResult<RevealUITag[]>>;
  findUnusedTags(): Promise<ServiceValidationResult<RevealUITag[]>>;
  findByCount(minCount: number): Promise<ServiceValidationResult<RevealUITag[]>>;

  // Tag count management methods
  updateCount(tagId: string, newCount: number): Promise<ServiceValidationResult<RevealUITag>>;
  incrementCount(tagId: string): Promise<ServiceValidationResult<RevealUITag>>;
  decrementCount(tagId: string): Promise<ServiceValidationResult<RevealUITag>>;
}

