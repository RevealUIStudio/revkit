// ====================================================================
// INFRASTRUCTURE UI COMPONENT INTERFACES
// ====================================================================
// Interface definitions for infrastructure/admin UI components

import type { AdminThemeConfig } from '@revealui/core/shared-types';
import type { ReactNode } from 'react';

/**
 * Admin theme configuration type
 */
/**
 * Admin theme context type
 */
export interface AdminThemeContextType {
  theme: AdminThemeConfig;
  frontendTheme: 'auto' | 'dark' | 'light';
  cssProperties: Record<string, string>;
  updateFrontendTheme: (theme: 'auto' | 'dark' | 'light') => void;
  isDarkMode: boolean;
  effectiveTheme: 'dark' | 'light';
}

/**
 * Admin theme provider props
 */
export interface AdminThemeProviderProps {
  children: ReactNode;
  themeOverride?: Partial<AdminThemeConfig>;
  syncWithFrontend?: boolean;
  defaultFrontendTheme?: 'auto' | 'dark' | 'light';
}

export interface ButtonProps {
  label: string;
}

export interface SearchBarProps {
  placeholder?: string;
}

/**
 * Before login component props
 */
export type BeforeLoginProps = Record<string, never>;

/**
 * Before dashboard component props
 */
export interface BeforeDashboardProps {
  className?: string;
  user?: {
    id?: string | number;
    name?: string;
    role?: string;
  };
  brandConfig?: {
    name?: string;
  };
  quickActions?: Array<{
    icon: string;
    title: string;
    description: string;
    onClick?: () => void;
  }>;
  systemStatus?: {
    status: 'online' | 'maintenance' | 'offline';
    message: string;
  };
}
