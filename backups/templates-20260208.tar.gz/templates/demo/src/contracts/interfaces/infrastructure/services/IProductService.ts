import type { DomainProduct, PaginatedResult, ProductFilters, ServiceResult } from '@/contracts';

export interface IInfrastructureProductService {
  createProduct(data: Partial<DomainProduct>): Promise<ServiceResult<DomainProduct>>;
  updateProduct(id: string, data: Partial<DomainProduct>): Promise<ServiceResult<DomainProduct>>;
  deleteProduct(id: string): Promise<ServiceResult<boolean>>;
  getProduct(id: string): Promise<ServiceResult<DomainProduct>>;
  listProducts(filters?: ProductFilters): Promise<ServiceResult<PaginatedResult<DomainProduct>>>;
  toggleFeatured(id: string): Promise<ServiceResult<DomainProduct>>;
}
