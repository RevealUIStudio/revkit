import type { ServiceValidationResult as ValidationResult } from '@/contracts';

/**
 * Authentication service interface for infrastructure layer
 */
export interface IInfrastructureAuthService {
  validateSession(token: string): Promise<boolean>;
  authenticateUser(
    email: string,
    password: string
  ): Promise<ValidationResult<{ id: string; email: string; role?: string }>>;
  generateToken(userId: string): Promise<string>;
  hashPassword(password: string): Promise<string>;
  verifyPassword(password: string, hash: string): Promise<boolean>;
  resetPassword(email: string): Promise<boolean>;
  forgotPassword(email: string): Promise<boolean>;
}
