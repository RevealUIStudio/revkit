import type { DomainPost as Post, PostStatus, ServiceResult } from '@/contracts';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Post repository interface with post-specific operations
 */
export interface IPostRepository extends IEntityRepository<Post> {
  // Post-specific query methods
  findByAuthor(authorId: string): Promise<ServiceResult<Post[]>>;
  findByCategory(categoryId: string): Promise<ServiceResult<Post[]>>;
  findByStatus(status: PostStatus): Promise<ServiceResult<Post[]>>;
  findBySlug(slug: string): Promise<ServiceResult<Post | null>>;

  // Published content methods
  findPublished(): Promise<ServiceResult<Post[]>>;
  findPublishedByAuthor(authorId: string): Promise<ServiceResult<Post[]>>;
  findPublishedByCategory(categoryId: string): Promise<ServiceResult<Post[]>>;

  // Post management methods
  publishPost(id: string): Promise<ServiceResult<Post>>;
  unpublishPost(id: string): Promise<ServiceResult<Post>>;
  archivePost(id: string): Promise<ServiceResult<Post>>;

  // Post search and analytics
  searchPosts(query: string): Promise<ServiceResult<Post[]>>;
  findFeaturedPosts(): Promise<ServiceResult<Post[]>>;
  findRecentPosts(limit?: number): Promise<ServiceResult<Post[]>>;
  findPopularPosts(limit?: number): Promise<ServiceResult<Post[]>>;
  incrementViewCount(id: string): Promise<ServiceResult<Post>>;
}
