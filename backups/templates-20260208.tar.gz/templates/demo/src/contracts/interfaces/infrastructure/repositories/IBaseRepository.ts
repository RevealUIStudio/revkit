export interface IBaseRepository<TEntity> {
  findAll(): Promise<TEntity[]>;
}

export type IEntityRepository<TEntity> = IBaseRepository<TEntity>;
