// =======
// FIGHTER REPOSITORY INTERFACE
// =======
// Repository interface for fighter-related data operations

import type { ServiceResult } from '../../../types/domain/service-results';
import type { Fighter } from '../../domain/models/fight';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Fighter repository interface extending base repository
 */
export interface IFighterRepository extends IEntityRepository<Fighter> {
  findByUserId(userId: string): Promise<ServiceResult<Fighter | null>>;
  findByWeightClass(weightClass: Fighter['weightClass']): Promise<ServiceResult<Fighter[]>>;
  findActive(): Promise<ServiceResult<Fighter[]>>;
  findInactive(): Promise<ServiceResult<Fighter[]>>;
  updateRecord(id: string, record: Fighter['record']): Promise<ServiceResult<Fighter>>;
  updateStats(id: string, stats: Fighter['stats']): Promise<ServiceResult<Fighter>>;
  searchFighters(query: string): Promise<ServiceResult<Fighter[]>>;
  findTopFighters(limit: number): Promise<ServiceResult<Fighter[]>>;
}
