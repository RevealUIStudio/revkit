import type { DomainMedia as Media, ServiceResult } from '@/contracts';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Media repository interface with media-specific operations
 */
export interface IMediaRepository extends IEntityRepository<Media> {
  // Media-specific query methods
  findByFilename(filename: string): Promise<ServiceResult<Media | null>>;
  findByMimeType(mimeType: string): Promise<ServiceResult<Media[]>>;
  findBySizeRange(minSize: number, maxSize: number): Promise<ServiceResult<Media[]>>;
  findByDimensions(width: number, height: number): Promise<ServiceResult<Media[]>>;

  // Media organization methods
  findByPrefix(prefixId: string): Promise<ServiceResult<Media[]>>;
  findUnassigned(): Promise<ServiceResult<Media[]>>;
  assignToPrefix(mediaId: string, prefixId: string): Promise<ServiceResult<Media>>;
  removeFromPrefix(mediaId: string): Promise<ServiceResult<Media>>;

  // Media search and filtering
  searchMedia(query: string): Promise<ServiceResult<Media[]>>;
  findImages(): Promise<ServiceResult<Media[]>>;
  findVideos(): Promise<ServiceResult<Media[]>>;
  findDocuments(): Promise<ServiceResult<Media[]>>;

  // Media analytics and management
  getMediaStats(): Promise<
    ServiceResult<{
      totalFiles: number;
      totalSize: number;
      byType: Record<string, number>;
      byPrefix: Record<string, number>;
    }>
  >;
  findOrphanedMedia(): Promise<ServiceResult<Media[]>>;
  cleanupOrphanedMedia(): Promise<ServiceResult<number>>;
}
