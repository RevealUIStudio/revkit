export interface MuxVideoPluginOptions {
  /**
   * Enable or disable the plugin
   * @default true
   */
  enabled?: boolean;

  /**
   * Collections to enable Mux video support for
   * @example { videos: true }
   */
  collections: {
    [collectionSlug: string]: boolean | MuxCollectionConfig;
  };

  /**
   * Mux API token ID (can also use environment variable MUX_TOKEN_ID)
   */
  tokenId?: string;

  /**
   * Mux API token secret (can also use environment variable MUX_TOKEN_SECRET)
   */
  tokenSecret?: string;

  /**
   * Webhook secret for verifying Mux webhooks (optional)
   */
  webhookSecret?: string;

  /**
   * Encoding tier for transcoding
   * @default 'baseline' (free tier)
   */
  encodingTier?: 'baseline' | 'smart' | 'optimized';

  /**
   * Maximum resolution tier
   * @default '1080p'
   */
  maxResolutionTier?: '1080p' | '1440p' | '2160p';

  /**
   * Enable MP4 support for downloads
   * @default 'standard'
   */
  mp4Support?: 'none' | 'standard' | 'audio-only';

  /**
   * Playback policy
   * @default ['public']
   */
  playbackPolicy?: Array<'public' | 'signed'>;

  /**
   * Normalize audio levels
   * @default true
   */
  normalizeAudio?: boolean;
}

export interface MuxCollectionConfig {
  /**
   * Disable local storage for this collection
   * @default true
   */
  disableLocalStorage?: boolean;

  /**
   * Custom encoding settings for this collection
   */
  encodingTier?: 'baseline' | 'smart' | 'optimized';
}

export interface MuxPluginConfig {
  tokenId: string;
  tokenSecret: string;
  webhookSecret?: string;
  encodingTier?: string;
  maxResolutionTier?: string;
  mp4Support?: string;
  playbackPolicy?: string[];
  normalizeAudio?: boolean;
}
