// ====================================================================
// CACHE INTERFACES
// ====================================================================
// Cache-related interfaces for the application

/**
 * Cache options
 */
export interface UseCacheOptions {
  ttl?: number;
  key?: string;
  enabled?: boolean;
  revalidateOnFocus?: boolean;
  revalidateOnReconnect?: boolean;
}

/**
 * Cache state
 */
export interface UseCacheState<T> {
  data: T | null;
  isLoading: boolean;
  error: Error | null;
  isValidating: boolean;
  mutate: (data?: T) => Promise<void>;
  revalidate: () => Promise<void>;
}

/**
 * Cache interface
 */
export interface ICache {
  readonly cacheName: string;
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttl?: number): Promise<void>;
  delete(key: string): Promise<boolean>;
  clear(): Promise<void>;
  has(key: string): Promise<boolean>;
}
