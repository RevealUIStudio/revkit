export interface ICategoryService {
  listCategories(): Promise<unknown[]>;
}
