// Define the types locally to avoid circular imports
export interface LogLevel {
  name: string;
  color: (input: string) => string;
  priority: number;
  emoji: string;
}

export interface LogEntry {
  timestamp: Date;
  level: string;
  context: string;
  message: string;
  data?: unknown;
  source: string;
}

export interface UnifiedLoggerConfig {
  enableRevealUIIntegration?: boolean;
  enableChalkStyling?: boolean;
  logLevel?: string;
  serviceName?: string;
}
