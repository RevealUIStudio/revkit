// =======
// CART REPOSITORY INTERFACE
// =======
// Repository interface for cart-related data operations

import type { ServiceResult } from '../../../types/domain/service-results';
import type { Cart } from '../../ecommerce';
import type { IEntityRepository } from './IBaseRepository';

/**
 * Cart repository interface extending base repository
 */
export interface ICartRepository extends IEntityRepository<Cart> {
  findByUserId(userId: string): Promise<ServiceResult<Cart | null>>;
  findExpired(): Promise<ServiceResult<Cart[]>>;
  clearExpired(): Promise<ServiceResult<number>>;
  addItem(cartId: string, productId: string, quantity: number): Promise<ServiceResult<Cart>>;
  removeItem(cartId: string, itemId: string): Promise<ServiceResult<Cart>>;
  updateItemQuantity(
    cartId: string,
    itemId: string,
    quantity: number
  ): Promise<ServiceResult<Cart>>;
  clearCart(cartId: string): Promise<ServiceResult<Cart>>;
}
