// ====================================================================
// INTERFACES TYPES - Centralized type exports for interfaces layer
// ====================================================================
// This file aggregates type aliases and type re-exports used by files under
// src/contracts/interfaces/**. Only interface files should import from here.
//
// All types are re-exported from the centralized ../types/index.ts

// --------------------------------------------------------------------
// Re-export all types from the centralized types folder
// --------------------------------------------------------------------
export * from '../types';
