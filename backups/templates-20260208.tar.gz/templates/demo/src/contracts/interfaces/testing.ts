// ====================================================================
// TESTING INTERFACES
// ====================================================================
// Interfaces for testing utilities, health checks, and analysis tools

/**
 * Health check result
 */
export interface HealthCheckResult {
  category: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  details?: string;
}

/**
 * Health report
 */
export interface HealthReport {
  timestamp: string;
  overallStatus: 'healthy' | 'warning' | 'critical';
  checks: HealthCheckResult[];
  summary: {
    total: number;
    passed: number;
    failed: number;
    warnings: number;
  };
}

/**
 * Analysis result
 */
export interface AnalysisResult {
  category: string;
  score: number;
  issues: string[];
  recommendations: string[];
  metrics?: Record<string, unknown>;
}

/**
 * Test fix options
 */
export interface TestFixOptions {
  fixLinting?: boolean;
  fixTypes?: boolean;
  fixBuild?: boolean;
  fixDependencies?: boolean;
  fixSecurity?: boolean;
  autoFix?: boolean;
  dryRun?: boolean;
  outputFormat?: 'table' | 'json' | 'csv';
}

/**
 * Test result
 */
export interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'skip';
  message?: string;
  details?: unknown;
}

/**
 * Test fix report
 */
export interface TestFixReport {
  timestamp: string;
  fixes: Array<{
    category: string;
    success: boolean;
    fixes: string[];
    errors?: string[];
  }>;
  summary: {
    total: number;
    successful: number;
    failed: number;
  };
}

/**
 * Analyze options
 */
export interface AnalyzeOptions {
  includeDependencies?: boolean;
  includeSecurity?: boolean;
  outputFormat?: 'table' | 'json' | 'csv';
}

/**
 * Clean options
 */
export interface CleanOptions {
  removeNodeModules?: boolean;
  removeBuildArtifacts?: boolean;
  removeCache?: boolean;
  dryRun?: boolean;
}

/**
 * Clean result
 */
export interface CleanResult {
  removed: string[];
  errors: string[];
  totalSize?: number;
}

/**
 * Update result
 */
export interface UpdateResult {
  updated: string[];
  errors: string[];
  summary: {
    total: number;
    successful: number;
    failed: number;
  };
}

/**
 * Dependency info
 */
export interface DependencyInfo {
  name: string;
  current: string;
  latest: string;
  type: 'dependencies' | 'devDependencies' | 'peerDependencies';
}

/**
 * Dependency report
 */
export interface DependencyReport {
  outdated: DependencyInfo[];
  vulnerabilities: Array<{
    name: string;
    severity: string;
    description: string;
  }>;
  summary: {
    total: number;
    outdated: number;
    vulnerabilities: number;
  };
}

/**
 * Audit result
 */
export interface AuditResult {
  timestamp: string;
  vulnerabilities: Array<{
    name: string;
    severity: string;
    description: string;
    recommendation?: string;
  }>;
  summary: {
    total: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}
