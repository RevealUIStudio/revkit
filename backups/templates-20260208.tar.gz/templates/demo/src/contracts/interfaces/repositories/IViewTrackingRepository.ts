// ====================================================================
// VIEW TRACKING REPOSITORY INTERFACE
// ====================================================================

import type { ServiceResult } from '@/contracts';

/**
 * View tracking data
 */
export interface ViewTrackingData {
  entityId: string;
  entityType: string;
  userId?: string;
  sessionId?: string;
  ipAddress?: string;
  userAgent?: string;
  referrer?: string;
  timestamp?: Date;
}

/**
 * Unique view check result
 */
export interface UniqueViewCheck {
  isUnique: boolean;
  existingViewId?: string;
}

/**
 * View tracking repository interface
 */
export interface IViewTrackingRepository {
  recordView(viewData: ViewTrackingData): Promise<ServiceResult<void>>;
  checkUniqueView(
    entityId: string,
    entityType: string,
    userId?: string,
    sessionId?: string
  ): Promise<ServiceResult<UniqueViewCheck>>;
  getViewCount(entityId: string, entityType: string): Promise<ServiceResult<number>>;
  getViewsByEntity(
    entityId: string,
    entityType: string,
    options?: { limit?: number; offset?: number }
  ): Promise<ServiceResult<ViewTrackingData[]>>;
}
