// ====================================================================
// ECOMMERCE TYPES
// ====================================================================
// Re-exports for Cart, Order, and Product types used by interface definitions

export type { DomainCart as Cart } from '../types/domain/entities/cart';
export type { DomainOrder as Order } from '../types/domain/entities/order';
export type { DomainProduct as Product, ProductInventory } from '../types/domain/entities/product';
export type { PaymentInfo, ShippingInfo } from '../types/domain/entities/order';
