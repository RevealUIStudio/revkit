# Interface Migration Guide

This guide shows how to migrate interfaces from the old structure to the new
feature-based organization.

## 📁 New Structure Overview

```
src/contracts/interfaces/
├── features/                    # Feature-specific domains
│   ├── auth/                    # Authentication domain
│   │   ├── auth.ts             # Core auth interfaces
│   │   ├── types.ts            # Auth-specific types
│   │   └── index.ts            # Barrel export
│   ├── ecommerce/               # E-commerce domain
│   │   ├── ecommerce.ts        # Core commerce interfaces
│   │   ├── types.ts            # Commerce-specific types
│   │   └── index.ts            # Barrel export
│   ├── user/                    # User management domain
│   │   ├── user.ts             # Core user interfaces
│   │   ├── types.ts            # User-specific types
│   │   └── index.ts            # Barrel export
│   ├── fight/                   # Fight/MMA domain
│   │   ├── fight.ts            # Core fight interfaces
│   │   ├── types.ts            # Fight-specific types
│   │   └── index.ts            # Barrel export
│   ├── media/                   # Media/content domain
│   │   ├── media.ts            # Core media interfaces
│   │   ├── types.ts            # Media-specific types
│   │   └── index.ts            # Barrel export
│   └── index.ts                # Features barrel export
├── infrastructure/              # Infrastructure layer
│   ├── services/                # Service interfaces
│   │   ├── auth.ts             # Auth service interfaces
│   │   ├── user.ts             # User service interfaces
│   │   ├── fight.ts            # Fight service interfaces
│   │   ├── ecommerce.ts        # E-commerce service interfaces
│   │   └── index.ts            # Services barrel export
│   ├── repositories/            # Repository interfaces (already moved)
│   └── components/              # Component interfaces
│       ├── ui.ts               # UI component interfaces
│       ├── forms.ts            # Form component interfaces
│       └── index.ts            # Components barrel export
├── shared/                      # Cross-cutting concerns
│   ├── types/                   # Common types
│   │   ├── base.ts             # Base interfaces/types
│   │   ├── theme.ts            # Theme interfaces
│   │   └── index.ts            # Types barrel export
│   ├── validation/              # Validation interfaces
│   │   ├── validation.ts       # Core validation interfaces
│   │   └── index.ts            # Validation barrel export
│   ├── events/                  # Event interfaces
│   │   ├── domain-events.ts    # Domain event interfaces
│   │   └── index.ts            # Events barrel export
│   ├── security/                # Security interfaces
│   │   ├── security.ts         # Core security interfaces
│   │   └── index.ts            # Security barrel export
│   └── index.ts                # Shared barrel export
└── index.ts                     # Main barrel export
```

## 🔄 Migration Steps

### Step 1: Move Feature Interfaces

#### Auth Domain

```bash
# Move auth interfaces to features/auth/
mv src/contracts/interfaces/auth.ts src/contracts/interfaces/features/auth/auth.ts
```

Create `src/contracts/interfaces/features/auth/index.ts`:

```typescript
export * from './auth';
```

#### E-commerce Domain

```bash
# Move ecommerce interfaces to features/ecommerce/
mv src/contracts/interfaces/ecommerce.ts src/contracts/interfaces/features/ecommerce/ecommerce.ts
```

Create `src/contracts/interfaces/features/ecommerce/index.ts`:

```typescript
export * from './ecommerce';
```

#### User Domain

```bash
# Move user interfaces to features/user/
mv src/contracts/interfaces/user.ts src/contracts/interfaces/features/user/user.ts
```

Create `src/contracts/interfaces/features/user/index.ts`:

```typescript
export * from './user';
```

#### Fight Domain

```bash
# Move fight interfaces to features/fight/
mv src/contracts/interfaces/domain/fight.ts src/contracts/interfaces/features/fight/fight.ts
```

Create `src/contracts/interfaces/features/fight/index.ts`:

```typescript
export * from './fight';
```

### Step 2: Move Infrastructure Interfaces

#### Services

```bash
# Move service interfaces to infrastructure/services/
mv src/contracts/interfaces/services/domain/* src/contracts/interfaces/infrastructure/services/
```

Create service-specific files:

```typescript
// infrastructure/services/auth.ts
export * from './IAuthService';

// infrastructure/services/user.ts
export * from './IUserService';

// infrastructure/services/fight.ts
export * from './IFightService';
export * from './IFighterService';

// infrastructure/services/ecommerce.ts
export * from './IProductService';
export * from './IOrderService';
export * from './ICartService';
```

#### Components

```bash
# Move component interfaces to infrastructure/components/
mv src/contracts/interfaces/ui.ts src/contracts/interfaces/infrastructure/components/ui.ts
mv src/contracts/interfaces/blocks.ts src/contracts/interfaces/infrastructure/components/blocks.ts
mv src/contracts/interfaces/hooks.ts src/contracts/interfaces/infrastructure/components/hooks.ts
```

### Step 3: Move Shared Interfaces

#### Types

```bash
# Move shared types to shared/types/
mv src/contracts/interfaces/theme.ts src/contracts/interfaces/shared/types/theme.ts
mv src/contracts/interfaces/session.ts src/contracts/interfaces/shared/types/session.ts
```

#### Validation & Security

```bash
# Move validation and security interfaces
mv src/contracts/interfaces/validation.ts src/contracts/interfaces/shared/validation/validation.ts
mv src/contracts/interfaces/security.ts src/contracts/interfaces/shared/security/security.ts
```

#### Events

```bash
# Move event interfaces
mv src/contracts/interfaces/domain/category.ts src/contracts/interfaces/shared/events/domain-events.ts
```

### Step 4: Update Import Statements

#### Old Import Style

```typescript
// ❌ Old way
import { User } from '@/contracts/interfaces';
import { IAuthService } from '@/contracts/interfaces/services/domain/IAuthService';
import { AuthState } from '@/contracts/interfaces/auth';
```

#### New Import Style

```typescript
// ✅ New way
import { User } from '@/contracts/interfaces/features/user';
import { IAuthService } from '@/contracts/interfaces/infrastructure/services/auth';
import { AuthState } from '@/contracts/interfaces/features/auth';
```

### Step 5: Update Main Index

Update `src/contracts/interfaces/index.ts`:

```typescript
// Main barrel export
export * from './features';
export * from './infrastructure';
export * from './shared';

// Legacy compatibility (remove after migration)
export * from '.'; // Remove after all imports updated
```

### Step 6: Clean Up

1. **Remove old files:**

   ```bash
   rm src/contracts/interfaces.ts
   rm src/contracts/interfaces/user-backup.ts
   rm -rf src/contracts/interfaces/domain/  # After moving interfaces
   rm -rf src/contracts/interfaces/services/ # After moving to infrastructure
   ```

2. **Update any remaining imports** that reference old paths

3. **Test the application** to ensure all imports work correctly

## 📋 File Mapping Reference

| Old Location        | New Location                                  |
| ------------------- | --------------------------------------------- |
| `auth.ts`           | `features/auth/auth.ts`                       |
| `ecommerce.ts`      | `features/ecommerce/ecommerce.ts`             |
| `user.ts`           | `features/user/user.ts`                       |
| `domain/fight.ts`   | `features/fight/fight.ts`                     |
| `ui.ts`             | `infrastructure/components/ui.ts`             |
| `blocks.ts`         | `infrastructure/components/blocks.ts`         |
| `validation.ts`     | `shared/validation/validation.ts`             |
| `security.ts`       | `shared/security/security.ts`                 |
| `theme.ts`          | `shared/types/theme.ts`                       |
| `services/domain/*` | `infrastructure/services/`                    |
| `repositories/*`    | `infrastructure/repositories/` (already done) |

## 🎯 Benefits of New Structure

1. **Feature Isolation**: Each domain has its own folder
2. **Clear Separation**: Business logic vs infrastructure separation
3. **Scalability**: Easy to add new features/domains
4. **Maintainability**: Related interfaces grouped together
5. **Discoverability**: Easier to find interfaces by feature
6. **Consistency**: Standardized naming and structure

## 🔍 Example Feature Structure

```
features/
└── auth/
    ├── auth.ts          # Core authentication interfaces
    ├── types.ts         # Auth-specific types
    ├── services.ts      # Auth service interfaces
    ├── repositories.ts  # Auth repository interfaces
    └── index.ts         # Barrel export
```

This structure makes it easy to understand what interfaces belong to
authentication and find them quickly.

## Phased Rollout for RevealUI Architecture Coherence

1. Phase 1 (Additive): Introduce `repositoryFactory`, `serviceFactory`,
   `tenantContext`, and `policies` alongside existing code. Migrate a few
   representative repositories (users, posts, orders) and collections
   (categories, posts, products) to shared hooks/access.
2. Phase 2 (Adoption): Gradually apply tenant scoping and shared access/hooks to
   remaining repositories and collections. Update endpoints to use the endpoint
   adapter with injected services.
3. Phase 3 (Cleanup): Remove deprecated functional repositories and ad-hoc
   access/hook patterns. Keep metrics and the events summary endpoint enabled.
