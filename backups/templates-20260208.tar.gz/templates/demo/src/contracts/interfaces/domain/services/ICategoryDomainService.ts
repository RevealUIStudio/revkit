import type {
  CategoryFiltersDTO,
  CategoryReorderDTO,
  CategoryStatisticsDTO,
  CreateCategoryDTO,
  UpdateCategoryDTO,
} from '../../../types/domain/dto/category';
import type { DomainCategory } from '../../../types/domain/entities/category';
import type { ServiceResult, ValidationResult } from '../../../types/domain/service-results';
import type { IBaseService } from '../base/IBaseService';

/**
 * Category domain service interface with domain-specific business logic
 */
export interface ICategoryDomainService extends IBaseService {
  // Updated methods using DTOs
  createCategory(data: CreateCategoryDTO): Promise<ServiceResult<DomainCategory>>;
  updateCategory(id: string, data: UpdateCategoryDTO): Promise<ServiceResult<DomainCategory>>;
  getCategoriesByFilters(filters: CategoryFiltersDTO): Promise<ServiceResult<DomainCategory[]>>;
  reorderCategory(data: CategoryReorderDTO): Promise<ServiceResult<DomainCategory>>;
  getCategoryStatistics(): Promise<ServiceResult<CategoryStatisticsDTO>>;

  // Existing methods
  deleteCategory(id: string): Promise<ServiceResult<boolean>>;
  getCategory(id: string): Promise<ServiceResult<DomainCategory>>;

  // Category hierarchy management
  createSubcategory(
    parentId: string,
    data: CreateCategoryDTO
  ): Promise<ServiceResult<DomainCategory>>;
  moveCategory(id: string, newParentId: string | null): Promise<ServiceResult<DomainCategory>>;
  reorderCategories(orderedIds: string[]): Promise<ServiceResult<DomainCategory[]>>;

  // Category tree operations
  getCategoryTree(): Promise<ServiceResult<DomainCategory[]>>;
  getCategoryPath(id: string): Promise<ServiceResult<DomainCategory[]>>;
  getCategoryChildren(id: string): Promise<ServiceResult<DomainCategory[]>>;
  getCategoryAncestors(id: string): Promise<ServiceResult<DomainCategory[]>>;
  getRootCategories(): Promise<ServiceResult<DomainCategory[]>>;

  // Category discovery
  getCategoryBySlug(slug: string): Promise<ServiceResult<DomainCategory | null>>;
  searchCategories(query: string): Promise<ServiceResult<DomainCategory[]>>;
  getFeaturedCategories(): Promise<ServiceResult<DomainCategory[]>>;

  // Category analytics
  getCategoryStats(id: string): Promise<
    ServiceResult<{
      postCount: number;
      subcategoryCount: number;
      totalViews: number;
      averageViewsPerPost: number;
    }>
  >;

  // Category validation
  validateCategoryData(data: Partial<DomainCategory>): Promise<ValidationResult<DomainCategory>>;
  validateCategorySlug(slug: string, excludeId?: string): Promise<ServiceResult<boolean>>;
  validateCategoryHierarchy(parentId: string | null): Promise<ServiceResult<boolean>>;
}
