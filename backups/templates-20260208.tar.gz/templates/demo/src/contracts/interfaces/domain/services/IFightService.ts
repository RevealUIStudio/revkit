// =======
// FIGHT DOMAIN SERVICE INTERFACE
// =======
// Domain service interface for fight-related business logic

import type { ServiceResult } from '@/contracts';

type Fight = {
  id?: string;
  status?: string;
  scheduledDate?: string;
  venue?: string;
  location?: string;
  weightClass?: string;
};

type FightResult = {
  winnerId?: string;
  loserId?: string;
  method?: string;
  round?: number;
  time?: string;
};

type FightFilters = {
  status?: string;
  weightClass?: string;
  page?: number;
  limit?: number;
};

type FightRevenue = {
  ticketSales: number;
  payPerView: number;
  merchandise: number;
  sponsorships: number;
};

type FightAudienceAnalytics = {
  totalViews: number;
  uniqueViewers: number;
  averageWatchTime: number;
  peakConcurrentViewers: number;
};

export interface IFightService {
  createFight(data: Partial<Fight>): Promise<ServiceResult<Fight>>;
  updateFight(id: string, data: Partial<Fight>): Promise<ServiceResult<Fight>>;
  deleteFight(id: string): Promise<ServiceResult<boolean>>;
  getFight(id: string): Promise<ServiceResult<Fight>>;
  getFights(filters?: FightFilters): Promise<
    ServiceResult<{
      docs: Fight[];
      totalDocs: number;
      totalPages: number;
      page: number;
      limit: number;
    }>
  >;
  scheduleFight(id: string, scheduledDate: string): Promise<ServiceResult<Fight>>;
  cancelFight(id: string, reason: string): Promise<ServiceResult<Fight>>;
  completeFight(id: string, result: FightResult): Promise<ServiceResult<Fight>>;
  updateFightRevenue(id: string, revenue: FightRevenue): Promise<ServiceResult<Fight>>;
  updateFightAnalytics(
    id: string,
    analytics: FightAudienceAnalytics
  ): Promise<ServiceResult<Fight>>;
  getFightAnalytics(id: string): Promise<
    ServiceResult<{
      totalFights: number;
      completedFights: number;
      cancelledFights: number;
      upcomingFights: number;
    }>
  >;
  getUpcomingFights(): Promise<ServiceResult<Fight[]>>;
  getCompletedFights(): Promise<ServiceResult<Fight[]>>;
}
