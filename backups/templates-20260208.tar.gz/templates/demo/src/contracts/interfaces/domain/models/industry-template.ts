export interface IndustryTemplateTerminology {
  users: string;
  products: string;
  events: string;
  categories: string;
  revenue: string;
  analytics: string;
}

export interface IndustryTemplateColors {
  primary: string;
  secondary: string;
  accent: string;
  success: string;
  warning: string;
  error: string;
}

export interface IndustryTemplateIcons {
  dashboard: string;
  users: string;
  products: string;
  events: string;
  analytics: string;
  revenue: string;
  settings: string;
}

export interface IndustryTemplateLayout {
  sidebarPosition: 'left' | 'right' | 'top' | 'bottom';
  navigationStyle: 'vertical' | 'horizontal' | 'tabs' | 'breadcrumbs';
  cardLayout: 'grid' | 'list' | 'masonry' | 'carousel';
}

export interface IndustryTemplateUIConfig {
  terminology: IndustryTemplateTerminology;
  colors: IndustryTemplateColors;
  icons: IndustryTemplateIcons;
  layout: IndustryTemplateLayout;
}

export interface IndustryTemplateWorkflow {
  userOnboarding: {
    enabled: boolean;
    steps: Array<{
      step: string;
      description?: string;
      required: boolean;
      order: number;
      estimatedTime?: number;
      skipable: boolean;
    }>;
    completionReward?: string;
  };
  productManagement: {
    requiresApproval: boolean;
    autoPublish: boolean;
    inventoryTracking: boolean;
    variants: boolean;
    reviews: boolean;
    relatedProducts: boolean;
  };
  orderManagement: {
    autoConfirm: boolean;
    paymentRequired: boolean;
    orderNotifications: boolean;
    cancellationPolicy?: string;
  };
  customerService: {
    supportTickets: boolean;
    liveChat: boolean;
    faq: boolean;
    responseTime?: number;
  };
}

export interface IndustryTemplateIntegrations {
  payment: {
    stripe: boolean;
    paypal: boolean;
    square: boolean;
  };
  marketing: {
    emailMarketing: boolean;
    socialMedia: boolean;
    googleAnalytics: boolean;
  };
  communication: {
    email: boolean;
    sms: boolean;
    pushNotifications: boolean;
  };
}

export interface IndustryTemplate {
  id: string;
  name: string;
  industry: string;
  description?: string;
  uiConfig: IndustryTemplateUIConfig;
  workflows: IndustryTemplateWorkflow;
  integrations: IndustryTemplateIntegrations;
  status: 'active' | 'draft' | 'archived' | 'beta' | 'deprecated';
  metadata?: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export interface UseIndustryTemplateOptions {
  industry?: string;
  status?: IndustryTemplate['status'];
  autoFetch?: boolean;
}

export interface UseIndustryTemplateReturn {
  template: IndustryTemplate | null;
  templates: IndustryTemplate[];
  loading: boolean;
  error: string | null;
  fetchTemplate: (industry: string) => Promise<void>;
  fetchTemplates: (options?: UseIndustryTemplateOptions) => Promise<void>;
  updateTemplate: (id: string, updates: Partial<IndustryTemplate>) => Promise<void>;
}

export interface IndustryTemplateDisplayProps {
  className?: string;
  showWorkflows?: boolean;
  showIntegrations?: boolean;
}

export interface IndustryTemplateContextValue {
  template: IndustryTemplate | null;
  templates: IndustryTemplate[];
  loading: boolean;
  error: string | null;
  fetchTemplate: (industry: string) => Promise<void>;
  fetchTemplates: (options?: {
    industry?: string;
    status?: IndustryTemplate['status'];
  }) => Promise<void>;
  updateTemplate: (id: string, updates: Partial<IndustryTemplate>) => Promise<void>;
}

export interface IndustryTemplateProviderProps {
  children: React.ReactNode;
  industry?: string;
  status?: IndustryTemplate['status'];
  autoFetch?: boolean;
}

export interface IndustryTemplateTesterProps {
  className?: string;
}
