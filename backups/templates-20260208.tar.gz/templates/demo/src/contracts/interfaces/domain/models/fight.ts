// ====================================================================
// FIGHT DOMAIN MODELS
// ====================================================================
// Re-export fight types from domain entities for interfaces

export type {
  Fight,
  Fighter,
  FightResult,
  FightRevenue,
  FightFilters,
  FightStatus,
  WeightClass,
  FightStance,
  FightRecord,
  FighterStats,
  FightAnalytics,
} from '@/contracts';
