// ====================================================================
// TAG DOMAIN SERVICE INTERFACE
// ====================================================================
// Domain service interface for Tag operations

import type { DomainTag, ServiceResult } from '@/contracts';

export interface ITagDomainService {
  validateTagCreation(
    tag: Partial<DomainTag>,
    context?: { existingTags?: DomainTag[]; operation?: 'create' | 'update' }
  ): Promise<
    ServiceResult<{
      canCreate: boolean;
      blockers: string[];
      requirements: string[];
      recommendations: string[];
    }>
  >;
  validateTagContent(content: {
    name: string;
    slug?: string;
    description?: string;
  }): Promise<
    ServiceResult<{
      isValid: boolean;
      violations: string[];
      warnings: string[];
    }>
  >;
  generateTagSlug(title: string): Promise<ServiceResult<string>>;
  createTag(tagData: Partial<DomainTag>): Promise<ServiceResult<DomainTag>>;
  updateTag(tagId: string, tagData: Partial<DomainTag>): Promise<ServiceResult<DomainTag>>;
  deleteTag(tagId: string): Promise<ServiceResult<void>>;
  getAllTags(): Promise<ServiceResult<DomainTag[]>>;
  findTagsByTitle(title: string): Promise<ServiceResult<DomainTag[]>>;
  getTagStatistics(): Promise<
    ServiceResult<{
      totalTags: number;
      tagsWithDescription: number;
      averageTitleLength: number;
      mostCommonTitleLength: number;
    }>
  >;
}
