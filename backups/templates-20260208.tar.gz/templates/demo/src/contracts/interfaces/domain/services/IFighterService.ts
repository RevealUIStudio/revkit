export interface IFighterService {
  listFighters(): Promise<unknown[]>;
}
