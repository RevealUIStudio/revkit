export interface IAuthService {
  validateSession(): Promise<boolean>;
}
