import type { DomainUser, ServiceResult } from '@/contracts';

export type UserStatistics = {
  total: number;
  active: number;
  inactive: number;
  admins: number;
  editors: number;
  users: number;
};

export type UserActivitySummary = {
  loginCount: number;
  lastLogin: Date | null;
  totalSessions: number;
  averageSessionDuration: number;
};

export interface IUserDomainService {
  activateUser(userId: string, adminId: string): Promise<ServiceResult<DomainUser>>;
  deactivateUser(userId: string, adminId: string): Promise<ServiceResult<DomainUser>>;
  promoteToAdmin(userId: string, adminId: string): Promise<ServiceResult<DomainUser>>;
  demoteFromAdmin(userId: string, adminId: string): Promise<ServiceResult<DomainUser>>;
  updateLoginActivity(userId: string): Promise<ServiceResult<DomainUser>>;
  getUsersByCriteria(criteria: {
    role?: DomainUser['role'];
    status?: DomainUser['status'];
    searchTerm?: string;
    limit?: number;
  }): Promise<ServiceResult<DomainUser[]>>;
  getUserStatistics(): Promise<ServiceResult<UserStatistics>>;
  validateUserPermissions(
    userId: string,
    requiredPermissions: string[]
  ): Promise<ServiceResult<boolean>>;
  getUserActivitySummary(userId: string): Promise<ServiceResult<UserActivitySummary>>;
}
