export interface IOrderService {
  listOrders(): Promise<unknown[]>;
}
