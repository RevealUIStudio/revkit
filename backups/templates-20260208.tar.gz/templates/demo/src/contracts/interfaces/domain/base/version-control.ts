export interface VersionControlMetadata {
  version?: string;
  updatedAt?: string;
}
