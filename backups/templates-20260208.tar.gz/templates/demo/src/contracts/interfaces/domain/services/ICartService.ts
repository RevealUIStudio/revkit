export interface ICartService {
  addItem(): Promise<void>;
}
