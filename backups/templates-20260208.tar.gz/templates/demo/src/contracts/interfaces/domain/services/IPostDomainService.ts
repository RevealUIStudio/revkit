import type { DomainPost, ServiceResult } from '@/contracts';

export type PostData = Partial<DomainPost> & {
  id?: string;
  slug?: string;
  status?: 'draft' | 'published' | 'archived';
  featured?: boolean;
  authors?: unknown[];
  categories?: unknown[];
  publishedDate?: string | Date;
};

export type PostPublicationContext = {
  userId?: number;
  userRole?: string;
  existingFeaturedCount?: number;
  operation?: 'create' | 'update';
};

export type PostPublicationAnalysis = {
  canPublish: boolean;
  blockers: string[];
  requirements: string[];
  recommendations: string[];
};

export type PostContentValidation = {
  isValid: boolean;
  violations: string[];
  warnings: string[];
};

export type PostSlugValidation = {
  isValid: boolean;
  violations: string[];
  suggestedSlug?: string;
};

export type PostMetricsSummary = {
  readingTimeMinutes: number;
  wordCount: number;
  characterCount: number;
  hasImages: boolean;
  hasCode: boolean;
};

export type PostSchedulingValidation = {
  isValid: boolean;
  violations: string[];
  warnings: string[];
  scheduledFor?: Date;
};

export interface IPostDomainService {
  validatePublicationWorkflow(
    post: PostData,
    context?: PostPublicationContext
  ): Promise<ServiceResult<PostPublicationAnalysis>>;
  validatePostContent(content: {
    title: string;
    content?: unknown;
    excerpt?: string;
  }): Promise<ServiceResult<PostContentValidation>>;
  validatePostSlug(
    slug: string,
    context?: {
      existingSlugs?: string[];
      operation?: 'create' | 'update';
    }
  ): Promise<ServiceResult<PostSlugValidation>>;
  calculatePostMetrics(
    post: Pick<PostData, 'content' | 'title'>
  ): Promise<ServiceResult<PostMetricsSummary>>;
  validatePostScheduling(
    publishedDate: string | Date | undefined,
    context?: { currentTime?: Date }
  ): Promise<ServiceResult<PostSchedulingValidation>>;
  publishPost(id: string, publisherId: string): Promise<ServiceResult<DomainPost>>;
  archivePost(id: string): Promise<ServiceResult<DomainPost>>;
  getPostsByCriteria(): Promise<ServiceResult<DomainPost[]>>;
  findRelatedPosts(postId: string, limit?: number): Promise<ServiceResult<DomainPost[]>>;
}
