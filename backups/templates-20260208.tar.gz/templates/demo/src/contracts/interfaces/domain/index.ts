// ====================================================================
// DOMAIN INTERFACES INDEX
// ====================================================================
// Domain layer interfaces: business logic contracts, models, and base interfaces

// ====================================================================
// DOMAIN SERVICES
// ====================================================================
export * from './services/IAuthService';
export * from './services/ICartService';
export * from './services/ICategoryDomainService';
export * from './services/IFighterService';
export * from './services/IFightService';
export * from './services/IMediaDomainService';
export * from './services/IOrderService';
export * from './services/IPostDomainService';
export * from './services/IProductService';
export * from './services/IUserDomainService';

// ====================================================================
// DOMAIN MODELS
// ====================================================================
export * from './models/fight';
export * from './models/industry-template';
export * from './models/paywall';

// ====================================================================
// DOMAIN BASE
// ====================================================================
export * from './base/domain-config';
export * from './base/IBaseService';
export * from './base/validation';
export * from './base/version-control';
