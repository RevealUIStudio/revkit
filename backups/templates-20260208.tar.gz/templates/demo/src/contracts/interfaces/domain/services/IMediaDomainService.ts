import type { DomainMedia } from '@/contracts';

export interface IMediaDomainService {
  activateMedia(mediaId: string, userId: string): Promise<DomainMedia>;
  deactivateMedia(mediaId: string, userId: string): Promise<DomainMedia>;
  getMedia(mediaId: string, userId?: string): Promise<DomainMedia>;
  findMedia(
    searchTerm?: string,
    mimeType?: string,
    limit?: number,
    page?: number
  ): Promise<DomainMedia[]>;
  findMediaByPrefix(prefixId: string): Promise<DomainMedia[]>;
  findMediaByMimeType(mimeType: string): Promise<DomainMedia[]>;
  findUnusedMedia(): Promise<DomainMedia[]>;
  cleanupUnusedMedia(): Promise<number>;
  getLargeMediaFiles(sizeThresholdMB: number): Promise<DomainMedia[]>;
  getMediaByParent(parentType: string, parentId: string): Promise<DomainMedia[]>;
}
