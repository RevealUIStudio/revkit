// ====================================================================
// DOMAIN CONFIGURATION INTERFACE
// ====================================================================
// Configuration interface for domain layer

/**
 * Domain configuration interface
 */
export interface IDomainConfiguration {
  getServerUrl(): string;
  getClientUrl(): string;
  isDevelopment(): boolean;
  isProduction(): boolean;
  isTest(): boolean;
  getEnvironment(): 'development' | 'staging' | 'production' | 'test';
}
