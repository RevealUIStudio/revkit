// =======
// PRODUCT DOMAIN SERVICE INTERFACE
// =======
// Domain service interface for product-related business logic

import type { DomainProduct, PaginatedResult, ServiceResult } from '@/contracts';

export type ProductFilters = {
  status?: string;
  categoryId?: string;
  featured?: boolean;
  searchTerm?: string;
  page?: number;
  limit?: number;
};

export interface IProductService {
  listProducts(filters?: ProductFilters): Promise<ServiceResult<PaginatedResult<DomainProduct>>>;
  toggleFeatured(id: string): Promise<ServiceResult<DomainProduct>>;
  createProduct(data: Partial<DomainProduct>): Promise<ServiceResult<DomainProduct>>;
  updateProduct(id: string, data: Partial<DomainProduct>): Promise<ServiceResult<DomainProduct>>;
  deleteProduct(id: string): Promise<ServiceResult<boolean>>;
}
