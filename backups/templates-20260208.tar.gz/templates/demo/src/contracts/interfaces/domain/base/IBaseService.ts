// ========
// BASE SERVICE INTERFACE
// ========

import type { ServiceResult } from '../../../types/domain/service-results';

/**
 * Base service interface for all domain services
 */
export interface IBaseService {
  readonly serviceName: string;
  readonly serviceType: 'application' | 'domain' | 'infrastructure';

  // Lifecycle methods
  initialize(): Promise<ServiceResult<void>>;
  cleanup(): Promise<ServiceResult<void>>;
  healthCheck(): Promise<ServiceResult<boolean>>;

  // Metadata
  getMetadata(): ServiceResult<{
    name: string;
    type: string;
    startTime: Date;
    version?: string;
  }>;
}

/**
 * Service metadata for discovery and monitoring
 */
export interface ServiceMetadata {
  name: string;
  version: string;
  description?: string;
  capabilities: string[];
  dependencies: string[];
  configuration: Record<string, unknown>;
  status: 'initializing' | 'ready' | 'degraded' | 'unhealthy';
  uptime: number;
  lastHealthCheck: string;
}
