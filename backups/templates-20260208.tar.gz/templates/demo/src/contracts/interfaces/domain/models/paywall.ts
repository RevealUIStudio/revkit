export interface PaywallAccess {
  hasAccess: boolean;
  reason: string;
  redirectTo: string | null;
}

export interface UsePaywallOptions {
  contentType: string;
  config?: Record<string, unknown>;
  autoRedirect?: boolean;
}

export interface UsePaywallReturn {
  hasAccess: boolean;
  loading: boolean;
  error: string | null;
  access: PaywallAccess | null;
  checkAccess: () => Promise<void>;
}

// Paywall Collection Interfaces
export interface PaywallData {
  price?: number;
  [key: string]: unknown;
}
