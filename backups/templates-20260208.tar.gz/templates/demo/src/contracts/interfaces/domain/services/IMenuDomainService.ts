// ====================================================================
// MENU DOMAIN SERVICE INTERFACE
// ====================================================================
// Domain service interface for Menu operations

import type { DomainMenu, ServiceResult } from '@/contracts';

export interface IMenuDomainService {
  getMenuByLocation(location: string): Promise<ServiceResult<DomainMenu>>;
  getActiveMenusByLocation(location: string): Promise<ServiceResult<DomainMenu[]>>;
  getMenuStatistics(): Promise<
    ServiceResult<{
      total: number;
      active: number;
      inactive: number;
      draft: number;
      byLocation: Record<string, number>;
    }>
  >;
  validateMenuStructure(
    menuId: string
  ): Promise<ServiceResult<{ isValid: boolean; issues: string[] }>>;
}
