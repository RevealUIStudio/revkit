/**
 * Validation-related interfaces for structure reference validation
 */

/**
 * Base filter interface for search and filtering operations
 */
export interface BaseFilter {
  search?: string;
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface ReferenceFix {
  file: string;
  oldReference: string;
  newReference: string;
  line: number;
}

export interface ValidationResult {
  success: boolean;
  errors: string[];
  warnings: string[];
  summary: {
    totalFiles: number;
    totalErrors: number;
    totalWarnings: number;
  };
}

export interface TypeDefinition {
  name: string;
  file: string;
  line: number;
  type: 'interface' | 'type';
}
