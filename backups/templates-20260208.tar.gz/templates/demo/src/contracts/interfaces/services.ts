// ====================================================================
// SERVICE INTERFACES
// ====================================================================
// Common service interfaces used across the application

/**
 * Slug validation data result
 */
export interface SlugValidationData {
  isValid: boolean;
  violations: string[];
  suggestions?: string[];
}

/**
 * Slug validation options
 */
export interface SlugValidationOptions {
  operation?: 'create' | 'update';
  excludeId?: string;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
}
