// ====================================================================
// CONTRACT UTILITIES
// ====================================================================
// Utilities library for versioning, comparison, and dependency analysis

import type { ContractSnapshot } from '../core/types';
import { ContractUtils, Contracts } from '../registry';
import type { ContractName } from '../registry';

/**
 * Contract version comparison
 */
export function compareContractVersions(
  contractName: ContractName,
  version1: string,
  version2: string
): number {
  const v1Parts = version1.split('.').map(Number);
  const v2Parts = version2.split('.').map(Number);

  for (let i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
    const v1Part = v1Parts[i] || 0;
    const v2Part = v2Parts[i] || 0;

    if (v1Part < v2Part) return -1;
    if (v1Part > v2Part) return 1;
  }

  return 0;
}

/**
 * Check if contract version is newer
 */
export function isNewerVersion(
  contractName: ContractName,
  version1: string,
  version2: string
): boolean {
  return compareContractVersions(contractName, version1, version2) > 0;
}

/**
 * Contract comparison result
 */
export interface ContractComparisonResult {
  identical: boolean;
  differences: string[];
  breakingChanges: string[];
}

/**
 * Compare two contracts
 */
export function compareContracts(
  contract1: ContractSnapshot,
  contract2: ContractSnapshot
): ContractComparisonResult {
  const differences: string[] = [];
  const breakingChanges: string[] = [];

  // Compare domain
  if (contract1.domain !== contract2.domain) {
    differences.push(`Domain changed: ${contract1.domain} -> ${contract2.domain}`);
  }

  // Compare version
  if (contract1.version !== contract2.version) {
    const versionDiff = compareContractVersions(
      contract1.domain as ContractName,
      contract1.version,
      contract2.version
    );
    if (versionDiff < 0) {
      differences.push(`Version updated: ${contract1.version} -> ${contract2.version}`);
    }
  }

  // Compare shape (simplified - would need deep comparison in practice)
  if (JSON.stringify(contract1.shape) !== JSON.stringify(contract2.shape)) {
    differences.push('Shape changed');
    breakingChanges.push('Shape changes may break existing code');
  }

  // Compare behavior
  if (JSON.stringify(contract1.behavior) !== JSON.stringify(contract2.behavior)) {
    differences.push('Behavior changed');
    breakingChanges.push('Behavior changes may break implementations');
  }

  // Compare validation schemas
  const validation1Keys = Object.keys(contract1.validation);
  const validation2Keys = Object.keys(contract2.validation);

  const removedSchemas = validation1Keys.filter(k => !validation2Keys.includes(k));
  const addedSchemas = validation2Keys.filter(k => !validation1Keys.includes(k));

  if (removedSchemas.length > 0) {
    differences.push(`Removed validation schemas: ${removedSchemas.join(', ')}`);
    breakingChanges.push(`Removed schemas: ${removedSchemas.join(', ')}`);
  }

  if (addedSchemas.length > 0) {
    differences.push(`Added validation schemas: ${addedSchemas.join(', ')}`);
  }

  return {
    identical: differences.length === 0,
    differences,
    breakingChanges,
  };
}

/**
 * Get contract dependency tree
 */
export function getContractDependencyTree(contractName: ContractName): {
  contract: ContractName;
  dependencies: ContractName[];
  dependents: ContractName[];
  depth: number;
} {
  const contract = ContractUtils.get(contractName);
  const dependencies = (contract.metadata?.dependsOn ?? []) as ContractName[];
  const dependents = ContractUtils.getDependents(contractName);

  // Calculate depth (simplified - would need recursive calculation)
  const depth = dependencies.length;

  return {
    contract: contractName,
    dependencies,
    dependents,
    depth,
  };
}

/**
 * Get all contract dependencies (recursive)
 */
export function getAllContractDependencies(
  contractName: ContractName,
  visited: Set<ContractName> = new Set()
): ContractName[] {
  if (visited.has(contractName)) {
    return [];
  }

  visited.add(contractName);
  const contract = ContractUtils.get(contractName);
  const directDeps = (contract.metadata?.dependsOn ?? []) as ContractName[];
  const allDeps: ContractName[] = [...directDeps];

  for (const dep of directDeps) {
    if (ContractUtils.has(dep)) {
      allDeps.push(...getAllContractDependencies(dep, visited));
    }
  }

  return Array.from(new Set(allDeps));
}

/**
 * Contract usage tracking
 */
export class ContractUsageTracker {
  private usageCounts = new Map<ContractName, number>();
  private lastAccess = new Map<ContractName, number>();

  /**
   * Track contract access
   */
  trackAccess(contractName: ContractName): void {
    const current = this.usageCounts.get(contractName) || 0;
    this.usageCounts.set(contractName, current + 1);
    this.lastAccess.set(contractName, Date.now());
  }

  /**
   * Get usage statistics
   */
  getUsageStats(): Array<{ contract: ContractName; count: number; lastAccess: number }> {
    return Array.from(this.usageCounts.entries()).map(([contract, count]) => ({
      contract,
      count,
      lastAccess: this.lastAccess.get(contract) || 0,
    }));
  }

  /**
   * Get most used contracts
   */
  getMostUsedContracts(limit: number = 10): ContractName[] {
    return Array.from(this.usageCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([contract]) => contract);
  }

  /**
   * Clear usage statistics
   */
  clear(): void {
    this.usageCounts.clear();
    this.lastAccess.clear();
  }
}

/**
 * Global usage tracker instance
 */
export const contractUsageTracker = new ContractUsageTracker();
