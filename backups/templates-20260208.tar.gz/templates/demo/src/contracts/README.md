# Contracts System

The **Contracts System** is a unified architecture that captures three
dimensions of every domain concept into a single **Contract Snapshot**:

- **Shape** (Static Types) - What the data looks like
- **Behavior** (Interfaces) - What operations are possible
- **Quality** (Validation) - What makes data valid

## Architecture Overview

```
contracts/
├── core/                    # Contract infrastructure
│   ├── types.ts            # Core contract types
│   ├── contract.ts         # Contract builder utilities
│   ├── registry.ts         # Registry implementation
│   └── index.ts            # Core exports
├── domains/                # Unified domain contracts
│   ├── user.contract.ts    # User domain snapshot
│   ├── product.contract.ts # Product domain snapshot
│   ├── fight.contract.ts   # Fight domain snapshot
│   ├── cart.contract.ts    # Cart domain snapshot
│   ├── order.contract.ts   # Order domain snapshot
│   ├── category.contract.ts # Category domain snapshot
│   ├── post.contract.ts    # Post domain snapshot
│   ├── media.contract.ts   # Media domain snapshot
│   ├── menu.contract.ts    # Menu domain snapshot
│   ├── tag.contract.ts     # Tag domain snapshot
│   └── index.ts            # Domain exports
├── registry.ts             # Contract registry
├── types/                  # Static type definitions (legacy)
├── interfaces/             # Service interfaces (legacy)
├── validation/             # Runtime validation (legacy)
├── index.ts                # Unified entry point
└── README.md               # This file
```

## Contract Snapshot Concept

Each domain has a **Contract Snapshot** that bundles together all related
contracts:

```typescript
export const UserContract = {
  domain: 'user',
  version: '1.0.0',

  // SHAPE - What the data looks like (static types)
  shape: {
    entity: DomainUser, // Domain entity
    dto: {
      create: CreateUserDTO, // Create DTO
      update: UpdateUserDTO, // Update DTO
    },
  },

  // BEHAVIOR - What operations are possible (interfaces)
  behavior: {
    service: IUserDomainService, // Service interface
  },

  // QUALITY - What makes data valid (validation schemas)
  validation: {
    create: createUserSchema, // Zod schema
    update: updateUserSchema, // Zod schema
  },

  // METADATA - Lineage, dependencies, usage
  metadata: {
    layer: 'domain',
    dependsOn: ['auth', 'role'],
    description: '...',
  },
};
```

## Usage Guide

### Basic Usage

#### Import a Domain Contract

```typescript
import { UserContract } from '@/contracts';

// Access the contract snapshot
console.log(UserContract.domain); // 'user'
console.log(UserContract.version); // '1.0.0'

// Access types
type User = typeof UserContract.shape.entity;
type CreateUser = typeof UserContract.shape.dto.create;
type UserService = typeof UserContract.behavior.service;

// Access validation schemas
const createSchema = UserContract.validation.create;
const updateSchema = UserContract.validation.update;

// Use in validation
const result = createSchema.safeParse(userData);
```

#### Convenience Exports

```typescript
// Instead of reaching into the contract snapshot
import {
  UserContract,
  type User,
  type CreateUser,
  type UpdateUser,
  type UserService,
  UserValidation,
} from '@/contracts';

// Now you have direct access
const schema = UserValidation.create;
type NewUser = CreateUser;
```

#### Registry Access

```typescript
import { Contracts, ContractUtils } from '@/contracts';

// Get contract by name
const userContract = Contracts.user;
const productContract = Contracts.product;

// Or use utility methods
const names = ContractUtils.getNames(); // ['user', 'product', ...]
const count = ContractUtils.count(); // 8
const hasUser = ContractUtils.has('user'); // true

// Type-safe access
type AvailableContracts = ContractName; // 'user' | 'product' | ...
type GetUserContract = GetContract<'user'>; // UserContract type
```

## Domain Contracts

### User Contract

```typescript
import {
  UserContract,
  UserValidation,
  type User,
  type CreateUser,
} from '@/contracts';

// Shape
type User = typeof UserContract.shape.entity;
type CreateUser = typeof UserContract.shape.dto.create;

// Behavior
type UserService = typeof UserContract.behavior.service;

// Quality
const schema = UserValidation.create;
```

**Components:**

- Entity: `DomainUser`
- DTOs: `CreateUserDTO`, `UpdateUserDTO`
- Service: `IUserDomainService`
- Validation: `createUserSchema`, `updateUserSchema`, `userFiltersSchema`,
`userProfileSchema`
- Depends on: `auth`, `role`

### Product Contract

```typescript
import { ProductContract, ProductValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainProduct`
- DTOs: `CreateProductDTO`, `UpdateProductDTO`
- Service: `IProductService`
- Validation: `createProductSchema`, `updateProductSchema`,
`productFiltersSchema`, `productVariantSchema`
- Depends on: `category`, `media`

### Fight Contract

```typescript
import { FightContract, FightValidation } from '@/contracts';
```

**Components:**

- Entity: `Fight`
- DTOs: `CreateFightInput`, `UpdateFightInput`
- Service: `IFightService`
- Validation: `createFightSchema`, `updateFightSchema`, `fightFiltersSchema`,
`fightResultSchema`
- Depends on: `user`, `media`, `category`

### Cart Contract

```typescript
import { CartContract, CartValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainCart`
- DTOs: `CreateCartItemDTO`, `UpdateCartItemDTO`
- Service: `ICartService`
- Validation: `createCartItemSchema`, `updateCartItemSchema`,
`cartFiltersSchema`, `cartCheckoutSchema`
- Depends on: `product`

### Order Contract

```typescript
import { OrderContract, OrderValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainOrder`
- DTOs: `CreateOrderDTO`, `UpdateOrderDTO`
- Service: `IOrderService`
- Validation: `createOrderSchema`, `updateOrderSchema`, `orderFiltersSchema`
- Depends on: `cart`, `product`

### Category Contract

```typescript
import { CategoryContract, CategoryValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainCategory`
- DTOs: `CreateCategoryDTO`, `UpdateCategoryDTO`
- Service: `ICategoryService`
- Validation: `createCategorySchema`, `updateCategorySchema`,
`categoryFiltersSchema`, `categoryReorderSchema`
- Depends on: None

### Post Contract

```typescript
import { PostContract, PostValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainPost`
- DTOs: `CreatePostDTO`, `UpdatePostDTO`
- Service: `IPostDomainService`
- Validation: `createPostSchema`, `updatePostSchema`, `postFiltersSchema`
- Depends on: `user`, `category`, `media`

### Media Contract

```typescript
import { MediaContract, MediaValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainMedia`
- DTOs: `UploadMediaDTO`, `UpdateMediaDTO`
- Service: `IMediaDomainService`
- Validation: `uploadMediaSchema`, `updateMediaSchema`, `mediaFiltersSchema`, `mediaResizeSchema`, `mediaCropSchema`
- Depends on: None

### Menu Contract

```typescript
import { MenuContract, MenuValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainMenu`
- DTOs: `CreateMenuDTO`, `UpdateMenuDTO`
- Service: `IMenuDomainService`
- Validation: `createMenuSchema`, `updateMenuSchema`, `menuFiltersSchema`
- Depends on: None

### Tag Contract

```typescript
import { TagContract, TagValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainTag`
- DTOs: `CreateTagDTO`, `UpdateTagDTO`
- Service: `ITagDomainService`
- Validation: `createTagSchema`, `updateTagSchema`, `tagFiltersSchema`
- Depends on: None

**Components:**

- Entity: `DomainPost`
- DTOs: `CreatePostDTO`, `UpdatePostDTO`
- Service: `IPostDomainService`
- Validation: `createPostSchema`, `updatePostSchema`, `postFiltersSchema`
- Depends on: `user`, `category`, `media`

### Media Contract

```typescript
import { MediaContract, MediaValidation } from '@/contracts';
```

**Components:**

- Entity: `DomainMedia`
- DTOs: Upload and update types
- Service: `IMediaDomainService`
- Validation: `uploadMediaSchema`, `updateMediaSchema`, `mediaFiltersSchema`,
`mediaResizeSchema`, `mediaCropSchema`
- Depends on: None

## Real-World Examples

### Example 1: API Route with Unified Contract

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { UserContract, UserValidationMiddleware } from '@/contracts';
import { createAuthenticatedAPIRoute } from '@revealui/infrastructure/middleware/api/createAPIRoute';

export const POST = createAuthenticatedAPIRoute(
  [UserValidationMiddleware.create],
  async (req, ctx) => {
    // req.body is validated and typed as CreateUser
    const data = await req.json(); // Type: CreateUser

    // Your service implementation
    const result = await userService.createUser(data);

    return NextResponse.json(result);
  }
);
```

### Example 2: Server Action with Contract

```typescript
import { createAuthenticatedServerAction } from '@revealui/infrastructure/middleware/serverActions/createServerAction';
import { ProductContract } from '@/contracts';

export const createProduct = createAuthenticatedServerAction(
  [validateInput(ProductContract.validation.create)],
  async (input, ctx) => {
    // input is validated and typed as CreateProduct
    return await productService.create(input);
  }
);
```

### Example 3: Domain Service Implementation

```typescript
import { UserContract } from '@/contracts';

export class UserDomainService implements UserContract.behavior.service {
  async createUser(data: UserContract.shape.dto.create) {
    // Data is strongly typed as CreateUserDTO
    const validated = UserContract.validation.create.parse(data);

    // Business logic here
    return await this.repository.create(validated);
  }
}
```

### Example 4: Form Validation with React Hook Form

```typescript
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { UserContract, type CreateUser } from '@/contracts';

function UserForm() {
  const form = useForm<CreateUser>({
    resolver: zodResolver(UserContract.validation.create),
  });

  return (
    <form onSubmit={form.handleSubmit(onSubmit)}>
      {/* Form fields */}
    </form>
  );
}
```

### Example 5: Type-Safe Service with Contract

```typescript
import { Contracts, type ContractName, type GetContract } from '@/contracts';

// Generic service that works with any contract
function createDomainService<T extends ContractName>(contractName: T) {
  const contract = Contracts[contractName];

  return {
    create: async (data: GetContract<T>['shape']['dto']['create']) => {
      // Validate using contract schema
      const validated = contract.validation.create.parse(data);
      // Business logic...
      return validated;
    },
  };
}

// Type-safe usage
const userService = createDomainService('user');
const productService = createDomainService('product');
```

## Migration from Legacy Imports

### Before (Legacy - Still Works)

```typescript
import { type User, type CreateUser, type UserService, UserValidation } from '@/contracts';
```

### After (Unified - Recommended)

```typescript
import {
  UserContract,
  type User,
  type CreateUser,
  UserValidation,
} from '@/contracts';

// Everything you need in one import
type User = typeof UserContract.shape.entity;
const schema = UserValidation.create;
```

## Benefits

### 1. **Single Source of Truth**

One contract per domain instead of scattered across three directories:

- ❌ Before: 3 files per domain (types, interface, validation)
- ✅ After: 1 unified contract snapshot

### 2. **Strong Cohesion**

Shape, behavior, and quality are always in sync:

```typescript
// Can't create a mismatch - they're defined together
const UserContract = createContractSnapshot({
  shape: { entity: DomainUser },
  behavior: { service: IUserDomainService },
  validation: { create: createUserSchema },
});
```

### 3. **Better Developer Experience**

```typescript
// Before: Multiple imports, unclear relationships
import { DomainUser } from '@/contracts/types/...';
import { IUserDomainService } from '@/contracts/interfaces/...';
import { createUserSchema } from '@/contracts/validation/...';

// After: Single import, clear relationships
import { UserContract } from '@/contracts';
```

### 4. **Traceability**

Each contract knows:

- What it depends on
- What layer it belongs to
- When it was last modified
- Who uses it

### 5. **Type Safety**

Full TypeScript integration with inference:

```typescript
type User = ExtractEntity<typeof UserContract>; // DomainUser
type CreateUser = ExtractCreateDTO<typeof UserContract>; // CreateUserDTO
type UserService = ExtractService<typeof UserContract>; // IUserDomainService
```

### 6. **Backward Compatible**

Legacy imports continue to work:

```typescript
// Old way still works
import { DomainUser } from '@/contracts/types';

// New way available
import { UserContract } from '@/contracts';
```

## Adding New Domain Contracts

### Step 1: Create Domain Files

Ensure you have:

- Entity type in `types/domain/entities/`
- DTOs in `types/domain/dto/`
- Service interface in `interfaces/domain/services/`
- Validation schemas in `validation/schemas/`

### Step 2: Create Contract File

```typescript
// contracts/domains/myNewDomain.contract.ts
import { createContractSnapshot } from '../core';
import type { MyEntity } from '../types/domain/entities/my';
import type { CreateMyDTO } from '../types/domain/dto/my';
import type { IMyService } from '../interfaces/domain/services/IMyService';
import { createMySchema, updateMySchema } from '../validation/schemas/my';

export const MyDomainContract = createContractSnapshot({
  domain: 'myDomain',
  version: '1.0.0',
  shape: {
    entity: {} as MyEntity,
    dto: { create: {} as CreateMyDTO },
  },
  behavior: {
    service: {} as IMyService,
  },
  validation: {
    create: createMySchema,
    update: updateMySchema,
  },
  metadata: {
    layer: 'domain',
    dependsOn: [],
  },
});

export type MyDomain = typeof MyDomainContract.shape.entity;
export const { validation: MyValidation } = MyDomainContract;
```

### Step 3: Register in Registry

```typescript
// contracts/registry.ts
import { MyDomainContract } from './domains/myDomain.contract';

export const Contracts = ContractRegistry.create({
  user: UserContract,
  product: ProductContract,
  // ... existing contracts
  myDomain: MyDomainContract, // Add here
});
```

### Step 4: Export in Main Index

```typescript
// contracts/index.ts
export {
  MyDomainContract,
  type MyDomain,
  MyValidation,
} from './domains/myDomain.contract';
```

Done! Your new domain contract is now available via `@/contracts`.

## Best Practices

### 1. Always Use Unified Contracts for New Code

```typescript
// ✅ Good
import { UserContract } from '@/contracts';

// ❌ Avoid in new code
import { DomainUser } from '@/contracts/types/domain/entities/user';
```

### 2. Prefer Contract Access Over Direct Imports

```typescript
// ✅ Good - maintains cohesion
const schema = UserContract.validation.create;
const Service = UserContract.behavior.service;

// ❌ Avoid - breaks cohesion
import { createUserSchema } from '@/contracts/validation';
import { IUserDomainService } from '@/contracts/interfaces';
```

### 3. Use Registry for Type-Safe Operations

```typescript
// ✅ Good - type-safe iteration
Object.values(Contracts).forEach(contract => {
  console.log(contract.domain);
});

// ❌ Avoid - no type safety
const contracts = [UserContract, ProductContract]; // No type safety
```

### 4. Leverage Metadata for Documentation

```typescript
// Each contract knows its lineage
console.log(UserContract.metadata.dependsOn); // ['auth', 'role']
console.log(UserContract.metadata.description); // 'User management...'
console.log(UserContract.metadata.lastModified); // ISO timestamp
```

## Contract Registry API

### Getting Contracts

```typescript
import { Contracts, ContractUtils } from '@/contracts';

// Direct access
const userContract = Contracts.user;

// Utility methods
const names = ContractUtils.getNames(); // Get all names
const contract = ContractUtils.get('user'); // Get by name
const exists = ContractUtils.has('user'); // Check existence
const count = ContractUtils.count(); // Get count
```

### Type-Safe Iteration

```typescript
import { Contracts, type ContractName } from '@/contracts';

// Type-safe iteration
(Object.keys(Contracts) as ContractName[]).forEach(name => {
  const contract = Contracts[name];
  console.log(`${name}: ${contract.version}`);
});
```

## Validation Integration

Contracts integrate seamlessly with validation middleware:

```typescript
import { UserContract } from '@/contracts';
import { validateInput } from '@revealui/infrastructure/middleware/EnhancedValidationMiddleware';

// Middleware automatically gets typed schema
export const POST = createAuthenticatedAPIRoute(
  [validateInput(UserContract.validation.create)],
  async (req, ctx) => {
    // req.body is typed as CreateUser
    const data = await req.json();
    // ...
  }
);
```

## Error Handling

Contracts provide consistent error structures:

```typescript
import { UserContract } from '@/contracts';
import { validateDTO } from '@/contracts/validation';

const result = validateDTO(UserContract.validation.create, userData);

if (!result.success) {
  // Handle validation errors
  result.errors?.forEach(error => {
    console.log(`${error.field}: ${error.message}`);
  });
}
```

## Advanced Patterns

### Composing Contracts

```typescript
// Contracts can share base components
import { UserContract, ProductContract } from '@/contracts';

// Both contracts depend on common types
const commonServices = {
  user: UserContract.behavior.service,
  product: ProductContract.behavior.service,
};
```

### Contract Versioning

```typescript
// Future: Track contract versions
const UserContractV1 = createContractSnapshot({
  domain: 'user',
  version: '1.0.0',
  // ...
});

const UserContractV2 = createContractSnapshot({
  domain: 'user',
  version: '2.0.0',
  // ... breaking changes
});
```

### Contract Metadata Enrichment

```typescript
// Contracts can track usage
UserContract.metadata.usedBy.push('presentation/services/UserService');
UserContract.metadata.lastModified = new Date().toISOString();
```

## Troubleshooting

### Issue: "Cannot find module '@/contracts'"

**Solution**: Ensure `tsconfig.json` has path alias configured:

```json
{
  "compilerOptions": {
    "paths": {
      "@/contracts/*": ["./src/contracts/*"]
    }
  }
}
```

### Issue: "Type not assignable to contract shape"

**Solution**: Ensure types align. Check entity DTO definitions match validation
schemas.

### Issue: "Contract metadata not updating"

**Solution**: Metadata is set at creation time. Recreate contract to update
metadata.

## Further Reading

- [Contract Guidelines](./CONTRACT_GUIDELINES.md) - What goes in contracts vs
implementation
- [Validation README](./validation/README.md) - Detailed validation patterns
- [Types README](./types/README.md) - Type system architecture
- [Interfaces Organization](./interfaces/MIGRATION_GUIDE.md) - Interface
patterns

## Summary

The **Unified Contract Snapshots** system transforms your codebase from:

- **Before**: Three separate definitions per domain, scattered imports, unclear
relationships
- **After**: One cohesive contract per domain, single import point, explicit
relationships

**Result**: Better cohesion, stronger types, clearer intent, easier maintenance.



































































