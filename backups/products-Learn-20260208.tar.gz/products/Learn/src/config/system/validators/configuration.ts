import type {
  ValidationError,
  ValidationResult as SharedValidationResult,
  ValidationRule,
} from '@revealui/core/shared-types/validation';

type RuleIssue = ValidationError & { severity: 'error' | 'warning' };
export type ConfigurationValidationResult = SharedValidationResult & {
  errors: RuleIssue[];
  warnings: RuleIssue[];
};

export class ConfigurationValidator {
  // Using Record<string, unknown> because configuration structure varies by configuration type and cannot be strictly typed
  validate<T extends Record<string, unknown>>(
    config: T,
    rules: ValidationRule<T>[]
  ): ConfigurationValidationResult {
    const errors: ConfigurationValidationResult['errors'] = [];
    const warnings: ConfigurationValidationResult['warnings'] = [];

    for (const rule of rules) {
      const value = config[rule.field];
      if (!rule.validator(value)) {
        const issue = {
          field: String(rule.field),
          message: rule.message,
          severity: rule.severity,
        };
        if (rule.severity === 'error') {
          errors.push(issue);
        } else {
          warnings.push(issue);
        }
      }
    }

    const success = errors.length === 0;
    return { success, isValid: success, errors, warnings };
  }
}

export const configurationValidator = new ConfigurationValidator();

export function requiredRule<T>(field: keyof T, message?: string): ValidationRule<T> {
  return {
    field,
    validator: value => value !== null && value !== undefined && value !== '',
    message: message ?? `Field '${String(field)}' is required`,
    severity: 'error',
  };
}

export const ValidationRules = {
  required: requiredRule,
} as const;

// Using Record<string, unknown> because configuration structure varies by configuration type and cannot be strictly typed
export function validateConfigWithRules<T extends Record<string, unknown>>(
  config: T,
  rules: ValidationRule<T>[]
): ConfigurationValidationResult {
  return configurationValidator.validate(config, rules);
}
