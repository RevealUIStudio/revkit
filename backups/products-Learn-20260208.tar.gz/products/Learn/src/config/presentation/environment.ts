/**
 * Presentation Layer Environment Configuration
 *
 * Presentation-specific environment variable exports and configuration.
 * For environment variable access utilities, see @/config/system/environment
 *
 * This module re-exports system environment utilities for backward compatibility
 * and provides presentation-layer-specific environment variable exports.
 *
 * @module config/presentation/environment
 */

// Re-export system environment utilities for backward compatibility
export {
  getEnvVar,
  getEnvVarWithFallback,
  getBooleanEnvVar,
  getNumericEnvVar,
  validateEnvironment,
  getCurrentEnvironment,
  validateRequiredEnvVarsAtBuildTime,
} from '@/config/system/environment';

import {
  type EnvironmentVariables,
  getCurrentEnvironment,
  getEnvVar,
} from '@/config/system/environment';

// Export default environment instance
export const env = getCurrentEnvironment();

// Export commonly used individual variables
export const APP_ENV = env.APP_ENV;
const NEXT_PUBLIC_SERVER_URL = getEnvVar('NEXT_PUBLIC_SERVER_URL');
export const REVEAL_PUBLIC_SERVER_URL =
  env.REVEAL_PUBLIC_SERVER_URL || env.REVEAL_PUBLIC_SERVER_URL || NEXT_PUBLIC_SERVER_URL || 'http://localhost:3000';
export const REVEAL_PUBLIC_SERVER_URL = REVEAL_PUBLIC_SERVER_URL; // Backward compatibility
export const REVEAL_PUBLIC_CLIENT_URL =
  env.REVEAL_PUBLIC_CLIENT_URL || env.NEXT_PUBLIC_SERVER_URL || NEXT_PUBLIC_SERVER_URL || 'http://localhost:3000';
export const REVEAL_PUBLIC_CLIENT_URL = REVEAL_PUBLIC_CLIENT_URL; // Backward compatibility
export const DATABASE_URL = env.DATABASE_URL;
export const REVEAL_SECRET = env.REVEAL_SECRET || env.REVEAL_SECRET;
export const REVEAL_SECRET = REVEAL_SECRET; // Backward compatibility
export const { BLOB_READ_WRITE_TOKEN } = env;
export const { LOG_LEVEL } = env;
