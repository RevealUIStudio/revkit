import type { StorageConfig } from '@revealui/core/shared-types';

/**
 * Default storage configuration
 * Currently uses local file system storage with hardcoded paths.
 * Future: Consider adding environment variable support for storage provider selection
 */
export const defaultStorageConfig: StorageConfig = {
  provider: 'local',
  directory: 'public/uploads',
  publicUrl: '/uploads',
};
