/**
 * Theme Configuration
 *
 * Centralized exports for theme and navigation configurations including:
 * - Admin theme (RevealUI Content Engine admin panel theming)
 * - Navigation configuration (menu items, redirects)
 *
 * @module config/presentation/theme
 * @example
 * ```typescript
 * // Get admin theme
 * import { adminThemeConfig } from '@/config/presentation/theme';
 *
 * // Get navigation config
 * import { navigationConfig } from '@/config/presentation/theme';
 * const mainMenu = navigationConfig.menu.main;
 * ```
 */

// Admin theme configuration
export * from './admin-theme.ts';

// Navigation configuration
export * from './navigation.ts';
