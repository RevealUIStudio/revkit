import type { ColorToken, DesignTokens } from '@revealui/core/shared-types';

type ColorStop = 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;

type ColorScale = Record<ColorStop, ColorToken>;

export const defaultDesignTokens: DesignTokens = {
  brand: {
    name: 'reveal UI',
    tagline: 'Where Beefs Get Settled',
  },
  colors: {
    primary: { hex: '#dc2626', oklch: '0.55 0.22 25', name: 'Combat Red' },
    secondary: { hex: '#f97316', oklch: '0.68 0.18 55', name: 'Fight Orange' },
    accent: { hex: '#f59e0b', oklch: '0.75 0.15 85', name: 'Victory Gold' },
    success: { hex: '#22c55e' },
    warning: { hex: '#f59e0b' },
    error: { hex: '#dc2626' },
    info: { hex: '#3b82f6' },
  },
  typography: {
    fonts: {
      heading: { family: 'FightKid, Impact, sans-serif' },
      body: { family: 'PlayRegular, Arial, sans-serif' },
      display: { family: 'SingleFighter, Impact, sans-serif' },
      mono: { family: 'ui-monospace, Consolas, monospace' },
    },
  },
  spacing: {
    base: '0.25rem',
  },
  radius: {
    base: '0.5rem',
    lg: '1rem',
    xl: '1.5rem',
  },
  transitions: {
    duration: { base: '200ms' },
    timing: { ease: 'ease-in-out' },
  },
};

export const corporateTheme: Partial<DesignTokens> = {
  brand: { name: 'Corporate CMS', tagline: 'Enterprise Content Management' },
};

export const ecommerceTheme: Partial<DesignTokens> = {
  brand: { name: 'Shop CMS', tagline: 'E-commerce Platform' },
};

export const creativeTheme: Partial<DesignTokens> = {
  brand: { name: 'Creative Studio', tagline: 'Design & Content Platform' },
};

export const revealColorPalette: Record<
  'red' | 'orange' | 'gold' | 'blue' | 'steel' | 'neutral',
  ColorScale
> = {
  red: {
    50: { hex: '#fef2f2' },
    100: { hex: '#fee2e2' },
    200: { hex: '#fecaca' },
    300: { hex: '#fca5a5' },
    400: { hex: '#f87171' },
    500: { hex: '#ef4444' },
    600: { hex: '#dc2626' },
    700: { hex: '#b91c1c' },
    800: { hex: '#991b1b' },
    900: { hex: '#7f1d1d' },
    950: { hex: '#450a0a' },
  },
  orange: {
    50: { hex: '#fff7ed' },
    100: { hex: '#ffedd5' },
    200: { hex: '#fed7aa' },
    300: { hex: '#fdba74' },
    400: { hex: '#fb923c' },
    500: { hex: '#f97316' },
    600: { hex: '#ea580c' },
    700: { hex: '#c2410c' },
    800: { hex: '#9a3412' },
    900: { hex: '#7c2d12' },
    950: { hex: '#431407' },
  },
  gold: {
    50: { hex: '#fffbeb' },
    100: { hex: '#fef3c7' },
    200: { hex: '#fde68a' },
    300: { hex: '#fcd34d' },
    400: { hex: '#fbbf24' },
    500: { hex: '#f59e0b' },
    600: { hex: '#d97706' },
    700: { hex: '#b45309' },
    800: { hex: '#92400e' },
    900: { hex: '#78350f' },
    950: { hex: '#451a03' },
  },
  blue: {
    50: { hex: '#eef2ff' },
    100: { hex: '#e0e7ff' },
    200: { hex: '#c7d2fe' },
    300: { hex: '#a5b4fc' },
    400: { hex: '#818cf8' },
    500: { hex: '#6366f1' },
    600: { hex: '#4f46e5' },
    700: { hex: '#4338ca' },
    800: { hex: '#3730a3' },
    900: { hex: '#312e81' },
    950: { hex: '#1e1b4b' },
  },
  steel: {
    50: { hex: '#f8fafc' },
    100: { hex: '#f1f5f9' },
    200: { hex: '#e2e8f0' },
    300: { hex: '#cbd5f5' },
    400: { hex: '#94a3b8' },
    500: { hex: '#64748b' },
    600: { hex: '#475569' },
    700: { hex: '#334155' },
    800: { hex: '#1e293b' },
    900: { hex: '#0f172a' },
    950: { hex: '#020617' },
  },
  neutral: {
    50: { hex: '#fafafa' },
    100: { hex: '#f5f5f5' },
    200: { hex: '#e5e5e5' },
    300: { hex: '#d4d4d4' },
    400: { hex: '#a3a3a3' },
    500: { hex: '#737373' },
    600: { hex: '#525252' },
    700: { hex: '#404040' },
    800: { hex: '#262626' },
    900: { hex: '#171717' },
    950: { hex: '#0a0a0a' },
  },
};

export function createCustomTokens(customTokens: Partial<DesignTokens>): DesignTokens {
  return {
    ...defaultDesignTokens,
    ...customTokens,
    brand: { ...defaultDesignTokens.brand, ...customTokens.brand },
    colors: { ...defaultDesignTokens.colors, ...customTokens.colors },
    typography: { ...defaultDesignTokens.typography, ...customTokens.typography },
    spacing: { ...defaultDesignTokens.spacing, ...customTokens.spacing },
    radius: { ...defaultDesignTokens.radius, ...customTokens.radius },
    transitions: { ...defaultDesignTokens.transitions, ...customTokens.transitions },
  };
}

export function tokensToCSSVariables(tokens: DesignTokens): Record<string, string> {
  return {
    '--brand-primary': tokens.colors.primary.hex,
    '--brand-secondary': tokens.colors.secondary.hex,
    '--brand-accent': tokens.colors.accent.hex,
    '--font-heading': tokens.typography.fonts.heading.family,
    '--font-body': tokens.typography.fonts.body.family,
    '--font-display': tokens.typography.fonts.display.family,
    '--font-mono': tokens.typography.fonts.mono.family,
    '--spacing-base': tokens.spacing.base,
    '--radius-base': tokens.radius.base,
    '--radius-lg': tokens.radius.lg,
    '--radius-xl': tokens.radius.xl,
    '--transition-duration': tokens.transitions.duration.base,
    '--transition-timing': tokens.transitions.timing.ease,
  };
}

export let activeDesignTokens: DesignTokens = defaultDesignTokens;

export function setActiveDesignTokens(tokens: Partial<DesignTokens>): DesignTokens {
  activeDesignTokens = createCustomTokens(tokens);
  return activeDesignTokens;
}
