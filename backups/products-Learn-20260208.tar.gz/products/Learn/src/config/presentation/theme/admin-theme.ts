import type { AdminThemeConfig } from '@revealui/core/shared-types';
import { activeDesignTokens, tokensToCSSVariables } from './design-tokens';

/**
 * Admin Theme Configuration - reveal UI
 *
 * Fight organization brand: Red, Orange, Black, White
 * Aggressive, energetic, bold design language
 */
export const adminThemeConfig: AdminThemeConfig = {
  brand: {
    name: 'reveal UI',
    tagline: 'Show Yourself',
  },

  colors: {
    primary: '#dc2626', // Combat Red
    secondary: '#f97316', // Fight Orange
    accent: '#f59e0b', // Victory Gold
    gradients: {
      // Red → Orange gradient (main brand)
      primary: 'from-[#dc2626] to-[#f97316]',
      // Orange → Gold gradient (winners/achievements)
      secondary: 'from-[#f97316] to-[#f59e0b]',
    },
  },

  typography: {
    primary: 'PlayRegular, Arial, sans-serif',
    secondary: 'FightKid, Impact, sans-serif',
  },

  features: [
    {
      icon: '🥊',
      label: 'Fight Content',
      description: 'Manage fighters, matches, and fight videos',
    },
    {
      icon: '[RESULTS]',
      label: 'Fighter Stats',
      description: 'Track wins, losses, and fighter rankings',
    },
    {
      icon: '[VIDEO]',
      label: 'Video Management',
      description: 'Upload and manage fight footage',
    },
    {
      icon: '👥',
      label: 'Community',
      description: 'Manage users and fighter profiles',
    },
  ],

  quickActions: [
    {
      icon: '🥊',
      title: 'Recent Fights',
      description: 'Manage latest fight content',
      route: '/admin/collections/posts',
    },
    {
      icon: '👊',
      title: 'Fighters',
      description: 'Manage fighter profiles',
      route: '/admin/collections/users',
    },
    {
      icon: '[TARGET]',
      title: 'Performance',
      description: 'View channel metrics',
      route: '/admin/analytics',
    },
    {
      icon: '🤖',
      title: 'Automation Dashboard',
      description: 'Monitor automation logs and agent performance',
      route: '/admin/automation',
    },
  ],

  animations: {
    duration: 'duration-200',
    easing: 'ease-in-out',
    hover: {
      transform: '-translate-y-1',
      duration: 'duration-200',
      scale: 'hover:scale-105',
    },
    focus: {
      ring: 'focus-visible:ring-2',
      ringOffset: 'focus-visible:ring-offset-2',
      transition: 'focus-visible:outline-none',
    },
    states: {
      loading: 'duration-500',
      success: 'duration-300',
      error: 'duration-300',
    },
  },

  frontend: {
    syncWithFrontend: true,
    overrideFrontendTheme: 'auto',
  },
};

/**
 * Get CSS custom properties for admin theme
 * Injects reveal brand colors as CSS variables
 */
export function getAdminThemeCSSProperties(): Record<string, string> {
  const baseProperties = tokensToCSSVariables(activeDesignTokens);

  return {
    ...baseProperties,
    // Combat Red (Primary)
    '--admin-primary-color': '#dc2626',
    '--admin-primary-oklch': '0.55 0.22 25',

    // Fight Orange (Secondary)
    '--admin-secondary-color': '#f97316',
    '--admin-secondary-oklch': '0.68 0.18 55',

    // Victory Gold (Accent)
    '--admin-accent-color': '#f59e0b',
    '--admin-accent-oklch': '0.75 0.15 85',

    // Typography
    '--admin-font-primary': 'PlayRegular, Arial, sans-serif',
    '--admin-font-secondary': 'FightKid, Impact, sans-serif',
    '--admin-font-display': 'SingleFighter, Impact, sans-serif',
  };
}

/**
 * Get frontend theme preference
 */
export function getFrontendThemePreference(): 'light' | 'dark' | 'auto' {
  if (!adminThemeConfig.frontend.syncWithFrontend) {
    return (adminThemeConfig.frontend.overrideFrontendTheme ?? 'auto') as 'light' | 'dark' | 'auto';
  }

  if (typeof window !== 'undefined') {
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    if (savedTheme) return savedTheme;

    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return prefersDark ? 'dark' : 'light';
  }

  return 'auto';
}

/**
 * Helper function to get theme configuration
 */
export function getAdminThemeConfig(): AdminThemeConfig {
  return adminThemeConfig;
}
