/**
 * Examples Configuration
 *
 * Feature flags and configuration for different RevealUI example scenarios
 */

import type { ExampleConfig } from '@revealui/core/shared-types';

/**
 * Available example configurations
 */
export const EXAMPLE_CONFIGS: Record<string, ExampleConfig> = {
	'saas': {
		mode: 'saas',
		title: 'SaaS Starter',
		description: 'Full-featured SaaS with Clean Architecture and multi-tenancy',
		route: '/saas',
		exportDir: 'saas-template',
		docs: ['saas'],
		features: {
			auth: true,
			payments: true,
			analytics: true,
			ai: true,
			multitenant: true,
			content: true,
			ecommerce: false,
			learning: false
		},
		theme: 'auto',
		demoData: ['users', 'tenants', 'content', 'analytics']
	},

	'ecommerce': {
		mode: 'ecommerce',
		title: 'E-commerce',
		description: 'Online store with products, orders, payments, and analytics',
		route: '/commerce',
		exportDir: 'e-commerce',
		docs: ['commerce'],
		features: {
			auth: true,
			payments: true,
			analytics: true,
			ai: false,
			multitenant: false,
			content: true,
			ecommerce: true,
			learning: false
		},
		theme: 'light',
		demoData: ['products', 'orders', 'users', 'content']
	},

	'cms': {
		mode: 'cms',
		title: 'Content Management',
		description: 'Headless CMS with media, SEO, and editorial workflow',
		route: '/cms',
		exportDir: 'basic-blog',
		docs: ['cms'],
		features: {
			auth: true,
			payments: false,
			analytics: false,
			ai: false,
			multitenant: false,
			content: true,
			ecommerce: false,
			learning: false
		},
		theme: 'light',
		demoData: ['content', 'users']
	},

	'ai-assistant': {
		mode: 'ai-assistant',
		title: 'AI Assistant',
		description: 'AI-powered chat and automation with analytics',
		route: '/ai',
		exportDir: 'ai',
		docs: ['ai'],
		features: {
			auth: true,
			payments: false,
			analytics: true,
			ai: true,
			multitenant: false,
			content: true,
			ecommerce: false,
			learning: false
		},
		theme: 'dark',
		demoData: ['ai-content', 'users']
	},

	'healthcare': {
		mode: 'healthcare',
		title: 'Healthcare',
		description: 'Patient management with AI triage, analytics, and compliance',
		route: '/healthcare',
		exportDir: 'healthcare',
		docs: ['healthcare'],
		features: {
			auth: true,
			payments: true,
			analytics: true,
			ai: true,
			multitenant: true,
			content: true,
			ecommerce: false,
			learning: false
		},
		theme: 'light',
		demoData: ['healthcare', 'patients', 'appointments']
	},

	'automotive': {
		mode: 'automotive',
		title: 'Automotive',
		description: 'Vehicle sales, parts ordering, and service scheduling',
		route: '/automotive',
		exportDir: 'automotive',
		docs: ['automotive'],
		features: {
			auth: true,
			payments: true,
			analytics: true,
			ai: false,
			multitenant: false,
			content: true,
			ecommerce: true,
			learning: false
		},
		theme: 'dark',
		demoData: ['vehicles', 'parts', 'orders']
	},

	'portfolio': {
		mode: 'portfolio',
		title: 'Portfolio',
		description: 'Personal portfolio with content, blog, and contact',
		route: '/portfolio',
		exportDir: 'portfolio',
		docs: ['portfolio'],
		features: {
			auth: false,
			payments: false,
			analytics: false,
			ai: false,
			multitenant: false,
			content: true,
			ecommerce: false,
			learning: false
		},
		theme: 'auto',
		demoData: ['portfolio']
	},

	'learning': {
		mode: 'learning',
		title: 'Learning Platform',
		description: 'Courses, lessons, progress tracking, and AI tutoring',
		route: '/learning',
		exportDir: 'learning',
		docs: ['learning'],
		features: {
			auth: true,
			payments: false,
			analytics: true,
			ai: true,
			multitenant: false,
			content: true,
			ecommerce: false,
			learning: true
		},
		theme: 'light',
		demoData: ['courses', 'lessons', 'progress']
	}
};

const DEFAULT_MODE = 'saas';

/**
 * Get current example configuration
 */
export function getExampleConfig(): ExampleConfig {
	const mode = process.env.EXAMPLE_MODE || DEFAULT_MODE;
	return EXAMPLE_CONFIGS[mode] || EXAMPLE_CONFIGS[DEFAULT_MODE];
}

/**
 * Check if a feature is enabled
 */
export function isFeatureEnabled(feature: keyof ExampleConfig['features']): boolean {
	return getExampleConfig().features[feature];
}

/**
 * Get current theme
 */
export function getCurrentTheme(): string {
	return getExampleConfig().theme;
}

/**
 * Manifest list used by the hybrid shell and export tooling
 */
export function getExampleManifest(): ExampleConfig[] {
	return Object.values(EXAMPLE_CONFIGS);
}
