import { getEnvVarWithFallback } from '@/config/system/environment';

const APP_ENV = getEnvVarWithFallback('APP_ENV', 'development');
const REVEAL_PUBLIC_SERVER_URL = getEnvVarWithFallback(
  'REVEAL_PUBLIC_SERVER_URL',
  'http://localhost:3000'
);
const REVEAL_PUBLIC_CLIENT_URL = getEnvVarWithFallback(
  'REVEAL_PUBLIC_CLIENT_URL',
  'http://localhost:3000'
);

export class DomainConfiguration {
  getServerUrl(): string {
    return REVEAL_PUBLIC_SERVER_URL;
  }

  getClientUrl(): string {
    return REVEAL_PUBLIC_CLIENT_URL;
  }

  getEnvironment(): 'development' | 'production' | 'test' {
    return (APP_ENV as 'development' | 'production' | 'test') ?? 'development';
  }

  isDevelopment(): boolean {
    return this.getEnvironment() === 'development';
  }

  isProduction(): boolean {
    return this.getEnvironment() === 'production';
  }

  isTest(): boolean {
    return this.getEnvironment() === 'test';
  }
}

export const domainConfig = new DomainConfiguration();

export * from './identity/roles/index.ts';
export * from './identity/users/index.ts';
export * from './ecommerce';
export * from './pricing/index.ts';
