import { type User } from '@/contracts';

type UserRole = User['role'];
type UserPermission = User['permissions'][number];

export function getRolePermissions(_role: UserRole): UserPermission[] {
  return [];
}

export function getRolePermissionsList(_role: UserRole): UserPermission[] {
  return [];
}

export function hasPermission(_role: UserRole, _permission: UserPermission): boolean {
  return false;
}

export function canRoleDelegate(): boolean {
  return false;
}

export function getDelegatablePermissions(): UserPermission[] {
  return [];
}

export function getEditableRoles(): UserRole[] {
  return [];
}

export function getMaxDelegations(): number {
  return 0;
}

export function getRoleHierarchyLevel(): number {
  return 0;
}

export function getRolesByTier(): UserRole[] {
  return [];
}

export function getSystemRoles(): UserRole[] {
  return [];
}

export function hasRoleHierarchy(): boolean {
  return false;
}
