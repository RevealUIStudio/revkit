// ====================================================================
// CATEGORY DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Category domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type {
  ICategoryDomainService,
  CreateCategoryDTO,
  UpdateCategoryDTO,
  Category as SharedCategory,
} from '@revealui/core/shared-types';
import type { DomainCategory } from '../types/domain/entities/category';
import {
  categoryFiltersSchema,
  categoryReorderSchema,
  createCategorySchema,
  updateCategorySchema,
} from '../validation/schemas/category';

/**
 * Category Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainCategory entity and DTOs
 * - Behavior: ICategoryDomainService interface
 * - Quality: Zod validation schemas
 */
export const CategoryContract = createContractSnapshot({
  domain: 'category',
  version: '1.0.0',

  shape: {
    entity: {} as DomainCategory,
    dto: {
      create: {} as CreateCategoryDTO,
      update: {} as UpdateCategoryDTO,
    },
  },

  behavior: {
    service: {} as ICategoryDomainService,
  },

  validation: {
    create: createCategorySchema,
    update: updateCategorySchema,
    filters: categoryFiltersSchema,
    reorder: categoryReorderSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: [],
    description: 'Category management domain contract including hierarchy and taxonomy',
    tags: ['content', 'taxonomy'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================

// Use canonical category type from shared types to avoid duplication
export type Category = SharedCategory;
export type CreateCategory = typeof CategoryContract.shape.dto.create;
export type UpdateCategory = typeof CategoryContract.shape.dto.update;
export type CategoryService = typeof CategoryContract.behavior.service;

export const { validation: CategoryValidation } = CategoryContract;
