// ====================================================================
// PRODUCT DOMAIN CONTRACT
// ====================================================================
// Unified contract snapshot for Product domain
// Captures: Shape (types), Behavior (interfaces), Quality (validation)

import { createContractSnapshot } from '../core';
import type { IProductService, CreateProductDTO, UpdateProductDTO, Product as SharedProduct } from '@revealui/core/shared-types';
import type { DomainProduct } from '../types/domain/entities/product';
import {
  createProductSchema,
  productFiltersSchema,
  productVariantSchema,
  updateProductSchema,
} from '../validation/schemas/product';

/**
 * Product Domain Contract Snapshot
 *
 * Unified contract bringing together:
 * - Shape: DomainProduct entity and DTOs
 * - Behavior: IProductService interface
 * - Quality: Zod validation schemas
 */
export const ProductContract = createContractSnapshot({
  domain: 'product',
  version: '1.0.0',

  shape: {
    entity: {} as DomainProduct,
    dto: {
      create: {} as CreateProductDTO,
      update: {} as UpdateProductDTO,
    },
  },

  behavior: {
    service: {} as IProductService,
  },

  validation: {
    create: createProductSchema,
    update: updateProductSchema,
    filters: productFiltersSchema,
    variant: productVariantSchema,
  },

  metadata: {
    layer: 'domain',
    dependsOn: ['category', 'media'],
    description: 'Product management domain contract including inventory, pricing, and variants',
    tags: ['ecommerce', 'inventory', 'pricing'],
  },
});

// ====================================================================
// CONVENIENCE EXPORTS
// ====================================================================
// Type-safe access to contract components
// Use canonical shared Product type to avoid duplicate definitions
export type Product = SharedProduct;
export type CreateProduct = typeof ProductContract.shape.dto.create;
export type UpdateProduct = typeof ProductContract.shape.dto.update;
export type ProductService = typeof ProductContract.behavior.service;

export const { validation: ProductValidation } = ProductContract;
