// ====================================================================
// TAG DOMAIN ENTITIES
// ====================================================================

import type { Tag as SharedTag } from '@revealui/core/shared-types';

/**
 * Enhanced Tag entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type { Tag as RevealUITag } from '@revealui/infrastructure/cms/db/reveal-types';
import type { EnhancedTag, HybridEntity, RevealUIToDomainTagMapper } from '@revealui/infrastructure/revealui-domain-bridge';

export type DomainTag = SharedTag;
export type TagWithRevealUI = HybridEntity<RevealUITag, DomainTag>;

/**
 * Enhanced Tag entity from bridge system
 */
export type TagEnhanced = EnhancedTag;

/**
 * Tag transformed from RevealUI Content Engine
 */
export type TagFromRevealUI<T extends RevealUITag = RevealUITag> = RevealUIToDomainTagMapper<T>;

/**
 * Type guard to check if tag has RevealUI Content Engine data
 */
export function isTagWithRevealUI(value: unknown): value is TagWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
