// ====================================================================
// PRODUCT DOMAIN ENTITIES
// ====================================================================

import type { Product as SharedProduct } from '@revealui/core/shared-types';
// Adopt canonical product shapes from shared types
export type DomainProduct = SharedProduct;
export type Product = SharedProduct;
// Additional product helper types live in shared types; import as needed at usage sites.
