// ====================================================================
// CATEGORY DOMAIN ENTITIES
// ====================================================================

import type {
  Category as SharedCategory,
  CategoryFilters,
  CategoryTree,
} from '@revealui/core/shared-types';

/**
 * Enhanced Category entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
import type { Category as RevealUICategory } from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedCategory,
  HybridEntity,
  RevealUIToDomainCategoryMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

export type DomainCategory = SharedCategory;
export type CategoryWithRevealUI = HybridEntity<RevealUICategory, DomainCategory>;

/**
 * Enhanced Category entity from bridge system
 */
export type CategoryEnhanced = EnhancedCategory;

/**
 * Category transformed from RevealUI Content Engine
 */
export type CategoryFromRevealUI<T extends RevealUICategory = RevealUICategory> =
  RevealUIToDomainCategoryMapper<T>;

/**
 * Type guard to check if category has RevealUI Content Engine data
 */
export function isCategoryWithRevealUI(value: unknown): value is CategoryWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
