// ====================================================================
// ORDER DOMAIN ENTITIES
// ====================================================================

import type {
  Order as SharedOrder,
  OrderItem,
  OrderTotals,
  OrderStatus,
  PaymentStatus,
  PaymentInfo,
  ShippingInfo,
  OrderMetadata,
  ProductVariantId,
  ProductPrice,
  BillingInfo as BillingAddress,
  ShippingInfo as ShippingAddress,
} from '@revealui/core/shared-types';
import type {
  Order as RevealUIOrder,
  Product as RevealUIProduct,
} from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedOrder,
  HybridEntity,
  RevealUIToDomainOrderMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

// Adopt canonical order shapes from shared types
export type DomainOrder = SharedOrder;
export type Order = SharedOrder;

export type OrderWithRevealUI = HybridEntity<RevealUIOrder, DomainOrder>;

/**
 * Enhanced Order entity from bridge system
 */
export type OrderEnhanced = EnhancedOrder;

/**
 * Order transformed from RevealUI Content Engine
 */
export type OrderFromRevealUI<T extends RevealUIOrder = RevealUIOrder> = RevealUIToDomainOrderMapper<T>;

/**
 * Type guard to check if order has RevealUI Content Engine data
 */
export function isOrderWithRevealUI(value: unknown): value is OrderWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'items' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
