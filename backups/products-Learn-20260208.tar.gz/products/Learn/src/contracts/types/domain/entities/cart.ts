// ====================================================================
// CART DOMAIN ENTITIES
// ====================================================================

import type {
  Cart as SharedCart,
  CartItem as SharedCartItem,
  CartTotals as SharedCartTotals,
} from '@revealui/core/shared-types';
import type {
  Cart as RevealUICart,
  Product as RevealUIProduct,
} from '@revealui/infrastructure/cms/db/revealui-types';
import type {
  EnhancedCart,
  HybridEntity,
  RevealUIToDomainCartMapper,
} from '@revealui/infrastructure/revealui-domain-bridge';

// Adopt canonical cart shapes from shared types
export type Cart = SharedCart;
export type CartItem = SharedCartItem;
export type CartTotals = SharedCartTotals;
export type DomainCart = SharedCart;

/**
 * Enhanced Cart entity combining RevealUI Content Engine and domain properties
 * Useful in application/presentation layers that need both revealui and domain data
 */
export type CartWithRevealUI = HybridEntity<RevealUICart, DomainCart>;

/**
 * Enhanced Cart entity from bridge system
 */
export type CartEnhanced = EnhancedCart;

/**
 * Cart transformed from RevealUI Content Engine
 */
export type CartFromRevealUI<T extends RevealUICart = RevealUICart> = RevealUIToDomainCartMapper<T>;

/**
 * Type guard to check if cart has RevealUI Content Engine data
 */
export function isCartWithRevealUI(value: unknown): value is CartWithRevealUI {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'items' in value &&
    '__source' in value &&
    (value as { __source: string }).__source === 'hybrid'
  );
}
