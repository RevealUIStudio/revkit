// =======
// EXTENDED REVEALUI TYPES
// =======
// Type extensions for RevealUI content engine

import type {
  Brand,
  Business,
  BusinessFeature,
  Config,
  Coupon,
  Folder,
  Form,
  FormSubmission,
  HelpArticle,
  IndustryTemplate,
  Cart as RevealUICart,
  Category as RevealUICategory,
  Media as RevealUIMedia,
  Menu as RevealUIMenu,
  Order as RevealUIOrder,
  Page as RevealUIPage,
  Post as RevealUIPost,
  Product as RevealUIProduct,
  Tag as RevealUITag,
  User as RevealUIUser,
  Paywall,
  PerformanceMetric,
  Prefix,
  Redirect,
  Search,
  Session,
  Tenant,
  Version,
  Video,
  VideoPurchase,
  VideoRequest,
} from '@revealui/infrastructure/cms/db/reveal-types';
import type { CollectionName as SharedCollectionName } from '@revealui/core/shared-types';
import type { RevealUI, RevealUIRequest, ValidationError } from '@revealui/content';

// ====================================================================
// CORE EXTENSIONS
// ====================================================================

/**
 * Extended RevealUI configuration type
 */
export interface ExtendedRevealUI extends RevealUI {
  // Additional custom properties for extended RevealUI functionality
  // Using Record<string, unknown> because custom config structure varies by RevealUI extension and cannot be strictly typed
  customConfig?: /* Using Record<string, unknown> because custom config structure varies by RevealUI extension and cannot be strictly typed */ Record<
    string,
    unknown
  >;
}

/**
 * Extended RevealUI configuration type
 * @deprecated Use ExtendedRevealUI instead (kept for backward compatibility)
 */
export interface ExtendedRevealUI extends ExtendedRevealUI {}

/**
 * Extended RevealUI request type
 */
export interface ExtendedRevealUIRequest extends RevealUIRequest {
  // Additional request properties
  userAgent?: string;
  ip?: string;
  geo?: {
    country?: string;
    region?: string;
    city?: string;
  };
}

/**
 * Extended RevealUI request type
 * @deprecated Use ExtendedRevealUIRequest instead
 */
export interface ExtendedRevealUIRequest extends ExtendedRevealUIRequest {}

/**
 * Enhanced validation error type
 */
export interface EnhancedValidationError extends ValidationError {
  // Additional validation error properties
  fieldPath?: string[];
  suggestedValue?: unknown;
  documentationUrl?: string;
}

// ====================================================================
// COLLECTION TYPE EXTRACTION UTILITIES
// ====================================================================

/**
 * Extract all collection names from Config as union type
 * NOTE: This is re-exported from revealui-collections.ts for convenience
 */
export type CollectionName = SharedCollectionName;

/**
 * Get a collection type by its slug/name
 * NOTE: This is re-exported from revealui-collections.ts for convenience
 */
export type CollectionBySlug<T extends CollectionName> = Config['collections'][T];

/**
 * All RevealUI entity types as a union
 */
export type RevealUIEntity =
  | Brand
  | BusinessFeature
  | Business
  | IndustryTemplate
  | RevealUIUser
  | RevealUIMedia
  | Video
  | VideoPurchase
  | VideoRequest
  | HelpArticle
  | RevealUIPage
  | RevealUIPost
  | Prefix
  | RevealUITag
  | Session
  | RevealUICategory
  | Folder
  | RevealUIMenu
  | Paywall
  | RevealUIProduct
  | RevealUICart
  | RevealUIOrder
  | Coupon
  | Tenant
  | Version
  | PerformanceMetric
  | Redirect
  | Search
  | Form
  | FormSubmission;

// ====================================================================
// RELATIONSHIP HANDLING UTILITIES
// ====================================================================

/**
 * RevealUI relationship fields can be either a string ID or the full entity object
 * This helper extracts the entity type from a relationship field
 */
export type RevealUIRelation<T> = T extends string | infer Entity ? Entity : never;

/**
 * Extract the full entity type from a RevealUI relationship field
 * Handles: string | Entity → Entity
 */
export type ExtractRevealUIEntity<T> = T extends string | infer E ? E : T;

/**
 * Extract ID from RevealUI relationship field
 * Handles both string IDs and entity objects
 */
export type ExtractRevealUIId<T> = T extends string ? T : T extends { id: string } ? T['id'] : never;

/**
 * Convert a RevealUI relation to just an ID string
 */
export type RelationToId<T> = T extends string ? T : T extends { id: string } ? string : never;

// ====================================================================
// ENTITY STATE DISCRIMINATED UNIONS
// ====================================================================

/**
 * RevealUI entity status states
 */
export type EntityStatus = 'draft' | 'published' | 'archived' | 'inactive';

/**
 * RevealUI entity with status discrimination
 */
export interface RevealUIEntityWithStatus<TEntity extends RevealUIEntity> {
  readonly __entityType: TEntity;
  readonly __status: EntityStatus;
}

/**
 * Draft entity variant
 */
export interface DraftEntity<TEntity extends RevealUIEntity>
  extends RevealUIEntityWithStatus<TEntity> {
  readonly __status: 'draft';
  status?: 'draft';
}

/**
 * Published entity variant
 */
export interface PublishedEntity<TEntity extends RevealUIEntity>
  extends RevealUIEntityWithStatus<TEntity> {
  readonly __status: 'published';
  status: 'published';
}

// ====================================================================
// TYPE GUARDS
// ====================================================================

/**
 * Type predicate to check if a value is a RevealUI entity
 */
export function isRevealUIEntity(value: unknown): value is RevealUIEntity {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    typeof (value as { id: unknown }).id === 'string' &&
    'createdAt' in value &&
    typeof (value as { createdAt: unknown }).createdAt === 'string' &&
    'updatedAt' in value &&
    typeof (value as { updatedAt: unknown }).updatedAt === 'string'
  );
}

/**
 * Type predicate to check if a value is a specific RevealUI entity type
 */
export function isRevealUIEntityOfType<T extends RevealUIEntity>(
  value: unknown,
  type: new () => T
): value is T {
  return isRevealUIEntity(value) && value instanceof type;
}

/**
 * Type predicate to check if an entity is published
 */
export function isPublishedEntity(entity: unknown): entity is PublishedEntity<RevealUIEntity> {
  return (
    isRevealUIEntity(entity) &&
    entity &&
    typeof entity === 'object' &&
    'status' in entity &&
    entity.status === 'published'
  );
}

/**
 * Type predicate to check if an entity is a draft
 */
export function isDraftEntity(entity: unknown): entity is DraftEntity<RevealUIEntity> {
  return (
    isRevealUIEntity(entity) &&
    entity &&
    typeof entity === 'object' &&
    'status' in entity &&
    (entity.status === 'draft' || entity.status === undefined)
  );
}

/**
 * Type predicate to check if a value is a RevealUI relation (string ID or entity)
 */
export function isRevealUIRelation<T extends RevealUIEntity>(value: unknown): value is string | T {
  return typeof value === 'string' || isRevealUIEntity(value);
}

/**
 * Type predicate to check if a RevealUI relation is a full entity (not just an ID)
 */
export function isRevealUIRelationEntity<T extends RevealUIEntity>(value: unknown): value is T {
  return isRevealUIEntity(value);
}

/**
 * Type predicate to check if a RevealUI relation is just an ID string
 */
export function isRevealUIRelationId(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0;
}

/**
 * Type predicate to check if an entity is archived
 */
export function isArchivedEntity(entity: unknown): entity is RevealUIEntity {
  return (
    isRevealUIEntity(entity) &&
    entity &&
    typeof entity === 'object' &&
    'status' in entity &&
    entity.status === 'archived'
  );
}

/**
 * Type predicate to check if an entity has a specific status
 */
export function hasEntityStatus(entity: unknown, status: EntityStatus): entity is RevealUIEntity {
  return (
    isRevealUIEntity(entity) &&
    entity &&
    typeof entity === 'object' &&
    'status' in entity &&
    entity.status === status
  );
}

// ====================================================================
// ENTITY TRANSFORMATIONS
// ====================================================================

/**
 * Extract only the essential fields from a RevealUI entity (ID + timestamps)
 */
export type RevealUIEntityEssentials = {
  id: string;
  createdAt: string;
  updatedAt: string;
};

/**
 * RevealUI entity without system-generated fields
 * Use for create operations
 */
export type RevealUIEntityInput<T extends RevealUIEntity> = Omit<T, 'id' | 'createdAt' | 'updatedAt'>;

/**
 * RevealUI entity for update operations (all fields optional except ID)
 */
export type RevealUIEntityUpdate<T extends RevealUIEntity> = Partial<Omit<T, 'id'>> & {
  id: T['id'];
};

// ====================================================================
// RICH TEXT HANDLING
// ====================================================================

/**
 * RevealUI rich text field structure (Lexical editor)
 */
export interface RevealUIRichText {
  root: {
    type: string;
    children: Array<{
      type: string;
      version: number;
      [k: string]: unknown;
    }>;
    direction: ('ltr' | 'rtl') | null;
    format: 'left' | 'start' | 'center' | 'right' | 'end' | 'justify' | '';
    indent: number;
    version: number;
  };
  [k: string]: unknown;
}

/**
 * Extract plain text from RevealUI rich text
 */
export type RichTextPlainText<T extends RevealUIRichText | string | null | undefined> =
  T extends string ? T : T extends RevealUIRichText ? string : never;
