'use client'

import { useState, useEffect } from 'react'
import { Button } from '@revealui/core'
import { ContentItem } from '@revealui/content'

export default function SuiteDemo() {
  const [activeTab, setActiveTab] = useState<'overview' | 'content' | 'ai' | 'integrated'>('overview')
  const [contentItems, setContentItems] = useState<ContentItem[]>([])
  const [aiAnalysis, setAiAnalysis] = useState('')
  const [loading, setLoading] = useState(false)

  // Sample content for demonstration
  const sampleContent = [
    {
      id: '1',
      title: 'Welcome to RevealUI Suite',
      body: 'Experience the power of integrated development tools with React, CMS, and AI working together seamlessly.',
      excerpt: 'Complete development platform',
      status: 'published' as const,
      tags: ['suite', 'integration'],
      author: 'RevealUI Team',
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: '2',
      title: 'Building Modern Web Applications',
      body: 'With RevealUI Core, you get modern React components, TypeScript support, and excellent developer experience.',
      excerpt: 'Modern web development',
      status: 'published' as const,
      tags: ['react', 'typescript'],
      author: 'Core Team',
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ]

  useEffect(() => {
    setContentItems(sampleContent)
  }, [])

  const analyzeWithAI = async () => {
    setLoading(true)
    setAiAnalysis('')

    try {
      // Simulate AI analysis of the content
      const analysis = `## AI Analysis Complete

### Content Quality Score: 92/100

**Strengths:**
- Clear, engaging titles
- Well-structured content
- Good use of keywords
- Professional tone

**Suggestions:**
- Add more specific examples
- Consider adding code snippets
- Include call-to-action buttons
- Optimize for SEO with meta descriptions

**Generated Tags:** react, typescript, web-development, cms

**Reading Time:** ~3 minutes
**Readability Score:** Excellent`

      // Simulate typing effect
      let index = 0
      const typeWriter = () => {
        if (index < analysis.length) {
          setAiAnalysis(prev => prev + analysis.charAt(index))
          index++
          setTimeout(typeWriter, 20)
        }
      }
      typeWriter()
    } catch (error) {
      setAiAnalysis('Error: Failed to analyze content')
    } finally {
      setLoading(false)
    }
  }

  const tabs = [
    { id: 'overview', label: 'Suite Overview', icon: '🚀' },
    { id: 'content', label: 'Content Management', icon: '📝' },
    { id: 'ai', label: 'AI Integration', icon: '🤖' },
    { id: 'integrated', label: 'Full Integration', icon: '⚡' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto py-8 px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            RevealUI Suite
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Complete Development Platform - React + CMS + AI
          </p>

          {/* Product Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/80 backdrop-blur-sm shadow-lg rounded-xl p-6 border border-green-200">
              <div className="text-3xl mb-3">⚛️</div>
              <h3 className="text-lg font-semibold text-green-800 mb-2">Core Framework</h3>
              <p className="text-green-600 text-sm">React 19 + Next.js 16 + Components</p>
              <div className="mt-3 flex items-center text-green-700">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Running at port 3000
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-sm shadow-lg rounded-xl p-6 border border-blue-200">
              <div className="text-3xl mb-3">📝</div>
              <h3 className="text-lg font-semibold text-blue-800 mb-2">Content Engine</h3>
              <p className="text-blue-600 text-sm">Headless CMS + API + Admin</p>
              <div className="mt-3 flex items-center text-blue-700">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                Running at port 4001
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-sm shadow-lg rounded-xl p-6 border border-purple-200">
              <div className="text-3xl mb-3">🤖</div>
              <h3 className="text-lg font-semibold text-purple-800 mb-2">MCP Platform</h3>
              <p className="text-purple-600 text-sm">AI Orchestration + Code Review</p>
              <div className="mt-3 flex items-center text-purple-700">
                <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                Running at port 4003
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-200 flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-lg transform scale-105'
                  : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md'
              }`}
            >
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-white/90 backdrop-blur-sm shadow-xl rounded-2xl p-8 min-h-[600px]">
          {activeTab === 'overview' && (
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Complete Development Suite</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div className="space-y-6">
                  <div className="text-left">
                    <h3 className="text-2xl font-semibold text-gray-800 mb-4">Why Choose RevealUI Suite?</h3>
                    <ul className="space-y-3 text-gray-600">
                      <li className="flex items-start gap-3">
                        <span className="text-green-500 mt-1">✓</span>
                        <span><strong>Integrated Platform:</strong> All tools work together seamlessly</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-blue-500 mt-1">✓</span>
                        <span><strong>Modern Stack:</strong> React 19, Next.js 16, TypeScript 5.9</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-purple-500 mt-1">✓</span>
                        <span><strong>AI-Powered:</strong> Code review, content generation, analysis</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-orange-500 mt-1">✓</span>
                        <span><strong>Production Ready:</strong> Enterprise-grade architecture</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl p-8">
                  <h4 className="text-xl font-semibold text-gray-800 mb-4">Live Integration Demo</h4>
                  <p className="text-gray-600 mb-6">
                    All three products are running simultaneously and can communicate with each other.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                      <span className="font-medium">Core Components</span>
                      <span className="text-green-600">✅ Active</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                      <span className="font-medium">Content API</span>
                      <span className="text-green-600">✅ Active</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white/50 rounded-lg">
                      <span className="font-medium">MCP Server</span>
                      <span className="text-green-600">✅ Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'content' && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">Content Management System</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Published Content</h3>
                  <div className="space-y-4">
                    {contentItems.filter(item => item.status === 'published').map((item) => (
                      <div key={item.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{item.title}</h4>
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                            Published
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm mb-3">{item.excerpt}</p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>By {item.author}</span>
                          <span>{item.createdAt.toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Content Features</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-medium text-blue-800 mb-2">📝 Rich Text Editor</h4>
                      <p className="text-blue-600 text-sm">Full-featured content editing with formatting, media, and links.</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h4 className="font-medium text-green-800 mb-2">🔗 REST API</h4>
                      <p className="text-green-600 text-sm">Complete CRUD API with filtering, pagination, and search.</p>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg">
                      <h4 className="font-medium text-purple-800 mb-2">🏷️ Custom Fields</h4>
                      <p className="text-purple-600 text-sm">Flexible content types with custom fields and relationships.</p>
                    </div>
                    <div className="p-4 bg-orange-50 rounded-lg">
                      <h4 className="font-medium text-orange-800 mb-2">📊 Admin Dashboard</h4>
                      <p className="text-orange-600 text-sm">User-friendly interface for content management and publishing.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ai' && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">AI-Powered Development</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Code Review Agent</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-purple-50 rounded-lg">
                      <h4 className="font-medium text-purple-800 mb-2">🔍 Code Analysis</h4>
                      <p className="text-purple-600 text-sm">Automated detection of bugs, security issues, and style violations.</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-medium text-blue-800 mb-2">📊 Quality Scoring</h4>
                      <p className="text-blue-600 text-sm">Comprehensive scoring system (0-100) for code quality assessment.</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h4 className="font-medium text-green-800 mb-2">💡 Improvement Suggestions</h4>
                      <p className="text-green-600 text-sm">Actionable recommendations for code optimization and best practices.</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">MCP Protocol</h3>
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                    <div className="mb-2 text-gray-400"># MCP Communication Example</div>
                    <div>{"-->"} initialize</div>
                    <div>{"<--"} capabilities: tools, resources</div>
                    <div>{"-->"} tools/call (analyze_code)</div>
                    <div>{"<--"} content: analysis results</div>
                    <div className="mt-3 text-blue-400"># Real-time AI orchestration</div>
                  </div>
                  <p className="text-gray-600 text-sm mt-3">
                    Model Context Protocol enables standardized communication between AI models and development tools.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'integrated' && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">Full Suite Integration</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Content with AI Analysis</h3>
                  <div className="space-y-4">
                    {contentItems.map((item) => (
                      <div key={item.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{item.title}</h4>
                          <Button
                            size="sm"
                            onClick={analyzeWithAI}
                            disabled={loading}
                          >
                            {loading ? 'Analyzing...' : 'AI Analyze'}
                          </Button>
                        </div>
                        <p className="text-gray-600 text-sm">{item.excerpt}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">AI Analysis Results</h3>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 min-h-[300px]">
                    {aiAnalysis ? (
                      <pre className="whitespace-pre-wrap text-sm text-gray-800 font-mono">
                        {aiAnalysis}
                      </pre>
                    ) : (
                      <div className="text-center text-gray-500 py-12">
                        <div className="text-4xl mb-3">🤖</div>
                        <p>Click "AI Analyze" on any content to see AI-powered insights</p>
                        <p className="text-sm mt-2">The analysis includes quality scoring, suggestions, and optimization recommendations.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8 text-center">
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Integration Benefits</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                    <div className="text-3xl mb-3">⚡</div>
                    <h4 className="font-semibold text-blue-800 mb-2">Unified Workflow</h4>
                    <p className="text-blue-600 text-sm">Seamless integration between design, content, and AI tools</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
                    <div className="text-3xl mb-3">🎯</div>
                    <h4 className="font-semibold text-green-800 mb-2">Intelligent Automation</h4>
                    <p className="text-green-600 text-sm">AI-powered content generation, code review, and optimization</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
                    <div className="text-3xl mb-3">🚀</div>
                    <h4 className="font-semibold text-purple-800 mb-2">Accelerated Development</h4>
                    <p className="text-purple-600 text-sm">Complete platform reduces development time and complexity</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
