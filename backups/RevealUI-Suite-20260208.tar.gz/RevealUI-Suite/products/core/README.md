# RevealUI Core

**Modern React 19 + Next.js 16 Framework**

A focused, production-ready React framework that provides the foundation for building modern web applications.

## ✨ Features

- **React 19** with concurrent features and modern hooks
- **Next.js 16** with App Router and advanced caching
- **TypeScript 5.9** with strict mode
- **Tailwind CSS 4.1** for utility-first styling
- **50+ Pre-built Components** - forms, layouts, navigation
- **Type-safe API Clients** with automatic retry logic
- **Form System** with validation and error handling
- **State Management** patterns and utilities

## 🚀 Quick Start

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build
```

## 📦 Packages

### Core Framework Packages
- **`@revealui/core`** - Main framework package
- **`@revealui/core-ui`** - Component library
- **`@revealui/core-forms`** - Form system
- **`@revealui/core-api`** - API client utilities

### Apps & Examples
- **`@revealui/core-examples`** - Example applications
- **`@revealui/core-showcase`** - Component showcase

## 🏗️ Architecture

### Clean Architecture
```
src/
├── domain/          # Business logic
├── application/     # Use cases
├── infrastructure/  # External dependencies
└── presentation/    # UI components
```

### Component Structure
```
packages/core-ui/src/
├── components/      # Individual components
├── layouts/         # Layout components
├── forms/           # Form components
└── utilities/       # Helper utilities
```

## 🎯 Use Cases

### ✅ Perfect For
- Building React applications from scratch
- Adding modern UI components to existing apps
- Creating consistent design systems
- Rapid prototyping with production-ready components

### ❌ Not For
- Content management (use RevealUI Content)
- AI features (use RevealUI MCP)
- Enterprise CMS functionality

## 🔗 Integration

### With RevealUI Content
```typescript
import { useContent } from '@revealui/content'
import { Button, Card } from '@revealui/core-ui'

// Use Core UI components with Content data
function ContentPage() {
  const { posts } = useContent()

  return (
    <div>
      {posts.map(post => (
        <Card key={post.id}>
          <h2>{post.title}</h2>
          <Button>Read More</Button>
        </Card>
      ))}
    </div>
  )
}
```

### With RevealUI MCP
```typescript
import { useAI } from '@revealui/mcp'
import { Input, Button } from '@revealui/core-ui'

// Use Core UI with AI features
function AIAssistant() {
  const { generateResponse } = useAI()

  return (
    <div>
      <Input placeholder="Ask me anything..." />
      <Button onClick={generateResponse}>
        Generate
      </Button>
    </div>
  )
}
```

## 📚 Documentation

- [Component Library](./docs/components.md)
- [API Reference](./docs/api.md)
- [Migration Guide](./docs/migration.md)
- [Contributing](./docs/contributing.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests and documentation
5. Submit a pull request

## 📄 License

Apache 2.0
