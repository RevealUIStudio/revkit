// Test PGlite database integration
import { electricRepositories } from './src/database/electric-repositories.js';

async function testPGlite() {
  try {
    console.log('Testing PGlite database...');

    // Test finding users
    const users = await electricRepositories.users.findAll(10, 0);
    console.log('Users found:', users.length);
    console.log('First user:', users[0]);

    // Test finding admin user
    const admin = await electricRepositories.users.findByEmail('admin@example.com');
    console.log('Admin user:', admin);

    // Test content
    const content = await electricRepositories.content.findAll(10, 0);
    console.log('Content items:', content.length);

    console.log('✅ PGlite database working correctly!');
  } catch (error) {
    console.error('❌ PGlite test failed:', error);
  }
}

testPGlite();
