import { Button } from '@revealui/core'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto py-12 px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            RevealUI Core Framework
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Modern React 19 + Next.js 16 framework for building web applications
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg">Get Started</Button>
            <Button variant="outline" size="lg">View Components</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white shadow rounded-lg p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              ⚛️
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">React 19</h3>
            <p className="text-gray-600">
              Latest React with concurrent features, modern hooks, and optimized rendering
            </p>
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              🚀
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Next.js 16</h3>
            <p className="text-gray-600">
              App Router, Server Components, and advanced caching capabilities
            </p>
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              🎨
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Component Library</h3>
            <p className="text-gray-600">
              50+ pre-built components with TypeScript and Tailwind CSS
            </p>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Component Showcase</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Buttons</h3>
              <div className="flex flex-wrap gap-2">
                <Button>Primary</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="outline">Outline</Button>
                <Button variant="ghost">Ghost</Button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Button Sizes</h3>
              <div className="flex flex-col gap-2">
                <Button size="sm">Small Button</Button>
                <Button size="md">Medium Button</Button>
                <Button size="lg">Large Button</Button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">States</h3>
              <div className="flex flex-col gap-2">
                <Button disabled>Disabled</Button>
                <Button className="bg-red-600 hover:bg-red-700">Custom</Button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Framework Status</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">React:</span>
                <span className="text-green-600 font-medium">✅ v19.2.3</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Next.js:</span>
                <span className="text-green-600 font-medium">✅ v16.0.10</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">TypeScript:</span>
                <span className="text-green-600 font-medium">✅ v5.9.3</span>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Components:</span>
                <span className="text-blue-600 font-medium">🚧 Building</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Forms:</span>
                <span className="text-yellow-600 font-medium">⏳ Planned</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">API Client:</span>
                <span className="text-yellow-600 font-medium">⏳ Planned</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
