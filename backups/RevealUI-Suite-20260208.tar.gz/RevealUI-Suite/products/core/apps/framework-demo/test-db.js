// Quick test of the database
import { electricRepositories } from './src/database/electric-repositories.js';

async function test() {
  console.log('Testing database...');

  // Create a test user
  const user = await electricRepositories.users.create({
    username: 'testuser',
    email: 'test@example.com',
    password: 'test123',
    role: 'user'
  });

  console.log('Created user:', user);

  // Find the user
  const found = await electricRepositories.users.findByEmail('test@example.com');
  console.log('Found user:', found);

  // List all users
  const all = await electricRepositories.users.findAll();
  console.log('All users:', all.length);
}

test().catch(console.error);
