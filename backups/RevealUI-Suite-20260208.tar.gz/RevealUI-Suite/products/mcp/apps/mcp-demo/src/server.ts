#!/usr/bin/env tsx

import { RevealUIMCPServer } from '@revealui/mcp'

async function main() {
  console.log('🚀 Starting RevealUI MCP Server...')

  const server = new RevealUIMCPServer(3002)

  server.on('listening', ({ port, hostname }) => {
    console.log(`✅ MCP Server listening on ws://${hostname}:${port}`)
    console.log('📋 Available tools:')
    console.log('  - analyze_code: Analyze code for issues and improvements')
    console.log('  - review_pull_request: Review pull requests for quality')
    console.log('📚 Available resources:')
    console.log('  - revealui://docs: RevealUI documentation')
    console.log('  - revealui://tools: Available tools list')
  })

  server.on('clientConnected', (address) => {
    console.log(`🔗 Client connected from ${address}`)
  })

  server.on('clientDisconnected', (address) => {
    console.log(`🔌 Client disconnected from ${address}`)
  })

  server.on('error', (error) => {
    console.error('❌ Server error:', error)
  })

  try {
    await server.start()

    // Graceful shutdown
    process.on('SIGINT', () => {
      console.log('\n🛑 Shutting down MCP Server...')
      server.stop()
      process.exit(0)
    })

    process.on('SIGTERM', () => {
      console.log('\n🛑 Shutting down MCP Server...')
      server.stop()
      process.exit(0)
    })

  } catch (error) {
    console.error('❌ Failed to start MCP Server:', error)
    process.exit(1)
  }
}

main().catch(console.error)
