import { NextRequest, NextResponse } from 'next/server'
import { CodeReviewAgent } from '@revealui/mcp'

const codeReviewAgent = new CodeReviewAgent()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { code, language, filename, options } = body

    if (!code || !language) {
      return NextResponse.json(
        { error: 'Code and language are required' },
        { status: 400 }
      )
    }

    // Execute the code analysis tool
    const results = await codeReviewAgent.executeTool('analyze_code', {
      code,
      language,
      filename,
      options
    })

    // Extract the analysis text from the tool results
    const analysis = results.find(result => result.type === 'text')?.text || 'No analysis available'

    return NextResponse.json({
      success: true,
      analysis,
      language,
      filename
    })
  } catch (error) {
    console.error('Code analysis error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Analysis failed'
      },
      { status: 500 }
    )
  }
}
