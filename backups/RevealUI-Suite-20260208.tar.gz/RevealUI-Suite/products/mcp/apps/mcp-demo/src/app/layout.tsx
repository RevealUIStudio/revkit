import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'RevealUI MCP Platform',
  description: 'AI-Powered Development with Model Context Protocol',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen bg-gray-50">
          <header className="bg-white shadow">
            <div className="mx-auto max-w-6xl px-4 py-6">
              <h1 className="text-2xl font-bold text-gray-900">
                RevealUI MCP Platform
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                AI Orchestration & Model Context Protocol
              </p>
            </div>
          </header>
          <main>
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
