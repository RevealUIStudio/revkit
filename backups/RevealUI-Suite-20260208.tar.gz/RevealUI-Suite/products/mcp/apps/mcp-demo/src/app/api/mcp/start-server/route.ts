import { NextResponse } from 'next/server'
import { spawn } from 'child_process'

let serverProcess: any = null

export async function POST() {
  try {
    if (serverProcess) {
      return NextResponse.json({
        success: true,
        message: 'MCP Server is already running'
      })
    }

    // Start the MCP server as a child process
    serverProcess = spawn('npx', ['tsx', 'src/server.ts'], {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore'
    })

    serverProcess.unref()

    // Give the server a moment to start
    await new Promise(resolve => setTimeout(resolve, 1000))

    return NextResponse.json({
      success: true,
      message: 'MCP Server started successfully',
      port: 3002
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to start MCP Server'
      },
      { status: 500 }
    )
  }
}
