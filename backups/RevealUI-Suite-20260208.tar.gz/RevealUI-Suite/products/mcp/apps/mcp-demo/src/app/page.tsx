'use client'

import { useState } from 'react'
import { Button } from '@revealui/core'

export default function Home() {
  const [code, setCode] = useState(`function calculateTotal(items) {
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    total += items[i].price * items[i].quantity;
  }
  console.log('Total calculated:', total);
  return total;
}`)

  const [analysis, setAnalysis] = useState<string>('')
  const [loading, setLoading] = useState(false)
  const [serverRunning, setServerRunning] = useState(false)

  const startServer = async () => {
    try {
      const response = await fetch('/api/mcp/start-server', {
        method: 'POST'
      })
      if (response.ok) {
        setServerRunning(true)
      }
    } catch (error) {
      console.error('Failed to start server:', error)
    }
  }

  const analyzeCode = async () => {
    setLoading(true)
    setAnalysis('')

    try {
      const response = await fetch('/api/mcp/analyze-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code,
          language: 'javascript',
          filename: 'example.js'
        })
      })

      if (response.ok) {
        const result = await response.json()
        setAnalysis(result.analysis || 'Analysis completed')
      } else {
        setAnalysis('Error: Failed to analyze code')
      }
    } catch (error) {
      setAnalysis(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            RevealUI MCP Platform
          </h1>
          <p className="text-gray-600 mb-4">
            AI-Powered Development with Model Context Protocol
          </p>

          <div className="flex gap-4 mb-4">
            <Button
              onClick={startServer}
              disabled={serverRunning}
              variant={serverRunning ? "secondary" : "primary"}
            >
              {serverRunning ? '✅ MCP Server Running' : '🚀 Start MCP Server'}
            </Button>
            <Button onClick={analyzeCode} disabled={loading || !serverRunning}>
              {loading ? '🔄 Analyzing...' : '🔍 Analyze Code'}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-800">🤖 AI Agents</h3>
              <p className="text-blue-600 text-sm">Code review and analysis agents</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold text-green-800">🔧 Tools</h3>
              <p className="text-green-600 text-sm">Automated code analysis tools</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold text-purple-800">📡 MCP Protocol</h3>
              <p className="text-purple-600 text-sm">Standardized AI model interactions</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Code to Analyze</h2>
            <textarea
              className="w-full h-64 p-3 border border-gray-300 rounded-md font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Paste your code here for AI analysis..."
            />
            <div className="mt-4 text-sm text-gray-500">
              Supports JavaScript, TypeScript, Python, and more
            </div>
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Analysis Results</h2>
            {analysis ? (
              <div className="h-64 overflow-auto">
                <pre className="whitespace-pre-wrap text-sm text-gray-800 font-mono bg-gray-50 p-3 rounded">
                  {analysis}
                </pre>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <div className="text-4xl mb-2">🔍</div>
                  <p>Click "Analyze Code" to get AI-powered insights</p>
                  <p className="text-sm mt-2">The analysis will check for bugs, style issues, and suggest improvements</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">MCP Capabilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">🤖 Available Agents</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><strong>Code Review Agent:</strong> Analyzes code quality and suggests improvements</li>
                <li><strong>Security Agent:</strong> Identifies potential security vulnerabilities</li>
                <li><strong>Performance Agent:</strong> Optimizes code for better performance</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">🔧 Tools & Resources</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><strong>analyze_code:</strong> Comprehensive code analysis</li>
                <li><strong>review_pull_request:</strong> PR review automation</li>
                <li><strong>RevealUI Docs:</strong> Integrated documentation</li>
                <li><strong>Tool Registry:</strong> Available capabilities listing</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">🚀 Integration Ready</h4>
            <p className="text-sm text-gray-600 mb-3">
              The MCP platform integrates seamlessly with RevealUI Core and Content products:
            </p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• <strong>Core Framework:</strong> AI-enhanced React components</li>
              <li>• <strong>Content Engine:</strong> Automated content generation and review</li>
              <li>• <strong>Cross-Product:</strong> Unified AI capabilities across the suite</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
