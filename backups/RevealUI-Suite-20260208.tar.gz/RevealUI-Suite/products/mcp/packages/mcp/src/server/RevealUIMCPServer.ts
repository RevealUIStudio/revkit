import { MCPServer } from './MCPServer.js'
import { CodeReviewAgent } from '../agents/CodeReviewAgent.js'
import { Tool, Resource, ToolContent, ResourceContent } from '../types/protocol.js'

export class RevealUIMCPServer extends MCPServer {
  private codeReviewAgent: CodeReviewAgent
  private resources: Resource[] = []

  constructor(port = 3001) {
    super({
      port,
      serverInfo: {
        name: 'RevealUI MCP Server',
        version: '0.1.0'
      },
      serverCapabilities: {
        tools: {
          listChanged: true
        },
        resources: {
          listChanged: true
        }
      }
    })

    this.codeReviewAgent = new CodeReviewAgent()

    // Initialize resources
    this.resources = [
      {
        uri: 'revealui://docs',
        name: 'RevealUI Documentation',
        description: 'Documentation and guides for RevealUI products',
        mimeType: 'text/markdown'
      },
      {
        uri: 'revealui://tools',
        name: 'Available Tools',
        description: 'List of available MCP tools and their capabilities',
        mimeType: 'application/json'
      }
    ]
  }

  getAvailableTools(): Tool[] {
    return this.codeReviewAgent.getTools()
  }

  async executeTool(name: string, args?: Record<string, any>): Promise<ToolContent[]> {
    return await this.codeReviewAgent.executeTool(name, args)
  }

  getAvailableResources(): Resource[] {
    return this.resources
  }

  async readResource(uri: string): Promise<ResourceContent[]> {
    switch (uri) {
      case 'revealui://docs':
        return [{
          uri,
          mimeType: 'text/markdown',
          text: `# RevealUI Documentation

Welcome to the RevealUI Suite documentation.

## Products

### Core Framework
- React/Next.js framework with components
- TypeScript-first development
- Modern build tools

### Content Engine
- Headless CMS for content management
- API-first architecture
- Rich text editing

### MCP Platform
- AI orchestration and automation
- Code review and analysis
- Model Context Protocol implementation

## Getting Started

Visit the individual product documentation for detailed guides.
`
        }]

      case 'revealui://tools':
        const tools = this.getAvailableTools()
        return [{
          uri,
          mimeType: 'application/json',
          text: JSON.stringify({ tools }, null, 2)
        }]

      default:
        throw new Error(`Resource not found: ${uri}`)
    }
  }
}
