import { Tool, ToolContent } from '../types/protocol.js'
import { Result, ResultUtil } from '@revealui/foundation'

export interface CodeReviewOptions {
  language?: string
  framework?: string
  rules?: string[]
}

export interface CodeReviewResult {
  score: number // 0-100
  issues: CodeIssue[]
  suggestions: CodeSuggestion[]
  summary: string
}

export interface CodeIssue {
  type: 'error' | 'warning' | 'info'
  message: string
  line?: number
  column?: number
  rule?: string
  severity: 'low' | 'medium' | 'high' | 'critical'
}

export interface CodeSuggestion {
  type: 'refactor' | 'optimization' | 'security' | 'performance' | 'maintainability'
  title: string
  description: string
  code?: string
  line?: number
}

export class CodeReviewAgent {
  private tools: Tool[]

  constructor() {
    this.tools = [
      {
        name: 'analyze_code',
        description: 'Analyze code for issues, bugs, and improvements',
        inputSchema: {
          type: 'object',
          properties: {
            code: {
              type: 'string',
              description: 'The code to analyze'
            },
            language: {
              type: 'string',
              description: 'Programming language (typescript, javascript, python, etc.)',
              enum: ['typescript', 'javascript', 'python', 'rust', 'go', 'java']
            },
            filename: {
              type: 'string',
              description: 'Name of the file being analyzed'
            },
            options: {
              type: 'object',
              description: 'Additional analysis options',
              properties: {
                framework: {
                  type: 'string',
                  description: 'Framework being used (react, nextjs, node, etc.)'
                },
                rules: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Specific rules to check'
                }
              }
            }
          },
          required: ['code', 'language']
        }
      },
      {
        name: 'review_pull_request',
        description: 'Review a pull request for code quality and best practices',
        inputSchema: {
          type: 'object',
          properties: {
            title: {
              type: 'string',
              description: 'Pull request title'
            },
            description: {
              type: 'string',
              description: 'Pull request description'
            },
            changedFiles: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  filename: { type: 'string' },
                  language: { type: 'string' },
                  code: { type: 'string' },
                  status: { type: 'string', enum: ['added', 'modified', 'deleted'] }
                }
              },
              description: 'Files changed in the pull request'
            }
          },
          required: ['changedFiles']
        }
      }
    ]
  }

  getTools(): Tool[] {
    return this.tools
  }

  async executeTool(name: string, args?: Record<string, any>): Promise<ToolContent[]> {
    switch (name) {
      case 'analyze_code':
        if (!args || typeof args.code !== 'string' || typeof args.language !== 'string') {
          throw new Error('Invalid arguments for analyze_code tool')
        }
        return await this.analyzeCode(args as {
          code: string
          language: string
          filename?: string
          options?: CodeReviewOptions
        })
      case 'review_pull_request':
        if (!args || !Array.isArray(args.changedFiles)) {
          throw new Error('Invalid arguments for review_pull_request tool')
        }
        return await this.reviewPullRequest(args as {
          title?: string
          description?: string
          changedFiles: Array<{
            filename: string
            language: string
            code: string
            status: 'added' | 'modified' | 'deleted'
          }>
        })
      default:
        throw new Error(`Unknown tool: ${name}`)
    }
  }

  private async analyzeCode(args: {
    code: string
    language: string
    filename?: string
    options?: CodeReviewOptions
  }): Promise<ToolContent[]> {
    const { code, language, filename, options } = args

    try {
      const result = await this.performCodeAnalysis(code, language, filename, options)

      const content: ToolContent[] = [
        {
          type: 'text',
          text: `## Code Review Results\n\n**Score: ${result.score}/100**\n\n${result.summary}\n\n### Issues Found (${result.issues.length})\n\n${
            result.issues.map(issue =>
              `- **${issue.type.toUpperCase()}** (${issue.severity}): ${issue.message}${issue.line ? ` (line ${issue.line})` : ''}`
            ).join('\n')
          }\n\n### Suggestions (${result.suggestions.length})\n\n${
            result.suggestions.map(suggestion =>
              `#### ${suggestion.title}\n${suggestion.description}${suggestion.code ? `\n\n\`\`\`\n${suggestion.code}\n\`\`\`` : ''}`
            ).join('\n\n')
          }`
        }
      ]

      return content
    } catch (error) {
      return [{
        type: 'text',
        text: `Error analyzing code: ${error instanceof Error ? error.message : 'Unknown error'}`
      }]
    }
  }

  private async reviewPullRequest(args: {
    title?: string
    description?: string
    changedFiles: Array<{
      filename: string
      language: string
      code: string
      status: 'added' | 'modified' | 'deleted'
    }>
  }): Promise<ToolContent[]> {
    const { title, description, changedFiles } = args

    try {
      const fileReviews = await Promise.all(
        changedFiles.map(async (file) => {
          if (file.status === 'deleted') return null
          return await this.performCodeAnalysis(file.code, file.language, file.filename)
        })
      )

      const validReviews = fileReviews.filter(review => review !== null) as CodeReviewResult[]
      const averageScore = validReviews.length > 0
        ? Math.round(validReviews.reduce((sum, review) => sum + review.score, 0) / validReviews.length)
        : 100

      const allIssues = validReviews.flatMap(review => review.issues)
      const allSuggestions = validReviews.flatMap(review => review.suggestions)

      const content: ToolContent[] = [
        {
          type: 'text',
          text: `## Pull Request Review\n\n**Title:** ${title || 'Untitled'}\n**Overall Score:** ${averageScore}/100\n\n### Summary\n\nReviewed ${changedFiles.length} files with ${allIssues.length} issues found and ${allSuggestions.length} suggestions provided.\n\n### Files Reviewed\n\n${
            changedFiles.map(file => `- **${file.filename}** (${file.language}) - ${file.status}`).join('\n')
          }\n\n### Key Issues\n\n${
            allIssues.slice(0, 10).map(issue =>
              `- **${issue.type.toUpperCase()}** in ${issue.rule || 'unknown'}: ${issue.message}`
            ).join('\n')
          }\n\n### Top Suggestions\n\n${
            allSuggestions.slice(0, 5).map(suggestion =>
              `- **${suggestion.type}**: ${suggestion.title}`
            ).join('\n')
          }`
        }
      ]

      return content
    } catch (error) {
      return [{
        type: 'text',
        text: `Error reviewing pull request: ${error instanceof Error ? error.message : 'Unknown error'}`
      }]
    }
  }

  private async performCodeAnalysis(
    code: string,
    language: string,
    filename?: string,
    options?: CodeReviewOptions
  ): Promise<CodeReviewResult> {
    // This is a simplified implementation
    // In a real implementation, this would use AI models, linters, etc.
    const issues: CodeIssue[] = []
    const suggestions: CodeSuggestion[] = []

    // Basic analysis based on language
    switch (language.toLowerCase()) {
      case 'typescript':
      case 'javascript':
        issues.push(...this.analyzeJavaScript(code, filename))
        suggestions.push(...this.suggestJavaScript(code, filename))
        break
      case 'python':
        issues.push(...this.analyzePython(code, filename))
        suggestions.push(...this.suggestPython(code, filename))
        break
      default:
        suggestions.push({
          type: 'maintainability',
          title: 'Consider adding language-specific analysis',
          description: `Add analysis rules for ${language} code`
        })
    }

    // Calculate score based on issues
    const baseScore = 100
    const issuePenalty = issues.reduce((penalty, issue) => {
      switch (issue.severity) {
        case 'critical': return penalty + 20
        case 'high': return penalty + 10
        case 'medium': return penalty + 5
        case 'low': return penalty + 1
        default: return penalty + 2
      }
    }, 0)

    const score = Math.max(0, Math.min(100, baseScore - issuePenalty))

    const summary = issues.length === 0
      ? 'Code looks good! No major issues found.'
      : `Found ${issues.length} issue(s) that should be addressed.`

    return {
      score,
      issues,
      suggestions,
      summary
    }
  }

  private analyzeJavaScript(code: string, filename?: string): CodeIssue[] {
    const issues: CodeIssue[] = []

    // Check for console.log statements
    if (code.includes('console.log')) {
      issues.push({
        type: 'warning',
        message: 'console.log statements should be removed in production',
        severity: 'medium',
        rule: 'no-console'
      })
    }

    // Check for any statements
    if (code.includes('any')) {
      issues.push({
        type: 'info',
        message: 'Consider using more specific types instead of `any`',
        severity: 'low',
        rule: 'no-any'
      })
    }

    // Check for long functions
    const functionMatches = code.match(/function\s+\w+\s*\([^)]*\)\s*{[^}]*}/g) || []
    functionMatches.forEach(match => {
      if (match.length > 200) {
        issues.push({
          type: 'info',
          message: 'Function is quite long, consider breaking it down',
          severity: 'low',
          rule: 'function-length'
        })
      }
    })

    return issues
  }

  private suggestJavaScript(code: string, filename?: string): CodeSuggestion[] {
    const suggestions: CodeSuggestion[] = []

    // Suggest using const/let instead of var
    if (code.includes('var ')) {
      suggestions.push({
        type: 'refactor',
        title: 'Use const/let instead of var',
        description: 'Replace var declarations with const or let for better scoping',
        code: 'const/let variableName = value;'
      })
    }

    // Suggest adding error handling
    if (code.includes('fetch(') && !code.includes('catch')) {
      suggestions.push({
        type: 'maintainability',
        title: 'Add error handling for async operations',
        description: 'Wrap fetch calls in try-catch blocks or use .catch()',
        code: 'try {\n  const response = await fetch(url);\n} catch (error) {\n  console.error(error);\n}'
      })
    }

    // Suggest using early returns
    if (code.includes('if') && code.includes('return') && code.match(/if\s*\([^)]+\)\s*{\s*return\s+[^}]+}/)) {
      suggestions.push({
        type: 'refactor',
        title: 'Consider early returns',
        description: 'Use early returns to reduce nesting and improve readability'
      })
    }

    return suggestions
  }

  private analyzePython(code: string, filename?: string): CodeIssue[] {
    const issues: CodeIssue[] = []

    // Check for print statements
    if (code.includes('print(')) {
      issues.push({
        type: 'warning',
        message: 'print statements should be replaced with proper logging',
        severity: 'medium',
        rule: 'no-print'
      })
    }

    return issues
  }

  private suggestPython(code: string, filename?: string): CodeSuggestion[] {
    const suggestions: CodeSuggestion[] = []

    suggestions.push({
      type: 'maintainability',
      title: 'Add type hints',
      description: 'Consider adding type hints for better code documentation and IDE support',
      code: 'def function_name(param: str) -> int:\n    return len(param)'
    })

    return suggestions
  }
}