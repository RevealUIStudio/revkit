// MCP Protocol Types - Based on Model Context Protocol specification

export interface MCPMessage {
  jsonrpc: "2.0"
  id?: string | number
  method?: string
  params?: any
  result?: any
  error?: MCPError
}

export interface MCPError {
  code: number
  message: string
  data?: any
}

export interface MCPRequest extends MCPMessage {
  id: string | number
  method: string
  params?: any
}

export interface MCPResponse extends MCPMessage {
  id: string | number
  result?: any
  error?: MCPError
}

export interface MCPNotification extends MCPMessage {
  method: string
  params?: any
}

// MCP Protocol Methods
export type MCPMethod =
  | "initialize"
  | "initialized"
  | "ping"
  | "tools/list"
  | "tools/call"
  | "resources/list"
  | "resources/read"
  | "resources/subscribe"
  | "resources/unsubscribe"
  | "logging/setLevel"

// Initialize Protocol
export interface InitializeRequest {
  method: "initialize"
  params: {
    protocolVersion: string
    capabilities: ClientCapabilities
    clientInfo: ClientInfo
  }
}

export interface InitializeResponse {
  protocolVersion: string
  capabilities: ServerCapabilities
  serverInfo: ServerInfo
}

// Capabilities
export interface ClientCapabilities {
  sampling?: {}
  experimental?: Record<string, any>
}

export interface ServerCapabilities {
  logging?: {}
  prompts?: {
    listChanged?: boolean
  }
  resources?: {
    subscribe?: boolean
    listChanged?: boolean
  }
  tools?: {
    listChanged?: boolean
  }
  experimental?: Record<string, any>
}

// Client/Server Info
export interface ClientInfo {
  name: string
  version: string
}

export interface ServerInfo {
  name: string
  version: string
}

// Tools Protocol
export interface Tool {
  name: string
  description: string
  inputSchema: {
    type: "object"
    properties?: Record<string, any>
    required?: string[]
  }
}

export interface ListToolsRequest {
  method: "tools/list"
  params?: {
    cursor?: string
  }
}

export interface ListToolsResponse {
  tools: Tool[]
  nextCursor?: string
}

export interface CallToolRequest {
  method: "tools/call"
  params: {
    name: string
    arguments?: Record<string, any>
  }
}

export interface CallToolResponse {
  content: ToolContent[]
  isError?: boolean
}

export interface ToolContent {
  type: "text" | "image" | "resource"
  text?: string
  image?: {
    data: string
    mimeType: string
  }
  resource?: {
    uri: string
    mimeType?: string
  }
}

// Resources Protocol
export interface Resource {
  uri: string
  mimeType?: string
  name?: string
  description?: string
}

export interface ListResourcesRequest {
  method: "resources/list"
  params?: {
    cursor?: string
  }
}

export interface ListResourcesResponse {
  resources: Resource[]
  nextCursor?: string
}

export interface ReadResourceRequest {
  method: "resources/read"
  params: {
    uri: string
  }
}

export interface ReadResourceResponse {
  contents: ResourceContent[]
}

export interface ResourceContent {
  uri: string
  mimeType?: string
  text?: string
  blob?: string
}

// Logging Protocol
export type LogLevel = "debug" | "info" | "notice" | "warning" | "error" | "critical" | "alert" | "emergency"

export interface SetLogLevelRequest {
  method: "logging/setLevel"
  params: {
    level: LogLevel
  }
}
