import { WebSocket } from 'ws'
import { MCPProtocol } from '../protocol/MCPProtocol.js'
import {
  MCPMessage,
  ClientCapabilities,
  ClientInfo,
  ServerCapabilities,
  ServerInfo,
  Tool,
  Resource,
  ToolContent
} from '../types/protocol.js'

export class MCPClient extends MCPProtocol {
  private ws: WebSocket | null = null
  private serverInfo: ServerInfo | null = null
  private serverCapabilities: ServerCapabilities | null = null

  constructor() {
    super()
  }

  async connect(url: string, clientInfo: ClientInfo, clientCapabilities: ClientCapabilities = {}): Promise<void> {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(url)

      this.ws.on('open', async () => {
        try {
          // Initialize the connection
          const result = await this.initialize(clientInfo, clientCapabilities)
          this.serverInfo = result.serverInfo
          this.serverCapabilities = result.serverCapabilities

          // Send initialized notification
          this.sendInitialized()

          this.emit('connected', { serverInfo: this.serverInfo, serverCapabilities: this.serverCapabilities })
          resolve()
        } catch (error) {
          reject(error)
        }
      })

      this.ws.on('message', (data: Buffer) => {
        try {
          const message: MCPMessage = JSON.parse(data.toString())
          this.handleMessage(message)
        } catch (error) {
          this.emit('error', error)
        }
      })

      this.ws.on('error', (error) => {
        this.emit('error', error)
        reject(error)
      })

      this.ws.on('close', () => {
        this.emit('disconnected')
        this.ws = null
      })
    })
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
  }

  // Tool methods
  async listTools(): Promise<Tool[]> {
    if (!this.serverCapabilities?.tools) {
      throw new Error('Server does not support tools')
    }

    const result = await this.request('tools/list')
    return result.tools || []
  }

  async callTool(name: string, args?: Record<string, any>): Promise<ToolContent[]> {
    if (!this.serverCapabilities?.tools) {
      throw new Error('Server does not support tools')
    }

    const result = await this.request('tools/call', { name, arguments: args })
    return result.content || []
  }

  // Resource methods
  async listResources(): Promise<Resource[]> {
    if (!this.serverCapabilities?.resources) {
      throw new Error('Server does not support resources')
    }

    const result = await this.request('resources/list')
    return result.resources || []
  }

  async readResource(uri: string): Promise<any[]> {
    if (!this.serverCapabilities?.resources) {
      throw new Error('Server does not support resources')
    }

    const result = await this.request('resources/read', { uri })
    return result.contents || []
  }

  // Getters
  getServerInfo(): ServerInfo | null {
    return this.serverInfo
  }

  getServerCapabilities(): ServerCapabilities | null {
    return this.serverCapabilities
  }

  isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN
  }

  protected sendMessage(message: MCPMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message))
    } else {
      throw new Error('WebSocket is not connected')
    }
    super.sendMessage(message)
  }

  protected async handleRequest(request: any): Promise<void> {
    // Client typically doesn't handle incoming requests
    // This could be extended for bidirectional communication
    this.emit('request', request)
  }

  protected async handleNotification(notification: any): Promise<void> {
    this.emit('notification', notification)
  }
}
