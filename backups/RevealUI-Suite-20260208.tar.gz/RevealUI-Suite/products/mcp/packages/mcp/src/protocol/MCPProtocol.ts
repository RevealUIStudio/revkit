import { EventEmitter } from 'events'
import {
  MCPMessage,
  MCPRequest,
  MCPResponse,
  MCPNotification,
  MCPError,
  ClientCapabilities,
  ServerCapabilities,
  ClientInfo,
  ServerInfo
} from '../types/protocol.js'

export abstract class MCPProtocol extends EventEmitter {
  protected nextId = 0
  protected pendingRequests = new Map<string | number, {
    resolve: (value: any) => void
    reject: (error: any) => void
    timeout: NodeJS.Timeout
  }>()

  constructor() {
    super()
  }

  protected generateId(): string {
    return `req_${++this.nextId}_${Date.now()}`
  }

  protected createRequest(method: string, params?: any): MCPRequest {
    return {
      jsonrpc: "2.0",
      id: this.generateId(),
      method,
      params
    }
  }

  protected createNotification(method: string, params?: any): MCPNotification {
    return {
      jsonrpc: "2.0",
      method,
      params
    }
  }

  protected createResponse(id: string | number, result?: any, error?: MCPError): MCPResponse {
    return {
      jsonrpc: "2.0",
      id,
      result,
      error
    }
  }

  protected sendMessage(message: MCPMessage): void {
    this.emit('message', message)
  }

  protected handleMessage(message: MCPMessage): void {
    if ('id' in message && 'result' in message || 'error' in message) {
      // This is a response
      this.handleResponse(message as MCPResponse)
    } else if ('method' in message) {
      // This is a request or notification
      if ('id' in message) {
        this.handleRequest(message as MCPRequest)
      } else {
        this.handleNotification(message as MCPNotification)
      }
    }
  }

  protected handleResponse(response: MCPResponse): void {
    const pending = this.pendingRequests.get(response.id)
    if (pending) {
      this.pendingRequests.delete(response.id)
      clearTimeout(pending.timeout)

      if (response.error) {
        pending.reject(response.error)
      } else {
        pending.resolve(response.result)
      }
    }
  }

  protected abstract handleRequest(request: MCPRequest): Promise<void>
  protected abstract handleNotification(notification: MCPNotification): Promise<void>

  async request(method: string, params?: any, timeout = 30000): Promise<any> {
    const request = this.createRequest(method, params)

    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingRequests.delete(request.id!)
        reject(new Error(`Request timeout: ${method}`))
      }, timeout)

      this.pendingRequests.set(request.id!, {
        resolve,
        reject,
        timeout: timeoutId
      })

      this.sendMessage(request)
    })
  }

  notify(method: string, params?: any): void {
    const notification = this.createNotification(method, params)
    this.sendMessage(notification)
  }

  // Protocol lifecycle
  async initialize(clientInfo: ClientInfo, clientCapabilities: ClientCapabilities): Promise<{
    serverInfo: ServerInfo
    serverCapabilities: ServerCapabilities
  }> {
    const result = await this.request('initialize', {
      protocolVersion: "2024-11-05",
      capabilities: clientCapabilities,
      clientInfo
    })

    return {
      serverInfo: result.serverInfo,
      serverCapabilities: result.capabilities
    }
  }

  sendInitialized(): void {
    this.notify('initialized', {})
  }

  async ping(): Promise<void> {
    await this.request('ping')
  }
}
