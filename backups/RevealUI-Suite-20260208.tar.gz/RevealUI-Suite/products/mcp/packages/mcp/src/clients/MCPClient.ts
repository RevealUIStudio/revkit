import { Result, ResultUtil } from '@revealui/foundation'
import { MCPProtocol } from '../protocol/MCPProtocol.js'
import { Agent, MCPMessage, CodeReviewRequest, CodeReviewResult } from '../types/mcp.js'

export class MCPClient {
  private protocol = new MCPProtocol()
  private agents = new Map<string, Agent>()

  constructor() {
    // Register built-in agents
    this.registerAgent(new (await import('../agents/CodeReviewAgent.js')).CodeReviewAgent())
  }

  /**
   * Register an agent with the MCP client
   */
  registerAgent(agent: Agent): void {
    this.agents.set(agent.name, agent)
  }

  /**
   * Get all registered agents
   */
  getAgents(): Agent[] {
    return Array.from(this.agents.values())
  }

  /**
   * Get a specific agent by name
   */
  getAgent(name: string): Agent | undefined {
    return this.agents.get(name)
  }

  /**
   * Send a message to an agent (simulated - in real implementation would use WebSocket/networking)
   */
  async sendMessage(agentName: string, method: string, params: any): Promise<Result<any, Error>> {
    const agent = this.agents.get(agentName)
    if (!agent) {
      return ResultUtil.err(new Error(`Agent '${agentName}' not found`))
    }

    try {
      // Simulate message sending through MCP protocol
      const message = this.protocol.createRequest(method, params)

      // Route to appropriate agent method
      switch (method) {
        case 'analyze_code':
          return await agent.config.tools
            .find(tool => tool.name === 'analyze_code')
            ?.handler(params) || ResultUtil.err(new Error('Tool not found'))

        case 'analyze_security':
          return await agent.config.tools
            .find(tool => tool.name === 'analyze_security')
            ?.handler(params) || ResultUtil.err(new Error('Tool not found'))

        case 'analyze_performance':
          return await agent.config.tools
            .find(tool => tool.name === 'analyze_performance')
            ?.handler(params) || ResultUtil.err(new Error('Tool not found'))

        default:
          return ResultUtil.err(new Error(`Unknown method: ${method}`))
      }
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }

  /**
   * Convenience method for code review
   */
  async reviewCode(request: CodeReviewRequest): Promise<Result<CodeReviewResult, Error>> {
    return await this.sendMessage('code-review-agent', 'analyze_code', request) as Result<CodeReviewResult, Error>
  }

  /**
   * Convenience method for security analysis
   */
  async analyzeSecurity(code: string, language: string): Promise<Result<any, Error>> {
    return await this.sendMessage('code-review-agent', 'analyze_security', { code, language })
  }

  /**
   * Convenience method for performance analysis
   */
  async analyzePerformance(code: string, language: string): Promise<Result<any, Error>> {
    return await this.sendMessage('code-review-agent', 'analyze_performance', { code, language })
  }

  /**
   * Get agent status information
   */
  getStatus(): {
    agents: Array<{
      name: string
      status: string
      capabilities: string[]
    }>
    protocol: 'mcp-1.0'
  } {
    return {
      agents: Array.from(this.agents.values()).map(agent => ({
        name: agent.name,
        status: agent.status,
        capabilities: agent.capabilities
      })),
      protocol: 'mcp-1.0'
    }
  }
}
