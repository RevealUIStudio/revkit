import { WebSocketServer, WebSocket } from 'ws'
import { IncomingMessage } from 'http'
import { MCPProtocol } from '../protocol/MCPProtocol.js'
import {
  MCPRequest,
  MCPNotification,
  ServerCapabilities,
  ServerInfo,
  Tool,
  Resource,
  ToolContent,
  ResourceContent
} from '../types/protocol.js'

export interface MCPServerOptions {
  port?: number
  hostname?: string
  serverInfo: ServerInfo
  serverCapabilities: ServerCapabilities
}

export abstract class MCPServer extends MCPProtocol {
  private wss: WebSocketServer | null = null
  private clients = new Map<WebSocket, MCPProtocol>()
  private options: MCPServerOptions

  constructor(options: MCPServerOptions) {
    super()
    this.options = {
      port: 3001,
      hostname: 'localhost',
      ...options
    }
  }

  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.wss = new WebSocketServer({
        port: this.options.port
      })

      this.wss.on('listening', () => {
        this.emit('listening', {
          port: this.options.port,
          hostname: this.options.hostname
        })
        resolve()
      })

      this.wss.on('connection', (ws: WebSocket, request: IncomingMessage) => {
        this.handleConnection(ws, request)
      })

      this.wss.on('error', (error) => {
        this.emit('error', error)
        reject(error)
      })
    })
  }

  stop(): void {
    if (this.wss) {
      this.wss.close()
      this.wss = null
      this.clients.clear()
      this.emit('stopped')
    }
  }

  private handleConnection(ws: WebSocket, request: IncomingMessage): void {
    const clientProtocol = new MCPClientProtocol(ws, this)
    this.clients.set(ws, clientProtocol)

    ws.on('close', () => {
      this.clients.delete(ws)
      this.emit('clientDisconnected', request.socket.remoteAddress)
    })

    this.emit('clientConnected', request.socket.remoteAddress)
  }

  // Abstract methods for server implementations
  abstract getAvailableTools(): Tool[]
  abstract executeTool(name: string, args?: Record<string, any>): Promise<ToolContent[]>
  abstract getAvailableResources(): Resource[]
  abstract readResource(uri: string): Promise<ResourceContent[]>

  protected sendMessage(message: any): void {
    // Server sends messages through client protocols
    // This is handled by individual client connections
  }

  protected async handleRequest(request: MCPRequest): Promise<void> {
    let result: any = null
    let error: any = null

    try {
      switch (request.method) {
        case 'initialize':
          result = {
            protocolVersion: "2024-11-05",
            capabilities: this.options.serverCapabilities,
            serverInfo: this.options.serverInfo
          }
          break

        case 'ping':
          result = {}
          break

        case 'tools/list':
          result = {
            tools: this.getAvailableTools()
          }
          break

        case 'tools/call':
          if (!this.options.serverCapabilities.tools) {
            throw new Error('Tools not supported')
          }
          result = {
            content: await this.executeTool(request.params.name, request.params.arguments)
          }
          break

        case 'resources/list':
          if (!this.options.serverCapabilities.resources) {
            throw new Error('Resources not supported')
          }
          result = {
            resources: this.getAvailableResources()
          }
          break

        case 'resources/read':
          if (!this.options.serverCapabilities.resources) {
            throw new Error('Resources not supported')
          }
          result = {
            contents: await this.readResource(request.params.uri)
          }
          break

        default:
          throw new Error(`Unknown method: ${request.method}`)
      }
    } catch (err) {
      error = {
        code: -32000,
        message: err instanceof Error ? err.message : 'Internal error'
      }
    }

    // Send response back through the client protocol
    const response = this.createResponse(request.id, result, error)
    this.emit('response', request, response)
  }

  protected async handleNotification(notification: MCPNotification): Promise<void> {
    this.emit('notification', notification)
  }

  getClientsCount(): number {
    return this.clients.size
  }

  getServerInfo(): ServerInfo {
    return this.options.serverInfo
  }

  getServerCapabilities(): ServerCapabilities {
    return this.options.serverCapabilities
  }
}

// Internal client protocol handler
class MCPClientProtocol extends MCPProtocol {
  private ws: WebSocket
  private server: MCPServer

  constructor(ws: WebSocket, server: MCPServer) {
    super()
    this.ws = ws
    this.server = server

    ws.on('message', (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString())
        this.handleMessage(message)
      } catch (error) {
        this.emit('error', error)
      }
    })

    ws.on('error', (error) => {
      this.emit('error', error)
    })
  }

  protected sendMessage(message: any): void {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message))
    }
  }

  protected async handleRequest(request: MCPRequest): Promise<void> {
    // Forward to server
    await this.server['handleRequest'](request)
  }

  protected async handleNotification(notification: MCPNotification): Promise<void> {
    // Forward to server
    await this.server['handleNotification'](notification)
  }
}
