import { BaseEntity } from '@revealui/foundation'

// MCP Protocol Types
export interface MCPMessage {
  jsonrpc: '2.0'
  id?: string | number
  method?: string
  params?: any
  result?: any
  error?: MCPError
}

export interface MCPError {
  code: number
  message: string
  data?: any
}

export interface MCPRequest extends MCPMessage {
  id: string | number
  method: string
  params?: any
}

export interface MCPResponse extends MCPMessage {
  id: string | number
  result?: any
  error?: MCPError
}

export interface MCPNotification extends MCPMessage {
  method: string
  params?: any
}

// Agent Types
export interface Agent extends BaseEntity {
  name: string
  description: string
  capabilities: string[]
  status: 'idle' | 'active' | 'error'
  config: AgentConfig
}

export interface AgentConfig {
  model?: string
  temperature?: number
  maxTokens?: number
  tools: Tool[]
  instructions?: string
}

export interface Tool {
  name: string
  description: string
  inputSchema: {
    type: 'object'
    properties: Record<string, any>
    required?: string[]
  }
  handler: (params: any) => Promise<any>
}

// Workflow Types
export interface Workflow extends BaseEntity {
  name: string
  description: string
  steps: WorkflowStep[]
  status: 'draft' | 'active' | 'paused' | 'completed' | 'error'
  config: WorkflowConfig
}

export interface WorkflowStep {
  id: string
  agentId: string
  toolName: string
  params: any
  dependsOn?: string[]
  retryPolicy?: {
    maxAttempts: number
    backoffMs: number
  }
}

export interface WorkflowConfig {
  timeout?: number
  parallelExecution?: boolean
  errorHandling?: 'fail' | 'continue' | 'retry'
}

// Session Types
export interface MCPSession extends BaseEntity {
  clientId: string
  status: 'connecting' | 'connected' | 'disconnected' | 'error'
  capabilities: string[]
  metadata: Record<string, any>
}

// Code Review Types
export interface CodeReviewRequest {
  code: string
  language: string
  filename?: string
  context?: string
}

export interface CodeReviewResult {
  issues: CodeIssue[]
  suggestions: CodeSuggestion[]
  score: number
  summary: string
}

export interface CodeIssue {
  type: 'error' | 'warning' | 'info'
  message: string
  line?: number
  column?: number
  rule?: string
}

export interface CodeSuggestion {
  type: 'improvement' | 'fix' | 'optimization'
  description: string
  code?: string
  line?: number
}

// Integration Types
export interface MCPIntegration {
  id: string
  name: string
  type: 'core' | 'content' | 'external'
  endpoint: string
  capabilities: string[]
  status: 'active' | 'inactive' | 'error'
}