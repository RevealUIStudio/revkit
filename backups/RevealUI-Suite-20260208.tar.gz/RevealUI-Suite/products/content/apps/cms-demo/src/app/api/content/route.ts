import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { ContentService } from '@revealui/content'

// Content validation schema
const contentSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200, 'Title too long'),
  body: z.string().min(1, 'Content is required'),
  excerpt: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).default('draft'),
  tags: z.array(z.string()).optional(),
  author: z.string().optional(),
})

// GET /api/content - List all content
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '10')
    const page = parseInt(searchParams.get('page') || '1')

    const filters = {
      status: status as 'draft' | 'published' | 'archived' | undefined,
    }

    const pagination = { limit, page }

    const result = await ContentService.find(filters, pagination)

    if (!result.success) {
      return NextResponse.json(
        { error: 'Failed to fetch content' },
        { status: 500 }
      )
    }

    return NextResponse.json(result.data)
  } catch (error) {
    console.error('GET /api/content error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch content' },
      { status: 500 }
    )
  }
}

// POST /api/content - Create new content
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate input
    const validatedData = contentSchema.parse(body)

    // Create new content item
    const result = await ContentService.create(validatedData)

    if (!result.success) {
      return NextResponse.json(
        { error: 'Failed to create content' },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { doc: result.data, message: 'Content created successfully' },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: 'Validation failed',
          details: error.format()
        },
        { status: 400 }
      )
    }

    console.error('POST /api/content error:', error)
    return NextResponse.json(
      { error: 'Failed to create content' },
      { status: 500 }
    )
  }
}
