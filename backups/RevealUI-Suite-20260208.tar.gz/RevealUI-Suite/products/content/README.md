# RevealUI Content

**Enterprise Headless CMS Framework**

A powerful, API-first content management system designed for modern web applications and digital experiences.

## ✨ Features

- **Headless Architecture** - API-first with flexible content delivery
- **Custom Content Types** - Define any content structure you need
- **Rich Text Editing** - Lexical-based WYSIWYG editor
- **Media Management** - File uploads, optimization, and CDN integration
- **Multi-tenant** - Single instance, multiple organizations
- **Access Control** - Granular permissions and user roles
- **API-first** - REST and GraphQL APIs
- **Real-time Collaboration** - Live editing and commenting

## 🚀 Quick Start

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build
```

## 📦 Packages

### Content Engine Packages
- **`@revealui/content`** - Main CMS package
- **`@revealui/content-admin`** - Admin interface
- **`@revealui/content-api`** - API layer
- **`@revealui/content-editor`** - Rich text editor

### Apps & Examples
- **`@revealui/content-studio`** - CMS admin interface
- **`@revealui/content-examples`** - Usage examples

## 🏗️ Architecture

### Content-First Design
```
src/
├── collections/      # Content type definitions
├── fields/          # Field types and validation
├── access/          # Permission system
├── hooks/           # Content lifecycle hooks
├── api/             # REST and GraphQL APIs
└── admin/           # Admin interface
```

### Collection Example
```typescript
import { CollectionConfig } from '@revealui/content'

export const BlogPost: CollectionConfig = {
  slug: 'blog-posts',
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
    },
    {
      name: 'content',
      type: 'richText',
      required: true,
    },
    {
      name: 'author',
      type: 'relationship',
      relationTo: 'users',
    },
    {
      name: 'publishedAt',
      type: 'date',
    },
  ],
  access: {
    read: () => true,  // Public read
    create: ({ req: { user } }) => user?.role === 'admin',
    update: ({ req: { user } }) => user?.role === 'admin',
  },
}
```

## 🎯 Use Cases

### ✅ Perfect For
- Content-heavy websites and applications
- Multi-channel content publishing
- Digital asset management
- Enterprise content workflows
- API-first architectures

### ❌ Not For
- Simple websites (use RevealUI Core)
- AI-powered features (use RevealUI MCP)

## 🔗 Integration

### With RevealUI Core
```typescript
import { Button, Card } from '@revealui/core'
import { useContent } from '@revealui/content'

// Use Core UI components with Content data
function BlogList() {
  const { posts } = useContent('blog-posts')

  return (
    <div className="grid gap-4">
      {posts.map(post => (
        <Card key={post.id}>
          <h2>{post.title}</h2>
          <p>{post.excerpt}</p>
          <Button>Read More</Button>
        </Card>
      ))}
    </div>
  )
}
```

### With RevealUI MCP
```typescript
import { useAI } from '@revealui/mcp'
import { useContent } from '@revealui/content'

// AI-powered content generation
function ContentGenerator() {
  const { generateContent } = useAI()
  const { createContent } = useContent('blog-posts')

  const handleGenerate = async () => {
    const content = await generateContent('Write a blog post about React 19')
    await createContent(content)
  }

  return <button onClick={handleGenerate}>Generate Content</button>
}
```

## 📚 Documentation

- [Getting Started](./docs/getting-started.md)
- [Collections](./docs/collections.md)
- [Fields](./docs/fields.md)
- [API Reference](./docs/api.md)
- [Admin Guide](./docs/admin.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests and documentation
5. Submit a pull request

## 📄 License

Apache 2.0
