// Simple in-memory content storage
// This will be replaced with a proper database later

export interface ContentItem {
  id: string
  title: string
  body: string
  excerpt?: string
  status: 'draft' | 'published' | 'archived'
  tags?: string[]
  author?: string
  createdAt: Date
  updatedAt: Date
}

// Initial sample content
export const initialContent: ContentItem[] = [
  {
    id: '1',
    title: 'Welcome to RevealUI CMS',
    body: 'This is the first piece of content in your CMS.',
    excerpt: 'Getting started with content management',
    status: 'published',
    tags: ['welcome', 'getting-started'],
    author: 'RevealUI Team',
    createdAt: new Date('2024-12-25T10:00:00Z'),
    updatedAt: new Date('2024-12-25T10:00:00Z'),
  },
  {
    id: '2',
    title: 'Content Management Best Practices',
    body: 'Learn about best practices for managing content in modern CMS systems.',
    excerpt: 'Professional content management techniques',
    status: 'draft',
    tags: ['best-practices', 'cms'],
    author: 'Content Team',
    createdAt: new Date('2024-12-25T11:00:00Z'),
    updatedAt: new Date('2024-12-25T11:00:00Z'),
  },
]

// In-memory storage
let contentStore: ContentItem[] = [...initialContent]

export function getContentStore(): ContentItem[] {
  return contentStore
}

export function addContentItem(item: Omit<ContentItem, 'id' | 'createdAt' | 'updatedAt'>): ContentItem {
  const newItem: ContentItem = {
    ...item,
    id: Date.now().toString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  contentStore.push(newItem)
  return newItem
}

export function updateContentItem(id: string, updates: Partial<Omit<ContentItem, 'id' | 'createdAt'>>): ContentItem | null {
  const index = contentStore.findIndex(item => item.id === id)
  if (index === -1) return null

  contentStore[index] = {
    ...contentStore[index],
    ...updates,
    updatedAt: new Date(),
  }

  return contentStore[index]
}

export function deleteContentItem(id: string): boolean {
  const index = contentStore.findIndex(item => item.id === id)
  if (index === -1) return false

  contentStore.splice(index, 1)
  return true
}

export function getContentItem(id: string): ContentItem | null {
  return contentStore.find(item => item.id === id) || null
}
