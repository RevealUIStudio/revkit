import { Result, ResultUtil, PaginationOptions, PaginatedResult } from '@revealui/foundation'
import { ContentItem, ContentFilters, CreateContentData, UpdateContentData } from '../types/content.js'

// In-memory storage - will be replaced with database later
let contentStore: ContentItem[] = [
  {
    id: '1',
    title: 'Welcome to RevealUI Content',
    body: 'This is the first piece of content in your CMS.',
    excerpt: 'Getting started with content management',
    status: 'published',
    tags: ['welcome', 'getting-started'],
    author: 'RevealUI Team',
    createdAt: new Date('2024-12-25T10:00:00Z'),
    updatedAt: new Date('2024-12-25T10:00:00Z'),
  },
  {
    id: '2',
    title: 'Content Management Best Practices',
    body: 'Learn about best practices for managing content in modern CMS systems.',
    excerpt: 'Professional content management techniques',
    status: 'draft',
    tags: ['best-practices', 'cms'],
    author: 'Content Team',
    createdAt: new Date('2024-12-25T11:00:00Z'),
    updatedAt: new Date('2024-12-25T11:00:00Z'),
  },
]

export class ContentService {
  static async find(
    filters: ContentFilters = {},
    pagination: PaginationOptions = {}
  ): Promise<Result<PaginatedResult<ContentItem>>> {
    try {
      let filteredContent = [...contentStore]

      // Apply filters
      if (filters.status) {
        filteredContent = filteredContent.filter(item => item.status === filters.status)
      }

      if (filters.author) {
        filteredContent = filteredContent.filter(item =>
          item.author?.toLowerCase().includes(filters.author!.toLowerCase())
        )
      }

      if (filters.tags?.length) {
        filteredContent = filteredContent.filter(item =>
          filters.tags!.some(tag => item.tags?.includes(tag))
        )
      }

      if (filters.search) {
        const searchLower = filters.search.toLowerCase()
        filteredContent = filteredContent.filter(item =>
          item.title.toLowerCase().includes(searchLower) ||
          item.body.toLowerCase().includes(searchLower) ||
          item.excerpt?.toLowerCase().includes(searchLower)
        )
      }

      // Sort by creation date (newest first)
      filteredContent.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

      // Pagination
      const limit = pagination.limit || 10
      const page = pagination.page || 1
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + limit
      const paginatedContent = filteredContent.slice(startIndex, endIndex)

      const result: PaginatedResult<ContentItem> = {
        docs: paginatedContent,
        totalDocs: filteredContent.length,
        limit,
        totalPages: Math.ceil(filteredContent.length / limit),
        page,
        hasPrevPage: page > 1,
        hasNextPage: endIndex < filteredContent.length,
        prevPage: page > 1 ? page - 1 : null,
        nextPage: endIndex < filteredContent.length ? page + 1 : null,
      }

      return ResultUtil.ok(result)
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }

  static async findById(id: string): Promise<Result<ContentItem | null>> {
    try {
      const item = contentStore.find(item => item.id === id) || null
      return ResultUtil.ok(item)
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }

  static async create(data: CreateContentData): Promise<Result<ContentItem>> {
    try {
      const newItem: ContentItem = {
        ...data,
        id: Date.now().toString(),
        status: data.status || 'draft',
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      contentStore.push(newItem)
      return ResultUtil.ok(newItem)
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }

  static async update(id: string, data: Partial<CreateContentData>): Promise<Result<ContentItem | null>> {
    try {
      const index = contentStore.findIndex(item => item.id === id)
      if (index === -1) {
        return ResultUtil.ok(null)
      }

      contentStore[index] = {
        ...contentStore[index],
        ...data,
        updatedAt: new Date(),
      }

      return ResultUtil.ok(contentStore[index])
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }

  static async delete(id: string): Promise<Result<boolean>> {
    try {
      const index = contentStore.findIndex(item => item.id === id)
      if (index === -1) {
        return ResultUtil.ok(false)
      }

      contentStore.splice(index, 1)
      return ResultUtil.ok(true)
    } catch (error) {
      return ResultUtil.err(error as Error)
    }
  }
}
