import { BaseEntity } from '@revealui/foundation'

export interface ContentItem extends BaseEntity {
  title: string
  body: string
  excerpt?: string
  status: 'draft' | 'published' | 'archived'
  tags?: string[]
  author?: string
}

export interface ContentFilters {
  status?: ContentItem['status']
  author?: string
  tags?: string[]
  search?: string
}

export interface ContentListResult {
  docs: ContentItem[]
  totalDocs: number
  limit: number
  totalPages: number
  page: number
  hasPrevPage: boolean
  hasNextPage: boolean
  prevPage: number | null
  nextPage: number | null
}

export interface CreateContentData {
  title: string
  body: string
  excerpt?: string
  status?: ContentItem['status']
  tags?: string[]
  author?: string
}

export interface UpdateContentData extends Partial<CreateContentData> {
  id: string
}
