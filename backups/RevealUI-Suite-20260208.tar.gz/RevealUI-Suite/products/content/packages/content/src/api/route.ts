import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { getContentStore, addContentItem } from '../content-store.js'

// Content validation schema
const contentSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200, 'Title too long'),
  body: z.string().min(1, 'Content is required'),
  excerpt: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).default('draft'),
  tags: z.array(z.string()).optional(),
  author: z.string().optional(),
})

// GET /api/content - List all content
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '10')
    const page = parseInt(searchParams.get('page') || '1')

    let contentStore = getContentStore()
    let filteredContent = contentStore

    // Filter by status if provided
    if (status) {
      filteredContent = filteredContent.filter(item => item.status === status)
    }

    // Sort by creation date (newest first)
    filteredContent.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedContent = filteredContent.slice(startIndex, endIndex)

    const response = {
      docs: paginatedContent,
      totalDocs: filteredContent.length,
      limit,
      totalPages: Math.ceil(filteredContent.length / limit),
      page,
      hasPrevPage: page > 1,
      hasNextPage: endIndex < filteredContent.length,
      prevPage: page > 1 ? page - 1 : null,
      nextPage: endIndex < filteredContent.length ? page + 1 : null,
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error('GET /api/content error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch content' },
      { status: 500 }
    )
  }
}

// POST /api/content - Create new content
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate input
    const validatedData = contentSchema.parse(body)

    // Create new content item
    const newContent = addContentItem(validatedData)

    return NextResponse.json(
      { doc: newContent, message: 'Content created successfully' },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: 'Validation failed',
          details: error.format()
        },
        { status: 400 }
      )
    }

    console.error('POST /api/content error:', error)
    return NextResponse.json(
      { error: 'Failed to create content' },
      { status: 500 }
    )
  }
}
