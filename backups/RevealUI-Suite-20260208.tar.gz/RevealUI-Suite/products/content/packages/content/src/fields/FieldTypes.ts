export type FieldType =
  | 'text'
  | 'textarea'
  | 'number'
  | 'boolean'
  | 'select'
  | 'date'
  | 'email'
  | 'url'

export interface BaseField {
  name: string
  type: FieldType
  label?: string
  required?: boolean
  defaultValue?: any
  description?: string
}

export interface TextField extends BaseField {
  type: 'text'
  minLength?: number
  maxLength?: number
}

export interface TextareaField extends BaseField {
  type: 'textarea'
  rows?: number
  minLength?: number
  maxLength?: number
}

export interface NumberField extends BaseField {
  type: 'number'
  min?: number
  max?: number
}

export interface BooleanField extends BaseField {
  type: 'boolean'
}

export interface SelectField extends BaseField {
  type: 'select'
  options: Array<{ label: string; value: string }>
}

export interface DateField extends BaseField {
  type: 'date'
}

export interface EmailField extends BaseField {
  type: 'email'
}

export interface UrlField extends BaseField {
  type: 'url'
}

export type Field =
  | TextField
  | TextareaField
  | NumberField
  | BooleanField
  | SelectField
  | DateField
  | EmailField
  | UrlField
