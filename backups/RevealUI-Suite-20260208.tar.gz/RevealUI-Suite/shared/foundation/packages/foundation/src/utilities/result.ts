import type { Result } from '../types/common'

/**
 * Result utility for functional error handling
 * Inspired by Rust's Result<T, E> type
 */
export class ResultUtil {
  static ok<T>(data: T): Result<T> {
    return { success: true, data }
  }

  static err<E>(error: E): Result<never, E> {
    return { success: false, error }
  }

  static from<T>(fn: () => T): Result<T> {
    try {
      return this.ok(fn())
    } catch (error) {
      return this.err(error as Error)
    }
  }

  static async fromAsync<T>(fn: () => Promise<T>): Promise<Result<T>> {
    try {
      const data = await fn()
      return this.ok(data)
    } catch (error) {
      return this.err(error as Error)
    }
  }
}

// Convenience functions
export const ok = ResultUtil.ok
export const err = ResultUtil.err
export const fromResult = ResultUtil.from
export const fromAsync = ResultUtil.fromAsync
