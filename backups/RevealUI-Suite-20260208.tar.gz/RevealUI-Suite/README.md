# RevealUI Suite

**Complete Development Platform - React + CMS + AI**

<div align="center">

![RevealUI Suite](https://img.shields.io/badge/RevealUI-Suite-blue?style=for-the-badge)
![React 19](https://img.shields.io/badge/React-19-61dafb?style=flat-square)
![Next.js 16](https://img.shields.io/badge/Next.js-16-000000?style=flat-square)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-3178c6?style=flat-square)

**🚀 [Live Suite Demo](http://localhost:3005) - All products working together**

</div>

---

## 🎯 What is RevealUI Suite?

RevealUI Suite is a **complete, integrated development platform** that combines three powerful products into a seamless developer experience:

### **Three Independent Products, One Unified Platform**

| Product | Purpose | Tech Stack | Status |
|---------|---------|------------|--------|
| **Core** | React Framework | React 19 + Next.js 16 | ✅ **Live** |
| **Content** | Headless CMS | API-first + Admin UI | ✅ **Live** |
| **MCP** | AI Platform | Model Context Protocol | ✅ **Live** |

---

## 🌟 Live Demos

### **Complete Suite Integration** 🚀
**http://localhost:3005** - Experience all three products working together

### **Individual Product Demos**
- **Core Framework**: http://localhost:3000 - Component showcase
- **Content CMS**: http://localhost:4001 - Content management
- **MCP Platform**: http://localhost:4003 - AI development tools

---

## 🏗️ Architecture Overview

```
RevealUI-Suite/
├── 🏗️ products/              # Independent products
│   ├── ⚛️ core/              # React/Next.js Framework
│   │   ├── packages/core/    # Framework package
│   │   └── apps/demo/        # Component showcase
│   ├── 📝 content/           # Enterprise CMS
│   │   ├── packages/content/ # CMS package
│   │   └── apps/cms-demo/    # Content management
│   └── 🤖 mcp/               # AI Platform
│       ├── packages/mcp/     # MCP implementation
│       └── apps/mcp-demo/    # AI tools
├── 🔧 shared/                # Cross-product utilities
│   └── 🏛️ foundation/        # Core utilities & types
└── 🎯 suite-demo/            # Integrated experience
```

### **Product Independence**
Each product operates independently but integrates seamlessly:
- **No tight coupling** - Products can be used separately
- **Shared foundation** - Common utilities and patterns
- **API integration** - RESTful communication between products

---

## 🚀 Quick Start

### **1. Install Everything**
```bash
pnpm install
```

### **2. Start All Products**
```bash
pnpm dev
```
This starts all four applications simultaneously!

### **3. Experience the Suite**
Visit **http://localhost:3005** to see all products working together

### **4. Individual Development**
```bash
# Core Framework
pnpm --filter @revealui/core dev

# Content CMS
pnpm --filter @revealui/content-demo dev

# MCP Platform
pnpm --filter @revealui/mcp-platform dev

# Suite Demo
pnpm --filter @revealui/suite-demo dev
```

---

## 🛠️ Product Details

### **⚛️ RevealUI Core - React Framework**
Modern React 19 + Next.js 16 framework with production-ready components.

**Features:**
- 🎨 50+ pre-built components with Tailwind CSS
- 🔧 Type-safe form system with validation
- 📡 API client with automatic retry logic
- 🎯 Component composition patterns
- 📱 Responsive design utilities

**Live Demo**: http://localhost:3000

### **📝 RevealUI Content - Headless CMS**
Enterprise-grade content management with API-first architecture.

**Features:**
- 📋 Custom content types and fields
- ✏️ Rich text editing (Lexical)
- 🖼️ Media management and CDN integration
- 🔐 Access control and permissions
- 🌐 REST & GraphQL APIs

**Live Demo**: http://localhost:4001

### **🤖 RevealUI MCP - AI Platform**
Model Context Protocol implementation with intelligent development tools.

**Features:**
- 🧠 Code review and analysis agents
- 🔍 Automated bug detection and fixes
- 💡 AI-powered refactoring suggestions
- 📊 Quality scoring (0-100 scale)
- 🔌 Plugin ecosystem for extensibility

**Live Demo**: http://localhost:4003

---

## 🔗 Integration Examples

### **Framework + CMS Integration**
```typescript
import { Button, Card } from '@revealui/core'
import { useContent } from '@revealui/content'

// Use Core components with Content data
function BlogList() {
  const { posts } = useContent('blog-posts')

  return (
    <div className="grid gap-4">
      {posts.map(post => (
        <Card key={post.id}>
          <h2>{post.title}</h2>
          <Button>Read More</Button>
        </Card>
      ))}
    </div>
  )
}
```

### **AI + Content Integration**
```typescript
import { useMCP } from '@revealui/mcp'
import { useContent } from '@revealui/content'

// AI-enhanced content creation
function SmartEditor() {
  const { analyzeContent } = useMCP()
  const { createContent } = useContent('articles')

  const handleSave = async (content) => {
    // AI analysis before publishing
    const analysis = await analyzeContent(content)
    if (analysis.score > 80) {
      await createContent(content)
    }
  }
}
```

---

## 📊 Technical Specifications

### **Performance**
- ⚡ **Sub-1s build times** with Turbo
- 📦 **Tree-shakable packages** for optimal bundles
- 🔄 **Hot reload** across all products
- 🧵 **Concurrent processing** with modern bundlers

### **Quality**
- 🎯 **TypeScript strict mode** throughout
- 🧪 **Comprehensive testing** setup
- 📏 **ESLint + Prettier** code quality
- 🔒 **Security-first** architecture

### **Compatibility**
- 🟢 **Node.js 22+** required
- 📦 **pnpm workspaces** for monorepo management
- 🏗️ **Modern ES modules** and tree-shaking
- 🌐 **Edge runtime** compatible

---

## 🎯 Use Cases

### **For Individual Developers**
- **Rapid prototyping** with Core components
- **Personal blogs/websites** with Content CMS
- **Code quality improvement** with MCP analysis

### **For Development Teams**
- **Design system** standardization with Core
- **Multi-channel content** management with Content
- **Code review automation** with MCP agents

### **For Enterprises**
- **Scalable applications** with Core framework
- **Multi-tenant CMS** with Content engine
- **AI-powered development** with MCP platform

---

## 🚢 Deployment & Production

### **Individual Product Deployment**
Each product can be deployed independently:
```bash
# Deploy Core Framework
pnpm --filter @revealui/core build
# Deploy to Vercel/Netlify

# Deploy Content CMS
pnpm --filter @revealui/content build
# Deploy to your preferred platform

# Deploy MCP Platform
pnpm --filter @revealui/mcp build
# Deploy with infrastructure requirements
```

### **Suite Deployment**
For organizations wanting the complete experience:
```bash
pnpm build  # Builds all products
# Deploy suite-demo as primary entry point
```

---

## 🤝 Contributing

### **Product-Specific Contributions**
Each product has its own contribution guidelines:
- [Core Framework](./products/core/README.md)
- [Content Engine](./products/content/README.md)
- [MCP Platform](./products/mcp/README.md)

### **Suite-Level Contributions**
For cross-product improvements:
1. **Foundation changes** affect all products
2. **Integration patterns** should be documented
3. **Testing** must cover all affected products

---

## 📈 Roadmap

### **Phase 4: Enterprise Features** (Next)
- 🔐 **Shared authentication** system
- 🗄️ **Database integrations** (PostgreSQL, MongoDB)
- 📊 **Analytics and monitoring**
- 🚀 **CI/CD pipelines**

### **Phase 5: Ecosystem Expansion**
- 🔌 **Plugin marketplace**
- 🌐 **Multi-language support**
- ☁️ **Cloud deployment templates**
- 🤝 **Third-party integrations**

---

## 📄 License & Support

**License**: Apache 2.0 - Open source and commercially friendly

**Support**: 
- 📚 [Documentation](./docs/)
- 🐛 [GitHub Issues](https://github.com/RevealUIStudio/reveal/issues)
- 💬 [Discord Community](https://discord.gg/revealui)

---

<div align="center">

**🎉 RevealUI Suite - The complete development platform for modern applications**

**[Start Building](http://localhost:3005) • [View Core Components](http://localhost:3000) • [Manage Content](http://localhost:4001) • [AI Development](http://localhost:4003)**

</div> - See individual product licenses
